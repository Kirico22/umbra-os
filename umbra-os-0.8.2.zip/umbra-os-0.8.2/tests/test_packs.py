import re
from pathlib import Path

import pytest

from umbra import packs
from umbra.nyx.rules import match

HELPER = Path(__file__).resolve().parents[1] / "iso/config/includes.chroot/usr/libexec/umbra/instalar-pack"


def test_helper_lists_match_python():
    text = HELPER.read_text()
    found = dict(re.findall(r'^\t(\w+)\) pkgs="([^"]+)"', text, re.M))
    assert found.keys() == packs.PACKS.keys()
    for pid, pack in packs.PACKS.items():
        assert tuple(found[pid].split()) == pack.apt


def test_helper_rejects_unknown_and_has_no_user_input_in_apt():
    text = HELPER.read_text()
    assert 'exit 2' in text and '"$1"' not in text.split("esac", 1)[1]


def test_flatpak_ids_look_valid():
    for pack in packs.PACKS.values():
        for app in pack.flatpak:
            assert re.fullmatch(r"[a-z0-9]+(\.[A-Za-z0-9_\-]+){2,}", app), app


def test_check_pack():
    packs.check_pack("gaming")
    with pytest.raises(ValueError):
        packs.check_pack("gaming; rm -rf /")


@pytest.mark.parametrize("frase, pack", [("instala el pack de gaming", "gaming"),
                                         ("ponme el pack de juegos", "gaming"),
                                         ("instala el pack creativo", "creativo"),
                                         ("quiero el pack de programación", "programacion")])
def test_pack_rules(frase, pack):
    call = match(frase).calls[0]
    assert call.action_id == "packages.pack" and call.args == {"name": pack}


def test_pack_install_is_high_risk_and_needs_permission(broker):
    from umbra.security import ToolCall

    res = broker.execute(ToolCall("packages.pack", {"name": "gaming"}))
    assert res.status == "denied"  # sin package.install en la política por defecto
    assert broker.execute(ToolCall("packages.packs", {})).ok
