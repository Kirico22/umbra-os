# ISO de UMBRA OS (Debian 13 "trixie")

La ISO se construye con `live-build` dentro de un contenedor Debian 13, normalmente
en GitHub Actions (`.github/workflows/iso.yml`).

## Qué lleva

| Parte | Detalle |
|---|---|
| Base | Debian 13 "trixie", amd64, ISO híbrida (USB y DVD, BIOS y UEFI) |
| Escritorio | XFCE con tema Arc-Dark, panel inferior de cristal tipo dock, iconos Papirus-Dark con carpetas violeta, iconos propios de UMBRA y 5 fondos |
| Fondo | Átomo de partículas (6 colores en `fondos/`); `umbra-atomo` lo anima encima usando `fondos-base/` |
| Puntero | UMBRA por defecto (`x-cursor-theme`); también UMBRA-Claro, Breeze, DMZ y Adwaita |
| Orbe de NYX | `nyx-orbe` arranca con la sesión: esfera flotante, arrastrable, clic para hablarle |
| Buscador | `umbra-buscar` con Súper + Espacio (atajo creado en el primer inicio) |
| Ajustes | `umbra-ajustes`; se abre como bienvenida en el primer inicio |
| Navegadores | Chromium incluido; repositorios oficiales de Opera GX y Google Chrome configurados (sus claves se descargan al construir) |
| Inicio de sesión | LightDM con fondo y tema de UMBRA |
| Arranque y apagado | Tema Plymouth `umbra`: intro de partículas (177 fotogramas: dispersión → esfera → «UMBRA» → esfera con nombre) y bucle de 50; al apagar, solo el bucle. Carga los fotogramas uno a uno (poca memoria) |
| Animaciones y cristal | picom 12: abrir/cerrar/minimizar/mover animados, sombras, esquinas y desenfoque (Liquid Glass); configurable por usuario |
| NYX | `/opt/umbra/venv` (ruedas incluidas, sin descargas); `nyx` (terminal) y `nyx-gui` (esfera de partículas) |
| Voz de NYX | Piper + voz `es_ES-sharvard-medium` (hablante femenina) en `/usr/share/umbra/voices`; respaldo espeak-ng |
| Instalador | Calamares (gráfico) |
| Sesión en vivo | usuario `umbra`, contraseña `live`, teclado y idioma en español |

## Construir a mano (en Debian 13, como root)

```bash
pip wheel .. --no-deps -w config/includes.chroot/opt/umbra/dist
apt-get install live-build
lb clean && lb config && lb build
```

## Regenerar recursos gráficos

```bash
for c in "morado #a76eff" "azul #5aa9ff" "rosa #ff6eb4" "verde #3fd99a" "ambar #ffb347" "nebulosa #56e6ff"; do
  set -- $c
  PYTHONPATH=../src python3 tools/make_wallpaper.py config/includes.chroot/usr/share/umbra/fondos/umbra-$1.png 1920 1080 "$2"
  PYTHONPATH=../src python3 tools/make_wallpaper.py config/includes.chroot/usr/share/umbra/fondos-base/umbra-$1.png 1920 1080 "$2" --sin-atomo
done
PYTHONPATH=../src python3 tools/make_icons.py config/includes.chroot/usr/share/icons/hicolor
PYTHONPATH=../src python3 tools/make_cursors.py config/includes.chroot/usr/share/icons   # necesita xcursorgen
# Los fondos (con y sin átomo) se generan con PYTHONPATH=../src y la opción --sin-atomo
PYTHONPATH=../src python3 tools/make_plymouth.py config/includes.chroot/usr/share/plymouth/themes/umbra preview.gif
```

## Comprobar en el primer arranque real

- Que el fondo de UMBRA aparece en XFCE (los nombres de monitor varían según el equipo).
- Que picom arranca (`pgrep picom`) y se ven las animaciones.
- Que en el sistema ya instalado aparece la animación de arranque (necesita `splash` en GRUB).
- Que la voz suena (Piper) y la esfera se mueve con ella.
- Que el desenfoque de picom (backend glx) va fluido en VirtualBox; si no, «Ajustes → Efecto cristal: Apagado».
- Que «Instalar Opera GX / Chrome» funciona con conexión a internet.
- Que el átomo vivo queda alineado con el fondo en la resolución de la VM (y debajo de las ventanas).
