"""Fondo de la pantalla de inicio de sesión: la esfera de NYX sobre el fondo de UMBRA.

uso: python3 iso/tools/make_login.py [salida.png]
"""

import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))
from umbra.sphere import ParticleSphere  # noqa: E402

ROOT = Path(__file__).resolve().parents[1] / "config/includes.chroot/usr/share/umbra"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "login.png"
BASE = ROOT / "fondos-base/umbra-morado.png"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
ACCENT = (167, 110, 255)
LIGHT = (221, 200, 255)


def main() -> None:
    img = Image.open(BASE).convert("RGBA")
    W, H = img.size
    cx, cy, r = W * 0.62, H * 0.45, H * 0.17  # sobre el brillo del fondo; el acceso va a la izquierda

    halo = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    hd = ImageDraw.Draw(halo)
    for i in range(30, 0, -1):
        rr = r * (1 + i * 0.06)
        hd.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=(*ACCENT, int(5 + (30 - i) * 0.6)))
    img.alpha_composite(halo.filter(ImageFilter.GaussianBlur(H * 0.03)))

    sphere = ParticleSphere(n=900, seed=11)
    for _ in range(40):
        sphere.update(1 / 30)
    dots = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dd = ImageDraw.Draw(dots)
    for p in sphere.project(cx, cy, r):
        s = max(1.2, p.size * H / 900)
        k = 0.2 + 0.8 * (p.depth + 1) / 2
        col = tuple(int(a * (1 - k) + b * k) for a, b in zip(ACCENT, LIGHT, strict=True))
        dd.ellipse([p.x - s, p.y - s, p.x + s, p.y + s], fill=(*col, int(255 * p.alpha)))
    glow = dots.filter(ImageFilter.GaussianBlur(2))
    img.alpha_composite(glow)
    img.alpha_composite(dots)

    d = ImageDraw.Draw(img)
    small = ImageFont.truetype(FONT, int(H * 0.019))
    sub = "Hola de nuevo. NYX te estaba esperando."
    sw = d.textlength(sub, font=small)
    d.text((cx - sw / 2, cy + r * 1.35), sub, font=small, fill=(*LIGHT, 210))
    img.convert("RGB").save(OUT, optimize=True)
    print(OUT, img.size, f"{OUT.stat().st_size // 1024} KB", math.floor(r))


if __name__ == "__main__":
    main()
