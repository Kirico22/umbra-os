"""Genera la animación de arranque de UMBRA (Plymouth) y una vista previa en GIF.

uso: PYTHONPATH=src python3 iso/tools/make_plymouth.py <carpeta_tema> [preview.gif]

Secuencia (a 25 fotogramas por segundo):
  1. Las partículas llegan dispersas y forman la esfera de NYX.
  2. La esfera gira.
  3. Las partículas se deshacen y escriben «UMBRA».
  4. Vuelven a la esfera, más pequeña y arriba, mientras el nombre aparece nítido debajo.
  5. Bucle final: la esfera gira con el nombre debajo.
Los fotogramas de la intro se llaman intro-N.png y los del bucle loop-N.png.
"""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from umbra.sphere import ParticleSphere

W, H = 560, 360
N = 640
FPS = 25
GATHER, SPIN, TO_TEXT, HOLD, TO_SPHERE = 50, 25, 40, 22, 40
LOOP = 50
BIG_R, SMALL_R = 105, 62
BIG_C = (W / 2, H / 2)
SMALL_C = (W / 2, 128)
TEXT_Y = 268
LIGHT = (222, 200, 255)
PURPLE = (167, 110, 255)
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_LIGHT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-ExtraLight.ttf"
FONT_SMALL = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def ease(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


def ease_out(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def text_targets(n: int) -> list[tuple[float, float]]:
    """n puntos repartidos sobre las letras de UMBRA."""
    font = ImageFont.truetype(FONT_BOLD, 92)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).text((W / 2, H / 2), "U M B R A", font=font, fill=255, anchor="mm")
    px = mask.load()
    pts = [(x, y) for y in range(0, H, 2) for x in range(0, W, 2) if px[x, y] > 128]
    rnd = random.Random(3)
    rnd.shuffle(pts)
    pts = pts[:n] if len(pts) >= n else (pts * (n // len(pts) + 1))[:n]
    return [(x + rnd.uniform(-0.8, 0.8), y + rnd.uniform(-0.8, 0.8)) for x, y in pts]


def by_x(items: list, key) -> list[int]:
    return [i for i, _ in sorted(enumerate(items), key=lambda e: key(e[1]))]


def render(points, glow_strength: float, logo_alpha: float, logo: Image.Image) -> Image.Image:
    """points: (x, y, tamaño, alpha 0..1, mezcla de color 0..1)."""
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if glow_strength > 0:
        halo = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        hd = ImageDraw.Draw(halo)
        for x, y, size, a, _k in points[::3]:
            r = size * 5
            hd.ellipse([x - r, y - r, x + r, y + r], fill=(*PURPLE, int(28 * a * glow_strength)))
        img = Image.alpha_composite(img, halo.filter(ImageFilter.GaussianBlur(9)))
    d = ImageDraw.Draw(img)
    for x, y, size, a, k in points:
        col = tuple(int(PURPLE[c] + (LIGHT[c] - PURPLE[c]) * k) for c in range(3))
        r = 0.6 + size
        d.ellipse([x - r, y - r, x + r, y + r], fill=(*col, int(255 * a)))
    if logo_alpha > 0:
        lg = logo.copy()
        lg.putalpha(lg.getchannel("A").point(lambda v: int(v * logo_alpha)))
        img.alpha_composite(lg, (int(W / 2 - lg.width / 2), int(TEXT_Y - lg.height / 2)))
    return img


def sphere_points(sph: ParticleSphere, center, radius) -> list:
    return sph.project(center[0], center[1], radius, sort=False)


def main() -> None:
    theme = Path(sys.argv[1])
    theme.mkdir(parents=True, exist_ok=True)
    rnd = random.Random(11)
    sph = ParticleSphere(n=N, seed=5)
    dt = 1 / FPS
    targets = text_targets(N)

    logo = Image.new("RGBA", (420, 60), (0, 0, 0, 0))
    ImageDraw.Draw(logo).text((210, 30), "U M B R A", font=ImageFont.truetype(FONT_LIGHT, 40),
                              fill=(238, 230, 255, 255), anchor="mm")

    # Posiciones de partida dispersas (fuera del centro)
    scatter = []
    for _ in range(N):
        ang, dist = rnd.uniform(0, math.tau), rnd.uniform(220, 420)
        scatter.append((BIG_C[0] + math.cos(ang) * dist, BIG_C[1] + math.sin(ang) * dist * 0.7))
    delay = [rnd.uniform(0, 0.35) for _ in range(N)]

    frames: list[Image.Image] = []

    def frame_from(pos_fn, glow, logo_alpha=0.0):
        pts = []
        for i in range(N):
            x, y, size, a, k = pos_fn(i)
            pts.append((x, y, size, a, k))
        pts.sort(key=lambda p: p[4])  # los más claros (delante) se pintan al final
        frames.append(render(pts, glow, logo_alpha, logo))

    # 1. Reunión: de dispersas a esfera
    for f in range(GATHER):
        sph.update(dt)
        sp = sphere_points(sph, BIG_C, BIG_R)
        t = f / (GATHER - 1)

        def pos(i, sp=sp, t=t):
            p = sp[i]
            e = ease_out((t - delay[i]) / (1 - 0.35))
            k = (p.depth + 1) / 2
            return (scatter[i][0] + (p.x - scatter[i][0]) * e, scatter[i][1] + (p.y - scatter[i][1]) * e,
                    p.size * 0.9, p.alpha * (0.2 + 0.8 * e), k)
        frame_from(pos, glow=t)

    # 2. Giro
    for _ in range(SPIN):
        sph.update(dt)
        sp = sphere_points(sph, BIG_C, BIG_R)
        frame_from(lambda i, sp=sp: (sp[i].x, sp[i].y, sp[i].size * 0.9, sp[i].alpha, (sp[i].depth + 1) / 2), 1.0)

    # 3. De esfera a texto (asignación de izquierda a derecha para que fluya)
    sp0 = sphere_points(sph, BIG_C, BIG_R)
    order_s = by_x(sp0, lambda p: p.x)
    order_t = by_x(targets, lambda p: p[0])
    target_of = {s: targets[t] for s, t in zip(order_s, order_t, strict=True)}
    stagger = {s: 0.3 * rank / N for rank, s in enumerate(order_s)}
    for f in range(TO_TEXT):
        sph.update(dt)
        sp = sphere_points(sph, BIG_C, BIG_R)
        t = f / (TO_TEXT - 1)

        def pos(i, sp=sp, t=t):
            e = ease((t - stagger[i]) / 0.7)
            tx, ty = target_of[i]
            lift = math.sin(e * math.pi) * 18  # pequeño arco en el vuelo
            k = (sp[i].depth + 1) / 2 * (1 - e) + e
            return (sp[i].x + (tx - sp[i].x) * e, sp[i].y + (ty - sp[i].y) * e - lift,
                    sp[i].size * 0.9 * (1 - e) + 0.75 * e, sp[i].alpha * (1 - e) + e, k)
        frame_from(pos, glow=1.0 - 0.4 * t)

    # 4. El nombre brilla un momento
    for f in range(HOLD):
        t = f / (HOLD - 1)

        def pos(i, t=t):
            tx, ty = target_of[i]
            shimmer = 0.75 + 0.25 * math.sin(t * math.pi * 2 + tx * 0.05)
            return (tx, ty, 0.75, shimmer, 1.0)
        frame_from(pos, glow=0.6)

    # 5. Del nombre a la esfera pequeña de arriba; el nombre nítido aparece debajo
    for f in range(TO_SPHERE):
        sph.update(dt)
        sp = sphere_points(sph, SMALL_C, SMALL_R)
        t = f / (TO_SPHERE - 1)

        def pos(i, sp=sp, t=t):
            e = ease((t - (1 - stagger[i] / 0.3) * 0.3) / 0.7)
            tx, ty = target_of[i]
            k = (sp[i].depth + 1) / 2 * e + (1 - e)
            return (tx + (sp[i].x - tx) * e, ty + (sp[i].y - ty) * e,
                    0.75 * (1 - e) + sp[i].size * 0.75 * e, (1 - e) + sp[i].alpha * e, k)
        frame_from(pos, glow=0.6 + 0.4 * t, logo_alpha=ease((t - 0.35) / 0.65))

    intro = frames[:]
    frames.clear()

    # Bucle final: esfera pequeña girando con el nombre (vuelta completa = bucle sin saltos)
    loop_sph = ParticleSphere(n=N, seed=5)
    loop_sph.angle_y = sph.angle_y
    for f in range(LOOP):
        loop_sph.angle_y = sph.angle_y + math.tau * f / LOOP / 2  # media vuelta: la esfera es simétrica
        loop_sph.t = f / LOOP * (math.tau / 1.6)  # respiración: un ciclo completo por bucle
        sp = sphere_points(loop_sph, SMALL_C, SMALL_R)
        frame_from(lambda i, sp=sp: (sp[i].x, sp[i].y, sp[i].size * 0.75, sp[i].alpha, (sp[i].depth + 1) / 2),
                   1.0, logo_alpha=1.0)
    loop = frames[:]

    def save(img: Image.Image, path: Path) -> None:
        # PNG con paleta de 64 colores y transparencia: ~4 veces más pequeño (va en el initramfs)
        img.quantize(colors=64, method=Image.Quantize.FASTOCTREE).save(path, optimize=True)

    for i, img in enumerate(intro):
        save(img, theme / f"intro-{i}.png")
    for i, img in enumerate(loop):
        save(img, theme / f"loop-{i}.png")

    dot = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
    ImageDraw.Draw(dot).ellipse([1, 1, 11, 11], fill=(*LIGHT, 255))
    dot.save(theme / "bullet.png")

    if len(sys.argv) > 2:
        small = ImageFont.truetype(FONT_SMALL, 13)
        gif = []
        seq = intro + loop * 2
        for i, f in enumerate(seq):
            bg = Image.new("RGBA", (W, H + 40), (6, 3, 12, 255))
            bg.alpha_composite(f, (0, 0))
            if i >= len(intro):
                dots = "." * (1 + (i // 12) % 3)
                ImageDraw.Draw(bg).text((W / 2, H + 8), f"Iniciando UMBRA OS{dots}", font=small,
                                        fill=(156, 134, 201, 255), anchor="mm")
            gif.append(bg.convert("RGB").convert("P", palette=Image.ADAPTIVE, colors=96))
        gif[0].save(sys.argv[2], save_all=True, append_images=gif[1:], duration=int(1000 / FPS), loop=0, optimize=True)
    print(f"intro: {len(intro)} fotogramas, bucle: {len(loop)} fotogramas en {theme}")


if __name__ == "__main__":
    main()
