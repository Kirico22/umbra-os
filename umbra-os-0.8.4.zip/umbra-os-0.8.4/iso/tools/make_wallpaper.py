"""Fondo de UMBRA OS: un átomo hecho de partículas.

Cada protón, neutrón y electrón es una bolita de partículas (la misma esfera que NYX).
El núcleo es un racimo de protones (color de acento) y neutrones (lila plateado);
tres órbitas inclinadas, dibujadas como estelas de partículas, llevan un electrón cada una.

Uso: PYTHONPATH=src python3 make_wallpaper.py salida.png [ancho alto] [color_hex] [--sin-atomo]
Con --sin-atomo genera solo el fondo (degradado, estrellas y nombre): debajo de él se dibuja
el átomo vivo del escritorio (umbra-atomo).
"""

from __future__ import annotations

import colorsys
import math
import random
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from umbra.sphere import ParticleSphere, fibonacci_sphere

NO_ATOM = "--sin-atomo" in sys.argv
sys.argv = [a for a in sys.argv if a != "--sin-atomo"]
out = sys.argv[1]
W, H = (int(sys.argv[2]), int(sys.argv[3])) if len(sys.argv) > 3 else (1920, 1080)
ACCENT = sys.argv[4] if len(sys.argv) > 4 else "#a76eff"
AR, AG, AB = (int(ACCENT.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
_h, _s, _v = colorsys.rgb_to_hsv(AR / 255, AG / 255, AB / 255)
GLOW = tuple(int(c * 255) for c in colorsys.hsv_to_rgb(_h, min(1.0, _s * 1.25), 0.52))
PROTON = (AR, AG, AB)
NEUTRON = (196, 188, 222)  # lila plateado: contrasta con cualquier acento
ELECTRON = tuple(min(255, int(c + (255 - c) * 0.55)) for c in PROTON)
FONT_LIGHT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-ExtraLight.ttf"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

SCALE = H / 1080
CX, CY = W * 0.62, H * 0.45
ORBIT_A, ORBIT_B = 430 * SCALE, 128 * SCALE
ORBIT_ANGLES = (math.radians(-28), math.radians(32), math.radians(92))
ELECTRON_T = (0.35, 2.4, 4.3)  # posición de cada electrón en su órbita (radianes)
rnd = random.Random(7)


def ball(img: Image.Image, cx: float, cy: float, radius: float, color, seed: int, n: int, spin: float,
         alpha: float = 1.0) -> None:
    """Dibuja una bolita de partículas (esfera 3D) con un halo suave."""
    halo = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(halo).ellipse([cx - radius * 1.5, cy - radius * 1.5, cx + radius * 1.5, cy + radius * 1.5],
                                 fill=(*color, int(55 * alpha)))
    img.alpha_composite(halo.filter(ImageFilter.GaussianBlur(radius * 0.7)))
    sph = ParticleSphere(n=n, seed=seed)
    sph.angle_y = spin
    # Cuerpo oscuro translúcido con borde difuminado: tapa lo de detrás y separa cada bolita
    body = radius * 1.02
    shade = Image.new("RGBA", img.size, (0, 0, 0, 0))
    dark = tuple(int(c * 0.16) for c in color)
    ImageDraw.Draw(shade).ellipse([cx - body, cy - body, cx + body, cy + body], fill=(*dark, int(165 * alpha)))
    img.alpha_composite(shade.filter(ImageFilter.GaussianBlur(max(1.5, radius * 0.18))))
    d = ImageDraw.Draw(img)
    for p in sph.project(cx, cy, radius / 1.3 * 1.7):
        k = (p.depth + 1) / 2
        col = tuple(int(color[c] + (255 - color[c]) * 0.45 * k) for c in range(3))
        r = max(0.7, (0.35 + 0.55 * p.size) * radius / 22)
        d.ellipse([p.x - r, p.y - r, p.x + r, p.y + r], fill=(*col, int(255 * p.alpha * alpha)))


def orbit_point(i: int, t: float) -> tuple[float, float, float]:
    """Punto de la órbita i: (x, y, profundidad). Profundidad > 0: delante del núcleo."""
    x, y = ORBIT_A * math.cos(t), ORBIT_B * math.sin(t)
    a = ORBIT_ANGLES[i]
    return CX + x * math.cos(a) - y * math.sin(a), CY + x * math.sin(a) + y * math.cos(a), math.sin(t)


def orbits(img: Image.Image, front: bool) -> None:
    """Estelas de partículas de las órbitas (la mitad trasera o la delantera)."""
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i in range(3):
        for k in range(900):
            t = k / 900 * math.tau
            x, y, z = orbit_point(i, t)
            if (z >= 0) != front:
                continue
            jitter = rnd.uniform(-2.2, 2.2) * SCALE
            # La estela se intensifica justo detrás de cada electrón
            lag = (ELECTRON_T[i] - t) % math.tau
            trail = max(0.0, 1 - lag / 2.2)
            a = int((22 + 55 * (z + 1) / 2) * (0.55 + 1.2 * trail))
            r = (0.7 + 0.9 * trail) * SCALE
            d.ellipse([x - r, y + jitter - r, x + r, y + jitter + r], fill=(*ELECTRON, min(255, a)))
    img.alpha_composite(layer)


def electrons(img: Image.Image, front: bool) -> None:
    for i, t in enumerate(ELECTRON_T):
        x, y, z = orbit_point(i, t)
        if (z >= 0) == front:
            ball(img, x, y, (15 + 3 * z) * SCALE, ELECTRON, seed=40 + i, n=70, spin=t)


def nucleus(img: Image.Image) -> None:
    """Racimo compacto de 14 nucleones (7 protones, 7 neutrones), pintados de atrás adelante."""
    pts = fibonacci_sphere(14)
    tilt = 0.5
    placed = []
    for idx, (x, y, z) in enumerate(pts):
        # gira el racimo para que no se vea ordenado
        x, z = x * math.cos(tilt) + z * math.sin(tilt), -x * math.sin(tilt) + z * math.cos(tilt)
        placed.append((z, CX + x * 60 * SCALE, CY + y * 60 * SCALE, idx))
    placed.sort()
    for z, x, y, idx in placed:
        color = PROTON if idx % 2 == 0 else NEUTRON
        ball(img, x, y, (23 + 4 * z) * SCALE, color, seed=idx, n=95, spin=idx * 0.7, alpha=0.75 + 0.25 * (z + 1) / 2)


def main() -> None:
    img = Image.new("RGB", (W, H), (5, 3, 10))
    px = img.load()
    maxd = math.hypot(W, H)
    for y in range(H):
        for x in range(W):
            dd = math.hypot(x - CX, (y - CY) * 1.25) / maxd
            g = max(0.0, 1 - dd * 2.3) ** 2.4
            px[x, y] = (int(5 + GLOW[0] * g * 0.8), int(3 + GLOW[1] * g * 0.8), int(10 + GLOW[2] * g * 0.8))
    img = img.convert("RGBA")

    stars = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(stars)
    for _ in range(int(320 * SCALE * SCALE)):
        x, y, s = rnd.uniform(0, W), rnd.uniform(0, H), rnd.choice((1, 1, 1, 2))
        sd.ellipse([x, y, x + s, y + s], fill=(*ELECTRON, rnd.randint(20, 90)))
    img.alpha_composite(stars)

    if not NO_ATOM:
        # Orden de pintado: detrás -> núcleo -> delante (sensación de 3D)
        orbits(img, front=False)
        electrons(img, front=False)
        nucleus(img)
        orbits(img, front=True)
        electrons(img, front=True)

    d = ImageDraw.Draw(img)
    big = ImageFont.truetype(FONT_LIGHT, int(H * 0.075))
    small = ImageFont.truetype(FONT, int(H * 0.018))
    d.text((W * 0.08, H * 0.74), "U M B R A", font=big, fill=(235, 225, 255, 235))
    d.text((W * 0.082, H * 0.74 + H * 0.095), "OS  ·  NYX", font=small, fill=(*PROTON, 220))
    img.convert("RGB").save(out, optimize=True)
    print(out, img.size)


if __name__ == "__main__":
    main()
