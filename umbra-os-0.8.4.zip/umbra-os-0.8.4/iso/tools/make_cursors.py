"""Punteros de ratón propios de UMBRA: «UMBRA» (oscuro) y «UMBRA-Claro».

Flecha con borde del color de acento y un brillo suave; mano para enlaces; cursor de texto;
y espera animada: una esfera de partículas que gira (la esfera de NYX en pequeño).

uso: PYTHONPATH=src python3 iso/tools/make_cursors.py <carpeta icons>   (necesita xcursorgen)
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

from umbra.sphere import ParticleSphere

SIZES = (24, 32, 48, 64)
SS = 4  # supermuestreo para bordes suaves
ACCENT = (167, 110, 255)
THEMES = {
    "UMBRA": {"fill": (18, 10, 30), "edge": (222, 205, 255), "glow": ACCENT, "comment": "Oscuro con borde lila"},
    "UMBRA-Claro": {"fill": (250, 248, 255), "edge": (40, 22, 70), "glow": ACCENT, "comment": "Claro con borde oscuro"},
}
ALIASES = {
    "left_ptr": ["default", "arrow", "top_left_arrow", "left_arrow"],
    "hand2": ["pointer", "hand1", "hand", "pointing_hand"],
    "xterm": ["text", "ibeam"],
    "watch": ["wait"],
    "left_ptr_watch": ["progress", "half-busy"],
}

ARROW = [(2, 1), (2, 23.5), (7.5, 18.3), (11.4, 27.4), (15.2, 25.8), (11.4, 16.9), (18.6, 16.9)]
HAND = [(10, 2), (13, 2), (14, 4), (14, 12), (16, 11), (18, 12), (18, 13.5), (20, 13), (22, 14.5),
        (22, 15.5), (24, 15.5), (25.5, 17), (25.5, 23), (23, 28.5), (13, 28.5), (8, 22), (6, 17.5),
        (6.8, 15.7), (9, 16.5), (9, 4)]


def _poly(points, size, base=32):
    k = size * SS / base
    return [(x * k, y * k) for x, y in points]


def _shape(points, size, style) -> Image.Image:
    big = size * SS
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    glow = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    ImageDraw.Draw(glow).polygon(_poly(points, size), fill=(*style["glow"], 150))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(big / 22)))
    d = ImageDraw.Draw(img)
    d.polygon(_poly(points, size), fill=(*style["fill"], 255), outline=(*style["edge"], 255),
              width=max(SS, int(SS * size / 24 * 1.4)))
    return img.resize((size, size), Image.LANCZOS)


def ibeam(size, style) -> Image.Image:
    big = size * SS
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    k = big / 32
    w = max(SS * 2, int(2.6 * k))
    for col, extra in ((style["edge"], w), (style["fill"], 0)):
        lw = w + extra
        d.line([(16 * k, 6 * k), (16 * k, 26 * k)], fill=(*col, 255), width=lw)
        d.line([(11 * k, 5 * k), (21 * k, 5 * k)], fill=(*col, 255), width=lw)
        d.line([(11 * k, 27 * k), (21 * k, 27 * k)], fill=(*col, 255), width=lw)
    return img.resize((size, size), Image.LANCZOS)


def spinner(size, style, frame, frames, small=False) -> Image.Image:
    """Esfera de partículas girando (cursor de espera)."""
    big = size * SS
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    sph = ParticleSphere(n=70 if not small else 45, seed=5)
    sph.angle_y = frame / frames * 3.14159 * 2 / 2  # media vuelta por ciclo: la esfera es simétrica
    if small:
        cx, cy, r = big * 0.72, big * 0.72, big * 0.17
    else:
        cx, cy, r = big / 2, big / 2, big * 0.30
    d = ImageDraw.Draw(img)
    halo = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    ImageDraw.Draw(halo).ellipse([cx - r * 1.4, cy - r * 1.4, cx + r * 1.4, cy + r * 1.4], fill=(*style["glow"], 90))
    img.alpha_composite(halo.filter(ImageFilter.GaussianBlur(r * 0.5)))
    d = ImageDraw.Draw(img)
    for p in sph.project(cx, cy, r):
        k = (p.depth + 1) / 2
        col = tuple(int(ACCENT[c] + (255 - ACCENT[c]) * 0.7 * k) for c in range(3))
        dot = max(SS * 0.8, r / 9) * (0.6 + 0.5 * p.size)
        d.ellipse([p.x - dot, p.y - dot, p.x + dot, p.y + dot], fill=(*col, int(255 * p.alpha)))
    return img.resize((size, size), Image.LANCZOS)


def build_theme(name: str, style: dict, icons_dir: Path) -> None:
    theme_dir = icons_dir / name
    cursors = theme_dir / "cursors"
    cursors.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        specs: dict[str, list[str]] = {}
        frames = 12
        for size in SIZES:
            s = size / 32
            items = {
                "left_ptr": [(_shape(ARROW, size, style), 2 * s, 1 * s, None)],
                "hand2": [(_shape(HAND, size, style), 11.5 * s, 2 * s, None)],
                "xterm": [(ibeam(size, style), 16 * s, 16 * s, None)],
                "watch": [(spinner(size, style, f, frames), size / 2, size / 2, 70) for f in range(frames)],
                "left_ptr_watch": [],
            }
            arrow = _shape(ARROW, size, style)
            for f in range(frames):
                img = arrow.copy()
                img.alpha_composite(spinner(size, style, f, frames, small=True))
                items["left_ptr_watch"].append((img, 2 * s, 1 * s, 70))
            for cname, frames_list in items.items():
                for i, (img, hx, hy, ms) in enumerate(frames_list):
                    png = tmp / f"{cname}-{size}-{i}.png"
                    img.save(png)
                    line = f"{size} {int(round(hx))} {int(round(hy))} {png}" + (f" {ms}" if ms else "")
                    specs.setdefault(cname, []).append(line)
        for cname, lines in specs.items():
            cfg = tmp / f"{cname}.cfg"
            cfg.write_text("\n".join(lines) + "\n")
            subprocess.run(["xcursorgen", str(cfg), str(cursors / cname)], check=True)
        for target, aliases in ALIASES.items():
            for alias in aliases:
                link = cursors / alias
                if link.exists() or link.is_symlink():
                    link.unlink()
                link.symlink_to(target)
        # vista previa para Ajustes de UMBRA
        prev = Image.new("RGBA", (200, 56), (0, 0, 0, 0))
        prev.alpha_composite(_shape(ARROW, 48, style), (4, 4))
        prev.alpha_composite(_shape(HAND, 48, style), (54, 4))
        prev.alpha_composite(ibeam(48, style), (100, 4))
        prev.alpha_composite(spinner(48, style, 2, frames), (146, 4))
        prev.save(theme_dir / "preview.png")
    (theme_dir / "index.theme").write_text(
        f"[Icon Theme]\nName={name}\nComment=Punteros de UMBRA OS: {style['comment']}\nInherits=Adwaita\n")
    (theme_dir / "cursor.theme").write_text(f"[Icon Theme]\nInherits={name}\n")


def main() -> None:
    icons = Path(sys.argv[1])
    for name, style in THEMES.items():
        build_theme(name, style, icons)
        print("tema de punteros:", name)


if __name__ == "__main__":
    main()
