#!/usr/bin/env bash
# Construye la ISO de UMBRA OS. Lo usa GitHub Actions, pero funciona en cualquier Linux con
# Python 3.13, Docker y conexión a internet:   bash iso/construir.sh
#
# Los pasos opcionales (voz, oído, cerebro, claves de navegadores) no paran la construcción si
# fallan: la ISO sale igual, solo sin esa parte, y se avisa en el registro.
set -euo pipefail
cd "$(dirname "$0")/.."

paso() { printf '\n\033[1;35m==> %s\033[0m\n' "$*"; }
aviso() { printf '\033[1;33m!! Aviso: %s\033[0m\n' "$*"; }
# Ejecuta un paso opcional en un subproceso (con set -e activo de verdad) y solo avisa si falla
opcional() {
	local nombre="$1"; shift
	( "$@" ) &
	if ! wait $!; then aviso "no se ha podido incluir: $nombre"; fi
}

INC=iso/config/includes.chroot
DIST=$INC/opt/umbra/dist
PLAT=(--platform manylinux_2_28_x86_64 --platform manylinux_2_17_x86_64 --platform manylinux2014_x86_64
      --platform manylinux2010_x86_64 --platform manylinux_2_12_x86_64 --python-version 3.13 --implementation cp)

paso "Pruebas de NYX"
python -m pip install -q -e ".[dev]"
python -m pytest -q

paso "Empaquetar NYX"
mkdir -p "$DIST"
python -m pip wheel . --no-deps -w "$DIST" -q

voz_piper() {
	python -m pip download "piper-tts==1.8.0" --only-binary=:all: "${PLAT[@]}" -d "$DIST" -q
	local V=$INC/usr/share/umbra/voices
	local BASE=https://huggingface.co/rhasspy/piper-voices/resolve/main/es/es_ES/sharvard/medium
	mkdir -p "$V"
	curl -fL --retry 3 -o "$V/es_ES-sharvard-medium.onnx" "$BASE/es_ES-sharvard-medium.onnx"
	curl -fL --retry 3 -o "$V/es_ES-sharvard-medium.onnx.json" "$BASE/es_ES-sharvard-medium.onnx.json"
}
paso "Voz de NYX (Piper)"
opcional "la voz Piper" voz_piper

oido_vosk() {
	# srt solo existe como código fuente: se compila aquí su rueda (es Python puro)
	python -m pip download "vosk==0.3.45" --no-deps --only-binary=:all: "${PLAT[@]}" -d "$DIST" -q
	python -m pip wheel srt --no-deps -w "$DIST" -q
	python -m pip download cffi requests tqdm websockets --only-binary=:all: "${PLAT[@]}" -d "$DIST" -q
	local M=$INC/usr/share/umbra/vosk
	mkdir -p "$M" /tmp/vosk
	curl -fL --retry 3 -o /tmp/vosk-es.zip https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip
	unzip -q -o /tmp/vosk-es.zip -d /tmp/vosk
	rm -rf "$M/es"
	mv /tmp/vosk/vosk-model-small-es-0.42 "$M/es"
}
paso "Oído de NYX (Vosk)"
opcional "el oído (Vosk)" oido_vosk

cerebro() {
	local L=$INC/opt/umbra/llama
	mkdir -p "$L" /tmp/llama
	gh release download -R ggml-org/llama.cpp --pattern '*-bin-ubuntu-x64.zip' -D /tmp/llama --clobber
	unzip -q -o /tmp/llama/*.zip -d /tmp/llama/x
	find /tmp/llama/x -name 'llama-server' -exec cp {} "$L/" \;
	find /tmp/llama/x -name '*.so*' -exec cp -P {} "$L/" \;
	chmod 755 "$L/llama-server"
	LD_LIBRARY_PATH="$L" "$L/llama-server" --version
}
paso "Motor del cerebro (llama-server)"
opcional "el motor del cerebro" cerebro

claves() {
	local K=$INC/usr/share/keyrings
	mkdir -p "$K"
	curl -fsSL https://dl.google.com/linux/linux_signing_key.pub | gpg --dearmor --yes -o "$K/google-chrome.gpg"
	curl -fsSL https://deb.opera.com/archive.key | gpg --dearmor --yes -o "$K/opera.gpg"
}
paso "Claves de los repositorios de Chrome y Opera GX"
opcional "las claves de los navegadores" claves

ls -lh "$DIST"

if [ -n "${GITHUB_ACTIONS:-}" ]; then
	paso "Liberar espacio en la máquina de GitHub"
	sudo rm -rf /usr/share/dotnet /usr/local/lib/android /opt/ghc /opt/hostedtoolcache/CodeQL
	df -h /
fi

paso "Construir la ISO en Debian 13 (trixie)"
docker run --rm --privileged -v "$PWD/iso:/build" -w /build debian:trixie bash -c \
	"apt-get update && apt-get install -y --no-install-recommends live-build ca-certificates && \
	 lb clean && lb config && lb build 2>&1 | tee build.log; exit \${PIPESTATUS[0]}"

paso "Nombrar la ISO"
VERSION=$(python -c "import tomllib;print(tomllib.load(open('pyproject.toml','rb'))['project']['version'])")
NAME="umbra-os-${VERSION}-amd64.iso"
sudo mv iso/live-image-amd64.hybrid.iso "$NAME"
sudo chown "$(id -u):$(id -g)" "$NAME"
sha256sum "$NAME" > "$NAME.sha256"
ls -lh "$NAME"
if [ -n "${GITHUB_OUTPUT:-}" ]; then
	echo "name=$NAME" >> "$GITHUB_OUTPUT"
fi
paso "Listo: $NAME"
