# Instalación

## Requisitos

- Linux con Python 3.11 o superior (Ubuntu 24.04 trae 3.12).
- Opcional, para conversación libre: un modelo local.

## Instalar NYX (desarrollo)

```bash
git clone https://github.com/<usuario>/umbra-os.git
cd umbra-os
python3 -m venv .venv && . .venv/bin/activate
pip install -e ".[dev]"
python -m pytest        # todas las pruebas deben pasar
nyx --sin-modelo "analiza el rendimiento del sistema"
```

## Modelo de IA local (opcional)

### Opción A: dentro de Python, sin servidor (recomendada)

```bash
pip install llama-cpp-python
mkdir -p ~/.local/share/umbra/models
# Copia un modelo .gguf (p. ej. Llama 3.2 1B o 3B Instruct, cuantización Q4_K_M) como:
#   ~/.local/share/umbra/models/nyx.gguf
nyx
```
En equipos con poca RAM, usa un modelo de 1B mientras desarrollas.

### Opción B: Ollama local

Si Ollama está en marcha en `http://127.0.0.1:11434`, NYX lo usa automáticamente
(`provider = "auto"`). Modelo por defecto: `llama3.2:3b`.

## Configuración

Por orden: `/etc/umbra/umbra.toml`, `~/.config/umbra/umbra.toml`, `--config FICHERO`.
Ver `config/umbra.toml` para todas las opciones.

## Ventana de NYX

Necesita GTK 4 para Python (en Debian/Ubuntu: `python3-gi gir1.2-gtk-4.0`). Si usas un entorno
virtual, créalo con `--system-site-packages`. Después: `nyx-gui`.

## ISO de UMBRA OS

1. En GitHub: pestaña **Actions → ISO de UMBRA OS → Run workflow** (o publica una etiqueta `v0.2.0`).
2. Al terminar (unos 30–60 min), descarga el artefacto `umbra-os-iso`.
3. En VirtualBox: nueva máquina «Debian (64-bit)», 2 CPU, 3–4 GB de RAM, 25 GB de disco, EFI opcional.
   Arranca desde la ISO. Sesión en vivo: usuario `umbra`, contraseña `live`.
4. Para instalar, abre el instalador (Calamares) desde el menú.

Detalles en [iso/README.md](iso/README.md).
