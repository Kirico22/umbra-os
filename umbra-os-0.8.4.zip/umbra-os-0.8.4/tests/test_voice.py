import math
import shutil
import wave
import array

import pytest

from umbra.nyx import voice


def test_speakable_reads_first_block_without_symbols():
    text = "CPU: 2 núcleos, carga 5% → bien.\nRAM: 3 GB libres.\n\nProcesos que más RAM usan:\n  200 MB claude"
    spoken = voice.speakable(text)
    assert "Procesos" not in spoken and "→" not in spoken
    assert "por ciento" in spoken and "gigas" in spoken


def test_speakable_skips_long_paths_and_limits_length():
    assert "esa ruta" in voice.speakable("Encontrado: /home/umbra/Documentos/factura.pdf")
    assert len(voice.speakable("palabra " * 200)) <= voice.MAX_SPOKEN_CHARS + 1


def test_envelope_follows_volume(tmp_path):
    rate = 16000
    path = tmp_path / "t.wav"
    samples = array.array("h")
    for i in range(rate):  # 0,5 s de silencio + 0,5 s de tono
        samples.append(0 if i < rate // 2 else int(12000 * math.sin(i / 8)))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(samples.tobytes())
    env = voice.envelope(path)
    assert len(env) in (60, 61)  # el último trozo puede ser parcial
    assert max(env[:25]) < 0.05 and min(env[35:]) > 0.9


@pytest.mark.skipif(shutil.which("espeak-ng") is None, reason="espeak-ng no instalado")
def test_espeak_fallback_synthesizes(monkeypatch, tmp_path):
    monkeypatch.setattr(voice, "VOICE_DIRS", [tmp_path])  # sin modelo de Piper
    v = voice.Voice()
    assert v.engine == "espeak-ng"
    utt = v.synthesize("Hola, soy NYX.")
    assert utt and utt.duration > 0.3 and max(utt.envelope) == 1.0
    utt.wav.unlink()


def test_sentences_split_and_merge_short():
    parts = voice.sentences("Hola. Soy NYX, tu asistente local. He revisado el archivo y es seguro. ¿Algo más?")
    assert parts[0].startswith("Hola. Soy NYX")  # «Hola.» es muy corta: va con la siguiente
    assert len(parts) == 3 and parts[-1] == "¿Algo más?"
    assert voice.sentences("") == []


def test_player_commands_use_a_large_buffer(tmp_path):
    wav = tmp_path / "a.wav"
    assert voice.player_command("pw-play", wav) == ["pw-play", "--latency", "250ms", str(wav)]
    assert "--latency-msec=250" in voice.player_command("paplay", wav)
    assert "--buffer-time=250000" in voice.player_command("aplay", wav)


def test_engine_choice_does_not_load_the_model(monkeypatch, tmp_path):
    (tmp_path / f"{voice.PIPER_VOICE}.onnx").write_bytes(b"no es un modelo")
    monkeypatch.setattr(voice, "VOICE_DIRS", [tmp_path])
    monkeypatch.setattr(voice.importlib.util, "find_spec", lambda name: object())
    v = voice.Voice()
    assert v.engine == "piper" and v._piper is None  # abrir la ventana no espera al modelo
    if shutil.which("espeak-ng"):
        assert v._load_piper() is False and v.engine == "espeak-ng"  # modelo roto: cae a espeak


def test_piper_leaves_headroom():
    assert 0.5 < voice.PIPER_VOLUME < 1.0


class _FakeVoice(voice.Voice):
    def __init__(self):
        super().__init__()
        self.engine, self.player, self.spoken = "falsa", None, []

    def _synth_one(self, text):
        import tempfile
        from pathlib import Path

        fd, name = tempfile.mkstemp(suffix=".wav")
        import os
        os.close(fd)
        self.spoken.append(text)
        return voice.Utterance(Path(name), [0.5] * 3, 0.05, "falsa")


def test_speak_streams_chunks_in_order_and_cleans_up():
    import threading

    v = _FakeVoice()
    chunks, done = [], threading.Event()
    assert v.speak("Primera frase bastante larga para ir sola. Segunda frase también larga, sí.",
                   on_chunk=lambda u: chunks.append(u.wav), on_done=done.set)
    assert done.wait(5)
    assert len(v.spoken) == 2 and v.spoken[0].startswith("Primera")
    assert len(chunks) == 2 and not any(p.exists() for p in chunks)


def test_stop_cancels_and_skips_on_done():
    import threading
    import time

    v = _FakeVoice()
    done = threading.Event()
    v.speak("Una frase larga que no debería terminar de sonar nunca jamás.", on_done=done.set)
    v.stop()
    time.sleep(0.3)
    assert not done.is_set()
    assert v.speak("") is False
