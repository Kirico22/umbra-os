from umbra import desktop


def test_picom_config_levels():
    alto = desktop.picom_config("alto")
    apagado = desktop.picom_config("apagado")
    assert 'backend = "glx"' in alto and "blur-strength = 7" in alto and "blur-background = true" in alto
    assert 'backend = "xrender"' in apagado and "blur-method" not in apagado
    for conf in (alto, apagado):
        assert conf.count("{") == conf.count("}") and conf.count("(") == conf.count(")")
        assert 'preset = "appear"' in conf and "NYX-orbe" in conf


def test_apply_glass_writes_user_config(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    path = desktop.apply_glass("medio", restart=False)
    assert path == tmp_path / "picom.conf" and "blur-strength = 4" in path.read_text()


def test_iso_picom_is_generated_from_default():
    from pathlib import Path
    iso = Path(__file__).resolve().parent.parent / "iso/config/includes.chroot/etc/xdg/picom.conf"
    assert iso.read_text() == desktop.picom_config("alto")


def test_browsers_are_fixed():
    assert set(desktop.BROWSERS) == {"opera-gx", "chrome"}
    ok, msg = desktop.install_browser("firefox; rm -rf /")
    assert not ok and "desconocido" in msg


def test_cursor_themes_and_apply(tmp_path, monkeypatch):
    icons = tmp_path / "icons"
    for name in ("Adwaita", "UMBRA", "Zeta", "SinCursores"):
        (icons / name / ("cursors" if name != "SinCursores" else "otro")).mkdir(parents=True)
    assert desktop.cursor_themes([icons]) == ["UMBRA", "Adwaita", "Zeta"]
    assert desktop.cursor_label("UMBRA-Claro") == "UMBRA claro"
    desktop.apply_cursor("UMBRA", 48, home=tmp_path)
    assert "Inherits=UMBRA" in (tmp_path / ".icons/default/index.theme").read_text()
    xres = (tmp_path / ".Xresources").read_text()
    assert "Xcursor.theme: UMBRA" in xres and "Xcursor.size: 48" in xres
    desktop.apply_cursor("Adwaita", 24, home=tmp_path)
    assert (tmp_path / ".Xresources").read_text().count("Xcursor.theme") == 1
