import json

from umbra.nyx import listen


class FakeRecognizer:
    """Reconocedor de mentira: cada trozo de audio es una palabra ya «reconocida»."""

    def __init__(self, final_after=None):
        self.words = []
        self.final_after = final_after

    def AcceptWaveform(self, chunk):  # noqa: N802 - nombre de la API de Vosk
        word = chunk.decode().strip()
        if word:
            self.words.append(word)
        return self.final_after is not None and len(self.words) >= self.final_after

    def Result(self):  # noqa: N802
        return json.dumps({"text": " ".join(self.words)})

    def PartialResult(self):  # noqa: N802
        return json.dumps({"partial": " ".join(self.words)})

    def FinalResult(self):  # noqa: N802
        return json.dumps({"text": " ".join(self.words)})


def chunks(*words, silence=0):
    pad = lambda w: w.encode().ljust(listen.CHUNK)  # noqa: E731
    return [pad(w) for w in words] + [b" " * listen.CHUNK] * silence


def test_transcribe_returns_complete_sentence():
    rec = FakeRecognizer(final_after=3)
    assert listen.transcribe(chunks("analiza", "las", "descargas", "basura"), rec) == "analiza las descargas"


def test_transcribe_stops_after_silence_and_reports_partials():
    seen = []
    rec = FakeRecognizer()
    text = listen.transcribe(chunks("abre", "firefox", silence=20), rec, silence_seconds=1.0, on_partial=seen.append)
    assert text == "abre firefox" and seen == ["abre", "abre firefox"]


def test_transcribe_has_time_limit():
    rec = FakeRecognizer()
    out = listen.transcribe(chunks(*["bla"] * 400), rec, max_seconds=2.0)
    assert len(out.split()) <= 17  # 2 s / 0,125 s por trozo


def test_wake_phrase_matching():
    phrases = ["oye nix", "hola nix"]
    assert listen.is_wake("oye nix", phrases)
    assert listen.is_wake("[unk] Hola Nix", phrases)
    assert not listen.is_wake("oye", phrases) and not listen.is_wake("nix", phrases)


def test_available_explains_what_is_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(listen, "MODEL_DIRS", [tmp_path / "nada"])
    ok, why = listen.available()
    assert not ok and why  # sin Vosk o sin modelo: lo dice en español


def test_listening_is_off_by_default():
    from umbra.theme import Appearance

    assert Appearance().escucha is False
