import pytest

from umbra.modules import builtin_modules
from umbra.nyx import Memory
from umbra.security import AuditLog, Broker, Policy


@pytest.fixture
def memory():
    m = Memory(":memory:")
    yield m
    m.close()


@pytest.fixture
def audit(tmp_path):
    return AuditLog(tmp_path / "audit.log")


@pytest.fixture
def broker(tmp_path, memory, audit):
    b = Broker(Policy(), audit)
    for module in builtin_modules([tmp_path], memory, tmp_path / ".undo"):
        b.register(module)
    return b
