import xml.etree.ElementTree as ET
from pathlib import Path

from umbra import desktop
from umbra.modules import apps
from umbra.search import all_apps, search

ROOT = Path(__file__).resolve().parents[1]
INC = ROOT / "iso/config/includes.chroot"


def _panel():
    tree = ET.parse(INC / "etc/xdg/xfce4/panel/default.xml")
    plugins = {p.get("name"): p for p in tree.getroot().iter("property") if p.get("name", "").startswith("plugin-")
               and p.get("type") == "string"}
    panel = next(p for p in tree.getroot().iter("property") if p.get("name") == "panel-1")
    props = {p.get("name"): p for p in panel}
    return plugins, props


def test_dock_is_small_and_centered_at_the_bottom():
    plugins, props = _panel()
    assert props["position"].get("value").startswith("p=10;")  # abajo, en el centro
    assert props["length-adjust"].get("value") == "true"
    ids = [v.get("value") for v in props["plugin-ids"]]
    kinds = [plugins[f"plugin-{i}"].get("value") for i in ids]
    assert kinds[0] == "launcher" and "systray" in kinds and "whiskermenu" not in kinds and "clock" not in kinds


def test_dock_buttons_in_order_and_shipped_in_skel():
    plugins, props = _panel()
    items = []
    for i in [v.get("value") for v in props["plugin-ids"]]:
        p = plugins[f"plugin-{i}"]
        if p.get("value") == "launcher":
            name = next(p.iter("value")).get("value")
            items.append(name)
            # el panel guarda sus lanzadores en ~/.config/xfce4/panel/launcher-N/: vienen de /etc/skel
            assert (INC / f"etc/skel/.config/xfce4/panel/launcher-{i}/{name}").is_file()
            assert (INC / f"usr/share/applications/{name}").is_file()
    assert items == ["umbra-apps.desktop", "umbra-archivos.desktop", "umbra-navegador.desktop", "umbra-apagar.desktop"]
    assert f"launcher-{desktop.DOCK_BROWSER_SLOT}" in str(
        next((INC / "etc/skel/.config/xfce4/panel").glob("launcher-*/umbra-navegador.desktop")))


def test_dock_icons_exist():
    for name in ("umbra-apps", "umbra-archivos", "umbra-apagar"):
        for size in (32, 48, 64, 128, 256):
            assert (INC / f"usr/share/icons/hicolor/{size}x{size}/apps/{name}.png").is_file()


def _desk(d: Path, name: str, **kw):
    lines = ["[Desktop Entry]", "Type=Application", f"Name={kw.pop('Name', name)}", "Exec=true"]
    lines += [f"{k.replace('_', '-')}={v}" for k, v in kw.items()]
    (d / f"{name}.desktop").write_text("\n".join(lines) + "\n")


def test_app_list_filters_and_groups(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CURRENT_DESKTOP", "XFCE")
    apps._CACHE.clear()
    _desk(tmp_path, "gimp", Name="GIMP", Icon="gimp", Categories="Graphics;2DGraphics;")
    _desk(tmp_path, "solo-gnome", OnlyShowIn="GNOME;")
    _desk(tmp_path, "desinstalado", TryExec="/no/existe/programa")
    _desk(tmp_path, "umbra-archivos", X_UMBRA_Dock="true")
    _desk(tmp_path, "oculto", NoDisplay="true")
    _desk(tmp_path, "writer", Name="Writer", Categories="Office;WordProcessor;")
    found = apps.installed([tmp_path])
    assert set(found) == {"gimp", "writer"}
    assert found["gimp"]["icono"] == "gimp" and found["gimp"]["grupo"] == "multimedia"
    assert found["writer"]["grupo"] == "oficina"
    assert [a["id"] for a in all_apps([tmp_path])] == ["gimp", "writer"]
    res = search("gim", root=tmp_path, app_dirs=[tmp_path])
    assert res[0].target == "gimp" and res[0].icon == "gimp"  # el icono real, no el id del lanzador


def test_app_list_is_cached_until_the_folder_changes(tmp_path):
    apps._CACHE.clear()
    _desk(tmp_path, "uno")
    assert set(apps.installed([tmp_path])) == {"uno"}
    import os
    import time
    _desk(tmp_path, "dos")
    os.utime(tmp_path, ns=(time.time_ns() + 10**9, time.time_ns() + 10**9))
    assert set(apps.installed([tmp_path])) == {"uno", "dos"}


def test_browser_button_takes_the_default_browser_icon(tmp_path, monkeypatch):
    data = tmp_path / "data"
    (data / "applications").mkdir(parents=True)
    (data / "applications/opera.desktop").write_text("[Desktop Entry]\nType=Application\nName=Opera GX\nIcon=opera-gx\n")
    monkeypatch.setenv("XDG_DATA_HOME", str(data))
    cfg = tmp_path / "cfg"
    assert desktop.sync_browser_launcher(cfg, "opera.desktop") is True
    f = cfg / f"xfce4/panel/launcher-{desktop.DOCK_BROWSER_SLOT}/umbra-navegador.desktop"
    text = f.read_text()
    assert "Icon=opera-gx" in text and "Exec=umbra-navegador %U" in text
    assert desktop.sync_browser_launcher(cfg, "opera.desktop") is False  # sin cambios, no reescribe


def test_vm_rendering_tweak_and_dock_style():
    x = (INC / "etc/X11/Xsession.d/60umbra-rendimiento").read_text()
    assert "GSK_RENDERER=cairo" in x and "systemd-detect-virt" in x
    css = (INC / "etc/skel/.config/gtk-3.0/gtk.css").read_text()
    assert ".xfce4-panel button" in css
    assert "corner-radius = 18" in (INC / "etc/xdg/picom.conf").read_text()
    assert "corner-radius = 18" in desktop.picom_config("alto")
    nav = (INC / "usr/bin/umbra-navegador")
    assert nav.stat().st_mode & 0o111 and "gtk-launch" in nav.read_text()
