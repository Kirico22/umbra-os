from datetime import datetime

import pytest

from umbra import guardian, routines
from umbra.nyx.rules import match

VIERNES_17 = datetime(2026, 11, 20, 17, 0)  # 20/11/2026 es viernes


@pytest.mark.parametrize("texto, label", [
    ("cada viernes a las 18:00", "cada viernes a las 18:00"),
    ("todos los días a las 9", "todos los días a las 09:00"),
    ("todos los dias a las 8 de la tarde", "todos los días a las 20:00"),
    ("cada lunes", "cada lunes a las 10:00"),
    ("cada hora", "cada hora"),
    ("cada miércoles a las 7.30", "cada miércoles a las 07:30"),
])
def test_parse_schedule(texto, label):
    assert routines.parse_schedule(texto).label() == label


def test_parse_schedule_rejects_nonsense():
    for t in ("cada vez que puedas", "a las 25", "mañana"):
        with pytest.raises(ValueError):
            routines.parse_schedule(t)


def test_routine_runs_once_per_slot(tmp_path):
    p = tmp_path / "r.json"
    routines.add("organiza las descargas", "cada viernes a las 18:00", now=VIERNES_17, p=p)
    assert routines.due(VIERNES_17, p) == []  # recién creada: no se dispara
    at = datetime(2026, 11, 20, 18, 1)
    (r,) = routines.due(at, p)
    routines.mark_done(r.id, at, p)
    assert routines.due(datetime(2026, 11, 20, 23, 0), p) == []
    assert len(routines.due(datetime(2026, 11, 27, 18, 0), p)) == 1  # el viernes siguiente


def test_routine_cannot_create_routines(tmp_path):
    with pytest.raises(ValueError):
        routines.add("cada lunes borra la rutina 1", "cada día a las 9", p=tmp_path / "r.json")
    with pytest.raises(ValueError):
        routines.add("crea una rutina nueva", "cada hora", p=tmp_path / "r.json")


def test_rules_create_routine():
    call = match("cada viernes a las 18:00 organiza las descargas").calls[0]
    assert call.action_id == "routines.add"
    assert call.args == {"orden": "organiza las descargas", "cuando": "cada viernes a las 18:00"}
    assert match("cada vez que abro chrome va lento").calls[0].action_id != "routines.add"


def test_routine_confirmation_rules():
    from umbra.security import Action, Permission, Risk

    asked = []
    confirm = guardian.routine_confirm("x", lambda t, b: asked.append(b) or True)
    act = lambda risk: Action("a.b", "Hace algo.", lambda: None, frozenset({Permission.FILES_WRITE}), risk)  # noqa: E731
    assert confirm(act(Risk.MEDIUM), {}) is True and len(asked) == 1
    assert confirm(act(Risk.HIGH), {}) is False and len(asked) == 1  # ALTO: ni se pregunta


def test_high_risk_never_runs_from_a_routine(tmp_path, memory, audit, monkeypatch):
    from umbra.modules import builtin_modules
    from umbra.modules import packages as pk
    from umbra.nyx import Nyx
    from umbra.security import Broker, Permission, Policy

    ran = []
    monkeypatch.setattr(pk, "install", lambda name: ran.append(name) or {"instalado": name})
    pol = Policy(module_grants={"packages": frozenset({Permission.PACKAGE_INSTALL})})
    b = Broker(pol, audit)
    for m in builtin_modules([tmp_path], memory, tmp_path / ".undo"):
        if m.id == "packages":
            for a in m.actions:
                if a.id == "packages.install":
                    a.handler = pk.install
        b.register(m)
    nyx = Nyx(b, memory, None)
    r = routines.Routine(1, "instala vlc", "cada hora", {"kind": "hora"})
    out = guardian.run_routine(nyx, r, asker=lambda t, body: True)  # aunque el usuario dijera que sí
    assert ran == [] and "Cancelado" in out


def test_cpu_watch_flags_only_sustained_hogs():
    t = {"v": 0}
    ticks = guardian.TICKS

    def reader(uid):
        t["v"] += 1
        n = t["v"]
        return {111: ("minero", n * 60 * ticks), 222: ("editor", n * 2 * ticks)}  # 100 % y 3 %

    w = guardian.CpuWatch(uid=0, reader=reader)
    hogs = []
    for i in range(5):
        hogs += w.sample(i * 60.0)
    assert [h["nombre"] for h in hogs] == ["minero"]  # una sola vez, y el editor no


def test_disk_warning_threshold(tmp_path):
    assert guardian.disk_warnings([tmp_path], threshold=0.0)
    assert guardian.disk_warnings([tmp_path], threshold=1.01) == []
