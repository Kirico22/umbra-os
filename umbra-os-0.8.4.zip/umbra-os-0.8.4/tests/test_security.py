"""Pruebas del intermediario seguro: lo más importante de UMBRA."""

import os

import pytest

from umbra.security import Action, Broker, Module, Param, Permission, Policy, Risk, ToolCall


def _module(handler, risk=Risk.LOW, perms=frozenset({Permission.SERVICE_CONTROL})):
    return Module(
        id="demo",
        name="Demo",
        description="",
        requested=perms,
        actions=[Action("demo.run", "Prueba", handler, perms, risk, (Param("n", int, required=False),))],
    )


def test_unknown_action_is_rejected(broker):
    r = broker.execute(ToolCall("shell.exec", {"cmd": "rm -rf /"}))
    assert r.status == "rejected" and not r.ok


def test_unknown_arguments_are_rejected(broker):
    r = broker.execute(ToolCall("system.info", {"extra": 1}))
    assert r.status == "rejected"


def test_wrong_type_is_rejected(broker):
    assert broker.execute(ToolCall("processes.top", {"n": "5"})).status == "rejected"
    assert broker.execute(ToolCall("processes.top", {"n": True})).status == "rejected"


def test_permission_not_granted_by_default(audit):
    calls = []
    b = Broker(Policy(), audit, confirm=lambda a, k: True)
    b.register(_module(lambda n=0: calls.append(n)))
    r = b.execute(ToolCall("demo.run", {}))
    assert r.status == "denied" and calls == []
    assert b.available_actions() == []  # ni siquiera se ofrece al modelo


def test_medium_risk_needs_confirmation(audit):
    calls = []
    policy = Policy(module_grants={"demo": frozenset({Permission.SERVICE_CONTROL})})
    denied = Broker(policy, audit)  # confirmación por defecto: siempre "no"
    denied.register(_module(lambda n=0: calls.append(n), Risk.MEDIUM))
    assert denied.execute(ToolCall("demo.run", {})).status == "cancelled"
    assert calls == []

    accepted = Broker(policy, audit, confirm=lambda a, k: True)
    accepted.register(_module(lambda n=0: calls.append(n), Risk.MEDIUM))
    assert accepted.execute(ToolCall("demo.run", {"n": 3})).ok
    assert calls == [3]


def test_confirmation_that_raises_counts_as_no(audit):
    def boom(a, k):
        raise RuntimeError

    policy = Policy(module_grants={"demo": frozenset({Permission.SERVICE_CONTROL})})
    b = Broker(policy, audit, confirm=boom)
    b.register(_module(lambda n=0: None, Risk.HIGH))
    assert b.execute(ToolCall("demo.run", {})).status == "cancelled"


def test_untrusted_module_gets_no_permissions(audit):
    mod = _module(lambda n=0: None, perms=frozenset({Permission.SYSTEM_READ}))
    mod.trusted = False
    b = Broker(Policy(), audit)
    b.register(mod)
    assert b.execute(ToolCall("demo.run", {})).status == "denied"


def test_module_cannot_use_unrequested_permission():
    with pytest.raises(ValueError):
        Module("x", "X", "", frozenset({Permission.SYSTEM_READ}),
               [Action("x.a", "", lambda: None, frozenset({Permission.PACKAGE_INSTALL}))])


def test_handler_errors_do_not_crash(audit):
    def fail(n=0):
        raise OSError("disco roto")

    b = Broker(Policy(module_grants={"demo": frozenset({Permission.SERVICE_CONTROL})}), audit)
    b.register(_module(fail))
    r = b.execute(ToolCall("demo.run", {}))
    assert r.status == "error" and "disco roto" in r.error


def test_everything_is_audited_and_secrets_hidden(broker, audit):
    broker.execute(ToolCall("system.info", {}))
    broker.execute(ToolCall("nope", {"password": "1234", "api_token": "abc"}))
    entries = audit.tail()
    assert [e["status"] for e in entries] == ["ok", "rejected"]
    assert entries[1]["args"] == {"password": "***", "api_token": "***"}
    assert oct(os.stat(audit.path).st_mode & 0o777) == "0o600"


def test_policy_from_file(tmp_path):
    f = tmp_path / "policy.toml"
    f.write_text('[grants]\ndemo = ["service.control"]\n')
    policy = Policy.from_file(f)
    assert Permission.SERVICE_CONTROL in policy.granted(_module(lambda: None))


def test_paths_outside_allowed_roots_are_denied(broker, tmp_path):
    (tmp_path / "a").mkdir()
    assert broker.execute(ToolCall("files.list", {"path": str(tmp_path / "a")})).ok
    for bad in ["/etc", str(tmp_path / ".." / ".."), "/"]:
        assert broker.execute(ToolCall("files.list", {"path": bad})).status == "denied"


def test_symlink_escape_is_denied(broker, tmp_path):
    (tmp_path / "trampa").symlink_to("/etc")
    assert broker.execute(ToolCall("files.list", {"path": str(tmp_path / "trampa")})).status == "denied"


def test_audit_log_rotates(tmp_path):
    from umbra.security import AuditLog as Log

    log = Log(tmp_path / "audit.log", max_bytes=300)
    for i in range(40):
        log.record(action="system.info", args={"i": i}, status="ok", error=None)
    files = sorted(p.name for p in tmp_path.iterdir())
    assert "audit.log.1" in files and "audit.log.4" not in files
    assert (tmp_path / "audit.log").stat().st_size < 600


def test_source_has_no_hidden_bidi_characters():
    """Defensa contra «Trojan Source»: el código no puede llevar caracteres que inviertan el texto."""
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    bidi = {chr(c) for c in (0x200E, 0x200F, *range(0x202A, 0x202F), *range(0x2066, 0x206A))}
    files = [*root.glob("src/**/*.py"), *root.glob("tests/*.py"), *root.glob("iso/**/*.py"),
             *root.glob("iso/config/includes.chroot/usr/bin/*")]
    bad = [str(f) for f in files if f.is_file() and bidi & set(f.read_text(encoding="utf-8", errors="ignore"))]
    assert not bad
