from pathlib import Path

import yaml

from umbra.nyx.rules import match

ISO = Path(__file__).resolve().parents[1] / "iso" / "config"


def test_game_mode_rules():
    assert match("activa el modo juego").calls[0].args == {"on": True}
    assert match("desactiva el modo juego").calls[0].args == {"on": False}
    assert match("sal del modo gaming").calls[0].args == {"on": False}


def test_game_mode_saves_and_restores(tmp_path, monkeypatch):
    from umbra import desktop, gamemode

    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    calls = []

    class R:
        returncode, stdout = 0, "false"

    def fake_run(cmd, timeout=10):
        calls.append(cmd)
        return R()

    monkeypatch.setattr(desktop, "_run", fake_run)
    monkeypatch.setattr(desktop, "restart_atom", lambda on: calls.append(["atomo", on]))
    monkeypatch.setattr(gamemode.subprocess, "Popen", lambda *a, **k: (_ for _ in ()).throw(OSError()))
    out = gamemode.enable()
    assert gamemode.active() and "GameMode" in out["mensaje"]
    assert ["xfconf-query", "-c", "xfce4-notifyd", "-p", "/do-not-disturb", "-n", "-t", "bool", "-s", "true"] in calls
    assert ["atomo", False] in calls
    calls.clear()
    gamemode.disable()
    assert not gamemode.active()
    assert ["xfconf-query", "-c", "xfce4-notifyd", "-p", "/do-not-disturb", "-n", "-t", "bool", "-s", "false"] in calls
    assert ["atomo", True] in calls


def test_safe_mode_disables_brain(monkeypatch):
    from umbra.cli import make_provider
    from umbra.config import load_config

    monkeypatch.setenv("UMBRA_SEGURO", "1")
    prov, label = make_provider(load_config())
    assert prov is None and "seguro" in label


def test_iso_v07_assets():
    inc = ISO / "includes.chroot"
    pkgs = (ISO / "package-lists/umbra.list.chroot").read_text()
    for pkg in ("libreoffice-writer", "vlc", "keepassxc", "timeshift", "deja-dup", "flatpak",
                "gnome-software-plugin-flatpak", "xfce4-pulseaudio-plugin", "gufw"):
        assert f"\n{pkg}\n" in pkgs, pkg
    conf = yaml.safe_load((inc / "etc/calamares/modules/partition.conf").read_text())
    assert conf["enableLuksAutomatedPartitioning"] is True and conf["initialPartitioningChoice"] == "none"
    greeter = (inc / "etc/lightdm/lightdm-gtk-greeter.conf").read_text()
    assert "/usr/share/umbra/login.png" in greeter and (inc / "usr/share/umbra/login.png").is_file()
    assert "UMBRA_SEGURO=1" in (inc / "usr/share/xsessions/umbra-seguro.desktop").read_text()
    assert (inc / "usr/share/themes/UMBRA/xfce-notify-4.0/gtk.css").is_file()
    for app in ("nyx-guardian", "umbra-vigia"):
        assert (inc / f"etc/xdg/autostart/{app}.desktop").is_file()
    hook = (ISO / "hooks/normal/9000-umbra.hook.chroot").read_text()
    for cmd in ("umbra-bienvenida", "nyx-guardian", "umbra-aviso"):
        assert cmd in hook
