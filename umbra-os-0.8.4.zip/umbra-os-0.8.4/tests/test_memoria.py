from pathlib import Path

from umbra import memoria as m
from umbra.nyx.rules import match

G = m.GIB
ROOT = Path(__file__).resolve().parents[1]
INC = ROOT / "iso/config/includes.chroot"


def st(**kw):
    base = dict(live=False, fs="ext4", disk_total=256 * G, disk_free=120 * G, ram=8 * G, swap_disk=0, ours=0)
    base.update(kw)
    return m.State(**base)


def test_creates_8gb_when_there_is_room():
    p = m.plan(st())
    assert p.action == "crear" and p.size == 8 * G


def test_never_in_live_session_or_unsupported_fs():
    assert m.plan(st(live=True)).action == "nada"
    assert m.plan(st(fs="overlay")).action == "nada"
    assert m.plan(st(fs="vfat")).action == "nada"


def test_keeps_free_space_for_the_user():
    p = m.plan(st(disk_total=64 * G, disk_free=20 * G))  # reserva 15 GB -> caben 5 GB
    assert p.action == "crear" and p.size == 5 * G
    assert m.plan(st(disk_total=64 * G, disk_free=15.5 * G)).action == "nada"  # no llega a 1 GB
    big = m.plan(st(disk_total=2000 * G, disk_free=205 * G))  # reserva el 10 %: 200 GB
    assert big.action == "crear" and big.size == 5 * G


def test_only_adds_what_the_installer_swap_is_missing():
    p = m.plan(st(swap_disk=2 * G))
    assert p.action == "crear" and p.size == 6 * G
    assert m.plan(st(swap_disk=8 * G)).action == "nada"
    assert m.plan(st(swap_disk=8 * G, ours=6 * G)).action == "quitar"


def test_keeps_existing_file_and_shrinks_it_if_disk_fills():
    assert m.plan(st(ours=8 * G, disk_free=60 * G)).action == "mantener"
    p = m.plan(st(ours=8 * G, disk_free=10 * G, disk_total=128 * G))  # 10 + 8 - 15 = 3 GB
    assert p.action == "crear" and p.size == 3 * G


def test_mode_no_removes_it():
    assert m.plan(st(ours=4 * G), "no").action == "quitar"
    assert m.plan(st(), "no").action == "nada"


def test_read_mode(tmp_path):
    c = tmp_path / "memoria.conf"
    assert m.read_mode(c) == "auto"
    c.write_text('modo = "no"\n')
    assert m.read_mode(c) == "no"
    c.write_text('modo = "rm -rf"\n')
    assert m.read_mode(c) == "auto"


def test_swaps_and_meminfo_parsing(tmp_path):
    (tmp_path / "proc").mkdir()
    (tmp_path / "proc/swaps").write_text("Filename Type Size Used Priority\n/dev/zram0 partition 4000000 0 100\n"
                                          "/swapfile file 2097148 0 -2\n")
    (tmp_path / "proc/meminfo").write_text("MemTotal:        8000000 kB\n")
    assert [s[0] for s in m._swaps(tmp_path)] == ["/dev/zram0", "/swapfile"]
    assert m._meminfo(tmp_path) == 8000000 * 1024


def test_nyx_rule():
    assert match("cuánta memoria virtual tengo").calls[0].action_id == "system.memory"
    assert match("estado del swap").calls[0].action_id == "system.memory"


def test_iso_wiring():
    unit = (INC / "etc/systemd/system/umbra-memoria.service").read_text()
    assert "ConditionPathExists=!/run/live/medium" in unit and "--aplicar" in unit
    hook = (ROOT / "iso/config/hooks/normal/9000-umbra.hook.chroot").read_text()
    assert "enable umbra-memoria.service" in hook and "umbra-memoria" in hook
    helper = INC / "usr/libexec/umbra/memoria-virtual"
    assert helper.stat().st_mode & 0o111 and "auto|no)" in helper.read_text()
    assert "os.umbra.memoria-virtual" in (INC / "usr/share/polkit-1/actions/os.umbra.navegador.policy").read_text()
    assert m.PRIORITY < 100  # siempre por debajo de zram
