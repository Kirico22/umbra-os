from pathlib import Path

from umbra import perf


def fake(tmp_path, product="", drivers=(), ram_gb=8):
    dmi = tmp_path / "sys/class/dmi/id"
    dmi.mkdir(parents=True)
    (dmi / "product_name").write_text(product)
    for i, d in enumerate(drivers):
        drv = tmp_path / f"drivers/{d}"
        drv.mkdir(parents=True)
        dev = tmp_path / f"sys/class/drm/card{i}/device"
        dev.mkdir(parents=True)
        (dev / "driver").symlink_to(drv)
    (tmp_path / "proc").mkdir()
    (tmp_path / "proc/meminfo").write_text(f"MemTotal:       {int(ram_gb * 1024 * 1024)} kB\n")
    return tmp_path


def test_virtualbox_is_light(tmp_path):
    info = perf.detect(fake(tmp_path, "VirtualBox", ["vboxvideo"], 4))
    assert info["maquina_virtual"] and perf.choose(info) == "ligero"


def test_real_laptop_with_intel_graphics(tmp_path):
    info = perf.detect(fake(tmp_path, "Inspiron 15", ["i915"], 8))
    assert not info["maquina_virtual"] and not info["sin_aceleracion"]
    assert perf.choose(info) in ("maximo", "equilibrado")


def test_low_memory_is_light(tmp_path):
    assert perf.choose(perf.detect(fake(tmp_path, "PC", ["i915"], 3))) == "ligero"


def test_manual_choice_wins(tmp_path):
    info = perf.detect(fake(tmp_path, "VirtualBox", ["vboxvideo"], 4))
    assert perf.profile("maximo", info) == "maximo" and perf.profile("auto", info) == "ligero"


def test_light_picom_has_no_blur_or_animations(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    text = perf.write_picom("ligero").read_text()
    assert 'backend = "xrender"' in text and "blur" not in text and "animations" not in text
    text = perf.write_picom("maximo", "alto").read_text()
    assert "dual_kawase" in text


def test_installer_launcher_never_uses_sudo():
    root = Path(__file__).resolve().parents[1] / "iso/config/includes.chroot"
    wrapper = (root / "usr/bin/umbra-instalar").read_text()
    helper = (root / "usr/libexec/umbra/instalador").read_text()
    code = "\n".join(line for line in (wrapper + helper).splitlines() if not line.strip().startswith("#"))
    assert "sudo " not in code and "pkexec /usr/libexec/umbra/instalador" in wrapper
    policy = (root / "usr/share/polkit-1/actions/os.umbra.navegador.policy").read_text()
    assert "/usr/libexec/umbra/instalador" in policy and "allow_gui" in policy
    assert "Hidden=true" in (root / "etc/xdg/autostart/calamares-desktop-icon.desktop").read_text()


def test_heavy_services_start_late():
    root = Path(__file__).resolve().parents[1] / "iso/config"
    auto = root / "includes.chroot/etc/xdg/autostart"
    assert "sleep" in (auto / "umbra-vigia.desktop").read_text()
    assert "sleep" in (auto / "nyx-guardian.desktop").read_text()
    hook = (root / "hooks/normal/9000-umbra.hook.chroot").read_text()
    assert "disable clamav-freshclam" in hook and "umbra-antivirus.timer" in hook
    assert "OnBootSec=20min" in (root / "includes.chroot/etc/systemd/system/umbra-antivirus.timer").read_text()
