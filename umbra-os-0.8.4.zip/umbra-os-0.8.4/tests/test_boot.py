import os

from umbra.boot import EFI_GLOBAL, boot_status
from umbra.nyx.rules import match


def fake_root(tmp_path, *, uefi=True, secure=None, setup=None, lockdown=None):
    if uefi:
        ev = tmp_path / "sys/firmware/efi/efivars"
        ev.mkdir(parents=True)
        for name, val in (("SecureBoot", secure), ("SetupMode", setup)):
            if val is not None:
                (ev / f"{name}-{EFI_GLOBAL}").write_bytes(b"\x06\x00\x00\x00" + bytes([val]))
    if lockdown:
        d = tmp_path / "sys/kernel/security"
        d.mkdir(parents=True)
        (d / "lockdown").write_text(lockdown)
    return tmp_path


def test_uefi_secure_boot_on(tmp_path):
    st = boot_status(fake_root(tmp_path, secure=1, lockdown="none [integrity] confidentiality\n"))
    assert st["firmware"] == "UEFI" and st["arranque_seguro"] == "activado"
    assert st["bloqueo_nucleo"] == "integrity" and st["nivel"] == "bien" and "shim" in st["consejo"]


def test_uefi_secure_boot_off_gives_advice_but_never_touches_bios(tmp_path):
    st = boot_status(fake_root(tmp_path, secure=0, setup=1))
    assert st["arranque_seguro"] == "desactivado" and st["nivel"] == "aviso"
    assert "NYX nunca toca la BIOS" in st["consejo"] and "modo configuración" in st["consejo"]


def test_legacy_bios(tmp_path):
    st = boot_status(fake_root(tmp_path, uefi=False))
    assert st["firmware"].startswith("BIOS") and st["arranque_seguro"] == "no disponible"


def test_boot_check_is_read_only(tmp_path):
    root = fake_root(tmp_path, secure=1)
    before = {p: p.stat().st_mtime_ns for p in root.rglob("*")}
    boot_status(root)
    assert {p: p.stat().st_mtime_ns for p in root.rglob("*")} == before


def test_boot_rules():
    for q in ("¿tengo el arranque seguro activado?", "¿mi arranque es seguro?", "revisa la bios", "secure boot"):
        assert match(q).calls[0].action_id == "security.boot", q


def test_iso_enables_secure_boot():
    from pathlib import Path

    root = Path(__file__).resolve().parents[1] / "iso"
    assert "--uefi-secure-boot enable" in (root / "auto/config").read_text()
    pkgs = (root / "config/package-lists/umbra.list.chroot").read_text()
    for p in ("shim-signed", "grub-efi-amd64-signed", "mokutil"):
        assert f"\n{p}\n" in pkgs
    assert os.access(root / "auto/config", os.R_OK)
