import hashlib
import io
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from umbra import brain
from umbra.nyx.providers import LlamaServerProvider, ProviderError

DATA = b"GGUF" + bytes(range(256)) * 40


class FakeResp(io.BytesIO):
    def __init__(self, data, status=200):
        super().__init__(data)
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


@pytest.fixture
def fake_model(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))
    m = brain.BrainModel("test", "Prueba", "test.gguf", "https://example.invalid/test.gguf",
                         hashlib.sha256(DATA).hexdigest(), len(DATA), "MIT", 0.1)
    monkeypatch.setitem(brain.MODELS, "test", m)
    return m


def test_real_model_entry_is_pinned():
    m = brain.MODELS[brain.DEFAULT]
    assert len(m.sha256) == 64 and m.url.startswith("https://huggingface.co/Qwen/") and m.license == "Apache 2.0"


def test_download_verifies_and_installs(fake_model):
    seen = []
    path = brain.download("test", progress=lambda d, t: seen.append(d), opener=lambda req, timeout: FakeResp(DATA))
    assert path.read_bytes() == DATA and brain.installed("test")
    assert seen[-1] == len(DATA)
    assert (path.stat().st_mode & 0o777) == 0o600


def test_download_resumes(fake_model):
    part = brain.model_path("test").with_name("test.gguf.part")
    part.parent.mkdir(parents=True)
    part.write_bytes(DATA[:1000])
    asked = {}

    def opener(req, timeout):
        asked["range"] = req.get_header("Range")
        return FakeResp(DATA[1000:], status=206)

    brain.download("test", opener=opener)
    assert asked["range"] == "bytes=1000-" and brain.installed("test")


def test_tampered_download_is_deleted(fake_model):
    bad = DATA[:-1] + b"X"
    with pytest.raises(RuntimeError, match="huella"):
        brain.download("test", opener=lambda req, timeout: FakeResp(bad))
    assert not brain.installed("test")
    assert not brain.model_path("test").with_name("test.gguf.part").exists()


class FakeLlama(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):  # noqa: N802
        self.send_response(200 if self.path == "/health" else 404)
        self.end_headers()
        self.wfile.write(b'{"status":"ok"}')

    def do_POST(self):  # noqa: N802
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        FakeLlama.last = body
        reply = {"choices": [{"message": {"content": json.dumps({"respuesta": "hola desde el cerebro"})}}]}
        data = json.dumps(reply).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(data)


def test_llama_server_provider_talks_openai_api(tmp_path):
    srv = HTTPServer(("127.0.0.1", 0), FakeLlama)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        p = LlamaServerProvider(tmp_path / "m.gguf", "/bin/false", port=srv.server_port, start=False)
        out = p.chat([{"role": "user", "content": "hola"}])
        assert "cerebro" in out and FakeLlama.last["stream"] is False
    finally:
        srv.shutdown()


def test_provider_not_running_and_no_autostart(tmp_path):
    p = LlamaServerProvider(tmp_path / "m.gguf", "/bin/false", port=1, start=False)
    with pytest.raises(ProviderError):
        p.chat([{"role": "user", "content": "hola"}])


def test_nyx_uses_brain_when_installed(monkeypatch, fake_model, tmp_path):
    from umbra.cli import make_provider
    from umbra.config import load_config

    monkeypatch.setattr(brain, "DEFAULT", "test")
    monkeypatch.setattr(brain, "server_binary", lambda: "/opt/umbra/llama/llama-server")
    cfg = load_config()
    cfg.nyx.provider = "auto"
    assert make_provider(cfg)[0] is None or make_provider(cfg)[0].name != "llama_server"
    brain.download("test", opener=lambda req, timeout: FakeResp(DATA))
    prov, label = make_provider(cfg)
    assert prov.name == "llama_server" and "cerebro" in label
