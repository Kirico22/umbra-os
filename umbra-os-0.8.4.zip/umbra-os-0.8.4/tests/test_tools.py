"""Pruebas de las herramientas nuevas de NYX."""

import os
import subprocess
import sys

import pytest

from umbra.modules import apps, files, packages, processes
from umbra.nyx import rules
from umbra.security import AuditLog, Broker, Permission, Policy, ToolCall


@pytest.fixture
def downloads(tmp_path):
    d = tmp_path / "Descargas"
    d.mkdir()
    for name in ["foto.JPG", "informe.pdf", "cancion.mp3", "juego.zip", "notas.txt", "raro.xyz", ".oculto.png"]:
        (d / name).write_text("x")
    (d / "Imágenes").mkdir()
    (d / "Imágenes" / "foto.JPG").write_text("ya existe")  # conflicto: no se sobrescribe
    return d


def _broker(tmp_path, grants=None, confirm=lambda a, k: True):
    b = Broker(Policy(module_grants=grants or {}), AuditLog(tmp_path / "a.log"), confirm=confirm)
    b.register(files.build([tmp_path], tmp_path / "undo"))
    b.register(processes.build())
    return b


def test_find(tmp_path, downloads):
    b = _broker(tmp_path)
    r = b.execute(ToolCall("files.find", {"name": "INFORME", "path": str(tmp_path)}))
    assert r.ok and r.output["resultados"] == [str(downloads / "informe.pdf")]
    r = b.execute(ToolCall("files.find", {"name": "*.mp3", "path": str(tmp_path)}))
    assert [os.path.basename(p) for p in r.output["resultados"]] == ["cancion.mp3"]


def test_organize_needs_write_permission(tmp_path, downloads):
    r = _broker(tmp_path).execute(ToolCall("files.organize", {"path": str(downloads)}))
    assert r.status == "denied"
    assert (downloads / "informe.pdf").exists()


def test_organize_needs_confirmation(tmp_path, downloads):
    b = _broker(tmp_path, {"files": frozenset({Permission.FILES_WRITE})}, confirm=lambda a, k: False)
    assert b.execute(ToolCall("files.organize", {"path": str(downloads)})).status == "cancelled"
    assert (downloads / "informe.pdf").exists()


def test_organize_and_undo(tmp_path, downloads):
    b = _broker(tmp_path, {"files": frozenset({Permission.FILES_WRITE})})
    preview = b.execute(ToolCall("files.organize_preview", {"path": str(downloads)})).output
    assert preview["por_carpeta"] == {"Documentos": 2, "Música": 1, "Comprimidos": 1}

    r = b.execute(ToolCall("files.organize", {"path": str(downloads)}))
    assert r.ok and r.output["movidos"] == 4
    assert (downloads / "Documentos" / "informe.pdf").exists()
    assert (downloads / "foto.JPG").exists()  # destino ocupado: no se toca
    assert (downloads / "Imágenes" / "foto.JPG").read_text() == "ya existe"
    assert (downloads / "raro.xyz").exists() and (downloads / ".oculto.png").exists()

    u = b.execute(ToolCall("files.undo_organize", {}))
    assert u.ok and u.output["restaurados"] == 4
    assert (downloads / "informe.pdf").exists() and not (downloads / "Documentos").exists()
    assert b.execute(ToolCall("files.undo_organize", {})).output["restaurados"] == 0


def test_apps_find_and_open(tmp_path):
    d = tmp_path / "applications"
    d.mkdir()
    (d / "firefox-esr.desktop").write_text("[Desktop Entry]\nType=Application\nName=Firefox ESR\nExec=firefox-esr\n")
    (d / "hidden.desktop").write_text("[Desktop Entry]\nType=Application\nName=Oculta\nNoDisplay=true\n")
    (d / "mousepad.desktop").write_text("[Desktop Entry]\nType=Application\nName=Mousepad\nName[es]=Editor de textos\n")
    launched = []
    mod = apps.build([d], launcher=launched.append)
    open_app = {a.id: a for a in mod.actions}["apps.open"].handler
    list_apps = {a.id: a for a in mod.actions}["apps.list"].handler
    assert [a["nombre"] for a in list_apps()] == ["Editor de textos", "Firefox ESR"]
    assert open_app("firefox")["id"] == "firefox-esr" and launched == ["firefox-esr"]
    with pytest.raises(LookupError):
        open_app("oculta")


def test_stop_only_own_processes(tmp_path):
    b = _broker(tmp_path, {"processes": frozenset({Permission.PROCESS_CONTROL})})
    assert b.execute(ToolCall("processes.stop", {"pid": 1})).status == "denied"
    assert b.execute(ToolCall("processes.stop", {"pid": os.getpid()})).status == "denied"
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"])
    try:
        r = b.execute(ToolCall("processes.stop", {"pid": child.pid}))
        if os.getuid() == 0:
            # Por diseño NYX nunca cierra procesos de root, aunque se ejecute como root
            assert r.status == "denied"
        else:
            assert r.ok
            assert child.wait(timeout=5) != 0
    finally:
        child.kill()


@pytest.mark.parametrize("bad", ["vim; rm -rf /", "-y", "a b", "../x", "", "X" * 80])
def test_package_names_are_strict(bad):
    with pytest.raises(ValueError):
        packages.valid_package(bad)


@pytest.mark.parametrize(
    "text, intent, args",
    [
        ("organiza estos archivos en ~/Descargas", "organizar", {"path": "~/Descargas"}),
        ("deshaz", "deshacer_organizar", {}),
        ("NYX, instala este programa: vlc", "instalar", {"name": "vlc"}),
        ("instala gimp", "instalar", {"name": "gimp"}),
        ("abre Firefox", "abrir_app", {"name": "Firefox"}),
        ("busca el archivo informe.pdf", "buscar_archivo", {"name": "informe.pdf"}),
        ("¿estoy conectado a internet?", "red", {}),
        ("cierra el proceso 4321", "cerrar_proceso", {"pid": 4321}),
        ("busca el programa blender", "buscar_programa", {"query": "blender"}),
    ],
)
def test_new_rules(text, intent, args):
    plan = rules.match(text)
    assert plan is not None and plan.intent == intent
    if args:
        assert plan.calls[-1].args == args or plan.calls[0].args == args


def test_forbidden_actions_are_refused_without_asking(tmp_path, downloads):
    asked = []
    b = _broker(tmp_path, {"processes": frozenset({Permission.PROCESS_CONTROL}),
                           "files": frozenset({Permission.FILES_WRITE})},
                confirm=lambda a, k: asked.append(a.id) or True)
    assert b.execute(ToolCall("processes.stop", {"pid": 1})).status == "denied"
    assert b.execute(ToolCall("files.organize", {"path": "/etc"})).status == "denied"
    assert asked == []  # no se molesta al usuario con algo prohibido


def test_invalid_package_rejected_before_confirmation(tmp_path):
    asked = []
    b = Broker(Policy(module_grants={"packages": frozenset({Permission.PACKAGE_INSTALL})}),
               AuditLog(tmp_path / "a.log"), confirm=lambda a, k: asked.append(1) or True)
    b.register(packages.build())
    assert b.execute(ToolCall("packages.install", {"name": "vlc; rm -rf /"})).status == "rejected"
    assert asked == []


@pytest.mark.parametrize("text, name", [("instala opera gx", "opera-gx"), ("NYX, instálame Chrome", "chrome"),
                                        ("pon Opera GX", "opera-gx")])
def test_browser_rules(text, name):
    plan = rules.match(text)
    assert plan.intent == "instalar_navegador" and plan.calls[0].args == {"name": name}


def test_browser_action_only_accepts_known(tmp_path):
    asked = []
    b = Broker(Policy(module_grants={"packages": frozenset({Permission.PACKAGE_INSTALL})}),
               AuditLog(tmp_path / "a.log"), confirm=lambda a, k: asked.append(1) or True)
    b.register(packages.build())
    assert b.execute(ToolCall("packages.browser", {"name": "edge"})).status == "rejected"
    assert asked == []
