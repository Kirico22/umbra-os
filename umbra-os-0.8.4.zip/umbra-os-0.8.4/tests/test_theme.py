from umbra import theme


def test_defaults_and_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert theme.load() == theme.Appearance()
    theme.save(theme.Appearance(acento="azul", cristal="medio", orbe=False, iconos=72))
    loaded = theme.load()
    assert (loaded.acento, loaded.cristal, loaded.orbe, loaded.iconos) == ("azul", "medio", False, 72)


def test_invalid_values_fall_back(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    p = tmp_path / "umbra" / "apariencia.toml"
    p.parent.mkdir(parents=True)
    p.write_text('acento = "fucsia"\ncristal = "x"\niconos = 9999\nraro = 1\n')
    a = theme.load()
    assert (a.acento, a.cristal, a.iconos) == ("morado", "alto", 128)
    p.write_text("esto no es toml [[[")
    assert theme.load() == theme.Appearance()


def test_glass_css_uses_accent():
    css = theme.glass_css(theme.Appearance(acento="verde"))
    assert "#3fd99a" in css and ".glass-panel" in css
    assert theme.picom_blur_strength(theme.Appearance(cristal="apagado")) == 0
