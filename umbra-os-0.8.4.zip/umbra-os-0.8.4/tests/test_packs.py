import re
from pathlib import Path

import pytest

from umbra import packs
from umbra.nyx.rules import match

HELPER = Path(__file__).resolve().parents[1] / "iso/config/includes.chroot/usr/libexec/umbra/instalar-pack"


def test_helper_lists_match_python():
    text = HELPER.read_text()
    found = dict(re.findall(r'^\t(\w+)\) pkgs="([^"]+)"', text, re.M))
    assert found.keys() == packs.PACKS.keys()
    for pid, pack in packs.PACKS.items():
        assert tuple(found[pid].split()) == pack.apt


def test_helper_rejects_unknown_and_has_no_user_input_in_apt():
    text = HELPER.read_text()
    assert 'exit 2' in text and '"$1"' not in text.split("esac", 1)[1]


def test_flatpak_ids_look_valid():
    for pack in packs.PACKS.values():
        for app in pack.flatpak:
            assert re.fullmatch(r"[a-z0-9]+(\.[A-Za-z0-9_\-]+){2,}", app), app


def test_check_pack():
    packs.check_pack("gaming")
    with pytest.raises(ValueError):
        packs.check_pack("gaming; rm -rf /")


@pytest.mark.parametrize("frase, pack", [("instala el pack de gaming", "gaming"),
                                         ("ponme el pack de juegos", "gaming"),
                                         ("instala el pack creativo", "creativo"),
                                         ("quiero el pack de programación", "programacion")])
def test_pack_rules(frase, pack):
    call = match(frase).calls[0]
    assert call.action_id == "packages.pack" and call.args == {"name": pack}


def test_pack_install_is_high_risk_and_needs_permission(broker):
    from umbra.security import ToolCall

    res = broker.execute(ToolCall("packages.pack", {"name": "gaming"}))
    assert res.status == "denied"  # sin package.install en la política por defecto
    assert broker.execute(ToolCall("packages.packs", {})).ok


def test_packs_refuse_live_session_and_check_space(tmp_path, monkeypatch):
    import pytest
    from umbra import packs

    monkeypatch.setattr(packs, "LIVE_MARK", tmp_path)  # existe -> sesión en vivo
    with pytest.raises(RuntimeError, match="sesión en vivo"):
        packs.install_pack("gaming")
    monkeypatch.setattr(packs, "LIVE_MARK", tmp_path / "no")
    import collections
    Usage = collections.namedtuple("Usage", "total used free")
    monkeypatch.setattr(packs.shutil, "disk_usage", lambda p: Usage(10, 0, 3 * 1024 ** 3))
    with pytest.raises(RuntimeError, match="no hay espacio"):
        packs.check_space(packs.PACKS["gaming"])
    monkeypatch.setattr(packs.shutil, "disk_usage", lambda p: Usage(10, 0, 50 * 1024 ** 3))
    packs.check_space(packs.PACKS["gaming"])


def test_helper_refuses_live_session():
    from pathlib import Path
    helper = Path(__file__).resolve().parents[1] / "iso/config/includes.chroot/usr/libexec/umbra/instalar-pack"
    assert "/run/live/medium" in helper.read_text()
