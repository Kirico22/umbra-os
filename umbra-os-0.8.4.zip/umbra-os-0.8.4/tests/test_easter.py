"""Pruebas de los easter eggs (¡spoilers!)."""

import datetime as dt
import random

import pytest

from umbra.nyx import easter
from umbra.nyx import Nyx
from umbra.sphere import ParticleSphere


@pytest.mark.parametrize("text, contains, effect", [
    ("NYX, ¿quién te creó?", "Héctor", None),
    ("¿Cuál es el sentido de la vida?", "42", None),
    ("hazme un sándwich", "sudo", None),
    ("sudo hazme un sándwich", "Marchando", None),
    ("hazme un café", "418", None),
    ("abre las puertas, NYX", "no puedo", None),
    ("¿qué es Umbra?", "ciudad", None),
    ("haz un barrel roll", "Wii", "barrel_roll"),
    ("big bang", "1…", "supernova"),
    ("modo arcoíris", "arcoíris", "arcoiris"),
    ("matrix", "conejo", "matrix"),
])
def test_secret_phrases(text, contains, effect):
    egg = easter.match(text)
    assert egg is not None and contains in egg.reply and egg.effect == effect


def test_jokes_and_normal_orders():
    assert easter.match("cuéntame un chiste", rnd=random.Random(1)).reply in easter.JOKES
    assert easter.match("analiza el rendimiento del sistema") is None


def test_special_days():
    assert "cumpleaños de UMBRA" in easter.greeting(dt.date(2026, 11, 20))
    assert "cumple 3 años" in easter.greeting(dt.date(2029, 11, 20))
    assert "Halloween" in easter.greeting(dt.date(2027, 10, 31))
    assert easter.seasonal_effect(dt.date(2027, 10, 31)) == "halloween"
    assert "noches" in easter.greeting(dt.date(2027, 3, 3), dt.datetime(2027, 3, 3, 23, 0))


def test_konami_code():
    k = easter.KonamiTracker()
    seq = ["Up", "Up", "Down", "Down", "Left", "Right", "Left", "Right", "b", "a"]
    assert not any(k.feed(x) for x in seq[:-1]) and k.feed("a")
    k2 = easter.KonamiTracker()
    assert not any(k2.feed(x) for x in ["Up", "Up", "Up", "Down", "Down", "Left", "Right", "Left", "Right", "B"]) \
        and k2.feed("A")  # un «Up» de más no rompe el código; mayúsculas valen


def test_click_burst():
    b = easter.ClickBurst(count=5, window=2.0)
    assert not any(b.click(t) for t in (0, 0.3, 0.6, 0.9))
    assert b.click(1.2)
    assert not b.click(5) and not b.click(9)


def test_nyx_reports_effect(broker, memory):
    nyx = Nyx(broker, memory, None)
    nyx.handle("supernova")
    assert nyx.last_effect == "supernova"
    nyx.handle("analiza el rendimiento")
    assert nyx.last_effect is None


def test_sphere_effects():
    s = ParticleSphere(n=100)
    calm = max(p.x for p in s.project(0, 0, 50))
    s.trigger("supernova")
    for _ in range(36):  # a mitad de la explosión
        s.update(1 / 30)
    assert max(p.x for p in s.project(0, 0, 50)) > calm * 2
    for _ in range(60):
        s.update(1 / 30)
    assert "supernova" not in s.effects  # termina sola
    s.trigger("arcoiris")
    assert s.tint(0) is not None and s.tint(0) != s.tint(50)


def test_secret_accent_needs_unlock(tmp_path, monkeypatch):
    from umbra import theme
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    theme.save(theme.Appearance(acento="nebulosa"))
    assert theme.load().acento == "morado"
    theme.save(theme.Appearance(acento="nebulosa", secreto=True))
    assert theme.load().acento == "nebulosa"
