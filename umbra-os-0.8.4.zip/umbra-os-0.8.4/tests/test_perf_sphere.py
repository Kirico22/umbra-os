from umbra import perf


def test_sphere_every_by_mode():
    assert perf.sphere_every("maximo") == (1, 3)
    assert perf.sphere_every("ligero") == (2, 4)
    active, idle = perf.sphere_every("equilibrado")
    assert active < idle
