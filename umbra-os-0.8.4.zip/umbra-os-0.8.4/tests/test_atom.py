from umbra.atom import FUSION_TIME, MINI_ATOMS, AtomScene


def _advance(scene, seconds, dt=1 / 30):
    for _ in range(int(seconds / dt)):
        scene.update(dt)


def test_idle_atom_has_nucleus_and_electrons():
    f = AtomScene().frame()
    kinds = [b.kind for b in f.balls]
    assert kinds.count("proton") == 7 and kinds.count("neutron") == 7 and kinds.count("electron") == 3
    assert not f.effects


def test_electrons_move():
    s = AtomScene()
    before = [(b.x, b.y) for b in s.frame().balls if b.kind == "electron"]
    _advance(s, 1.0)
    after = [(b.x, b.y) for b in s.frame().balls if b.kind == "electron"]
    assert before != after


def test_fusion_sequence():
    s = AtomScene()
    assert s.hit_nucleus(10, 20) and not s.hit_nucleus(400, 0)
    assert s.trigger_fusion() and not s.trigger_fusion()  # no se acumulan
    _advance(s, 0.9)
    f = s.frame()
    assert any(e.kind == "glow" for e in f.effects) and any(e.kind == "ring" for e in f.effects)
    _advance(s, 0.6)  # 1,5 s: mini átomos volando, sin núcleo
    f = s.frame()
    minis = [b for b in f.balls if b.kind.startswith("mini")]
    assert len(minis) == MINI_ATOMS and not any(b.kind in ("proton", "neutron") for b in f.balls)
    assert max(abs(b.x) for b in minis) > 150
    _advance(s, FUSION_TIME)  # vuelve al reposo
    assert not s.fusing
    kinds = [b.kind for b in s.frame().balls]
    assert kinds.count("proton") == 7 and not any(k.startswith("mini") for k in kinds)
