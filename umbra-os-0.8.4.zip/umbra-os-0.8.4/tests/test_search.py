from umbra import search


def test_search_apps_files_and_nyx(tmp_path):
    apps = tmp_path / "applications"
    apps.mkdir()
    (apps / "chromium.desktop").write_text("[Desktop Entry]\nType=Application\nName=Chromium\nComment=Navegador web\n")
    (apps / "xfce4-display-settings.desktop").write_text("[Desktop Entry]\nType=Application\nName=Pantalla\nComment=Ajustes de pantalla\n")
    home = tmp_path / "home"
    (home / "Documentos").mkdir(parents=True)
    (home / "Documentos" / "chromium-notas.txt").write_text("x")
    (home / ".oculto").mkdir()
    (home / ".oculto" / "chromium-secreto").write_text("x")

    res = search.search("chrom", root=home, app_dirs=[apps])
    kinds = [(r.kind, r.title) for r in res]
    assert kinds[0] == ("app", "Chromium")
    assert ("archivo", "chromium-notas.txt") in kinds
    assert all("secreto" not in t for _, t in kinds)  # no entra en carpetas ocultas
    assert res[-1].kind == "nyx" and res[-1].target == "chrom"

    res = search.search("pantalla", root=home, app_dirs=[apps])
    assert res[0].kind == "ajuste"


def test_empty_query():
    assert search.search("   ") == []
