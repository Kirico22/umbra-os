# Seguridad de UMBRA OS

La seguridad es prioridad absoluta. Principio: **privilegios mínimos**.

## Garantías básicas (desde v0.1.0)

1. **NYX no ejecuta comandos generados por el modelo.** No existe ninguna acción tipo
   "ejecutar shell". El modelo solo puede pedir acciones registradas por nombre.
2. **Intermediario obligatorio.** Toda acción pasa por `security/broker.py`.
3. **Lista de operaciones permitidas.** Solo existen las acciones registradas por módulos;
   los argumentos se validan (sin claves extra, tipos estrictos).
4. **Permisos por módulo.** Cada módulo declara los permisos que solicita; la política
   decide cuáles se conceden. Por defecto solo lectura y memoria propia.
5. **Confirmación humana.** Riesgo MEDIO: `s/N`. Riesgo ALTO: escribir `CONFIRMAR`.
   Sin terminal interactivo, se cancela. Si la confirmación falla, cuenta como "no".
6. **Auditoría.** Cada intento (aceptado, rechazado, denegado, cancelado o con error) se
   añade a `~/.local/share/umbra/audit.log` (permisos 600). Los argumentos con nombres
   de secreto (`password`, `token`…) se ocultan.
7. **El modelo no puede concederse permisos.** La política se lee de `/etc/umbra/policy.toml`
   (propiedad de root). Ninguna acción la modifica.
8. **Módulos no confiables.** Un módulo con `trusted=False` no recibe ningún permiso.
9. **Rutas confinadas.** El módulo de archivos resuelve enlaces simbólicos y `..` y solo
   actúa dentro de `allowed_roots`.
10. **Datos privados.** La memoria (SQLite) se crea con permisos 600. NYX funciona en local;
    no envía datos a ningún servicio externo.

## Acciones que modifican el sistema (v0.2.0)

| Acción | Riesgo | Protección |
|---|---|---|
| `files.organize`, `files.undo_organize` | MEDIO | Confirmación; nunca sobrescribe; solo primer nivel; registro para deshacer |
| `processes.stop` | MEDIO | Confirmación; solo procesos del propio usuario; nunca root, PID 1 ni NYX |
| `packages.install` | ALTO | Escribir CONFIRMAR **y** contraseña de administrador vía polkit (`pkexec`); nombre validado con expresión estricta; sin shell |
| `apps.open` | BAJO | Solo lanzadores `.desktop` instalados (se ejecuta su identificador, no el texto del modelo) |

En la ISO, `/etc/umbra/policy.toml` concede `files.write`, `process.control` y `package.install`.

## Navegadores

Opera GX y Google Chrome se instalan con `/usr/libexec/umbra/instalar-navegador`, que solo acepta
dos valores fijos (`opera-gx` o `chrome`) y se ejecuta con polkit (`pkexec`), pidiendo la contraseña
de administrador. Los repositorios van firmados (`Signed-By`) y se quitan si falta su clave.

## Voz

La voz se genera en el propio equipo (Piper o espeak-ng). Ni el texto ni el audio salen del equipo;
los audios temporales se borran al terminar de sonar.

## Protección contra descargas dañinas (v0.6.0)

### NYX analiza lo que descargas
`umbra-vigia` arranca con la sesión y vigila la carpeta Descargas. Cuando una descarga termina (ignora
`.crdownload`, `.part`, `.opdownload`… y espera a que el tamaño deje de cambiar), NYX la analiza **sin
abrirla ni ejecutarla** (`src/umbra/scanner.py`, Python puro, sin conexión a internet):

| Comprueba | Ejemplo |
|---|---|
| Tipo real por los primeros bytes, no por la extensión | `vacaciones.jpg` que en realidad es un programa |
| Extensiones dobles y caracteres invisibles que invierten el nombre | `factura.pdf.exe`, `foto<U+202E>gpj.sh` |
| Órdenes peligrosas en scripts y lanzadores | `curl … \| sh`, `base64 -d \| bash`, `/dev/tcp`, `rm -rf /`, mineros, bomba fork, setuid |
| Macros de Office y PDF con JavaScript o `/Launch` | macros que se ejecutan al abrir, plantillas remotas |
| Comprimidos (zip, tar.gz/xz/bz2) por dentro | bombas zip, rutas con `..`, contenido cifrado, programas disfrazados |
| Scripts de instalación de paquetes `.deb` | `postinst` que descarga y ejecuta código como root |
| Firma de prueba EICAR, lista local de huellas SHA-256 y ClamAV | `/usr/share/umbra/firmas.txt`, `~/.local/share/umbra/firmas.txt` |

Veredictos: **seguro**, **precaución** (programas, scripts, macros, comprimidos con contraseña) y
**peligroso** (engaños o código dañino). Si algo no es seguro:
1. le quita el permiso de ejecución al momento,
2. lo apunta en el registro de auditoría (`vigia.analisis`),
3. abre el **aviso de NYX** (`umbra-aviso`) con los motivos y, si es peligroso, lo dice en voz alta.

NYX **nunca borra ni mueve nada por su cuenta**: la cuarentena la decide el usuario con el botón
del aviso o diciéndoselo a NYX. La cuarentena pasa por el broker como cualquier acción (permiso
`files.write` en la política, auditoría) y deja el archivo en `~/.local/share/umbra/cuarentena`
con permisos `000`. Restaurar es riesgo ALTO (hay que escribir CONFIRMAR), nunca sobrescribe y
devuelve el archivo sin permiso de ejecución.

ClamAV: `clamscan` carga ~1 GB de firmas en cada uso, así que el vigía solo usa el demonio `clamd` si
está activo; los análisis manuales sí usan `clamscan`. En Ajustes → Seguridad se puede pedir ClamAV
en cada descarga. Ni los archivos ni sus huellas se envían a ningún servicio externo.

Límites honestos: es un análisis estático. Detecta los engaños y patrones más habituales, pero un
programa dañino bien escondido puede pasar. «Seguro» significa «no he encontrado nada sospechoso».

### Sistema endurecido de serie
- **Cortafuegos ufw activo**: bloquea todo lo que entra, permite lo que sale.
- **AppArmor** con perfiles extra (`apparmor-profiles`, `apparmor-profiles-extra`).
- **Parches de seguridad automáticos** (`unattended-upgrades`, solo el canal de seguridad de Debian)
  y `needrestart` para avisar de servicios que deben reiniciarse.
- **Núcleo** (`/etc/sysctl.d/99-umbra.conf`): `kptr_restrict=2`, `dmesg_restrict=1`,
  `ptrace_scope=1`, BPF solo para root, `fs.protected_*`, sin redirecciones ICMP, `rp_filter`,
  `tcp_syncookies`, `suid_dumpable=0`. No se tocan los *user namespaces* porque el aislamiento
  (sandbox) de Chrome y Chromium los necesita.
- Carpetas personales nuevas con permisos `0700`.
- El registro de auditoría rota a los 5 MB (guarda 3 copias).
- Una prueba impide que el código lleve caracteres de inversión de texto («Trojan Source»).

`nyx "¿estoy protegido?"` o Ajustes → Seguridad muestran el estado de todo esto.

## Novedades de seguridad de la 0.7.0

- **Micrófono**: «Oye NYX» está apagado por defecto. Cuando se activa, Vosk escucha con un vocabulario
  mínimo (solo la frase de activación); el audio se procesa en memoria y nunca se guarda ni se envía.
- **Cerebro local**: el modelo se descarga solo cuando el usuario lo pide, desde la URL fija oficial, y se
  borra si su SHA-256 no coincide con la huella fijada en el código. llama-server escucha solo en
  127.0.0.1 y NYX no usa la opción `--sleep-idle-seconds` (afectada por CVE-2026-43631/43632). El modelo
  sigue sin poder ejecutar nada: solo propone acciones al broker.
- **Rutinas**: pasan por el broker. Riesgo bajo: se hacen solas; medio: preguntan con una notificación;
  alto: nunca se ejecutan desde una rutina. Una rutina no puede crear ni borrar rutinas.
- **Packs**: el ayudante de polkit solo acepta el nombre del pack; las listas de paquetes están escritas
  dentro (una prueba comprueba que coinciden con las de NYX). Flathub se instala solo para el usuario.
- **Modo seguro**: sesión sin cerebro, sin animaciones ni rutinas; el vigía de descargas sigue activo.
- **Cifrado**: el instalador ofrece «Cifrar el sistema» (LUKS1, compatible con el GRUB de Debian 13) y no
  preselecciona borrar el disco.

## Conceder permisos extra

`/etc/umbra/policy.toml` (solo root puede editarlo):
```toml
[grants]
services = ["service.control"]
```

## Pendiente

- Ejecutar UMBRA CORE como usuario de sistema `umbra` sin privilegios.
- Acciones administrativas vía polkit (autorización del sistema, no de NYX).
- Firma de módulos externos antes de marcarlos como confiables.
- Procedimiento de recuperación (modo seguro sin módulos externos).

## Informar de un problema

Abre una incidencia privada en el repositorio.
