"""Buscador y cajón de aplicaciones de UMBRA OS (botón de NYX en la barra o Super + Espacio).

Ventana de cristal centrada. Sin escribir nada muestra todas las aplicaciones en cuadrícula,
por categorías; al escribir busca aplicaciones, ajustes, archivos y te deja preguntar a NYX.
Flechas para moverse, Intro para abrir, Esc para cerrar.
"""

from __future__ import annotations

import subprocess
import sys
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import theme  # noqa: E402
from .modules.apps import GROUPS  # noqa: E402
from .search import Result, all_apps, search  # noqa: E402
from .sphere import ParticleSphere  # noqa: E402
from .widgets import SpeakingSphere, draw_sphere, wmctrl  # noqa: E402

ICONS = {"app": "application-x-executable", "ajuste": "preferences-system", "archivo": "text-x-generic",
         "carpeta": "folder", "nyx": "dialog-question"}

EXTRA_CSS = """
.search-entry { font-size: 20px; padding: 14px 16px; }
.result-title { font-size: 14px; color: #ffffff; }
.kind { font-size: 10px; letter-spacing: 1px; color: @accent_light; }
list.results { background: transparent; }
list.results row { background: transparent; padding: 0; }
.answer { font-family: "DejaVu Sans Mono", monospace; font-size: 12px; color: #f3eefc; }
flowbox.apps { background: transparent; }
flowbox.apps flowboxchild { padding: 0; border-radius: 16px; background: transparent; }
flowbox.apps flowboxchild:selected, flowbox.apps flowboxchild:hover { background: alpha(@accent, 0.22); }
.app-tile { padding: 10px 4px 8px 4px; }
.app-name { font-size: 12px; color: #f3eefc; }
button.chip { border-radius: 999px; padding: 4px 14px; min-height: 0; font-size: 12px;
              background: alpha(#ffffff, 0.06); border: 1px solid alpha(#ffffff, 0.12); color: #d9cff0; }
button.chip.on { background: alpha(@accent, 0.55); border-color: alpha(@accent_light, 0.8); color: #ffffff; }
"""
WIN_W, WIN_H = 780, 600


class SearchWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title="Aplicaciones de UMBRA", decorated=False, resizable=False)
        self.add_css_class("glass")
        self.set_default_size(WIN_W, WIN_H)
        self.look = theme.load()
        self.results: list[Result] = []
        self._query_id = 0
        self._nyx = None

        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        panel.add_css_class("glass-panel")
        for side in ("top", "bottom", "start", "end"):
            getattr(panel, f"set_margin_{side}")(18)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for side in ("top", "bottom", "start", "end"):
            getattr(inner, f"set_margin_{side}")(16)

        top = Gtk.Box(spacing=12)
        self.sphere = ParticleSphere(n=150)
        self.speaker = SpeakingSphere(self.sphere, warm=False)  # la voz se carga solo si preguntas a NYX
        self.speaker.enabled = self.look.voz and self.speaker.voice.available
        orb = Gtk.DrawingArea(content_width=52, content_height=52)
        orb.set_draw_func(lambda _a, cr, w, h: draw_sphere(cr, self.sphere, w / 2, h / 2, w * 0.3,
                                                           self.look.rgb(0), halo=False))
        self._last = None
        orb.add_tick_callback(self._tick)
        self.orb = orb
        self.entry = Gtk.Entry(placeholder_text="Escribe para buscar apps, archivos, ajustes… o pregúntale a NYX",
                               hexpand=True)
        self.entry.add_css_class("glass-entry")
        self.entry.add_css_class("search-entry")
        self.entry.connect("changed", self._changed)
        self.entry.connect("activate", lambda _e: self._open_selected())
        top.append(orb)
        top.append(self.entry)

        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.listbox.add_css_class("results")
        self.listbox.connect("row-activated", lambda _l, row: self._open(self.results[row.get_index()]))
        scroller = Gtk.ScrolledWindow(vexpand=True)
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_child(self.listbox)

        self.answer = Gtk.Label(xalign=0, wrap=True, selectable=True)
        self.answer.add_css_class("answer")
        self.answer_rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=220)
        self.answer_rev.set_child(self.answer)

        results_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        results_page.append(self.answer_rev)
        results_page.append(scroller)

        # Cajón de aplicaciones: chips de categoría + cuadrícula
        self.apps = all_apps()
        self.group = "todas"
        chips = Gtk.Box(spacing=6)
        self.chips: dict[str, Gtk.Button] = {}
        present = {a["grupo"] for a in self.apps}
        for key, label in [("todas", "Todas"), *[(k, lbl) for k, lbl, _ in GROUPS if k in present],
                           *([("otras", "Otras")] if "otras" in present else [])]:
            b = Gtk.Button(label=label)
            b.add_css_class("chip")
            b.connect("clicked", lambda _b, k=key: self._set_group(k))
            chips.append(b)
            self.chips[key] = b
        self.flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.SINGLE, homogeneous=True,
                                max_children_per_line=6, min_children_per_line=4, row_spacing=6,
                                column_spacing=6, activate_on_single_click=True, valign=Gtk.Align.START)
        self.flow.add_css_class("apps")
        self.flow.connect("child-activated", lambda _f, child: self._launch(child.app_id))
        self.flow.set_filter_func(lambda child: self.group == "todas" or child.group == self.group)
        for a in self.apps:
            self.flow.append(self._tile(a))
        grid_scroll = Gtk.ScrolledWindow(vexpand=True)
        grid_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        grid_scroll.set_child(self.flow)
        apps_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        apps_page.append(chips)
        apps_page.append(grid_scroll)
        self._set_group("todas")

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=150,
                               vexpand=True)
        self.stack.add_named(apps_page, "apps")
        self.stack.add_named(results_page, "results")
        self.stack.set_visible_child_name("apps")

        self.hint = Gtk.Label(label=f"{len(self.apps)} aplicaciones · escribe para buscar · Esc para cerrar", xalign=0)
        self.hint.add_css_class("glass-dim")
        inner.append(top)
        inner.append(self.stack)
        inner.append(self.hint)
        panel.append(inner)
        self.set_child(panel)

        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._key)
        self.add_controller(keys)
        # Al perder el foco (clic fuera), el buscador se cierra
        self.connect("notify::is-active", lambda w, _p: (not w.is_active() and not self._nyx_busy()
                                                          and GLib.timeout_add(150, self._close_if_inactive)))

    def _tile(self, app: dict) -> Gtk.FlowBoxChild:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.add_css_class("app-tile")
        icon = Gtk.Image.new_from_icon_name(app["icono"])
        icon.set_pixel_size(48)
        name = Gtk.Label(label=app["nombre"], ellipsize=3, max_width_chars=12, justify=Gtk.Justification.CENTER)
        name.add_css_class("app-name")
        box.append(icon)
        box.append(name)
        child = Gtk.FlowBoxChild()
        child.set_child(box)
        child.set_tooltip_text(app["descripcion"] or app["nombre"])
        child.app_id, child.group = app["id"], app["grupo"]
        return child

    def _set_group(self, key: str) -> None:
        self.group = key
        for k, b in self.chips.items():
            (b.add_css_class if k == key else b.remove_css_class)("on")
        self.flow.invalidate_filter()

    def _launch(self, app_id: str) -> None:
        try:
            subprocess.Popen(["gtk-launch", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except OSError:
            pass
        self.close()

    def _nyx_busy(self) -> bool:
        return self.sphere.state != "reposo"

    def _close_if_inactive(self) -> bool:
        if not self.is_active():
            self.close()
        return False

    def _tick(self, _w, clock) -> bool:
        now = clock.get_frame_time() / 1e6
        dt = 1 / 60 if self._last is None else now - self._last
        self._last = now
        self.speaker.tick()
        self._frame = getattr(self, "_frame", 0) + 1
        every = 1 if self.sphere.state != "reposo" else 3  # en reposo, 20 fps
        if self._frame % every:
            return True
        self.sphere.update(dt * every)
        self.orb.queue_draw()
        return True

    # --- búsqueda (en segundo plano para no bloquear al escribir) -----------------------
    def _changed(self, entry) -> None:
        self._query_id += 1
        qid, text = self._query_id, entry.get_text()
        self.answer_rev.set_reveal_child(False)
        if not text.strip():
            self.stack.set_visible_child_name("apps")
            self.hint.set_label(f"{len(self.apps)} aplicaciones · escribe para buscar · Esc para cerrar")
            return
        self.stack.set_visible_child_name("results")
        self.hint.set_label("↑ ↓ para elegir · Intro para abrir · Esc para cerrar")

        def work() -> None:
            time.sleep(0.12)  # espera a que dejes de teclear
            if qid != self._query_id:
                return
            res = search(text)
            GLib.idle_add(self._show, qid, res)

        threading.Thread(target=work, daemon=True).start()

    def _show(self, qid: int, results: list[Result]) -> bool:
        if qid != self._query_id:
            return False
        self.results = results
        self.listbox.remove_all()
        for r in results:
            row = Gtk.Box(spacing=12)
            row.add_css_class("glass-row")
            icon = Gtk.Image.new_from_icon_name(r.icon or ICONS[r.kind] if r.kind in ("app", "ajuste") else ICONS[r.kind])
            icon.set_pixel_size(30)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t = Gtk.Label(label=r.title, xalign=0, ellipsize=3)
            t.add_css_class("result-title")
            s = Gtk.Label(label=r.subtitle, xalign=0, ellipsize=3)
            s.add_css_class("glass-dim")
            texts.append(t)
            texts.append(s)
            kind = Gtk.Label(label=r.kind.upper(), hexpand=True, xalign=1)
            kind.add_css_class("kind")
            row.append(icon)
            row.append(texts)
            row.append(kind)
            self.listbox.append(row)
        first = self.listbox.get_row_at_index(0)
        if first:
            self.listbox.select_row(first)
        return False

    def _key(self, _c, keyval, _code, _state) -> bool:
        if keyval == Gdk.KEY_Escape:
            self.close()
            return True
        if self.stack.get_visible_child_name() == "apps":
            if keyval == Gdk.KEY_Down and self.entry.has_focus():
                first = next((c for c in self._children() if c.get_child_visible()), None)
                if first:
                    self.flow.select_child(first)
                    first.grab_focus()
                return True
            return False
        if keyval in (Gdk.KEY_Down, Gdk.KEY_Up) and self.results:
            row = self.listbox.get_selected_row()
            i = row.get_index() if row else -1
            i = min(len(self.results) - 1, i + 1) if keyval == Gdk.KEY_Down else max(0, i - 1)
            self.listbox.select_row(self.listbox.get_row_at_index(i))
            return True
        return False

    def _children(self):
        child = self.flow.get_first_child()
        while child is not None:
            yield child
            child = child.get_next_sibling()

    def _open_selected(self) -> None:
        if self.stack.get_visible_child_name() == "apps":
            sel = self.flow.get_selected_children()
            if sel:
                self._launch(sel[0].app_id)
            return
        row = self.listbox.get_selected_row()
        if row is not None and self.results:
            self._open(self.results[row.get_index()])

    def _open(self, r: Result) -> None:
        if r.kind == "nyx":
            self._ask_nyx(r.target)
            return
        cmd = ["gtk-launch", r.target] if r.kind in ("app", "ajuste") else ["xdg-open", r.target]
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError:
            pass
        self.close()

    def _ask_nyx(self, text: str) -> None:
        if self._nyx is None:
            from .cli import build_nyx, make_provider
            from .config import load_config

            cfg = load_config()
            provider, _ = make_provider(cfg)
            self._nyx = build_nyx(cfg, provider)
        self.speaker.thinking()
        self.answer.set_label("…")
        self.answer_rev.set_reveal_child(True)

        def work() -> None:
            try:
                reply = self._nyx.handle(text)
            except Exception as exc:
                reply = f"Ha ocurrido un error: {exc}"
            GLib.idle_add(self._answer, reply)

        threading.Thread(target=work, daemon=True).start()

    def _answer(self, reply: str) -> bool:
        self.answer.set_label(reply)
        if self._nyx.last_effect:
            self.sphere.trigger(self._nyx.last_effect)
        self.speaker.say(reply)
        return False


class SearchApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.Buscar")

    def do_activate(self) -> None:
        win = self.props.active_window
        if win:  # segunda pulsación de Super+Espacio: se cierra
            win.close()
            return
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data((theme.glass_css() + EXTRA_CSS).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        win = SearchWindow(self)
        win.present()
        win.entry.grab_focus()
        GLib.timeout_add(60, self._center, win)

    def _center(self, win) -> bool:
        """Centrado en horizontal y a un tercio de altura, como un buscador tipo Spotlight."""
        monitors = Gdk.Display.get_default().get_monitors()
        if monitors.get_n_items():
            geo = monitors.get_item(0).get_geometry()
            x = geo.x + (geo.width - WIN_W) // 2
            y = geo.y + max(20, (geo.height - WIN_H) // 2 - 30)
            wmctrl("-r", "Aplicaciones de UMBRA", "-e", f"0,{x},{y},-1,-1")
        return False


def main() -> int:
    GLib.set_prgname("umbra-buscar")  # clase de ventana «Umbra-buscar»: picom le pone el cristal
    return SearchApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
