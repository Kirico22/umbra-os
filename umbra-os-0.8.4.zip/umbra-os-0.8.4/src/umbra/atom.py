"""Modelo del átomo vivo del escritorio (matemática pura, sin GTK).

En reposo: el núcleo (protones y neutrones, cada uno una bolita de partículas) gira despacio
y tres electrones recorren sus órbitas.

🥚 Fusión (clic derecho sobre el núcleo):
  0,0–0,7 s  colapso: los nucleones caen al centro y los electrones entran en espiral
  0,7–1,2 s  destello blanco
  0,7–2,2 s  onda expansiva
  0,9–3,4 s  mini átomos que salen disparados en todas direcciones y se desvanecen
  3,0–4,8 s  el átomo se recompone partícula a partícula
Las coordenadas son relativas al centro del átomo, en píxeles de una pantalla de 1080 px de alto.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from .sphere import ParticleSphere, fibonacci_sphere

ORBIT_A, ORBIT_B = 430.0, 128.0
ORBIT_ANGLES = (math.radians(-28), math.radians(32), math.radians(92))
ELECTRON_SPEED = (0.50, 0.41, 0.33)
NUCLEUS_SPREAD = 60.0
FUSION_TIME = 4.8
MINI_ATOMS = 12


def _ease(p: float) -> float:
    p = max(0.0, min(1.0, p))
    return p * p * (3 - 2 * p)


def _window(t: float, start: float, end: float) -> float | None:
    """Progreso 0..1 si t está en [start, end); None si no."""
    if start <= t < end:
        return (t - start) / (end - start)
    return None


@dataclass
class Ball:
    x: float
    y: float
    radius: float
    kind: str  # proton | neutron | electron | mini
    sphere: ParticleSphere
    alpha: float = 1.0
    depth: float = 0.0


@dataclass
class Effect:
    kind: str  # glow | ring | mini-orbit
    x: float
    y: float
    radius: float
    alpha: float


@dataclass
class Frame:
    balls: list[Ball] = field(default_factory=list)
    effects: list[Effect] = field(default_factory=list)
    orbit_scale: float = 1.0
    orbit_alpha: float = 1.0
    electrons: list[tuple[int, float]] = field(default_factory=list)  # (órbita, ángulo) para estelas


def orbit_point(i: int, angle: float, scale: float = 1.0) -> tuple[float, float, float]:
    x, y = ORBIT_A * scale * math.cos(angle), ORBIT_B * scale * math.sin(angle)
    a = ORBIT_ANGLES[i]
    return x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a), math.sin(angle)


class AtomScene:
    def __init__(self, seed: int = 7) -> None:
        rnd = random.Random(seed)
        self.t = 0.0
        self.spin = 0.0
        self.fusion_start: float | None = None
        self.nucleons = [(x, y, z, "proton" if i % 2 == 0 else "neutron", ParticleSphere(n=40, seed=i))
                         for i, (x, y, z) in enumerate(fibonacci_sphere(14))]
        self.electron_phase = [0.35, 2.4, 4.3]
        self.electron_spheres = [ParticleSphere(n=30, seed=40 + i) for i in range(3)]
        self.minis = []
        for k in range(MINI_ATOMS):
            ang = k / MINI_ATOMS * math.tau + rnd.uniform(-0.2, 0.2)
            self.minis.append({
                "dir": (math.cos(ang), math.sin(ang) * 0.75),
                "speed": rnd.uniform(420, 700),
                "sphere": ParticleSphere(n=34, seed=100 + k),
                "esphere": ParticleSphere(n=12, seed=200 + k),
                "orbit": rnd.uniform(0, math.tau),
                "tilt": rnd.uniform(-1.2, 1.2),
                "kind": "proton" if k % 3 else "neutron",
            })

    @property
    def fusing(self) -> bool:
        return self.fusion_start is not None

    def trigger_fusion(self) -> bool:
        if self.fusing:
            return False
        self.fusion_start = self.t
        return True

    def hit_nucleus(self, x: float, y: float, scale: float = 1.0) -> bool:
        """¿El punto (relativo al centro) cae sobre el núcleo?"""
        return math.hypot(x, y) <= (NUCLEUS_SPREAD + 45) * scale

    def update(self, dt: float) -> None:
        dt = max(0.0, min(dt, 0.1))
        self.t += dt
        self.spin += dt * 0.25
        speed_boost = 1.0
        if self.fusing:
            ft = self.t - self.fusion_start
            if ft < 0.7:
                speed_boost = 1 + 6 * ft  # los electrones aceleran al caer
            if ft >= FUSION_TIME:
                self.fusion_start = None
        for i in range(3):
            self.electron_phase[i] = (self.electron_phase[i] + ELECTRON_SPEED[i] * speed_boost * dt) % math.tau
        for _, _, _, _, sph in self.nucleons:
            sph.update(dt)
        for sph in self.electron_spheres:
            sph.update(dt)

    def frame(self) -> Frame:
        f = Frame()
        ft = self.t - self.fusion_start if self.fusing else None
        collapse = _ease(ft / 0.7) if ft is not None and ft < 0.7 else (1.0 if ft is not None and ft < 3.0 else 0.0)
        reform = _window(ft, 3.0, FUSION_TIME) if ft is not None else None
        appear = _ease(reform) if reform is not None else (0.0 if ft is not None and ft >= 0.7 else 1.0)

        # Órbitas y electrones: se encogen en espiral y vuelven a crecer al recomponerse
        if ft is None:
            scale = 1.0
        elif ft < 0.7:
            scale = 1 - collapse
        else:
            scale = appear
        f.orbit_scale = max(0.001, scale)
        f.orbit_alpha = 1.0 if ft is None else (1 - collapse * 0.9 if ft < 0.7 else appear)
        if scale > 0.02:
            for i, ang in enumerate(self.electron_phase):
                x, y, z = orbit_point(i, ang, scale)
                f.electrons.append((i, ang))
                f.balls.append(Ball(x, y, 15 + 3 * z, "electron", self.electron_spheres[i],
                                    alpha=f.orbit_alpha, depth=z * 2))

        # Núcleo: gira; cae al centro en el colapso; reaparece creciendo
        c, s = math.cos(self.spin), math.sin(self.spin)
        if ft is None or ft < 0.75 or reform is not None:
            for x, y, z, kind, sph in self.nucleons:
                rx, rz = x * c + z * s, -x * s + z * c
                pull = (1 - collapse) if ft is not None and ft < 0.75 else appear
                rad = (23 + 4 * rz) * (0.35 + 0.65 * pull if ft is not None else 1)
                f.balls.append(Ball(rx * NUCLEUS_SPREAD * pull, y * NUCLEUS_SPREAD * pull, rad, kind, sph,
                                    alpha=0.75 + 0.25 * (rz + 1) / 2 if ft is None else max(0.2, pull), depth=rz))

        if ft is not None:
            flash = _window(ft, 0.6, 1.25)
            if flash is not None:
                f.effects.append(Effect("glow", 0, 0, 60 + 460 * flash, math.sin(math.pi * flash) ** 0.6))
            ring = _window(ft, 0.7, 2.2)
            if ring is not None:
                f.effects.append(Effect("ring", 0, 0, 30 + 900 * _ease(ring) ** 0.8, (1 - ring) ** 1.5))
            fly = _window(ft, 0.9, 3.4)
            if fly is not None:
                dist = 1 - (1 - fly) ** 2.2  # salen rápido y frenan
                for m in self.minis:
                    mx = m["dir"][0] * m["speed"] * dist
                    my = m["dir"][1] * m["speed"] * dist
                    fade = 1.0 if fly < 0.6 else 1 - (fly - 0.6) / 0.4
                    f.balls.append(Ball(mx, my, 22, "mini-" + m["kind"], m["sphere"], alpha=fade, depth=3))
                    ea = m["orbit"] + self.t * 5
                    ex = mx + 52 * math.cos(ea) * math.cos(m["tilt"]) - 16 * math.sin(ea) * math.sin(m["tilt"])
                    ey = my + 52 * math.cos(ea) * math.sin(m["tilt"]) + 16 * math.sin(ea) * math.cos(m["tilt"])
                    f.balls.append(Ball(ex, ey, 8, "electron", m["esphere"], alpha=fade, depth=3.1))
                    f.effects.append(Effect("mini-orbit", mx, my, 52, fade * 0.45))
        f.balls.sort(key=lambda b: b.depth)
        return f
