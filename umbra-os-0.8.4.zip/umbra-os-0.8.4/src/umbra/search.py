"""Lógica del buscador de UMBRA (sin GTK, para poder probarla).

Busca a la vez en: aplicaciones, ajustes del sistema y archivos del usuario.
La última opción siempre es «Preguntar a NYX».
"""

from __future__ import annotations

import os
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from .modules.apps import installed

SETTINGS_HINTS = ("settings", "ajustes", "configuracion", "preferencias", "xfce4-", "umbra-ajustes")
MAX_FILE_SCAN = 40_000


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in text if not unicodedata.combining(c)).strip()


@dataclass
class Result:
    kind: str  # app | ajuste | archivo | carpeta | nyx
    title: str
    subtitle: str
    target: str  # id del lanzador, ruta o texto para NYX
    score: float
    icon: str = ""  # nombre del icono (apps y ajustes)


def _score(query: str, text: str) -> float:
    q, t = norm(query), norm(text)
    if not q or q not in t:
        return 0.0
    if t == q:
        return 1.0
    if t.startswith(q):
        return 0.9
    if any(w.startswith(q) for w in t.split()):
        return 0.75
    return 0.5


def search_apps(query: str, dirs=None) -> list[Result]:
    out = []
    for app in installed(dirs).values():
        s = max(_score(query, app["nombre"]), _score(query, app["id"]) * 0.9,
                _score(query, app["descripcion"]) * 0.6)
        if s:
            is_setting = any(h in app["id"].lower() or h in norm(app["nombre"]) for h in SETTINGS_HINTS)
            out.append(Result("ajuste" if is_setting else "app", app["nombre"],
                              app["descripcion"] or ("Ajuste del sistema" if is_setting else "Aplicación"),
                              app["id"], s + (0.05 if not is_setting else 0), app.get("icono", "")))
    return out


_INDEX: dict = {}
INDEX_TTL = 60.0


def _file_index(root: Path) -> list[tuple[str, str, bool]]:
    """Nombres de la carpeta personal (nombre normalizado, ruta, es carpeta). Se recorre una vez
    por minuto como mucho, no en cada tecla."""
    import time

    now = time.monotonic()
    if _INDEX.get("root") == root and now - _INDEX.get("at", -1e9) < INDEX_TTL:
        return _INDEX["items"]
    items: list[tuple[str, str, bool]] = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False, onerror=lambda e: None):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in ("node_modules", "__pycache__")]
        for name in dirnames:
            items.append((norm(name), os.path.join(dirpath, name), True))
        for name in filenames:
            items.append((norm(name), os.path.join(dirpath, name), False))
        if len(items) > MAX_FILE_SCAN:
            break
    _INDEX.update(root=root, at=now, items=items)
    return items


def search_files(query: str, root: Path | None = None, limit: int = 8) -> list[Result]:
    root = Path(root or Path.home())
    q = norm(query)
    if len(q) < 2:
        return []
    home = str(Path.home())
    out = []
    for name_n, full, is_dir in _file_index(root):
        if q not in name_n:
            continue
        s = _score(q, name_n)
        name = os.path.basename(full)
        out.append(Result("carpeta" if is_dir else "archivo", name, full.replace(home, "~", 1), full, s * 0.8))
        if len(out) > limit * 4:
            break
    out.sort(key=lambda r: -r.score)
    return out[:limit]


def all_apps(app_dirs=None) -> list[dict]:
    """Todas las aplicaciones, ordenadas por nombre, para el cajón de aplicaciones."""
    return sorted(installed(app_dirs).values(), key=lambda a: norm(a["nombre"]))


def search(query: str, root: Path | None = None, app_dirs=None) -> list[Result]:
    query = query.strip()
    if not query:
        return []
    results = search_apps(query, app_dirs) + search_files(query, root)
    results.sort(key=lambda r: -r.score)
    results = results[:12]
    results.append(Result("nyx", f"Preguntar a NYX: «{query}»", "NYX lo entiende y te responde", query, 0.0))
    return results
