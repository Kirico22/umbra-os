"""Packs de aplicaciones: grupos de programas que NYX instala de una vez.

- La parte de Debian (apt) la instala el ayudante /usr/libexec/umbra/instalar-pack como root,
  mediante polkit (pide la contraseña de administrador). El ayudante tiene las listas escritas
  dentro: solo acepta el NOMBRE del pack, nunca nombres de paquetes, así nadie puede colarle otro.
- La parte de Flathub (Flatpak) se instala solo para el usuario (--user), sin permisos de
  administrador, y cada aplicación queda aislada del sistema.

Una prueba comprueba que las listas de aquí y las del ayudante coinciden.
"""

from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

HELPER = "/usr/libexec/umbra/instalar-pack"
FLATHUB = "https://dl.flathub.org/repo/flathub.flatpakrepo"


@dataclass(frozen=True)
class Pack:
    id: str
    name: str
    description: str
    apt: tuple[str, ...]
    flatpak: tuple[str, ...] = ()
    size_mb: int = 1000  # lo que ocupa instalado, aproximado (incluye los runtimes de Flatpak)


PACKS: dict[str, Pack] = {p.id: p for p in (
    Pack("gaming", "Gaming", "Steam, Heroic (Epic y GOG), Lutris, Discord, ProtonUp-Qt, GameMode y MangoHud",
         apt=("gamemode", "mangohud"),
         flatpak=("com.valvesoftware.Steam", "com.heroicgameslauncher.hgl", "net.lutris.Lutris",
                  "com.discordapp.Discord", "net.davidotek.pupgui2"), size_mb=4500),
    Pack("creativo", "Creativo", "GIMP, Krita, Inkscape, Kdenlive, OBS Studio, Audacity y Blender",
         apt=("gimp", "krita", "inkscape", "kdenlive", "obs-studio", "audacity", "blender"), size_mb=3000),
    Pack("programacion", "Programación", "Git, Python, Node.js, compiladores y VSCodium",
         apt=("git", "python3-pip", "python3-venv", "nodejs", "npm", "build-essential"),
         flatpak=("com.vscodium.codium",), size_mb=1500),
    Pack("multimedia", "Multimedia", "Shotcut, HandBrake y Spotify",
         apt=("shotcut", "handbrake"), flatpak=("com.spotify.Client",), size_mb=1500),
)}

ALIASES = {
    "gaming": "gaming", "juegos": "gaming", "gamer": "gaming", "jugar": "gaming",
    "creativo": "creativo", "diseno": "creativo", "creatividad": "creativo", "edicion": "creativo",
    "programacion": "programacion", "programar": "programacion", "desarrollo": "programacion",
    "codigo": "programacion", "multimedia": "multimedia", "musica": "multimedia", "video": "multimedia",
}


def check_pack(name: str) -> None:
    if name not in PACKS:
        raise ValueError(f"pack desconocido: {name!r} (hay: {', '.join(PACKS)})")


def _run(cmd: list[str], timeout: int) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None


def flatpak_installed(app_id: str) -> bool:
    r = _run(["flatpak", "info", app_id], 20) if shutil.which("flatpak") else None
    return bool(r and r.returncode == 0)


LIVE_MARK = Path("/run/live/medium")
MARGIN_MB = 2048  # además del pack, que quede algo libre


def is_live() -> bool:
    """Sesión en vivo (USB o ISO sin instalar): todo lo que se instala va a la RAM."""
    return LIVE_MARK.exists()


LIVE_MSG = ("estás en la sesión en vivo: lo que instales se guarda en la memoria RAM, puede llenarla y "
            "dejar la pantalla en negro, y se borra al apagar. Instala UMBRA primero y luego pide el pack")


def check_space(pack: Pack, root: Path = Path("/"), home: Path | None = None) -> None:
    """Comprueba que caben los programas (la parte de Debian va a /, la de Flathub a tu carpeta)."""
    need = pack.size_mb + MARGIN_MB
    for where in {root, home or Path.home()}:
        try:
            free = shutil.disk_usage(where).free // 1024 ** 2
        except OSError:
            continue
        if free < need:
            raise RuntimeError(f"no hay espacio: el pack {pack.name} necesita unos {need // 1024 + 1} GB libres "
                               f"y en {where} quedan {free / 1024:.1f} GB")


def install_pack(name: str) -> dict:
    check_pack(name)
    pack = PACKS[name]
    if is_live():
        raise RuntimeError(LIVE_MSG)
    check_space(pack)
    done: list[str] = []
    failed: list[str] = []
    if pack.apt:
        if not Path(HELPER).exists() or shutil.which("pkexec") is None:
            raise RuntimeError("falta el instalador de packs de UMBRA")
        r = _run(["pkexec", HELPER, name], 3600)
        if r is not None and r.returncode == 126:
            raise PermissionError("la autorización de administrador se canceló o se denegó")
        if r is None or r.returncode != 0:
            raise RuntimeError("no se pudieron instalar los programas de Debian. ¿Hay conexión a internet?")
        done += list(pack.apt)
    if pack.flatpak:
        if shutil.which("flatpak") is None:
            failed += list(pack.flatpak)
        else:
            _run(["flatpak", "remote-add", "--user", "--if-not-exists", "flathub", FLATHUB], 120)
            for app in pack.flatpak:
                r = _run(["flatpak", "install", "--user", "-y", "--noninteractive", "flathub", app], 3600)
                (done if r is not None and r.returncode == 0 else failed).append(app)
    return {"pack": pack.name, "instalados": done, "fallidos": failed}


def list_packs() -> list[dict]:
    return [{"id": p.id, "nombre": p.name, "contenido": p.description,
             "ocupa": f"unos {p.size_mb / 1024:.1f} GB".replace(".", ",")} for p in PACKS.values()]
