"""Rutinas de NYX: órdenes que se repiten solas («cada viernes organiza las descargas»).

Seguridad:
- Una rutina es una orden de NYX como cualquier otra: pasa por el broker, sus permisos y la auditoría.
- Las acciones de riesgo BAJO se hacen solas. Las de riesgo MEDIO piden permiso con una notificación
  («¿Lo hago?»). Las de riesgo ALTO NUNCA se hacen desde una rutina: hay que pedirlas a mano.
- Una rutina no puede crear otras rutinas.
- Se guardan en ~/.config/umbra/rutinas.json (solo las lee y escribe tu usuario).
"""

from __future__ import annotations

import json
import os
import re
import unicodedata
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path

from .config import user_config_dir

DAYS = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"]
DAY_LABEL = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
MAX_ROUTINES = 30


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in text if not unicodedata.combining(c)).strip()


@dataclass
class Schedule:
    kind: str  # "hora" | "diario" | "semanal"
    day: int = 0  # 0 = lunes (solo semanal)
    hour: int = 10
    minute: int = 0

    def label(self) -> str:
        hhmm = f"{self.hour:02d}:{self.minute:02d}"
        if self.kind == "hora":
            return "cada hora"
        if self.kind == "diario":
            return f"todos los días a las {hhmm}"
        return f"cada {DAY_LABEL[self.day]} a las {hhmm}"

    def last_due(self, now: datetime) -> datetime:
        """Último momento (<= now) en que tocaba ejecutarla."""
        if self.kind == "hora":
            return now.replace(minute=0, second=0, microsecond=0)
        t = now.replace(hour=self.hour, minute=self.minute, second=0, microsecond=0)
        if self.kind == "diario":
            return t if t <= now else t - timedelta(days=1)
        t -= timedelta(days=(now.weekday() - self.day) % 7)
        return t if t <= now else t - timedelta(days=7)


def parse_schedule(text: str) -> Schedule:
    """«cada viernes a las 18:30», «todos los días a las 9», «cada hora», «cada lunes»…"""
    t = _norm(text)
    hour, minute = 10, 0
    m = re.search(r"a las (\d{1,2})(?:[:.h](\d{2}))?\s*(de la (manana|tarde|noche)|am|pm)?", t)
    if m:
        hour, minute = int(m.group(1)), int(m.group(2) or 0)
        part = m.group(4) or m.group(3) or ""
        if part in ("tarde", "noche", "pm") and hour < 12:
            hour += 12
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError("esa hora no existe")
    if re.search(r"\bcada hora\b", t):
        return Schedule("hora")
    if re.search(r"\b(todos los dias|cada dia|diariamente|a diario)\b", t):
        return Schedule("diario", hour=hour, minute=minute)
    for i, d in enumerate(DAYS):
        if re.search(rf"\b(cada|todos los|los)\s+{d}s?\b", t):
            return Schedule("semanal", day=i, hour=hour, minute=minute)
    raise ValueError("no entiendo cuándo: di por ejemplo «cada viernes a las 18:00» o «todos los días a las 9»")


SPLIT_RE = re.compile(
    r"^\s*(?:nyx[\s,:]*)?((?:cada|todos los|todas las)\s+[^,]*?(?:\s+a las \d{1,2}(?:[:.h]\d{2})?"
    r"(?:\s*(?:de la (?:manana|mañana|tarde|noche)|am|pm))?)?)[\s,]+(.+)$", re.IGNORECASE)


def split_request(text: str) -> tuple[str, str] | None:
    """«cada viernes a las 18:00 organiza las descargas» -> («cada viernes a las 18:00», «organiza las descargas»)."""
    m = SPLIT_RE.match(text.strip())
    if not m:
        return None
    when, order = m.group(1).strip(), m.group(2).strip().rstrip(".")
    # «cada día a las 9» puede quedar partido: lo que empiece por "a las" pertenece a "cuándo"
    m2 = re.match(r"^(a las \d{1,2}(?:[:.h]\d{2})?(?:\s*(?:de la \w+|am|pm))?)[\s,]+(.+)$", order, re.I)
    if m2:
        when, order = f"{when} {m2.group(1)}", m2.group(2)
    try:
        parse_schedule(when)
    except ValueError:
        return None  # «cada vez que abro Chrome va lento» no es una rutina
    return when, order


@dataclass
class Routine:
    id: int
    orden: str
    cuando: str
    schedule: dict
    ultima: str = ""  # ISO de la última ejecución

    @property
    def sched(self) -> Schedule:
        return Schedule(**self.schedule)


def path() -> Path:
    return user_config_dir() / "rutinas.json"


def load(p: Path | None = None) -> list[Routine]:
    try:
        raw = json.loads((p or path()).read_text(encoding="utf-8"))
        return [Routine(**r) for r in raw]
    except (OSError, ValueError, TypeError):
        return []


def save(items: list[Routine], p: Path | None = None) -> None:
    p = p or path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps([asdict(r) for r in items], ensure_ascii=False, indent=1), encoding="utf-8")
    os.chmod(tmp, 0o600)
    tmp.replace(p)


def check_order(orden: str) -> None:
    o = _norm(orden)
    if not o or len(o) > 200:
        raise ValueError("la orden de la rutina está vacía o es demasiado larga")
    if re.search(r"\brutina", o) or SPLIT_RE.match(orden):
        raise ValueError("una rutina no puede crear ni borrar rutinas")


def add(orden: str, cuando: str, now: datetime | None = None, p: Path | None = None) -> dict:
    check_order(orden)
    sched = parse_schedule(cuando)
    items = load(p)
    if len(items) >= MAX_ROUTINES:
        raise ValueError(f"como mucho {MAX_ROUTINES} rutinas")
    rid = max((r.id for r in items), default=0) + 1
    # Se marca como hecha en su último turno para que no se dispare nada más crearla
    last = sched.last_due(now or datetime.now()).isoformat(timespec="minutes")
    r = Routine(rid, orden.strip(), sched.label(), asdict(sched), last)
    items.append(r)
    save(items, p)
    return {"id": rid, "orden": r.orden, "cuando": r.cuando}


def remove(rid: int, p: Path | None = None) -> dict:
    items = load(p)
    keep = [r for r in items if r.id != rid]
    if len(keep) == len(items):
        raise ValueError(f"no hay ninguna rutina con el número {rid}")
    save(keep, p)
    gone = next(r for r in items if r.id == rid)
    return {"id": rid, "orden": gone.orden}


def listing(p: Path | None = None) -> list[dict]:
    return [{"id": r.id, "orden": r.orden, "cuando": r.cuando} for r in load(p)]


def due(now: datetime, p: Path | None = None) -> list[Routine]:
    out = []
    for r in load(p):
        last = datetime.fromisoformat(r.ultima) if r.ultima else datetime.min
        if r.sched.last_due(now) > last:
            out.append(r)
    return out


def mark_done(rid: int, when: datetime, p: Path | None = None) -> None:
    items = load(p)
    for r in items:
        if r.id == rid:
            r.ultima = when.isoformat(timespec="minutes")
    save(items, p)
