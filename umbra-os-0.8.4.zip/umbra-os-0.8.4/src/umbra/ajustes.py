"""Ajustes de UMBRA: personaliza el sistema con cambios que se aplican al momento.

Apariencia (color, cristal, fondo, iconos), NYX (orbe, tamaño, voz) y navegador.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
import threading

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk  # noqa: E402

from . import desktop, theme  # noqa: E402

EXTRA_CSS = """
.section { font-size: 12px; letter-spacing: 3px; color: @accent_light; margin-top: 8px; }
.swatch { min-width: 34px; min-height: 34px; border-radius: 99px; padding: 0;
          border: 2px solid alpha(#ffffff, 0.15); transition: all 160ms ease-out; }
.swatch.selected { border: 3px solid #ffffff; box-shadow: 0 0 14px alpha(#ffffff, 0.45); }
.wall { border-radius: 12px; border: 2px solid alpha(#ffffff, 0.12); padding: 0; background: none; box-shadow: none; }
.wall:hover { border-color: @accent_light; }
.wall.selected { border-color: @accent_light; }
.status { font-size: 12px; color: alpha(#f3eefc, 0.8); }
.sec-summary { font-family: "DejaVu Sans Mono", monospace; font-size: 12px; color: #f3eefc; background: alpha(#000000, 0.22); border-radius: 14px; padding: 10px 14px; }
"""


class SettingsWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title="Ajustes de UMBRA")
        self.add_css_class("glass")
        self.set_default_size(620, 760)
        self.look = theme.load()

        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        panel.add_css_class("glass-panel")
        for side in ("top", "bottom", "start", "end"):
            getattr(panel, f"set_margin_{side}")(14)
        scroller = Gtk.ScrolledWindow(vexpand=True)
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for side in ("top", "bottom", "start", "end"):
            getattr(body, f"set_margin_{side}")(22)
        scroller.set_child(body)
        panel.append(scroller)
        self.set_child(panel)

        title = Gtk.Label(label="A J U S T E S", xalign=0)
        title.add_css_class("glass-title")
        body.append(title)
        # 🥚 7 clics en el título desbloquean el color secreto
        from .nyx.easter import ClickBurst

        self._title_burst = ClickBurst(count=7, window=3.0)
        tap = Gtk.GestureClick()
        tap.connect("released", self._title_tap)
        title.add_controller(tap)

        # --- Apariencia ---
        body.append(self._section("APARIENCIA"))
        body.append(self._row("Color de acento", self._swatches()))
        glass = Gtk.DropDown.new_from_strings(["Alto", "Medio", "Apagado"])
        glass.set_selected(["alto", "medio", "apagado"].index(self.look.cristal))
        glass.connect("notify::selected", lambda d, _p: self._set_glass(["alto", "medio", "apagado"][d.get_selected()]))
        body.append(self._row("Efecto cristal", glass, "Desenfoque detrás de ventanas, panel y menús"))
        icons = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 32, 96, 8)
        icons.set_value(self.look.iconos)
        icons.set_hexpand(True)
        icons.connect("value-changed", self._set_icons)
        body.append(self._row("Tamaño de los iconos del escritorio", icons))
        body.append(self._walls())
        live = Gtk.Switch(active=self.look.fondo_vivo, valign=Gtk.Align.CENTER)
        live.connect("notify::active", self._set_live)
        body.append(self._row("Fondo animado", live, "El átomo del escritorio se mueve. Prueba a hacerle clic derecho al núcleo…"))
        from . import perf

        info = perf.detect()
        detected = perf.choose(info)
        why = ("máquina virtual" if info["maquina_virtual"] else "sin aceleración gráfica" if info["sin_aceleracion"]
               else f"{info['ram_gb']:.0f} GB de RAM, {info['nucleos']} núcleos")
        modes = list(perf.PROFILES)
        names = [f"Automático ({perf.LABELS[detected].lower()})"] + [perf.LABELS[m] for m in modes[1:]]
        perf_dd = Gtk.DropDown.new_from_strings(names)
        cur = getattr(self.look, "rendimiento", "auto")
        perf_dd.set_selected(modes.index(cur) if cur in modes else 0)
        perf_dd.connect("notify::selected", lambda d, _p: self._set_perf(modes[d.get_selected()]))
        body.append(self._row("Rendimiento", perf_dd,
                              f"Detectado: {why}. «Ligero» quita el desenfoque, las animaciones y el fondo animado."))
        from . import memoria

        self.mem_switch = Gtk.Switch(active=memoria.read_mode() == "auto", valign=Gtk.Align.CENTER)
        self.mem_switch.connect("notify::active", self._set_memory)
        body.append(self._row("Memoria virtual (hasta 8 GB)", self.mem_switch,
                              "Como la «RAM virtual» de los móviles: si se llena la RAM, usa un archivo del disco. "
                              "Solo si te quedan libres al menos 15 GB. No se usa en la sesión en vivo."))

        # --- Puntero del ratón ---
        body.append(self._section("PUNTERO"))
        self._cursor_names = desktop.cursor_themes() or ["Adwaita"]
        cursor = Gtk.DropDown.new_from_strings([desktop.cursor_label(n) for n in self._cursor_names])
        if self.look.puntero in self._cursor_names:
            cursor.set_selected(self._cursor_names.index(self.look.puntero))
        cursor.connect("notify::selected", self._set_cursor_theme)
        body.append(self._row("Estilo del puntero", cursor, "Se aplica al momento en todo el sistema"))
        self._cursor_preview = Gtk.Picture()
        self._cursor_preview.set_size_request(200, 56)
        self._update_cursor_preview()
        body.append(self._cursor_preview)
        sizes = [str(x) for x in desktop.CURSOR_SIZES]
        csize = Gtk.DropDown.new_from_strings([f"{x} px" for x in sizes])
        if str(self.look.puntero_tamano) in sizes:
            csize.set_selected(sizes.index(str(self.look.puntero_tamano)))
        csize.connect("notify::selected", lambda d, _p: self._set_cursor_size(int(sizes[d.get_selected()])))
        body.append(self._row("Tamaño del puntero", csize))

        # --- NYX ---
        body.append(self._section("NYX"))
        orb = Gtk.Switch(active=self.look.orbe, valign=Gtk.Align.CENTER)
        orb.connect("notify::active", lambda s, _p: self._update(orbe=s.get_active(), restart_orb=True))
        body.append(self._row("Orbe en el escritorio", orb, "La esfera flotante: arrástrala o haz clic para hablarle"))
        size = Gtk.DropDown.new_from_strings(["Pequeño", "Mediano", "Grande"])
        sizes = list(theme.ORB_SIZES)
        size.set_selected(sizes.index(self.look.orbe_tamano))
        size.connect("notify::selected", lambda d, _p: self._update(orbe_tamano=sizes[d.get_selected()], restart_orb=True))
        body.append(self._row("Tamaño del orbe", size))
        voice = Gtk.Switch(active=self.look.voz, valign=Gtk.Align.CENTER)
        voice.connect("notify::active", lambda s, _p: self._update(voz=s.get_active()))
        body.append(self._row("Voz de NYX", voice))
        from .nyx import listen

        ok, why = listen.available()
        ear = Gtk.Switch(active=self.look.escucha and ok, valign=Gtk.Align.CENTER, sensitive=ok)
        ear.connect("notify::active", lambda s, _p: self._update(escucha=s.get_active(), restart_orb=True))
        body.append(self._row("«Oye NYX»", ear,
                              "NYX escucha de fondo solo la frase para despertarla. Todo se procesa en tu "
                              "equipo y no se guarda ningún audio." if ok else f"No disponible: {why}."))

        self._build_brain(body)

        # --- Seguridad ---
        self._build_security(body)

        # --- Navegador ---
        body.append(self._section("NAVEGADOR"))
        self.status = Gtk.Label(xalign=0, wrap=True)
        self.status.add_css_class("status")
        for key, (name, *_rest) in desktop.BROWSERS.items():
            btn = Gtk.Button(label=("✓ " if desktop.browser_installed(key) else "Instalar ") + name)
            btn.add_css_class("glass-accent" if not desktop.browser_installed(key) else "glass-pill")
            btn.connect("clicked", self._install_browser, key)
            body.append(self._row(name, btn, "Desde su repositorio oficial; será tu navegador predeterminado"))
        body.append(self.status)

    # --- cerebro local -------------------------------------------------------------------
    def _build_brain(self, body: Gtk.Box) -> None:
        from . import brain

        st = brain.status()
        self.brain_btn = Gtk.Button()
        self.brain_btn.connect("clicked", self._brain_clicked)
        sub = (f"{st['modelo']} · {st['tamano_gb']} GB · usa ~{st['ram_gb']:.0f} GB de RAM. Con él NYX entiende "
               "frases libres y conversa. Funciona sin internet una vez descargado.")
        if not st["motor"]:
            sub += " (Falta el motor llama-server en este sistema.)"
        body.append(self._row("Cerebro local de NYX", self.brain_btn, sub))
        self.brain_bar = Gtk.ProgressBar(show_text=True, visible=False)
        body.append(self.brain_bar)
        self._brain_cancel = False
        self._brain_busy = False
        self._brain_label()

    def _brain_label(self) -> None:
        from . import brain

        if brain.installed():
            self.brain_btn.set_label("Borrar")
            self.brain_btn.set_css_classes(["glass-pill"])
        else:
            self.brain_btn.set_label(f"Descargar ({brain.MODELS[brain.DEFAULT].size / 1024**3:.1f} GB)")
            self.brain_btn.set_css_classes(["glass-accent"])

    def _brain_clicked(self, _b) -> None:
        from . import brain

        if self._brain_busy:
            self._brain_cancel = True
            return
        if brain.installed():
            brain.remove()
            self._brain_label()
            self.status.set_label("Cerebro borrado. NYX vuelve a usar solo su motor de intenciones.")
            return
        self._brain_busy, self._brain_cancel = True, False
        self.brain_btn.set_label("Cancelar")
        self.brain_bar.set_visible(True)

        def progress(done: int, total: int) -> None:
            GLib.idle_add(self.brain_bar.set_fraction, done / total)
            GLib.idle_add(self.brain_bar.set_text, f"{done / 1024**2:,.0f} de {total / 1024**2:,.0f} MB".replace(",", "."))

        def work() -> None:
            try:
                brain.download(progress=progress, cancel=lambda: self._brain_cancel)
                msg = "Cerebro descargado y verificado. NYX lo usará la próxima vez que la abras."
            except Exception as exc:  # noqa: BLE001 - sin red, sin espacio, cancelado…
                msg = f"No se pudo descargar: {exc}."
            GLib.idle_add(self._brain_done, msg)

        threading.Thread(target=work, daemon=True).start()

    def _brain_done(self, msg: str) -> bool:
        self._brain_busy = False
        self.brain_bar.set_visible(False)
        self.status.set_label(msg)
        self._brain_label()
        return False

    # --- seguridad -----------------------------------------------------------------------
    def _build_security(self, body: Gtk.Box) -> None:
        from . import vigia

        body.append(self._section("SEGURIDAD"))
        self.sec = vigia.load_settings()
        self.sec_summary = Gtk.Label(xalign=0, wrap=True, label="Comprobando la protección…")
        self.sec_summary.add_css_class("sec-summary")
        body.append(self.sec_summary)
        watch = Gtk.Switch(active=self.sec.vigia, valign=Gtk.Align.CENTER)
        watch.connect("notify::active", self._set_vigia)
        body.append(self._row("Vigía de descargas", watch,
                              "NYX analiza todo lo que descargas y te avisa si es peligroso"))
        safe = Gtk.Switch(active=self.sec.avisar_seguros, valign=Gtk.Align.CENTER)
        safe.connect("notify::active", lambda w, _p: self._set_sec(avisar_seguros=w.get_active()))
        body.append(self._row("Avisar también si todo va bien", safe, "Una notificación discreta por cada descarga"))
        voice = Gtk.Switch(active=self.sec.voz, valign=Gtk.Align.CENTER)
        voice.connect("notify::active", lambda w, _p: self._set_sec(voz=w.get_active()))
        body.append(self._row("NYX lee los avisos en voz alta", voice))
        av = Gtk.Switch(active=self.sec.antivirus_completo, valign=Gtk.Align.CENTER)
        av.connect("notify::active", lambda w, _p: self._set_sec(antivirus_completo=w.get_active()))
        body.append(self._row("Antivirus ClamAV en cada descarga", av,
                              "Más seguro pero más lento: usa cerca de 1 GB de RAM durante unos segundos"))
        from . import honeyshield

        self.hs = honeyshield.load_settings()
        self.hs_switch = Gtk.Switch(active=self.hs.activo, valign=Gtk.Align.CENTER)
        self.hs_switch.connect("notify::active", self._set_honeyshield)
        body.append(self._row("HoneyShield: señuelos en la red", self.hs_switch,
                              "Servicios falsos que detectan escaneos y ataques. Abre 6 puertos en el cortafuegos "
                              "(te pide la contraseña). Pregúntale a NYX «¿quién me está atacando?»"))
        self.scan_btn = Gtk.Button(label="Analizar ahora")
        self.scan_btn.add_css_class("glass-accent")
        self.scan_btn.connect("clicked", self._scan_downloads)
        body.append(self._row("Analizar la carpeta Descargas", self.scan_btn))
        self.quar_label = Gtk.Label(xalign=0)
        body.append(self._row("Cuarentena", self.quar_label,
                              "Para sacar algo, díselo a NYX: «restaura <archivo> de la cuarentena»"))
        self.sec_status = Gtk.Label(xalign=0, wrap=True)
        self.sec_status.add_css_class("status")
        body.append(self.sec_status)
        threading.Thread(target=self._load_security, daemon=True).start()

    def _load_security(self) -> None:
        from . import scanner

        st = scanner.security_status()
        GLib.idle_add(self._show_security, st)

    def _show_security(self, st: dict) -> bool:
        def mark(ok: bool) -> str:
            return "✔" if ok else "✖"

        cells = [
            (st["cortafuegos"] == "activo", f"Cortafuegos: {st['cortafuegos']}"),
            (st["apparmor"] == "activo", f"AppArmor: {st['apparmor']}"),
            (st["antivirus"].startswith("ClamAV, "), f"Antivirus: {st['antivirus']}"),
            (st["actualizaciones_automaticas"] == "sí", f"Parches automáticos: {st['actualizaciones_automaticas']}"),
        ]
        lines = [f"{mark(ok)} {text}" for ok, text in cells]
        self.sec_summary.set_label(f"{lines[0]:<34}{lines[1]}\n{lines[2]:<34}{lines[3]}")
        n = st["cuarentena"]
        self.quar_label.set_label("vacía" if n == 0 else f"{n} archivo{'s' if n != 1 else ''}")
        return False

    def _set_sec(self, **changes) -> None:
        from . import vigia

        for k, v in changes.items():
            setattr(self.sec, k, v)
        vigia.save_settings(self.sec)

    def _set_vigia(self, switch, _p) -> None:
        self._set_sec(vigia=switch.get_active())
        if switch.get_active() and shutil.which("umbra-vigia"):
            subprocess.Popen(["umbra-vigia"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)  # si ya hay uno, el nuevo sale solo
        self.sec_status.set_label("Vigía activado." if switch.get_active() else
                                  "Vigía desactivado: tus descargas ya no se revisan solas.")

    def _set_honeyshield(self, switch, _p) -> None:
        from . import honeyshield

        on = switch.get_active()
        if on == self.hs.activo:
            return
        switch.set_sensitive(False)
        self.sec_status.set_label("Abriendo los señuelos…" if on else "Cerrando los señuelos…")

        def work() -> None:
            msg, ok = "", True
            try:
                if on:
                    if self.hs.direccion == "0.0.0.0":
                        honeyshield.firewall("abrir")
                    self.hs.activo = True
                    honeyshield.save_settings(self.hs)
                    if shutil.which("umbra-honeyshield"):
                        subprocess.Popen(["umbra-honeyshield"], stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL, start_new_session=True)
                    msg = "HoneyShield activado: NYX te avisará si alguien toca los señuelos."
                else:
                    self.hs.activo = False
                    honeyshield.save_settings(self.hs)
                    if self.hs.direccion == "0.0.0.0":
                        honeyshield.firewall("cerrar")
                    msg = "HoneyShield apagado y puertos cerrados."
            except Exception as e:  # sin contraseña o fuera de UMBRA
                ok = False
                msg = f"No se ha podido cambiar el cortafuegos: {e}"
            GLib.idle_add(self._honeyshield_done, ok, msg)

        threading.Thread(target=work, daemon=True).start()

    def _honeyshield_done(self, ok: bool, msg: str) -> bool:
        self.hs_switch.set_sensitive(True)
        if not ok:
            self.hs_switch.set_active(self.hs.activo)
        self.sec_status.set_label(msg)
        return False

    def _scan_downloads(self, button: Gtk.Button) -> None:
        from . import scanner

        button.set_sensitive(False)
        button.set_label("Analizando…")
        antivirus = True if self.sec.antivirus_completo else "rapido"

        def work() -> None:
            folder = scanner.downloads_dir()
            reports = []
            try:
                files = sorted((f for f in folder.iterdir() if f.is_file() and not f.is_symlink()),
                               key=lambda f: f.stat().st_mtime, reverse=True)[:200]
                for f in files:
                    try:
                        reports.append(scanner.scan(f, antivirus=antivirus))
                    except (OSError, ValueError):
                        continue
            except OSError:
                pass
            GLib.idle_add(self._scanned, button, reports)

        threading.Thread(target=work, daemon=True).start()

    def _scanned(self, button: Gtk.Button, reports) -> bool:
        from . import scanner

        button.set_sensitive(True)
        button.set_label("Analizar ahora")
        bad = [r for r in reports if r.verdict == scanner.PELIGROSO]
        warn = [r for r in reports if r.verdict == scanner.PRECAUCION]
        for r in bad + warn:
            scanner.strip_exec(r.path)

        def n(count: int, one: str, many: str) -> str:
            return f"{count} {one if count == 1 else many}"

        text = (f"He analizado {n(len(reports), 'archivo', 'archivos')}: {n(len(bad), 'peligroso', 'peligrosos')}, "
                f"{len(warn)} con precaución.")
        if bad:
            text += " Peligrosos: " + ", ".join(r.name for r in bad[:4]) + ("…" if len(bad) > 4 else "")
            if shutil.which("umbra-aviso"):
                from .vigia import save_report

                for r in bad[:3]:
                    subprocess.Popen(["umbra-aviso", str(save_report(r))], start_new_session=True,
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.sec_status.set_label(text)
        threading.Thread(target=self._load_security, daemon=True).start()
        return False

    # --- piezas de la interfaz ------------------------------------------------------------
    def _section(self, text: str) -> Gtk.Label:
        lbl = Gtk.Label(label=text, xalign=0)
        lbl.add_css_class("section")
        return lbl

    def _row(self, title: str, widget: Gtk.Widget, subtitle: str = "") -> Gtk.Box:
        row = Gtk.Box(spacing=14)
        row.add_css_class("glass-row")
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, valign=Gtk.Align.CENTER)
        texts.append(Gtk.Label(label=title, xalign=0))
        if subtitle:
            s = Gtk.Label(label=subtitle, xalign=0, wrap=True)
            s.add_css_class("glass-dim")
            texts.append(s)
        row.append(texts)
        row.append(widget)
        return row

    def _swatches(self) -> Gtk.Box:
        box = Gtk.Box(spacing=10)
        self._swatch_buttons = {}
        css = Gtk.CssProvider()
        css.load_from_data("".join(
            f".sw-{k} {{ background: {v[0]}; }}" for k, v in theme.ACCENTS.items()).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
        self._swatch_box = box
        for name in theme.ACCENTS:
            if name in theme.SECRET_ACCENTS and not self.look.secreto:
                continue
            box.append(self._make_swatch(name))
        return box

    def _make_swatch(self, name: str) -> Gtk.Button:
        b = Gtk.Button(tooltip_text=name.capitalize())
        b.add_css_class("swatch")
        b.add_css_class(f"sw-{name}")
        if name == self.look.acento:
            b.add_css_class("selected")
        b.connect("clicked", lambda _b, n=name: self._set_accent(n))
        self._swatch_buttons[name] = b
        return b

    def _walls(self) -> Gtk.Widget:
        box = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3,
                          column_spacing=8, row_spacing=8)
        for path in desktop.wallpapers():
            color = path.stem.replace("umbra-", "")
            if color in theme.SECRET_ACCENTS and not self.look.secreto:
                continue
            try:
                pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path), 160, 90, True)
            except GLib.Error:
                continue
            pic = Gtk.Picture.new_for_pixbuf(pix)
            pic.set_content_fit(Gtk.ContentFit.COVER)
            pic.set_size_request(160, 90)
            btn = Gtk.Button(child=pic, tooltip_text=path.stem.replace("umbra-", "").capitalize())
            btn.add_css_class("wall")
            btn.connect("clicked", lambda _b, p=path: self._set_wallpaper(p))
            box.append(btn)
        wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        wrap.append(Gtk.Label(label="Fondo de escritorio", xalign=0))
        wrap.append(box)
        return wrap

    def _title_tap(self, *_args) -> None:
        import time

        if self._title_burst.click(time.monotonic()) and not self.look.secreto:
            self._update(secreto=True)
            self._swatch_box.append(self._make_swatch("nebulosa"))
            self.status.set_label("🥚 Has encontrado el color secreto «nebulosa».")

    # --- cambios ----------------------------------------------------------------------------
    def _update(self, restart_orb: bool = False, **changes) -> None:
        for k, v in changes.items():
            setattr(self.look, k, v)
        theme.save(self.look)
        if restart_orb:
            desktop.set_orb(self.look.orbe)

    def _set_wallpaper(self, path) -> None:
        desktop.apply_wallpaper(path)
        self._update(fondo=path.stem.replace("umbra-", ""))
        desktop.restart_atom(self.look.fondo_vivo)

    def _set_accent(self, name: str) -> None:
        for n, b in self._swatch_buttons.items():
            (b.add_css_class if n == name else b.remove_css_class)("selected")
        self._update(acento=name, restart_orb=True)
        walls = [p for p in desktop.wallpapers() if p.stem.endswith(name)]
        if walls:
            desktop.apply_wallpaper(walls[0])
            self._update(fondo="")
        desktop.restart_atom(self.look.fondo_vivo)
        self.status.set_label("Color aplicado. Las ventanas abiertas lo usarán al volver a abrirlas.")

    def _set_live(self, switch, _p) -> None:
        self._update(fondo_vivo=switch.get_active())
        desktop.restart_atom(self.look.fondo_vivo)

    def _set_cursor_theme(self, dropdown, _p) -> None:
        self._update(puntero=self._cursor_names[dropdown.get_selected()])
        desktop.apply_cursor(self.look.puntero, self.look.puntero_tamano)
        self._update_cursor_preview()

    def _set_cursor_size(self, size: int) -> None:
        self._update(puntero_tamano=size)
        desktop.apply_cursor(self.look.puntero, size)

    def _update_cursor_preview(self) -> None:
        for d in desktop.CURSOR_DIRS:
            prev = d / self.look.puntero / "preview.png"
            if prev.is_file():
                self._cursor_preview.set_filename(str(prev))
                self._cursor_preview.set_visible(True)
                return
        self._cursor_preview.set_visible(False)

    def _set_perf(self, mode: str) -> None:
        from . import perf

        self._update(rendimiento=mode)
        effective = perf.profile(mode)
        path = perf.write_picom(effective, self.look.cristal)
        if shutil.which("picom"):
            subprocess.run(["pkill", "-x", "picom"], check=False)
            subprocess.Popen(["picom", "--config", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        desktop.restart_atom(self.look.fondo_vivo and effective != "ligero")
        self.status.set_label(f"Modo de rendimiento: {perf.LABELS[effective].lower()}.")

    def _set_memory(self, switch, _p) -> None:
        from . import memoria

        mode = "auto" if switch.get_active() else "no"
        if mode == memoria.read_mode():
            return
        switch.set_sensitive(False)
        self.status.set_label("Preparando la memoria virtual…" if mode == "auto" else "Quitando la memoria virtual…")

        def work() -> None:
            try:
                r = subprocess.run(["pkexec", "/usr/libexec/umbra/memoria-virtual", mode], capture_output=True,
                                   text=True, timeout=600)
                ok, msg = r.returncode == 0, (r.stdout or r.stderr).strip()
            except (OSError, subprocess.TimeoutExpired) as e:
                ok, msg = False, str(e)
            GLib.idle_add(self._memory_done, ok, msg)

        threading.Thread(target=work, daemon=True).start()

    def _memory_done(self, ok: bool, msg: str) -> bool:
        from . import memoria

        self.mem_switch.set_sensitive(True)
        if not ok:
            self.mem_switch.set_active(memoria.read_mode() == "auto")
            msg = "No se ha cambiado la memoria virtual" + (f": {msg}" if msg else ".")
        self.status.set_label(f"Memoria virtual: {msg}")
        return False

    def _set_glass(self, level: str) -> None:
        self._update(cristal=level)
        desktop.apply_glass(level)

    def _set_icons(self, scale: Gtk.Scale) -> None:
        size = int(round(scale.get_value() / 8) * 8)
        self._update(iconos=size)
        desktop.apply_icon_size(size)

    def _install_browser(self, button: Gtk.Button, key: str) -> None:
        if desktop.browser_installed(key):
            desktop.set_default_browser(key)
            self.status.set_label(f"{desktop.BROWSERS[key][0]} es ahora tu navegador predeterminado.")
            return
        button.set_sensitive(False)
        self.status.set_label(f"Instalando {desktop.BROWSERS[key][0]}… (te pedirá la contraseña de administrador)")

        def work() -> None:
            ok, msg = desktop.install_browser(key)
            GLib.idle_add(self._installed, button, key, ok, msg)

        threading.Thread(target=work, daemon=True).start()

    def _installed(self, button, key, ok, msg) -> bool:
        self.status.set_label(msg)
        button.set_sensitive(True)
        if ok:
            button.set_label("✓ " + desktop.BROWSERS[key][0])
        return False


class SettingsApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.Ajustes")

    def do_activate(self) -> None:
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data((theme.glass_css() + EXTRA_CSS).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        (self.props.active_window or SettingsWindow(self)).present()


def main() -> int:
    GLib.set_prgname("umbra-ajustes")  # clase de ventana «Umbra-ajustes»: picom le pone el cristal
    return SettingsApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
