"""Piezas gráficas compartidas (GTK 4): dibujo de la esfera, voz animada y utilidades de ventana."""

from __future__ import annotations

import json
import math
import shutil
import subprocess
import time

import cairo
from gi.repository import GLib

from .nyx.voice import Voice
from .sphere import ParticleSphere


def draw_sphere(cr: cairo.Context, sphere: ParticleSphere, cx: float, cy: float, radius: float,
                accent: tuple[float, float, float], halo: bool = True) -> None:
    """Dibuja la esfera de partículas con el color de acento."""
    r0, g0, b0 = accent
    e = sphere.energy
    if halo:
        glow = cairo.RadialGradient(cx, cy, 0, cx, cy, radius * (1.9 + 0.6 * e))
        glow.add_color_stop_rgba(0, r0 * 0.7, g0 * 0.6, b0 * 0.9, 0.30 + 0.25 * e)
        glow.add_color_stop_rgba(0.45, r0 * 0.4, g0 * 0.25, b0 * 0.55, 0.10)
        glow.add_color_stop_rgba(1, 0, 0, 0, 0)
        cr.set_source(glow)
        cr.arc(cx, cy, radius * (1.9 + 0.6 * e), 0, math.tau)
        cr.fill()
    scale = max(0.55, radius / 90)
    for p in sphere.project(cx, cy, radius):
        k = max(0.0, min(1.0, (p.depth + 1) / 2))  # delante: casi blanco con tinte; detrás: acento
        tint = sphere.tint(p.index) if sphere.effects else None
        r1, g1, b1 = tint if tint else (r0, g0, b0)
        cr.set_source_rgba(r1 + (1 - r1) * 0.75 * k, g1 + (1 - g1) * 0.75 * k, b1 + (1 - b1) * 0.75 * k, p.alpha)
        cr.arc(p.x, p.y, (0.45 + 0.85 * p.size) * scale, 0, math.tau)
        cr.fill()


class SpeakingSphere:
    """Une la esfera con la voz: sintetiza, reproduce y mueve la esfera con el volumen."""

    def __init__(self, sphere: ParticleSphere, on_state=None, warm: bool = True) -> None:
        self.sphere = sphere
        self.voice = Voice()
        self.enabled = self.voice.available
        self.on_state = on_state or (lambda s: None)
        self._speech: tuple[float, list[float]] | None = None
        if warm:  # solo donde NYX va a hablar seguro (el orbe); cargar la voz cuesta ~100 MB
            GLib.timeout_add_seconds(4, self._warm)

    def _warm(self) -> bool:
        if self.enabled:
            self.voice.warm_up()  # el modelo se carga ya, sin bloquear la ventana
        return False

    def tick(self) -> None:
        if self._speech is not None:
            start, env = self._speech
            i = int((time.monotonic() - start) * 60)
            self.sphere.set_energy(env[i] if 0 <= i < len(env) else 0.0)

    def set_state(self, state: str) -> None:
        self.sphere.state = state
        self.on_state(state)

    def thinking(self) -> None:
        self.voice.stop()
        self._speech = None
        self.set_state("pensando")

    def say(self, text: str) -> None:
        """Habla frase a frase; la esfera sigue el volumen de cada trozo."""
        if not (self.enabled and self.voice.available):
            self.set_state("reposo")
            return
        started = self.voice.speak(
            text,
            on_chunk=lambda utt: GLib.idle_add(self._chunk, utt.envelope),
            on_done=lambda: GLib.idle_add(self._end),
        )
        if not started:
            self.set_state("reposo")

    def _chunk(self, env: list[float]) -> bool:
        self.set_state("hablando")
        self._speech = (time.monotonic(), env)
        return False

    def _end(self) -> bool:
        self._speech = None
        self.sphere.set_energy(0)
        self.set_state("reposo")
        return False

    def stop(self) -> None:
        self.voice.stop()
        self._end()


# --- Ventanas en el escritorio (X11) con wmctrl --------------------------------------
def wmctrl(*args: str) -> str:
    if shutil.which("wmctrl") is None:
        return ""
    try:
        return subprocess.run(["wmctrl", *args], capture_output=True, text=True, timeout=3).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def window_geometry(title: str) -> tuple[int, int, int, int] | None:
    """(x, y, ancho, alto) de la ventana con ese título exacto."""
    for line in wmctrl("-lG").splitlines():
        parts = line.split(None, 7)
        if len(parts) == 8 and parts[7] == title:
            try:
                return int(parts[2]), int(parts[3]), int(parts[4]), int(parts[5])
            except ValueError:
                return None
    return None


def float_window(title: str, x: int | None = None, y: int | None = None) -> None:
    """Siempre encima, en todos los escritorios y fuera de la barra de tareas."""
    wmctrl("-r", title, "-b", "add,above,sticky")
    wmctrl("-r", title, "-b", "add,skip_taskbar,skip_pager")
    if x is not None and y is not None:
        wmctrl("-r", title, "-e", f"0,{x},{y},-1,-1")


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default
