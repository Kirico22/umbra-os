"""Guardián de NYX: la parte proactiva. Arranca con la sesión (``nyx-guardian``).

- Avisa si el disco se está llenando, si un programa se come la CPU durante minutos o si hay
  actualizaciones pendientes, y propone qué decirle a NYX para arreglarlo. Nunca actúa solo.
- Ejecuta las rutinas a su hora. Riesgo BAJO: solas. Riesgo MEDIO: pregunta con una notificación.
  Riesgo ALTO: nunca desde una rutina.
"""

from __future__ import annotations

import argparse
import fcntl
import os
import shutil
import subprocess
import threading
import time
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from . import routines
from .vigia import load_settings, notify

DISK_WARN = 0.90
CPU_WARN = 85.0  # % de un núcleo
CPU_SAMPLES = 3  # muestras seguidas por encima (cada una de CPU_INTERVAL segundos)
CPU_INTERVAL = 60.0
TICKS = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


# --------------------------------------------------------------------------- comprobaciones

def disk_warnings(paths: list[Path], threshold: float = DISK_WARN) -> list[dict]:
    seen, out = set(), []
    for p in paths:
        try:
            st = os.statvfs(p)
        except OSError:
            continue
        if st.f_fsid in seen:
            continue
        seen.add(st.f_fsid)
        total = st.f_blocks * st.f_frsize
        free = st.f_bavail * st.f_frsize
        if total and 1 - free / total >= threshold:
            out.append({"ruta": str(p), "uso": round(100 * (1 - free / total)), "libre_gb": round(free / 1024**3, 1)})
    return out


def _proc_times(uid: int) -> dict[int, tuple[str, int]]:
    out = {}
    for d in Path("/proc").glob("[0-9]*"):
        try:
            if d.stat().st_uid != uid:
                continue
            raw = (d / "stat").read_text()
        except OSError:
            continue
        name = raw[raw.index("(") + 1 : raw.rindex(")")]
        fields = raw[raw.rindex(")") + 2 :].split()
        out[int(d.name)] = (name, int(fields[11]) + int(fields[12]))  # utime + stime
    return out


class CpuWatch:
    def __init__(self, uid: int | None = None, reader: Callable[[int], dict] = _proc_times) -> None:
        self.uid = os.getuid() if uid is None else uid
        self.reader = reader
        self.prev: dict[int, tuple[str, int]] = {}
        self.prev_t = 0.0
        self.streak: dict[int, int] = {}
        self.warned: set[int] = set()

    def sample(self, now: float) -> list[dict]:
        cur = self.reader(self.uid)
        hogs = []
        if self.prev:
            dt = max(1e-6, now - self.prev_t)
            for pid, (name, ticks) in cur.items():
                if pid not in self.prev or pid == os.getpid():
                    continue
                pct = 100.0 * (ticks - self.prev[pid][1]) / TICKS / dt
                self.streak[pid] = self.streak.get(pid, 0) + 1 if pct >= CPU_WARN else 0
                if self.streak[pid] >= CPU_SAMPLES and pid not in self.warned:
                    self.warned.add(pid)
                    hogs.append({"pid": pid, "nombre": name, "cpu": round(pct)})
        self.prev, self.prev_t = cur, now
        self.streak = {p: s for p, s in self.streak.items() if p in cur}
        self.warned &= set(cur)
        return hogs


def pending_updates() -> int | None:
    if shutil.which("apt-get") is None:
        return None
    try:
        r = subprocess.run(["apt-get", "-s", "-o", "Debug::NoLocking=true", "upgrade"],
                           capture_output=True, text=True, timeout=120, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return sum(1 for line in r.stdout.splitlines() if line.startswith("Inst "))


# --------------------------------------------------------------------------- rutinas

def ask(title: str, body: str, timeout: int = 600) -> bool:
    """Pregunta con una notificación con botones. Sin respuesta (o sin notificaciones): no."""
    if shutil.which("notify-send") is None:
        return False
    try:
        r = subprocess.run(["notify-send", "-a", "NYX", "-i", "dialog-question", "-u", "normal",
                            "-A", "si=Sí, hazlo", "-A", "no=Ahora no", "--wait", "--", title, body],
                           capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.stdout.strip() == "si"


def routine_confirm(routine_text: str, asker: Callable[[str, str], bool] = ask):
    """Confirmación del broker para rutinas: MEDIO pregunta; ALTO nunca."""
    from .security import Risk

    def confirm(action, args) -> bool:
        if action.risk >= Risk.HIGH:
            return False
        return asker("Rutina de NYX", f"Toca «{routine_text}»: {action.description} ¿Lo hago?")

    return confirm


def run_routine(nyx, r: routines.Routine, asker: Callable[[str, str], bool] = ask) -> str:
    nyx.broker.confirm = routine_confirm(r.orden, asker)
    try:
        return nyx.handle(r.orden)
    except Exception as exc:  # noqa: BLE001 - una rutina rota no tumba al guardián
        return f"La rutina «{r.orden}» ha fallado: {exc}"


# --------------------------------------------------------------------------- bucle

def _lock() -> object | None:
    d = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp"))
    fh = open(d / f"nyx-guardian-{os.getuid()}.lock", "w")  # noqa: SIM115
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return None
    return fh


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="nyx-guardian", description="La parte proactiva de NYX")
    parser.add_argument("--una-vez", action="store_true", help="comprobar todo una vez y salir")
    args = parser.parse_args(argv)

    if args.una_vez:
        for w in disk_warnings([Path("/"), Path.home()], threshold=0.0):
            print(f"Disco {w['ruta']}: {w['uso']}% usado, {w['libre_gb']} GB libres")
        n = pending_updates()
        print(f"Actualizaciones pendientes: {n if n is not None else 'desconocido'}")
        for r in routines.load():
            print(f"Rutina {r.id}: {r.cuando} → {r.orden} (última: {r.ultima or 'nunca'})")
        return 0

    from .config import safe_mode

    if safe_mode():
        return 0  # modo seguro: sin rutinas ni avisos (el vigía de descargas sí sigue)
    lock = _lock()
    if lock is None:
        return 0
    from .cli import build_nyx
    from .config import load_config

    nyx = build_nyx(load_config(), None)
    cpu = CpuWatch()
    last_disk = last_updates = 0.0
    last_cpu = 0.0
    busy = threading.Lock()
    while True:
        now = time.monotonic()
        settings = load_settings()
        if settings.avisos_sistema:
            if now - last_disk > 6 * 3600 or last_disk == 0:
                for w in disk_warnings([Path("/"), Path.home()]):
                    notify("Te queda poco espacio", f"El disco está al {w['uso']}% ({w['libre_gb']} GB libres). "
                           "Pregúntame «¿qué ocupa espacio?» y te ayudo a liberar.", urgency="normal",
                           icon="drive-harddisk")
                    last_disk = now
                last_disk = last_disk or now
            if now - last_cpu >= CPU_INTERVAL:
                last_cpu = now
                for h in cpu.sample(now):
                    notify(f"{h['nombre']} está usando mucha CPU",
                           f"Lleva unos minutos al {h['cpu']}%. Si se ha quedado colgado, dime "
                           f"«cierra el proceso {h['pid']}».", icon="utilities-system-monitor")
            if now - last_updates > 24 * 3600 or last_updates == 0:
                last_updates = now
                n = pending_updates()
                if n:
                    notify("Hay actualizaciones", f"{n} programas se pueden actualizar. Los parches de "
                           "seguridad se instalan solos; el resto, desde la tienda de aplicaciones.",
                           urgency="low", icon="system-software-update")
        if not busy.locked():
            for r in routines.due(datetime.now()):
                routines.mark_done(r.id, datetime.now())

                def work(r=r) -> None:
                    with busy:
                        notify("Rutina de NYX", run_routine(nyx, r)[:400], urgency="low", icon="nyx")

                threading.Thread(target=work, daemon=True).start()
        time.sleep(30)


if __name__ == "__main__":
    raise SystemExit(main())
