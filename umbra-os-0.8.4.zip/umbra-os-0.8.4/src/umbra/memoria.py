"""Memoria virtual de UMBRA OS: hasta 8 GB de swap en el disco, solo si sobra espacio.

Es lo mismo que la «RAM virtual» o «RAM Plus» de los móviles: cuando la RAM se llena, lo que
menos se usa pasa al disco y el sistema no se cuelga ni cierra programas.

Va en dos niveles:
  1. zram (ya en UMBRA): memoria comprimida dentro de la propia RAM. Muy rápida. Prioridad 100.
  2. Este archivo de swap en el disco: más lento, pero mucho más grande. Prioridad 10, así que
     solo se usa cuando zram ya está lleno.

Reglas de seguridad:
  - Nunca en la sesión en vivo (USB/ISO): ahí no hay disco instalado.
  - Nunca toca particiones: es un archivo normal, /swapfile-umbra, con permisos 600 (solo root).
  - Solo si después quedan libres al menos 15 GB (o el 10 % del disco, lo que sea mayor).
  - Si el instalador ya creó un swap, solo añade lo que falte hasta 8 GB.
  - Se puede apagar desde Ajustes o con «umbra-memoria --modo no»: borra el archivo.

uso: umbra-memoria [--estado] | --aplicar (lo ejecuta el sistema al arrancar, como root)
                   | --modo auto|no (lo cambia Ajustes, con contraseña)
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

GIB = 1024 ** 3
TARGET = 8 * GIB  # «hasta 8 GB»
MIN_SIZE = 1 * GIB  # menos de esto no merece la pena
RESERVE = 15 * GIB  # espacio que siempre queda libre para ti
RESERVE_FRACTION = 0.10
PRIORITY = 10  # por debajo de zram (100)
SWAPFILE = Path("/swapfile-umbra")
CONFIG = Path("/etc/umbra/memoria.conf")
SAFE_FS = {"ext4", "ext3", "xfs", "btrfs"}


@dataclass
class State:
    live: bool
    fs: str
    disk_total: int
    disk_free: int
    ram: int
    swap_disk: int  # swap en disco que ya existe (sin contar el nuestro ni zram)
    ours: int  # tamaño de /swapfile-umbra si ya existe


@dataclass
class Plan:
    action: str  # crear | mantener | quitar | nada
    size: int
    reason: str


def gb(n: int) -> str:
    return f"{n / GIB:.1f}".rstrip("0").rstrip(".").replace(".", ",") + " GB"  # 7,8 GB


def plan(st: State, mode: str = "auto") -> Plan:
    """Decide qué hacer. Lógica pura (sin tocar el sistema) para poder probarla."""
    if mode == "no":
        return Plan("quitar" if st.ours else "nada", 0, "apagada en Ajustes")
    if st.live:
        return Plan("nada", 0, "sesión en vivo: no hay disco instalado")
    if st.fs not in SAFE_FS:
        return Plan("nada", 0, f"el sistema de archivos {st.fs or 'desconocido'} no admite archivos de swap")
    want = max(0, TARGET - st.swap_disk)
    if want < MIN_SIZE:
        return Plan("quitar" if st.ours else "nada", 0,
                    f"ya tienes {gb(st.swap_disk)} de swap en el disco")
    reserve = max(RESERVE, int(st.disk_total * RESERVE_FRACTION))
    available = st.disk_free + st.ours - reserve  # el nuestro se puede rehacer más pequeño
    size = min(want, max(0, available))
    size -= size % (256 * 1024 ** 2)  # múltiplo de 256 MB
    if size < MIN_SIZE:
        return Plan("quitar" if st.ours else "nada", 0,
                    f"poco espacio libre: hacen falta al menos {gb(reserve + MIN_SIZE)} libres")
    if st.ours and abs(st.ours - size) < 512 * 1024 ** 2:
        return Plan("mantener", st.ours, f"{gb(st.ours)} de memoria virtual en el disco")
    return Plan("crear", size, f"{gb(size)} de memoria virtual en el disco")


# --------------------------------------------------------------------------- leer el sistema

def _meminfo(root: Path = Path("/")) -> int:
    try:
        for line in (root / "proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"):
                return int(line.split()[1]) * 1024
    except (OSError, ValueError):
        pass
    return 0


def _swaps(root: Path = Path("/")) -> list[tuple[str, str, int]]:
    out = []
    try:
        for line in (root / "proc/swaps").read_text().splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 3:
                out.append((parts[0], parts[1], int(parts[2]) * 1024))
    except (OSError, ValueError):
        pass
    return out


def _fs_type(path: Path, root: Path = Path("/")) -> str:
    best, fs = "", ""
    try:
        for line in (root / "proc/mounts").read_text().splitlines():
            parts = line.split()
            if len(parts) >= 3 and (str(path) + "/").startswith(parts[1].rstrip("/") + "/") and len(parts[1]) >= len(best):
                best, fs = parts[1], parts[2]
    except OSError:
        pass
    return fs


def read_state(root: Path = Path("/")) -> State:
    disk = shutil.disk_usage(SWAPFILE.parent)
    swaps = _swaps(root)
    disk_swap = sum(size for name, kind, size in swaps
                    if not name.startswith("/dev/zram") and name != str(SWAPFILE))
    ours = SWAPFILE.stat().st_size if SWAPFILE.exists() else 0
    return State(live=(root / "run/live/medium").exists(), fs=_fs_type(SWAPFILE.parent, root),
                 disk_total=disk.total, disk_free=disk.free, ram=_meminfo(root), swap_disk=disk_swap, ours=ours)


def read_mode(config: Path = CONFIG) -> str:
    try:
        for line in config.read_text().splitlines():
            if line.strip().startswith("modo"):
                value = line.split("=", 1)[1].strip().strip('"')
                if value in ("auto", "no"):
                    return value
    except (OSError, IndexError):
        pass
    return "auto"


def status() -> dict:
    """Para NYX y Ajustes: lo que hay ahora y lo que haría UMBRA."""
    st = read_state()
    mode = read_mode()
    p = plan(st, mode)
    active = {name: size for name, _k, size in _swaps()}
    zram = sum(size for name, size in active.items() if name.startswith("/dev/zram"))
    return {
        "modo": mode,
        "ram": gb(st.ram),
        "memoria_comprimida_zram": gb(zram) if zram else "apagada",
        "swap_en_disco": gb(st.swap_disk + (active.get(str(SWAPFILE), 0))),
        "memoria_virtual_umbra": gb(active[str(SWAPFILE)]) if str(SWAPFILE) in active else "no",
        "espacio_libre": gb(st.disk_free),
        "decision": p.reason,
    }


# --------------------------------------------------------------------------- aplicar (root)

def _run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def _remove() -> None:
    if any(name == str(SWAPFILE) for name, _k, _s in _swaps()):
        subprocess.run(["swapoff", str(SWAPFILE)], check=False)
    SWAPFILE.unlink(missing_ok=True)


def _create(size: int, fs: str) -> None:
    _remove()
    if fs == "btrfs":
        # btrfs necesita un archivo sin copia en escritura ni compresión: lo hace su propia orden
        _run(["btrfs", "filesystem", "mkswapfile", "--size", f"{size // 1024 ** 2}m", str(SWAPFILE)])
    else:
        fd = os.open(SWAPFILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            os.posix_fallocate(fd, 0, size)
        finally:
            os.close(fd)
        _run(["mkswap", str(SWAPFILE)])
    os.chmod(SWAPFILE, 0o600)


def apply() -> str:
    if os.geteuid() != 0:
        raise PermissionError("esto lo hace el sistema al arrancar (como administrador)")
    st = read_state()
    p = plan(st, read_mode())
    try:
        if p.action == "quitar":
            _remove()
        elif p.action == "crear":
            _create(p.size, st.fs)
        if p.action in ("crear", "mantener") and not any(n == str(SWAPFILE) for n, _k, _s in _swaps()):
            _run(["swapon", "--priority", str(PRIORITY), str(SWAPFILE)])
    except (OSError, subprocess.CalledProcessError) as e:
        if p.action == "crear":
            SWAPFILE.unlink(missing_ok=True)  # no dejar un archivo a medias
        detail = getattr(e, "stderr", b"") or b""
        return f"no se pudo preparar la memoria virtual: {e} {detail.decode(errors='replace').strip()}"
    return p.reason


def set_mode(mode: str) -> str:
    if mode not in ("auto", "no"):
        raise ValueError("modo: auto o no")
    if os.geteuid() != 0:
        raise PermissionError("hace falta ser administrador")
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text("# Memoria virtual de UMBRA (swap en el disco, hasta 8 GB): auto o no\n"
                      f'modo = "{mode}"\n', encoding="utf-8")
    CONFIG.chmod(0o644)
    return apply()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="umbra-memoria", description="Memoria virtual (swap) de UMBRA OS")
    ap.add_argument("--aplicar", action="store_true", help="crear, ajustar o quitar el swap (root)")
    ap.add_argument("--modo", choices=["auto", "no"], help="encender (auto) o apagar (no); root")
    args = ap.parse_args(argv)
    try:
        if args.modo:
            print(set_mode(args.modo))
        elif args.aplicar:
            print(apply())
        else:
            print(json.dumps(status(), ensure_ascii=False, indent=2))
    except (PermissionError, ValueError) as e:
        print(f"umbra-memoria: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

