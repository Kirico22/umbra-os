"""Modo juego de UMBRA: todo el ordenador para el juego, y se deshace con una frase.

Al activarlo:
- «No molestar»: las notificaciones esperan hasta que salgas.
- Modo presentación: la pantalla no se apaga ni se bloquea mientras juegas.
- Se pausa el átomo animado del fondo para liberar CPU y gráfica.
- GameMode (si está instalado) pone el procesador en modo rendimiento.
Al desactivarlo, todo vuelve exactamente a como estaba (se guarda el estado anterior).
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
from pathlib import Path

from . import desktop, theme
from .config import user_config_dir


def state_path() -> Path:
    return user_config_dir() / "modo-juego.json"


def _xfconf_get(channel: str, prop: str) -> str | None:
    r = desktop._run(["xfconf-query", "-c", channel, "-p", prop])
    return r.stdout.strip() if r and r.returncode == 0 else None


def _xfconf_set(channel: str, prop: str, value: bool) -> None:
    desktop._run(["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", "bool", "-s", "true" if value else "false"])


def active() -> bool:
    return state_path().is_file()


def enable() -> dict:
    if active():
        return {"modo_juego": True, "mensaje": "El modo juego ya estaba activado."}
    prev = {
        "dnd": _xfconf_get("xfce4-notifyd", "/do-not-disturb"),
        "presentacion": _xfconf_get("xfce4-power-manager", "/xfce4-power-manager/presentation-mode"),
        "fondo_vivo": theme.load().fondo_vivo,
        "gamemode_pid": None,
    }
    _xfconf_set("xfce4-notifyd", "/do-not-disturb", True)
    _xfconf_set("xfce4-power-manager", "/xfce4-power-manager/presentation-mode", True)
    if prev["fondo_vivo"]:
        desktop.restart_atom(False)
    try:
        # gamemoderun mantiene GameMode activo mientras viva este proceso
        proc = subprocess.Popen(["gamemoderun", "sleep", "infinity"], stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, start_new_session=True)
        prev["gamemode_pid"] = proc.pid
    except OSError:
        pass
    path = state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(prev), encoding="utf-8")
    extra = "" if prev["gamemode_pid"] else " (instala el pack de gaming para tener también GameMode)"
    return {"modo_juego": True, "mensaje": "Modo juego activado: sin notificaciones, la pantalla no se apaga "
                                           f"y el fondo animado está en pausa{extra}. ¡A jugar!"}


def disable() -> dict:
    path = state_path()
    if not path.is_file():
        return {"modo_juego": False, "mensaje": "El modo juego no estaba activado."}
    try:
        prev = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        prev = {}
    _xfconf_set("xfce4-notifyd", "/do-not-disturb", prev.get("dnd") == "true")
    _xfconf_set("xfce4-power-manager", "/xfce4-power-manager/presentation-mode", prev.get("presentacion") == "true")
    if prev.get("fondo_vivo", True):
        desktop.restart_atom(True)
    pid = prev.get("gamemode_pid")
    if isinstance(pid, int) and pid > 1:
        try:
            cmd = Path(f"/proc/{pid}/cmdline").read_bytes()
            if b"gamemoderun" in cmd or b"sleep" in cmd:  # solo si sigue siendo nuestro proceso
                os.killpg(pid, signal.SIGTERM)
        except (OSError, ProcessLookupError):
            pass
    path.unlink(missing_ok=True)
    return {"modo_juego": False, "mensaje": "Modo juego desactivado: todo vuelve a estar como antes."}
