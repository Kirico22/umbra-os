"""Puente de confirmación entre el hilo de trabajo de NYX y la interfaz gráfica.

El broker pide confirmación desde el hilo de trabajo; la ventana la muestra y el
usuario responde. Si nadie responde a tiempo, cuenta como "no".
Sin dependencias de GTK para poder probarlo.
"""

from __future__ import annotations

import threading
from typing import Any, Callable

from .security import Action

AskFn = Callable[[Action, dict[str, Any], Callable[[bool], None]], None]


class ConfirmBridge:
    def __init__(self, ask_ui: AskFn, timeout: float = 120.0) -> None:
        self.ask_ui = ask_ui  # muestra la tarjeta en la UI y llama a reply(True/False)
        self.timeout = timeout

    def __call__(self, action: Action, args: dict[str, Any]) -> bool:
        done = threading.Event()
        answer = {"ok": False}

        def reply(ok: bool) -> None:
            if not done.is_set():
                answer["ok"] = bool(ok)
                done.set()

        self.ask_ui(action, args, reply)
        if not done.wait(self.timeout):
            return False
        return answer["ok"]
