"""NYX Memory: memoria persistente en SQLite que sobrevive a reinicios."""

from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS facts (
    key      TEXT PRIMARY KEY,
    value    TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    created  REAL NOT NULL,
    updated  REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    session TEXT NOT NULL,
    role    TEXT NOT NULL,
    content TEXT NOT NULL,
    ts      REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session, id);
"""


class Memory:
    def __init__(self, path: Path | str) -> None:
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        # La ventana gráfica usa NYX desde un hilo de trabajo: conexión compartida con candado
        self.db = sqlite3.connect(str(path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        self.db.executescript(SCHEMA)
        if str(path) != ":memory:":
            Path(path).chmod(0o600)  # datos privados: solo el usuario

    # --- hechos y preferencias -------------------------------------------
    def remember(self, key: str, value: str, category: str = "general") -> None:
        key = key.strip().lower()
        if not key:
            raise ValueError("la clave no puede estar vacía")
        now = time.time()
        with self._lock:
            self._remember(key, value, category, now)

    def _remember(self, key: str, value: str, category: str, now: float) -> None:
        self.db.execute(
            """INSERT INTO facts(key, value, category, created, updated) VALUES (?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value,
               category=excluded.category, updated=excluded.updated""",
            (key, value, category, now, now),
        )
        self.db.commit()

    def recall(self, query: str = "") -> list[dict]:
        like = f"%{query.strip().lower()}%"
        with self._lock:
            rows = self.db.execute(
                "SELECT key, value, category FROM facts WHERE key LIKE ? OR lower(value) LIKE ? ORDER BY updated DESC",
                (like, like),
            ).fetchall()
        return [dict(r) for r in rows]

    def forget(self, key: str) -> bool:
        with self._lock:
            cur = self.db.execute("DELETE FROM facts WHERE key = ?", (key.strip().lower(),))
            self.db.commit()
        return cur.rowcount > 0

    # --- conversación ----------------------------------------------------
    def add_message(self, session: str, role: str, content: str) -> None:
        with self._lock:
            self.db.execute(
                "INSERT INTO messages(session, role, content, ts) VALUES (?,?,?,?)",
                (session, role, content, time.time()),
            )
            self.db.commit()

    def recent_messages(self, session: str, limit: int = 12) -> list[dict[str, str]]:
        with self._lock:
            rows = self.db.execute(
                "SELECT role, content FROM messages WHERE session = ? ORDER BY id DESC LIMIT ?",
                (session, limit),
            ).fetchall()
        return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]

    def close(self) -> None:
        with self._lock:
            self.db.close()
