"""Proveedores de modelo de lenguaje para NYX.

Todos funcionan en local, sin internet ni APIs externas:
- LlamaCppProvider: carga un modelo .gguf directamente dentro de Python (llama-cpp-python).
- LlamaServerProvider: llama-server (llama.cpp) en 127.0.0.1, arrancado por NYX con el
                     «cerebro» descargado desde Ajustes. Es lo que usa UMBRA por defecto.
- OllamaProvider:   usa un servidor Ollama local (opcional).
- FakeProvider:     respuestas guionizadas para pruebas.
Si no hay modelo disponible, NYX sigue funcionando con el motor de intenciones (rules.py).
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from pathlib import Path
from typing import Protocol

Message = dict[str, str]  # {"role": "system"|"user"|"assistant", "content": "..."}


class ProviderError(RuntimeError):
    pass


class Provider(Protocol):
    name: str

    def chat(self, messages: list[Message]) -> str: ...


class LlamaCppProvider:
    """Modelo cargado en el propio proceso de Python. Sin servidor, sin red."""

    name = "llama_cpp"

    def __init__(self, model_path: Path, context_size: int = 4096, threads: int | None = None) -> None:
        model_path = Path(model_path).expanduser()
        if not model_path.is_file():
            raise ProviderError(f"no existe el modelo {model_path}")
        try:
            from llama_cpp import Llama  # import tardío: dependencia opcional
        except ImportError as exc:
            raise ProviderError("falta llama-cpp-python (pip install llama-cpp-python)") from exc
        self._llm = Llama(
            model_path=str(model_path), n_ctx=context_size, n_threads=threads, verbose=False
        )

    def chat(self, messages: list[Message]) -> str:
        out = self._llm.create_chat_completion(messages=messages, temperature=0.2)
        return out["choices"][0]["message"]["content"]


class LlamaServerProvider:
    """Servidor llama.cpp solo en 127.0.0.1 (nunca accesible desde la red).

    Si no está en marcha, NYX lo arranca con el modelo descargado y lo deja vivo para las
    siguientes preguntas (lo comparten el orbe, la ventana de NYX y el buscador)."""

    name = "llama_server"

    def __init__(self, model_path: Path, binary: str, port: int = 8737, timeout: int = 180,
                 threads: int | None = None, start: bool = True) -> None:
        self.model_path = Path(model_path)
        self.binary = binary
        self.url = f"http://127.0.0.1:{port}"
        self.port = port
        self.timeout = timeout
        self.threads = threads
        self.autostart = start

    def healthy(self) -> bool:
        try:
            with urllib.request.urlopen(self.url + "/health", timeout=2) as resp:
                return resp.status == 200
        except (urllib.error.URLError, OSError, TimeoutError):
            return False

    def ensure_running(self, wait: float = 90.0) -> None:
        import fcntl
        import os
        import subprocess
        import time

        if self.healthy():
            return
        if not self.autostart:
            raise ProviderError("el cerebro de NYX no está en marcha")
        lock_path = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / f"umbra-cerebro-{os.getuid()}.lock"
        with open(lock_path, "w") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)  # solo un proceso arranca el servidor
            if not self.healthy():
                cmd = [self.binary, "-m", str(self.model_path), "--host", "127.0.0.1",
                       "--port", str(self.port), "-c", "4096", "--no-webui"]
                if self.threads:
                    cmd += ["-t", str(self.threads)]
                env = dict(os.environ)
                # Las bibliotecas de llama.cpp van junto al ejecutable (/opt/umbra/llama)
                env["LD_LIBRARY_PATH"] = ":".join(filter(None, [str(Path(self.binary).parent),
                                                               env.get("LD_LIBRARY_PATH", "")]))
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 start_new_session=True, env=env)
                deadline = time.monotonic() + wait
                while time.monotonic() < deadline:
                    if self.healthy():
                        return
                    time.sleep(0.5)
                raise ProviderError("el cerebro de NYX no ha arrancado a tiempo")

    def chat(self, messages: list[Message]) -> str:
        self.ensure_running()
        body = json.dumps({"messages": messages, "temperature": 0.2, "stream": False}).encode()
        req = urllib.request.Request(self.url + "/v1/chat/completions", data=body,
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode())
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            raise ProviderError(f"el cerebro de NYX no responde: {exc}") from exc
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(f"respuesta inesperada del cerebro: {data!r:.200}") from exc


class OllamaProvider:
    """Servidor Ollama local. Nunca se usa streaming: una petición, una respuesta completa."""

    name = "ollama"

    def __init__(self, model: str, url: str = "http://127.0.0.1:11434", timeout: int = 120) -> None:
        self.model = model
        self.url = url.rstrip("/")
        self.timeout = timeout

    def chat(self, messages: list[Message]) -> str:
        body = json.dumps(
            {"model": self.model, "messages": messages, "stream": False, "keep_alive": "30m"}
        ).encode()
        req = urllib.request.Request(
            self.url + "/api/chat", data=body, headers={"Content-Type": "application/json"}
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.URLError as exc:
            raise ProviderError(f"no se puede conectar con Ollama en {self.url}: {exc.reason}") from exc
        except TimeoutError as exc:
            raise ProviderError("Ollama tardó demasiado en responder") from exc
        try:
            return data["message"]["content"]
        except (KeyError, TypeError) as exc:
            raise ProviderError(f"respuesta inesperada de Ollama: {data!r:.200}") from exc


class FakeProvider:
    """Devuelve respuestas fijas en orden. Para pruebas."""

    name = "fake"

    def __init__(self, replies: list[str] | None = None) -> None:
        self.replies = list(replies or [])
        self.seen: list[list[Message]] = []

    def chat(self, messages: list[Message]) -> str:
        self.seen.append([dict(m) for m in messages])
        if not self.replies:
            return json.dumps({"respuesta": "No tengo nada más que decir."})
        return self.replies.pop(0)
