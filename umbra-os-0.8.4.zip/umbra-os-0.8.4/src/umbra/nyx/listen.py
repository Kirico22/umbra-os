"""Oído de NYX: voz a texto en el propio equipo, con Vosk. Nada sale del ordenador.

- ``Listener.listen_once()`` graba desde el micrófono hasta que dejas de hablar y devuelve el texto.
- ``WakeWord`` escucha de fondo solo unas pocas frases («oye nix», «hola nix»...) para despertar a NYX.
  Está APAGADA por defecto: el micrófono solo se usa si el usuario la activa en Ajustes.
- El audio no se guarda en ningún sitio: se procesa en memoria y se descarta.

El micrófono se lee con pw-record (PipeWire), parec (PulseAudio) o arecord (ALSA), lo que haya,
siempre a 16 kHz, mono, 16 bits.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
import unicodedata
from collections.abc import Callable, Iterable, Iterator
from pathlib import Path

RATE = 16000
CHUNK = 4000  # 125 ms de audio (2 bytes por muestra)

MODEL_DIRS = [
    Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "umbra/vosk/es",
    Path("/usr/share/umbra/vosk/es"),
]

# Frases para despertar a NYX. «Nyx» no es una palabra española: el modelo la oye como «nix».
# Si ninguna está en el vocabulario del modelo, se usa «oye noche» (Nyx es la diosa de la noche).
WAKE_CANDIDATES = ("oye nix", "hola nix", "oye nics", "oye nyx", "oye noche", "hola noche")


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    return re.sub(r"\s+", " ", "".join(c for c in text if not unicodedata.combining(c))).strip()


def find_model() -> Path | None:
    for d in MODEL_DIRS:
        if (d / "am").is_dir() or (d / "conf").is_dir():
            return d
    return None


def recorder_command() -> list[str] | None:
    if shutil.which("pw-record"):
        return ["pw-record", "--rate", str(RATE), "--channels", "1", "--format", "s16", "-"]
    if shutil.which("parec"):
        return ["parec", f"--rate={RATE}", "--channels=1", "--format=s16le", "--latency-msec=100"]
    if shutil.which("arecord"):
        return ["arecord", "-q", "-f", "S16_LE", "-r", str(RATE), "-c", "1", "-t", "raw"]
    return None


def available() -> tuple[bool, str]:
    """¿Puede escuchar NYX? Devuelve (sí/no, motivo en español)."""
    try:
        import vosk  # noqa: F401
    except ImportError:
        return False, "falta el motor de reconocimiento de voz (Vosk)"
    if find_model() is None:
        return False, "falta el modelo de voz en español"
    if recorder_command() is None:
        return False, "no hay programa para leer el micrófono"
    return True, "listo"


def microphone(stop: threading.Event) -> Iterator[bytes]:
    cmd = recorder_command()
    if cmd is None:
        raise RuntimeError("no hay programa para leer el micrófono")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        while not stop.is_set():
            data = proc.stdout.read(CHUNK) if proc.stdout else b""
            if not data:
                break
            yield data
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


def transcribe(chunks: Iterable[bytes], recognizer, *, max_seconds: float = 10.0,
               silence_seconds: float = 1.2, on_partial: Callable[[str], None] | None = None) -> str:
    """Pasa audio al reconocedor hasta que hay una frase completa, un silencio largo o se acaba el tiempo."""
    heard = ""
    elapsed = 0.0
    quiet = 0.0
    last_partial = ""
    for chunk in chunks:
        elapsed += len(chunk) / (2 * RATE)
        if recognizer.AcceptWaveform(chunk):
            text = json.loads(recognizer.Result()).get("text", "")
            if text:
                return text
        else:
            partial = json.loads(recognizer.PartialResult()).get("partial", "")
            if partial and partial != last_partial:
                last_partial, quiet = partial, 0.0
                heard = partial
                if on_partial:
                    on_partial(partial)
            else:
                quiet += len(chunk) / (2 * RATE)
            if heard and quiet >= silence_seconds:
                break
        if elapsed >= max_seconds:
            break
    final = json.loads(recognizer.FinalResult()).get("text", "")
    return final or heard


class Listener:
    def __init__(self, model_dir: Path | None = None) -> None:
        import vosk

        vosk.SetLogLevel(-1)
        path = model_dir or find_model()
        if path is None:
            raise RuntimeError("falta el modelo de voz en español")
        self._vosk = vosk
        self.model = vosk.Model(str(path))
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()

    def listen_once(self, max_seconds: float = 10.0, on_partial: Callable[[str], None] | None = None) -> str:
        self._stop.clear()
        rec = self._vosk.KaldiRecognizer(self.model, RATE)
        return transcribe(microphone(self._stop), rec, max_seconds=max_seconds, on_partial=on_partial)

    def wake_phrases(self) -> list[str]:
        ok = [p for p in WAKE_CANDIDATES if all(self.model.vosk_model_find_word(w) != -1 for w in p.split())]
        return ok or ["oye noche"]


class WakeWord:
    """Escucha de fondo, con un vocabulario mínimo, solo para oír la frase de activación."""

    def __init__(self, listener: Listener, on_wake: Callable[[], None]) -> None:
        self.listener = listener
        self.on_wake = on_wake
        self.phrases = listener.wake_phrases()
        self._stop = threading.Event()
        self.paused = threading.Event()  # mientras NYX habla o escucha una orden
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        vosk = self.listener._vosk
        grammar = json.dumps([*self.phrases, "[unk]"])
        rec = vosk.KaldiRecognizer(self.listener.model, RATE, grammar)
        last = 0.0
        for chunk in microphone(self._stop):
            if self.paused.is_set():
                rec.Reset()
                continue
            if rec.AcceptWaveform(chunk):
                text = json.loads(rec.Result()).get("text", "")
            else:
                text = json.loads(rec.PartialResult()).get("partial", "")
            if is_wake(text, self.phrases) and time.monotonic() - last > 3:
                last = time.monotonic()
                rec.Reset()
                self.on_wake()


def is_wake(text: str, phrases: Iterable[str]) -> bool:
    t = _norm(text)
    return any(_norm(p) in t for p in phrases)
