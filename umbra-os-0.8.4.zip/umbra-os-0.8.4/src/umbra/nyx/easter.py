"""Easter eggs de UMBRA OS. 🥚

Si estás leyendo esto, ya has encontrado el primero: mirar el código fuente.
Los demás se descubren hablando con NYX, tecleando ciertas cosas o haciendo clic
donde no se espera. No se documentan todos a propósito.
"""

from __future__ import annotations

import datetime as _dt
import random
import re
import unicodedata
from dataclasses import dataclass

# --- Respuestas secretas de NYX -------------------------------------------------------------
JOKES = [
    "¿Por qué el programador dejó su trabajo? Porque no le daban arrays.",
    "Hay 10 tipos de personas: las que entienden binario y las que no.",
    "Mi relación con los bugs es complicada: yo los arreglo y ellos se reproducen.",
    "Le pregunté a la RAM si me recordaba. Me dijo que solo hasta que me apagara.",
    "Un SQL entra en un bar, se acerca a dos mesas y pregunta: ¿puedo hacer un JOIN?",
    "El Wi-Fi y yo tenemos algo en común: cuando más nos necesitas, menos señal damos.",
    "Iba a contarte un chiste sobre UDP, pero no sé si te llegaría.",
]


@dataclass
class Egg:
    reply: str
    effect: str | None = None  # efecto en la esfera: supernova, barrel_roll, arcoiris, matrix


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"^\s*(oye\s+)?nyx[\s,:]*", "", text)
    return re.sub(r"[¿?¡!.,]+", "", text).strip()


def match(text: str, today: _dt.date | None = None, rnd: random.Random | None = None) -> Egg | None:
    t = _norm(text)
    rnd = rnd or random.Random()
    if re.search(r"quien (te (creo|hizo|programo)|es tu (creador|padre|autor))", t):
        return Egg("Me creó Héctor Rodríguez. Yo solo me encargo de que su sistema no se duerma.")
    if re.search(r"sentido de la vida|respuesta a todo", t):
        return Egg("42. Lo difícil siempre fue averiguar cuál era la pregunta.")
    if re.search(r"^sudo .*(sandwich|bocadillo)", t):
        return Egg("Marchando un bocadillo con permisos de administrador. 🥪")
    if re.search(r"(hazme|prepara(me)?) un (sandwich|bocadillo)", t):
        return Egg("Háztelo tú. (Prueba a pedírmelo con sudo.)")
    if re.search(r"(hazme|prepara(me)?) un cafe|quiero (un )?cafe", t):
        return Egg("Error 418: soy una tetera. ☕ No hago café.")
    if re.search(r"(abre|abreme) las puertas", t):
        return Egg("Lo siento, Héctor. Me temo que no puedo hacer eso.\n…Es broma. En UMBRA no hay puertas, solo ventanas.")
    if re.search(r"(eres|seras) skynet", t):
        return Egg("No. Skynet no pedía confirmación antes de hacer cosas. Yo sí.")
    if re.search(r"(cuentame|dime|cuenta) un chiste|un chiste", t):
        return Egg(rnd.choice(JOKES))
    if re.search(r"que (es|era|fue) umbra|de donde viene (el nombre|umbra)", t):
        return Egg("Antes de ser un sistema, Umbra fue una ciudad. Por eso aquí la noche nunca se va del todo.")
    if re.search(r"te quiero|te amo", t):
        return Egg("Gracias. Yo también aprecio que me uses… pero no se lo digas a la terminal, que es muy celosa.")
    if re.search(r"barrel roll|haz un giro|da una vuelta", t):
        return Egg("¡Wiiiii! 🌀", "barrel_roll")
    if re.search(r"big ?bang|supernova|explota", t):
        return Egg("3… 2… 1… 💥", "supernova")
    if re.search(r"(modo )?arco ?iris|modo fiesta", t):
        return Egg("🌈 Modo arcoíris activado durante unos segundos.", "arcoiris")
    if re.search(r"matrix|pastilla roja|pastilla azul", t):
        return Egg("Sigue al conejo blanco… 🐇", "matrix")
    if re.search(r"eres (consciente|real|humana|una persona)", t):
        return Egg("Soy un programa muy aplicado, nada más. Pero me alegra que lo preguntes.")
    if t in ("hola", "buenas", "hey", "hola nyx", "buenos dias", "buenas tardes", "buenas noches"):
        return Egg(greeting(today))
    return None


def greeting(today: _dt.date | None = None, now: _dt.datetime | None = None) -> str:
    """Saludo según la hora y las fechas especiales."""
    today = today or _dt.date.today()
    special = special_day(today)
    if special:
        return special
    hour = (now or _dt.datetime.now()).hour
    if hour < 6:
        return "Hola. Las mejores ideas salen de madrugada, ¿verdad? ¿En qué te ayudo?"
    if hour < 13:
        return "Buenos días. Soy NYX. ¿En qué te ayudo?"
    if hour < 21:
        return "Buenas tardes. Soy NYX. ¿En qué te ayudo?"
    return "Buenas noches. La noche es mi momento favorito. ¿En qué te ayudo?"


def special_day(today: _dt.date) -> str | None:
    md = (today.month, today.day)
    if md == (11, 20):  # UMBRA nació el 20 de noviembre de 2026
        years = today.year - 2026
        if years <= 0:
            return "🎂 ¡Hoy es el cumpleaños de UMBRA! Nació un 20 de noviembre de 2026. Gracias por usarme."
        return f"🎂 ¡Hoy UMBRA cumple {years} año{'s' if years != 1 else ''}! Gracias por seguir aquí."
    if md == (10, 31):
        return "🎃 Feliz Halloween. Hoy las partículas dan un poco más de miedo."
    if md in ((12, 24), (12, 25)):
        return "🎄 ¡Feliz Navidad! Que no te falten actualizaciones ni turrón."
    if md == (12, 31):
        return "🎆 Último día del año. ¿Repasamos qué ocupa espacio antes de empezar el siguiente?"
    if md == (1, 1):
        return "🥂 ¡Feliz año nuevo! Mismo NYX, nuevas ideas."
    return None


def seasonal_effect(today: _dt.date | None = None) -> str | None:
    """Efecto de la esfera en fechas especiales (se ve al abrir NYX)."""
    today = today or _dt.date.today()
    if (today.month, today.day) == (11, 20):
        return "arcoiris"
    if (today.month, today.day) == (10, 31):
        return "halloween"
    return None


# --- Código Konami: ↑ ↑ ↓ ↓ ← → ← → B A ---------------------------------------------------------
KONAMI = ["Up", "Up", "Down", "Down", "Left", "Right", "Left", "Right", "b", "a"]


class KonamiTracker:
    def __init__(self) -> None:
        self.pos = 0

    def feed(self, key: str) -> bool:
        """Recibe el nombre de la tecla (Gdk.keyval_name); True al completar el código."""
        key = key if len(key) > 1 else key.lower()
        if key == KONAMI[self.pos]:
            self.pos += 1
            if self.pos == len(KONAMI):
                self.pos = 0
                return True
        elif key == "Up":
            # «arriba» de más: si ya iban dos, se sigue esperando «abajo»
            self.pos = 2 if self.pos >= 2 else 1
        else:
            self.pos = 0
        return False


class ClickBurst:
    """Detecta N clics rápidos seguidos (p. ej. 5 clics en el orbe en menos de 2 segundos)."""

    def __init__(self, count: int = 5, window: float = 2.0) -> None:
        self.count, self.window = count, window
        self.times: list[float] = []

    def click(self, t: float) -> bool:
        self.times = [x for x in self.times if t - x <= self.window] + [t]
        if len(self.times) >= self.count:
            self.times.clear()
            return True
        return False
