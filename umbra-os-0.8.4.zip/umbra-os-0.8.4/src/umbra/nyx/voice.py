"""Voz de NYX: síntesis local (sin internet ni APIs) y envolvente de volumen.

Motores, por orden de preferencia:
  1. Piper (voz neuronal, natural) con la voz española "sharvard", hablante femenina.
  2. espeak-ng (más robótica, pero siempre disponible en UMBRA OS).

`Voice.speak()` trocea la respuesta en frases: sintetiza la primera, empieza a hablar y prepara
las siguientes mientras suena (NYX responde antes). Cada trozo lleva su envolvente de volumen
(60 valores por segundo, de 0 a 1) para que la esfera se mueva al ritmo de la voz.

Para que no se distorsione ni se corte:
  - Piper se genera al 80 % del volumen máximo: a tope, la voz llega al límite (muestras
    recortadas) y al convertirla a 48 kHz el recorte se oye como ruido.
  - El reproductor usa un búfer de 250 ms: si el procesador va justo (máquina virtual), el
    sonido no se queda sin datos a mitad de frase.
  - La síntesis corre en un hilo con prioridad baja (nice 10) y el modelo se carga ahí, no al
    abrir la ventana: la interfaz y el audio tienen preferencia.
"""

from __future__ import annotations

import array
import importlib.util
import math
import os
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import wave
from dataclasses import dataclass
from pathlib import Path

VOICE_DIRS = [Path("/usr/share/umbra/voices"), Path.home() / ".local" / "share" / "umbra" / "voices"]
PIPER_VOICE = "es_ES-sharvard-medium"
PIPER_SPEAKER = "F"  # voz femenina: NYX es la diosa griega de la noche
PIPER_LENGTH_SCALE = 1.08  # un poco más pausada de lo normal: tono calmado
PIPER_VOLUME = 0.8  # margen para no recortar picos (ver arriba)
PLAYER_BUFFER_MS = 250
SYNTH_NICE = 10
ENVELOPE_FPS = 60
MAX_SPOKEN_CHARS = 320


def speakable(text: str) -> str:
    """Prepara una respuesta para leerla en voz alta: primera parte útil, sin símbolos ni tablas."""
    lines = [ln.strip() for ln in text.strip().splitlines()]
    out: list[str] = []
    for ln in lines:
        if not ln:
            if out:
                break  # solo el primer bloque: no se leen listas largas
            continue
        out.append(ln)
    spoken = " ".join(out)
    spoken = re.sub(r"[→✓✗•·⚠│|`*_#>\[\]{}]", " ", spoken)
    spoken = re.sub(r"(/[\w.\-]+){2,}", " esa ruta ", spoken)  # no leer rutas enteras
    spoken = spoken.replace("%", " por ciento").replace("GB", " gigas").replace("MB", " megas")
    spoken = re.sub(r"\s+", " ", spoken).strip()
    if len(spoken) > MAX_SPOKEN_CHARS:
        cut = spoken[:MAX_SPOKEN_CHARS]
        spoken = cut[: cut.rfind(".") + 1] or cut[: cut.rfind(" ")] + "…"
    return spoken


def envelope(wav_path: Path, fps: int = ENVELOPE_FPS) -> list[float]:
    """Volumen (RMS) normalizado de 0 a 1, `fps` valores por segundo."""
    with wave.open(str(wav_path), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("se esperaba audio de 16 bits")
        rate, channels = w.getframerate(), w.getnchannels()
        raw = w.readframes(w.getnframes())
    step = max(1, rate // fps)
    try:
        import numpy as np

        a = np.frombuffer(raw, dtype="<i2")[::channels].astype(np.float64)
        n = -(-len(a) // step)
        pad = np.zeros(n * step)
        pad[: len(a)] = a
        sq = (pad ** 2).reshape(n, step).sum(axis=1)
        counts = np.full(n, step, dtype=np.float64)
        if n and len(a) % step:
            counts[-1] = len(a) % step
        values = [float(v) for v in np.sqrt(sq / counts)] if n else []
    except ImportError:  # sin numpy: más lento, mismo resultado
        samples = array.array("h", raw)[::channels]
        values = []
        for i in range(0, len(samples), step):
            chunk = samples[i : i + step]
            values.append(math.sqrt(sum(s * s for s in chunk) / len(chunk)))
    peak = max(values, default=0) or 1.0
    # Raíz para que las partes suaves también muevan la esfera
    return [min(1.0, (v / peak) ** 0.6) for v in values]


def sentences(text: str, min_chars: int = 30) -> list[str]:
    """Trocea en frases para empezar a hablar cuanto antes; une las muy cortas a la siguiente."""
    parts = [p.strip() for p in re.split(r"(?<=[.!?…;:])\s+", text.strip()) if p.strip()]
    out: list[str] = []
    for part in parts:
        if out and len(out[-1]) < min_chars:
            out[-1] = f"{out[-1]} {part}"
        else:
            out.append(part)
    return out


def player_command(player: str, wav: Path, buffer_ms: int = PLAYER_BUFFER_MS) -> list[str]:
    """Orden de reproducción con un búfer amplio para que el audio no se entrecorte."""
    if player == "pw-play":
        return [player, "--latency", f"{buffer_ms}ms", str(wav)]
    if player == "paplay":
        return [player, f"--latency-msec={buffer_ms}", str(wav)]
    if player == "aplay":
        return [player, "-q", f"--buffer-time={buffer_ms * 1000}", str(wav)]
    return [player, str(wav)]


def _lower_priority(nice: int = SYNTH_NICE) -> None:
    """Baja la prioridad del hilo actual (en Linux, la prioridad es por hilo y la heredan sus hijos)."""
    try:
        os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), nice)
    except (AttributeError, OSError):
        pass


@dataclass
class Utterance:
    wav: Path
    envelope: list[float]
    duration: float
    engine: str


class Voice:
    def __init__(self) -> None:
        self._model = next((d / f"{PIPER_VOICE}.onnx" for d in VOICE_DIRS if (d / f"{PIPER_VOICE}.onnx").is_file()), None)
        self._piper = None
        self._piper_cfg = None
        self._load_lock = threading.Lock()
        self._espeak = shutil.which("espeak-ng") is not None
        # Elegir motor es instantáneo: el modelo (3-10 s) se carga después, en el hilo de voz
        if self._model is not None and importlib.util.find_spec("piper") is not None:
            self.engine = "piper"
        elif self._espeak:
            self.engine = "espeak-ng"
        else:
            self.engine = "ninguno"
        self.player = next((p for p in ("pw-play", "paplay", "aplay") if shutil.which(p)), None)
        self._current: subprocess.Popen | None = None
        self._gen = 0
        self._jobs: queue.Queue | None = None

    @property
    def available(self) -> bool:
        return self.engine != "ninguno"

    # --- hilo de síntesis (prioridad baja) ------------------------------------------
    def _submit(self, job) -> None:
        if self._jobs is None:
            self._jobs = queue.Queue()

            def worker() -> None:
                _lower_priority()
                while True:
                    fn = self._jobs.get()
                    try:
                        fn()
                    except Exception:
                        pass

            threading.Thread(target=worker, name="nyx-voz", daemon=True).start()
        self._jobs.put(job)

    def warm_up(self) -> None:
        """Carga el modelo en segundo plano para que la primera respuesta no espere."""
        if self.engine == "piper":
            self._submit(self._load_piper)

    def _load_piper(self) -> bool:
        with self._load_lock:
            if self._piper is not None:
                return True
            if self.engine != "piper":
                return False
            try:
                from piper import PiperVoice, SynthesisConfig

                piper = PiperVoice.load(self._model)
                speaker = piper.config.speaker_id_map.get(PIPER_SPEAKER)
                self._piper_cfg = SynthesisConfig(speaker_id=speaker, length_scale=PIPER_LENGTH_SCALE,
                                                  volume=PIPER_VOLUME)
                self._piper = piper
                return True
            except Exception:
                self.engine = "espeak-ng" if self._espeak else "ninguno"
                return False

    # --- síntesis -------------------------------------------------------------------
    def _synth_one(self, text: str) -> Utterance:
        fd, name = tempfile.mkstemp(prefix="nyx-voz-", suffix=".wav")
        os.close(fd)
        wav = Path(name)
        try:
            if self.engine == "piper" and self._load_piper():
                with wave.open(str(wav), "wb") as w:
                    self._piper.synthesize_wav(text, w, syn_config=self._piper_cfg)
            elif self.engine == "espeak-ng":
                # Voz española, algo más grave y pausada para sonar menos robótica
                subprocess.run(["espeak-ng", "-v", "es+f3", "-s", "150", "-p", "38", "-w", str(wav), text],
                               check=True, timeout=60, capture_output=True)
            else:
                raise RuntimeError("no hay motor de voz")
            env = envelope(wav)
        except Exception:
            wav.unlink(missing_ok=True)
            raise
        return Utterance(wav, env, len(env) / ENVELOPE_FPS, self.engine)

    def synthesize(self, text: str) -> Utterance | None:
        """Todo el texto de una vez, en el hilo que llama (para pruebas y exportar audio)."""
        text = speakable(text)
        if not text or not self.available:
            return None
        return self._synth_one(text)

    # --- hablar ---------------------------------------------------------------------
    def speak(self, text: str, on_chunk=None, on_done=None) -> bool:
        """Habla en segundo plano, frase a frase. `on_chunk(utt)` se llama al empezar cada trozo y
        `on_done()` al terminar (no se llama si otra frase o `stop()` la interrumpen).
        Devuelve False si no hay nada que decir."""
        spoken = speakable(text)
        if not spoken or not self.available:
            return False
        self.stop()
        gen = self._gen
        chunks = sentences(spoken)
        ready: queue.Queue = queue.Queue()

        def synth() -> None:
            try:
                for chunk in chunks:
                    if gen != self._gen:
                        break
                    ready.put(self._synth_one(chunk))
            except Exception:
                pass
            finally:
                ready.put(None)

        def play_all() -> None:  # hilo normal, no el de prioridad baja
            while True:
                utt = ready.get()
                if utt is None:
                    break
                try:
                    if gen == self._gen:
                        if on_chunk:
                            on_chunk(utt)
                        self._play_blocking(utt)
                finally:
                    utt.wav.unlink(missing_ok=True)
            if gen == self._gen and on_done:
                on_done()

        threading.Thread(target=play_all, name="nyx-voz-play", daemon=True).start()
        self._submit(synth)
        return True

    def _play_blocking(self, utt: Utterance) -> None:
        start = time.monotonic()
        code = None
        if self.player:
            try:
                self._current = subprocess.Popen(player_command(self.player, utt.wav),
                                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                code = self._current.wait()
            except OSError:
                code = None
        if code not in (0, -15):
            # Sin sonido (o sin reproductor): la esfera se mueve igualmente lo que dura la frase
            time.sleep(max(0.0, utt.duration - (time.monotonic() - start)))

    def play(self, utt: Utterance, on_done=None) -> None:
        """Reproduce un audio ya sintetizado en segundo plano y lo borra al terminar."""
        self.stop()
        gen = self._gen

        def run() -> None:
            try:
                self._play_blocking(utt)
            finally:
                utt.wav.unlink(missing_ok=True)
                if on_done and gen == self._gen:
                    on_done()

        threading.Thread(target=run, daemon=True).start()

    def stop(self) -> None:
        self._gen += 1
        if self._current and self._current.poll() is None:
            self._current.terminate()
