"""Bienvenida de UMBRA OS: se abre en el primer inicio de sesión de cada usuario.

    umbra-bienvenida             (solo si no se ha completado antes)
    umbra-bienvenida --otra-vez  (para volver a verla)

Pasos: saludo de NYX → color → navegador → NYX (voz, «Oye NYX», cerebro) → packs de
aplicaciones → protección y copias de seguridad → listo. Todo se puede cambiar después en Ajustes.
Lo que necesita permisos de administrador (navegador, packs) pide la contraseña con polkit.
"""

from __future__ import annotations

import subprocess
import sys
import threading

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import desktop, packs, theme  # noqa: E402
from .config import user_config_dir  # noqa: E402
from .sphere import ParticleSphere  # noqa: E402
from .widgets import SpeakingSphere, draw_sphere, wmctrl  # noqa: E402

TITLE = "Bienvenida a UMBRA"
W, H = 820, 600

EXTRA_CSS = """
.hero { font-size: 34px; font-weight: 300; letter-spacing: 2px; color: #ffffff; }
.lead { font-size: 15px; color: alpha(#f3eefc, 0.86); }
.step { font-size: 11px; letter-spacing: 3px; color: @accent_light; }
.choice { padding: 14px 18px; border-radius: 18px; }
.choice.selected { border-color: @accent_light; background-color: alpha(@accent, 0.28); }
.choice-title { font-size: 15px; font-weight: 600; color: #ffffff; }
.dots label { font-size: 16px; color: alpha(#ffffff, 0.25); }
.dots label.on { color: @accent_light; }
.swatch { min-width: 52px; min-height: 52px; border-radius: 99px; padding: 0;
          border: 2px solid alpha(#ffffff, 0.15); transition: all 160ms ease-out; }
.swatch.selected { border: 3px solid #ffffff; box-shadow: 0 0 18px alpha(#ffffff, 0.5); }
.status { font-size: 12px; color: alpha(#f3eefc, 0.8); }
button:disabled { opacity: 0.4; }
.keys { font-family: "DejaVu Sans Mono", monospace; font-size: 13px; color: #ffffff;
        background: alpha(#000000, 0.25); border-radius: 14px; padding: 14px 18px; }
"""


def done_flag():
    return user_config_dir() / ".bienvenida-hecha"


class Welcome(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title=TITLE, decorated=False, resizable=False)
        self.add_css_class("glass")
        self.set_default_size(W, H)
        self.set_size_request(W, H)
        self.look = theme.load()
        self.sel_packs: set[str] = set()
        self._swatches: dict[str, Gtk.Button] = {}

        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        panel.add_css_class("glass-panel")
        for side in ("top", "bottom", "start", "end"):
            getattr(panel, f"set_margin_{side}")(18)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, vexpand=True)
        for side in ("top", "bottom", "start", "end"):
            getattr(inner, f"set_margin_{side}")(28)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.SLIDE_LEFT_RIGHT,
                               transition_duration=380, vexpand=True)
        self.pages = [self._p_hola(), self._p_color(), self._p_browser(), self._p_nyx(),
                      self._p_packs(), self._p_safety(), self._p_done()]
        for i, page in enumerate(self.pages):
            scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True)
            scroll.set_child(page)
            self.stack.add_named(scroll, str(i))

        nav = Gtk.Box(spacing=10)
        self.back = Gtk.Button(label="Atrás")
        self.back.add_css_class("glass-pill")
        self.back.connect("clicked", lambda _b: self.go(-1))
        self.dots = Gtk.Box(spacing=6, hexpand=True, halign=Gtk.Align.CENTER)
        self.dots.add_css_class("dots")
        self._dots = []
        for _ in self.pages:
            d = Gtk.Label(label="●")
            self.dots.append(d)
            self._dots.append(d)
        self.next = Gtk.Button(label="Empezar")
        self.next.add_css_class("glass-accent")
        self.next.connect("clicked", lambda _b: self.go(+1))
        nav.append(self.back)
        nav.append(self.dots)
        nav.append(self.next)

        self.status = Gtk.Label(xalign=0.5, wrap=True)
        self.status.add_css_class("status")
        inner.append(self.stack)
        inner.append(self.status)
        inner.append(nav)
        panel.append(inner)
        self.set_child(panel)
        self.index = 0
        self._refresh()

    # --- navegación ---------------------------------------------------------------------
    def go(self, delta: int) -> None:
        if self.index == len(self.pages) - 1 and delta > 0:
            self.finish()
            return
        self.index = max(0, min(len(self.pages) - 1, self.index + delta))
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT if delta > 0
                                       else Gtk.StackTransitionType.SLIDE_RIGHT)
        self.stack.set_visible_child_name(str(self.index))
        self.status.set_label("")
        self._refresh()

    def _refresh(self) -> None:
        self.back.set_visible(self.index > 0)
        last = self.index == len(self.pages) - 1
        self.next.set_label("Empezar" if self.index == 0 else "Terminar" if last else "Siguiente")
        for i, d in enumerate(self._dots):
            (d.add_css_class if i == self.index else d.remove_css_class)("on")

    def finish(self) -> None:
        flag = done_flag()
        flag.parent.mkdir(parents=True, exist_ok=True)
        flag.touch()
        self.close()

    # --- piezas -------------------------------------------------------------------------
    def _page(self, step: str, title: str, lead: str) -> Gtk.Box:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, valign=Gtk.Align.CENTER)
        if step:
            s = Gtk.Label(label=step, xalign=0)
            s.add_css_class("step")
            box.append(s)
        t = Gtk.Label(label=title, xalign=0, wrap=True)
        t.add_css_class("hero")
        box.append(t)
        if lead:
            lab = Gtk.Label(label=lead, xalign=0, wrap=True)
            lab.set_max_width_chars(70)
            lab.add_css_class("lead")
            box.append(lab)
        return box

    def _choice(self, title: str, text: str, on_click, selected: bool = False) -> Gtk.Button:
        b = Gtk.Button()
        b.add_css_class("glass-pill")
        b.add_css_class("choice")
        if selected:
            b.add_css_class("selected")
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        t = Gtk.Label(label=title, xalign=0)
        t.add_css_class("choice-title")
        d = Gtk.Label(label=text, xalign=0, wrap=True)
        d.set_max_width_chars(60)
        d.add_css_class("glass-dim")
        col.append(t)
        col.append(d)
        b.set_child(col)
        b.connect("clicked", on_click)
        return b

    def _switch_row(self, title: str, text: str, active: bool, on_toggle, sensitive: bool = True) -> Gtk.Box:
        row = Gtk.Box(spacing=14)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
        t = Gtk.Label(label=title, xalign=0)
        t.add_css_class("choice-title")
        d = Gtk.Label(label=text, xalign=0, wrap=True)
        d.set_max_width_chars(62)
        d.add_css_class("glass-dim")
        col.append(t)
        col.append(d)
        sw = Gtk.Switch(active=active, valign=Gtk.Align.CENTER, sensitive=sensitive)
        sw.connect("notify::active", lambda s, _p: on_toggle(s.get_active()))
        row.append(col)
        row.append(sw)
        return row

    # --- páginas ------------------------------------------------------------------------
    def _p_hola(self) -> Gtk.Box:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, valign=Gtk.Align.CENTER)
        self.sphere = ParticleSphere(n=420, seed=3)
        # La Bienvenida va en silencio: no carga la voz (~100 MB y unos segundos de CPU) en el
        # primer arranque, que es cuando más trabajo tiene el equipo. NYX habla después, en el orbe.
        self.speaker = SpeakingSphere(self.sphere, warm=False)
        self.speaker.enabled = False
        area = Gtk.DrawingArea(content_width=260, content_height=260, halign=Gtk.Align.CENTER)
        area.set_draw_func(lambda _a, cr, w, h: draw_sphere(cr, self.sphere, w / 2, h / 2, w * 0.30,
                                                            self.look.rgb(0)))
        self._last = None

        self._frame = 0

        def tick(_w, clock) -> bool:
            now = clock.get_frame_time() / 1e6
            dt = 1 / 60 if self._last is None else now - self._last
            self._last = now
            self._frame += 1
            if self._frame % 3:  # 20 fps: la esfera sigue viva y gasta un tercio
                return True
            self.sphere.update(dt * 3)
            area.queue_draw()
            return True

        area.add_tick_callback(tick)
        t = Gtk.Label(label="Hola, soy NYX")
        t.add_css_class("hero")
        lead = Gtk.Label(label="Bienvenido a UMBRA OS. Vamos a dejarlo a tu gusto en un minuto.\n"
                               "Todo lo que elijas aquí se puede cambiar después en Ajustes.",
                         justify=Gtk.Justification.CENTER, wrap=True)
        lead.add_css_class("lead")
        box.append(area)
        box.append(t)
        box.append(lead)
        return box

    def _p_color(self) -> Gtk.Box:
        box = self._page("1 · COLOR", "Elige tu color", "Cambia el acento de las ventanas, el orbe de NYX y el "
                         "átomo del fondo.")
        row = Gtk.Box(spacing=18, halign=Gtk.Align.START, margin_top=10)
        for name in theme.ACCENTS:
            if name in theme.SECRET_ACCENTS:
                continue
            b = Gtk.Button(tooltip_text=name.capitalize())
            b.add_css_class("swatch")
            b.add_css_class(f"sw-{name}")
            if name == self.look.acento:
                b.add_css_class("selected")
            b.connect("clicked", lambda _b, n=name: self._set_accent(n))
            self._swatches[name] = b
            row.append(b)
        box.append(row)
        return box

    def _set_accent(self, name: str) -> None:
        for n, b in self._swatches.items():
            (b.add_css_class if n == name else b.remove_css_class)("selected")
        self.look.acento = name
        self.look.fondo = ""
        theme.save(self.look)
        walls = [p for p in desktop.wallpapers() if p.stem.endswith(name)]
        if walls:
            desktop.apply_wallpaper(walls[0])
        desktop.restart_atom(self.look.fondo_vivo)
        desktop.set_orb(self.look.orbe)
        self.status.set_label(f"Color {name} aplicado.")
        self.queue_draw()

    def _p_browser(self) -> Gtk.Box:
        box = self._page("2 · NAVEGADOR", "¿Con qué navegador te quedas?",
                         "Chromium viene incluido. Opera GX y Google Chrome se instalan desde su repositorio "
                         "oficial (te pedirá la contraseña de administrador).")
        for key, (name, *_r) in desktop.BROWSERS.items():
            extra = " (ya instalado)" if desktop.browser_installed(key) else ""
            text = {"opera-gx": "El navegador para jugadores: limitador de RAM y CPU, Twitch y Discord integrados.",
                    "chrome": "El de Google, con tu cuenta y tus extensiones."}.get(key, "")
            box.append(self._choice(name + extra, text, lambda b, k=key: self._install_browser(b, k)))
        box.append(self._choice("Me quedo con Chromium", "Libre y ya instalado.",
                                lambda _b: self.go(+1)))
        return box

    def _install_browser(self, button: Gtk.Button, key: str) -> None:
        name = desktop.BROWSERS[key][0]
        if desktop.browser_installed(key):
            desktop.set_default_browser(key)
            self.status.set_label(f"{name} es ahora tu navegador predeterminado.")
            return
        button.set_sensitive(False)
        self.status.set_label(f"Instalando {name}… puedes seguir con los demás pasos.")

        def work() -> None:
            ok, msg = desktop.install_browser(key)
            GLib.idle_add(lambda: (self.status.set_label(msg), button.set_sensitive(True)) and False)

        threading.Thread(target=work, daemon=True).start()

    def _p_nyx(self) -> Gtk.Box:
        from . import brain
        from .nyx import listen

        box = self._page("3 · NYX", "Cómo quieres a NYX", "Todo funciona en tu ordenador: ni tu voz ni tus "
                         "preguntas salen de él.")
        box.append(self._switch_row("Voz de NYX", "NYX te responde hablando.", self.look.voz,
                                    lambda v: self._set_look(voz=v)))
        ok, why = listen.available()
        box.append(self._switch_row("«Oye NYX»", "Despiértala con la voz. El micrófono solo busca esa frase "
                                    "y no se guarda ningún audio." if ok else f"No disponible: {why}.",
                                    self.look.escucha and ok, lambda v: self._set_look(escucha=v), sensitive=ok))
        st = brain.status()
        self.brain_btn = self._choice(
            "Descargar el cerebro de NYX" if not st["instalado"] else "Cerebro de NYX: listo",
            f"Opcional. {st['tamano_gb']} GB, usa ~{st['ram_gb']:.0f} GB de RAM. Con él NYX entiende frases "
            "libres y conversa. Sin él, entiende las órdenes habituales.", self._download_brain)
        self.brain_btn.set_sensitive(not st["instalado"])
        box.append(self.brain_btn)
        return box

    def _set_look(self, **changes) -> None:
        for k, v in changes.items():
            setattr(self.look, k, v)
        theme.save(self.look)
        if "escucha" in changes:
            desktop.set_orb(self.look.orbe)

    def _download_brain(self, button: Gtk.Button) -> None:
        from . import brain

        button.set_sensitive(False)

        def progress(done: int, total: int) -> None:
            GLib.idle_add(self.status.set_label, f"Descargando el cerebro: {done * 100 // total}%")

        def work() -> None:
            try:
                brain.download(progress=progress)
                msg = "Cerebro descargado y verificado."
            except Exception as exc:  # noqa: BLE001
                msg = f"No se pudo descargar el cerebro: {exc}. Puedes hacerlo luego en Ajustes."
            GLib.idle_add(self.status.set_label, msg)

        threading.Thread(target=work, daemon=True).start()

    def _p_packs(self) -> Gtk.Box:
        box = self._page("4 · APLICACIONES", "¿Qué vas a hacer con UMBRA?",
                         "Ya tienes oficina, vídeo, correo y contraseñas. Marca los packs que quieras y los "
                         "instalo (o pídemelo luego: «instala el pack de gaming»).")
        grid = Gtk.FlowBox(min_children_per_line=2, max_children_per_line=2, homogeneous=True, selection_mode=Gtk.SelectionMode.NONE,
                           column_spacing=10, row_spacing=10)
        live = packs.is_live()
        for p in packs.PACKS.values():
            def toggle(b, pid=p.id):
                if pid in self.sel_packs:
                    self.sel_packs.discard(pid)
                    b.remove_css_class("selected")
                else:
                    self.sel_packs.add(pid)
                    b.add_css_class("selected")
                self.install_btn.set_sensitive(bool(self.sel_packs))
            choice = self._choice(p.name, f"{p.description} · unos {p.size_mb / 1024:.1f} GB".replace(".", ","), toggle)
            choice.set_sensitive(not live)
            grid.append(choice)
        box.append(grid)
        if live:
            note = Gtk.Label(label="Estás probando UMBRA sin instalar: los packs se guardarían en la memoria RAM, "
                                   "podrían llenarla y se borrarían al apagar. Instala UMBRA (icono «Instalar UMBRA» "
                                   "del escritorio) y luego pídeselos a NYX.", wrap=True, xalign=0)
            note.add_css_class("glass-dim")
            box.append(note)
        self.install_btn = Gtk.Button(label="Instalar los marcados", halign=Gtk.Align.START, sensitive=False)
        self.install_btn.add_css_class("glass-accent")
        self.install_btn.connect("clicked", self._install_packs)
        box.append(self.install_btn)
        return box

    def _install_packs(self, button: Gtk.Button) -> None:
        chosen = sorted(self.sel_packs)
        button.set_sensitive(False)

        def work() -> None:
            msgs = []
            for pid in chosen:
                GLib.idle_add(self.status.set_label, f"Instalando el pack {packs.PACKS[pid].name}…")
                try:
                    r = packs.install_pack(pid)
                    msgs.append(f"{r['pack']}: listo" + (f" (fallaron {len(r['fallidos'])})" if r["fallidos"] else ""))
                except Exception as exc:  # noqa: BLE001
                    msgs.append(f"{packs.PACKS[pid].name}: {exc}")
            GLib.idle_add(self.status.set_label, " · ".join(msgs))

        threading.Thread(target=work, daemon=True).start()

    def _p_safety(self) -> Gtk.Box:
        from . import vigia

        box = self._page("5 · PROTECCIÓN", "Tu equipo, protegido",
                         "El cortafuegos, AppArmor y los parches de seguridad automáticos ya están activos.")
        sec = vigia.load_settings()

        def set_vigia(v: bool) -> None:
            sec.vigia = v
            vigia.save_settings(sec)

        box.append(self._switch_row("Vigía de descargas", "NYX analiza cada descarga y te avisa si es peligrosa.",
                                    sec.vigia, set_vigia))
        box.append(self._choice("Configurar copias de seguridad", "Timeshift guarda «fotos» del sistema para volver "
                                "atrás si algo se rompe. Déjà Dup copia tus archivos a un disco externo o a la nube.",
                                lambda _b: self._launch(["timeshift-launcher"], ["deja-dup"])))
        return box

    def _launch(self, *candidates: list[str]) -> None:
        import shutil

        for cmd in candidates:
            if shutil.which(cmd[0]):
                subprocess.Popen(cmd, start_new_session=True)
                return
        self.status.set_label("Esa aplicación no está instalada.")

    def _p_done(self) -> Gtk.Box:
        box = self._page("LISTO", "Todo preparado", "Algunas cosas que te vendrán bien:")
        keys = Gtk.Label(xalign=0, label=(
            "Súper + Espacio     Buscar aplicaciones, archivos y ajustes\n"
            "Súper + N           Abrir NYX\n"
            "Orbe del escritorio Clic para hablar · mantén pulsado para moverlo\n"
            "«¿Es seguro …?»     NYX analiza cualquier archivo\n"
            "«Cada viernes …»    Crea rutinas que NYX repite sola"))
        keys.add_css_class("keys")
        box.append(keys)
        return box


class WelcomeApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.Bienvenida")

    def do_activate(self) -> None:
        if self.props.active_window:
            self.props.active_window.present()
            return
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        css = theme.glass_css() + EXTRA_CSS + "".join(
            f".sw-{k} {{ background: {v[0]}; }}" for k, v in theme.ACCENTS.items())
        provider.load_from_data(css.encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        win = Welcome(self)
        win.present()
        GLib.timeout_add(80, self._center)

    def _center(self) -> bool:
        monitors = Gdk.Display.get_default().get_monitors()
        if monitors.get_n_items():
            geo = monitors.get_item(0).get_geometry()
            wmctrl("-r", TITLE, "-e", f"0,{geo.x + (geo.width - W - 36) // 2},{geo.y + (geo.height - H - 36) // 2},-1,-1")
        return False


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if done_flag().exists() and "--otra-vez" not in argv:
        return 0
    GLib.set_prgname("umbra-bienvenida")
    return WelcomeApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
