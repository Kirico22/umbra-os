"""Dibuja el átomo vivo con cairo (lo usan la ventana del escritorio y el generador de vídeo)."""

from __future__ import annotations

import math

import cairo

from .atom import Frame, orbit_point

NEUTRON = (196 / 255, 188 / 255, 222 / 255)


class AtomRenderer:
    def __init__(self, proton: tuple[float, float, float], center: tuple[float, float], scale: float) -> None:
        self.proton = proton
        self.electron = tuple(c + (1 - c) * 0.55 for c in proton)
        self.center = center
        self.scale = scale

    def draw(self, cr: cairo.Context, frame: Frame) -> None:
        cx, cy = self.center
        s = self.scale
        self._orbits(cr, frame, front=False)
        drawn_front = False
        for b in frame.balls:  # de atrás hacia delante
            if not drawn_front and b.depth > 1.0:  # todo el núcleo ya está pintado
                self._orbits(cr, frame, front=True)
                drawn_front = True
            self._ball(cr, cx + b.x * s, cy + b.y * s, b.radius * s, b.kind, b.sphere, b.alpha)
        if not drawn_front:
            self._orbits(cr, frame, front=True)
        for e in frame.effects:
            self._effect(cr, cx + e.x * s, cy + e.y * s, e.radius * s, e.kind, e.alpha)

    def _color(self, kind: str) -> tuple[float, float, float]:
        if "neutron" in kind:
            return NEUTRON
        if kind == "electron":
            return self.electron
        return self.proton

    def _ball(self, cr, x, y, radius, kind, sphere, alpha) -> None:
        if alpha <= 0.01 or radius <= 0.5:
            return
        r0, g0, b0 = self._color(kind)
        glow = cairo.RadialGradient(x, y, 0, x, y, radius * 1.8)
        glow.add_color_stop_rgba(0, r0, g0, b0, 0.22 * alpha)
        glow.add_color_stop_rgba(1, r0, g0, b0, 0)
        cr.set_source(glow)
        cr.arc(x, y, radius * 1.8, 0, math.tau)
        cr.fill()
        # cuerpo oscuro que separa cada bolita de las que tiene detrás
        cr.set_source_rgba(r0 * 0.16, g0 * 0.16, b0 * 0.16, 0.6 * alpha)
        cr.arc(x, y, radius * 0.98, 0, math.tau)
        cr.fill()
        dot = max(0.6, radius / 18)
        for p in sphere.project(x, y, radius / 1.3):
            k = max(0.0, min(1.0, (p.depth + 1) / 2))
            cr.set_source_rgba(r0 + (1 - r0) * 0.45 * k, g0 + (1 - g0) * 0.45 * k, b0 + (1 - b0) * 0.45 * k,
                               p.alpha * alpha)
            cr.arc(p.x, p.y, dot * (0.5 + 0.5 * p.size), 0, math.tau)
            cr.fill()

    def _orbits(self, cr, frame: Frame, front: bool) -> None:
        if frame.orbit_scale < 0.02:
            return
        cx, cy = self.center
        s = self.scale
        er, eg, eb = self.electron
        phases = [None, None, None]
        for i, ang in frame.electrons:
            phases[i] = ang
        segments = 140
        cr.set_line_width(max(1.0, 1.4 * s))
        for i, phase in enumerate(phases):
            for k in range(segments):
                a0 = k / segments * math.tau
                a1 = (k + 1) / segments * math.tau
                x0, y0, z = orbit_point(i, a0, frame.orbit_scale)
                if (z >= 0) != front:
                    continue
                x1, y1, _ = orbit_point(i, a1, frame.orbit_scale)
                lag = (phase - a0) % math.tau if phase is not None else math.tau
                trail = max(0.0, 1 - lag / 2.2)  # estela brillante detrás del electrón
                alpha = (0.10 + 0.22 * (z + 1) / 2 + 0.55 * trail) * frame.orbit_alpha
                cr.set_source_rgba(er, eg, eb, alpha)
                cr.move_to(cx + x0 * s, cy + y0 * s)
                cr.line_to(cx + x1 * s, cy + y1 * s)
                cr.stroke()

    def _effect(self, cr, x, y, radius, kind, alpha) -> None:
        if alpha <= 0.01:
            return
        if kind == "glow":  # destello de la fusión
            g = cairo.RadialGradient(x, y, 0, x, y, radius)
            g.add_color_stop_rgba(0, 1, 1, 1, 0.95 * alpha)
            g.add_color_stop_rgba(0.3, *self.electron, 0.6 * alpha)
            g.add_color_stop_rgba(1, *self.proton, 0)
            cr.set_source(g)
            cr.arc(x, y, radius, 0, math.tau)
            cr.fill()
        elif kind == "ring":  # onda expansiva
            cr.set_line_width(max(2.0, 10 * alpha * self.scale))
            cr.set_source_rgba(*self.electron, min(1.0, 1.2 * alpha))
            cr.arc(x, y, radius, 0, math.tau)
            cr.stroke()
            cr.set_line_width(max(1.0, 34 * alpha * self.scale))
            cr.set_source_rgba(*self.proton, 0.30 * alpha)
            cr.arc(x, y, radius * 0.96, 0, math.tau)
            cr.stroke()
        elif kind == "mini-orbit":  # órbita de cada mini átomo
            cr.save()
            cr.translate(x, y)
            cr.scale(1, 0.32)
            cr.set_line_width(max(1.2, 1.8 * self.scale))
            cr.set_source_rgba(*self.electron, alpha)
            cr.arc(0, 0, radius, 0, math.tau)
            cr.restore()
            cr.stroke()
