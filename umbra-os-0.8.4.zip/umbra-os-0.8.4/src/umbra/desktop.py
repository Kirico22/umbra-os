"""Aplica la personalización de UMBRA al escritorio (XFCE + picom). Sin GTK.

Todos los comandos son fijos y se lanzan sin shell. Lo único que necesita permisos de
administrador es instalar un navegador, y pasa por polkit (pkexec) con un script fijo.
"""

from __future__ import annotations

import glob
import os
import shutil
import subprocess
from pathlib import Path

from . import theme

WALLPAPER_DIR = Path("/usr/share/umbra/fondos")
BROWSER_HELPER = "/usr/libexec/umbra/instalar-navegador"
BROWSERS = {
    # clave: (nombre visible, paquete, patrón del lanzador .desktop, orden para comprobar si está)
    "opera-gx": ("Opera GX", "opera-gx-stable", "opera*gx*.desktop", "opera-gx"),
    "chrome": ("Google Chrome", "google-chrome-stable", "google-chrome*.desktop", "google-chrome-stable"),
}


def _run(cmd: list[str], timeout: int = 10) -> subprocess.CompletedProcess | None:
    if shutil.which(cmd[0]) is None:
        return None
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None


# --- picom: animaciones + cristal ----------------------------------------------------------
def picom_config(level: str = "alto") -> str:
    """Configuración completa de picom para un nivel de cristal (alto, medio o apagado)."""
    strength = theme.GLASS_LEVELS.get(level, theme.GLASS_LEVELS["alto"])[1]
    blur = strength > 0
    # Las ventanas de UMBRA se llaman umbra-* (clase «Umbra-*»): ver set_prgname en cada aplicación
    glass_match = ("class_g ~= '^Umbra' || class_g = 'Xfce4-panel' || class_g = 'Wrapper-2.0' || "
                   "class_g = 'Xfce4-notifyd' || window_type = 'menu' || window_type = 'dropdown_menu' || "
                   "window_type = 'popup_menu'")
    blur_block = (f"""
# --- Cristal (Liquid Glass): desenfoque detrás de las ventanas de UMBRA, el panel y los menús ---
blur-method = "dual_kawase";
blur-strength = {strength};
blur-background-fixed = true;
""" if blur else "\n# Cristal apagado: sin desenfoque (mejor rendimiento)\n")
    glass_rule = f"""  {{
    # Ventanas de cristal de UMBRA, panel y menús: desenfoque del fondo
    match = "{glass_match}";
    blur-background = {'true' if blur else 'false'};
    shadow = true;
  }},
"""
    return f"""# Compositor de UMBRA OS (picom 12): animaciones, cristal, sombras y esquinas redondeadas.
# Generado por UMBRA (nivel de cristal: {level}). Se cambia desde «Ajustes de UMBRA».

# "glx" es necesario para el desenfoque; en máquinas virtuales usa la aceleración por software.
backend = "{'glx' if blur else 'xrender'}";
vsync = true;

# --- Sombras suaves y esquinas redondeadas ---
shadow = true;
shadow-radius = 18;
shadow-opacity = 0.45;
shadow-offset-x = -16;
shadow-offset-y = -12;
shadow-color = "#05020a";
corner-radius = 12;
{blur_block}
# --- Fundidos (respaldo si las animaciones no se pueden usar) ---
fading = true;
fade-in-step = 0.07;
fade-out-step = 0.08;
fade-delta = 8;

# --- Animaciones de ventana ---
animations = (
  {{
    # Abrir una aplicación o volver a mostrarla tras minimizar: aparece creciendo
    triggers = [ "open", "show" ];
    preset = "appear";
    duration = 0.22;
    scale = 0.9;
  }},
  {{
    # Cerrar o minimizar: se encoge y se desvanece
    triggers = [ "close", "hide" ];
    preset = "disappear";
    duration = 0.16;
    scale = 0.9;
  }},
  {{
    # Mover, maximizar o cambiar de tamaño: transición suave
    triggers = [ "geometry" ];
    preset = "geometry-change";
    duration = 0.2;
  }}
);

# --- Reglas por tipo de ventana ---
rules = (
{glass_rule}  {{
    # Escritorio: sin sombra, sin esquinas y sin animación
    match = "window_type = 'desktop'";
    shadow = false;
    corner-radius = 0;
    animations = ();
  }},
  {{
    # Dock de UMBRA: cápsula redondeada y sin animación de apertura
    match = "class_g = 'Xfce4-panel' && window_type = 'dock'";
    corner-radius = 18;
    animations = ();
  }},
  {{
    # El orbe de NYX: sin sombra cuadrada ni esquinas (es una esfera)
    match = "name = 'NYX-orbe'";
    shadow = false;
    corner-radius = 0;
    blur-background = false;
  }},
  {{
    # Menús y avisos: animación más corta y discreta
    match = "window_type = 'menu' || window_type = 'dropdown_menu' || window_type = 'popup_menu' || window_type = 'tooltip' || window_type = 'notification'";
    corner-radius = 8;
    animations = (
      {{ triggers = [ "open", "show" ]; preset = "appear"; duration = 0.12; scale = 0.97; }},
      {{ triggers = [ "close", "hide" ]; preset = "disappear"; duration = 0.1; scale = 0.97; }}
    );
  }},
  {{
    # Ventanas a pantalla completa (vídeos, juegos): sin esquinas
    match = "fullscreen";
    corner-radius = 0;
  }}
);
"""


def user_picom_path() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "picom.conf"


def apply_glass(level: str, restart: bool = True) -> Path:
    path = user_picom_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(picom_config(level), encoding="utf-8")
    if restart and shutil.which("picom"):
        _run(["pkill", "-x", "picom"])
        subprocess.Popen(["picom", "--config", str(path)], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    return path


# --- Escritorio XFCE --------------------------------------------------------------------
def _xfconf_set(channel: str, prop: str, kind: str, value: str) -> bool:
    r = _run(["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", kind, "-s", value])
    return bool(r and r.returncode == 0)


def apply_icon_size(size: int) -> bool:
    return _xfconf_set("xfce4-desktop", "/desktop-icons/icon-size", "uint", str(max(32, min(size, 128))))


def wallpapers() -> list[Path]:
    return sorted(Path(p) for p in glob.glob(str(WALLPAPER_DIR / "*.png")))


def apply_wallpaper(path: Path) -> int:
    """Pone el fondo en todos los monitores y escritorios que XFCE tenga registrados."""
    r = _run(["xfconf-query", "-c", "xfce4-desktop", "-l"])
    props = [p for p in (r.stdout.splitlines() if r else []) if p.endswith("/last-image")]
    if not props:
        props = ["/backdrop/screen0/monitor0/workspace0/last-image"]
    done = sum(_xfconf_set("xfce4-desktop", p, "string", str(path)) for p in props)
    return done


# --- Puntero del ratón -------------------------------------------------------------------
CURSOR_DIRS = [Path.home() / ".icons", Path.home() / ".local/share/icons", Path("/usr/share/icons")]
CURSOR_ORDER = ["UMBRA", "UMBRA-Claro", "Bibata-Modern-Classic", "Bibata-Modern-Ice", "Bibata-Original-Classic",
                "breeze_cursors", "Breeze_Light", "DMZ-White", "DMZ-Black", "Adwaita"]
CURSOR_NAMES = {"UMBRA": "UMBRA (oscuro)", "UMBRA-Claro": "UMBRA claro", "breeze_cursors": "Breeze",
                "Breeze_Light": "Breeze claro", "DMZ-White": "DMZ blanco", "DMZ-Black": "DMZ negro"}
CURSOR_SIZES = (24, 32, 48, 64)


def cursor_themes(dirs: list[Path] | None = None) -> list[str]:
    """Temas de puntero instalados (carpetas con cursors/), los de UMBRA primero."""
    found = set()
    for d in dirs or CURSOR_DIRS:
        if d.is_dir():
            for theme_dir in d.iterdir():
                if (theme_dir / "cursors").is_dir():
                    found.add(theme_dir.name)
    ordered = [t for t in CURSOR_ORDER if t in found]
    return ordered + sorted(found - set(ordered))


def cursor_label(name: str) -> str:
    return CURSOR_NAMES.get(name, name.replace("-", " ").replace("_", " "))


def apply_cursor(name: str, size: int, home: Path | None = None) -> None:
    """Cambia el puntero: XFCE/GTK (xsettings) y el de X11 (~/.icons/default), para todas las apps."""
    size = max(16, min(int(size), 96))
    _xfconf_set("xsettings", "/Gtk/CursorThemeName", "string", name)
    _xfconf_set("xsettings", "/Gtk/CursorThemeSize", "int", str(size))
    default = (home or Path.home()) / ".icons" / "default"
    default.mkdir(parents=True, exist_ok=True)
    (default / "index.theme").write_text(f"[Icon Theme]\nInherits={name}\n", encoding="utf-8")
    xres = (home or Path.home()) / ".Xresources"
    lines = [ln for ln in (xres.read_text().splitlines() if xres.exists() else [])
             if not ln.startswith(("Xcursor.theme:", "Xcursor.size:"))]
    lines += [f"Xcursor.theme: {name}", f"Xcursor.size: {size}"]
    xres.write_text("\n".join(lines) + "\n", encoding="utf-8")
    _run(["xrdb", "-merge", str(xres)])


# --- Átomo vivo del escritorio ---------------------------------------------------------------
def restart_atom(enabled: bool) -> None:
    _run(["pkill", "-f", "umbra.atomo|umbra-atomo"])
    if enabled and shutil.which("umbra-atomo"):
        subprocess.Popen(["umbra-atomo"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)


# --- Orbe de NYX ------------------------------------------------------------------------
def set_orb(visible: bool) -> None:
    _run(["pkill", "-f", "umbra.orb|nyx-orbe"])
    if visible and shutil.which("nyx-orbe"):
        subprocess.Popen(["nyx-orbe", "--forzar"], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)


# --- Navegadores ------------------------------------------------------------------------
def browser_installed(key: str) -> bool:
    return shutil.which(BROWSERS[key][3]) is not None


def install_browser(key: str) -> tuple[bool, str]:
    """Instala Opera GX o Chrome desde su repositorio oficial y lo pone como predeterminado."""
    if key not in BROWSERS:
        return False, "Navegador desconocido."
    name = BROWSERS[key][0]
    if not Path(BROWSER_HELPER).exists() or shutil.which("pkexec") is None:
        return False, "Falta el instalador de navegadores de UMBRA."
    r = _run(["pkexec", BROWSER_HELPER, key], timeout=1800)
    if r is None or r.returncode != 0:
        if r is not None and r.returncode == 126:
            return False, "Instalación cancelada."
        return False, f"No se pudo instalar {name}. ¿Hay conexión a internet?"
    set_default_browser(key)
    return True, f"{name} instalado y elegido como navegador predeterminado."


NAV_LAUNCHER = "umbra-navegador.desktop"


def _desktop_entry(path: Path) -> dict[str, str]:
    import configparser

    cp = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        cp.read(path, encoding="utf-8")
        return dict(cp["Desktop Entry"])
    except (configparser.Error, KeyError, UnicodeDecodeError, OSError):
        return {}


DOCK_BROWSER_SLOT = 4  # plugin-4 del dock (etc/xdg/xfce4/panel/default.xml)


def sync_browser_launcher(config_home: Path | None = None, default_id: str | None = None) -> bool:
    """Pone en el botón «Navegador» del dock el nombre y el icono del navegador predeterminado.

    Escribe el lanzador en ~/.config/xfce4/panel/launcher-4/, que es donde el panel guarda los
    suyos: el panel vigila esa carpeta y cambia el icono al momento, sin reiniciarse.
    Devuelve True si ha cambiado algo."""
    if default_id is None:
        r = _run(["xdg-settings", "get", "default-web-browser"])
        default_id = r.stdout.strip() if r and r.returncode == 0 else ""
    default_id = default_id.removesuffix(".desktop")
    if not default_id or default_id == NAV_LAUNCHER.removesuffix(".desktop"):
        default_id = "chromium"
    entry: dict[str, str] = {}
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    for d in (data_home / "applications", Path("/usr/share/applications"),
              Path("/var/lib/flatpak/exports/share/applications")):
        if (d / f"{default_id}.desktop").is_file():
            entry = _desktop_entry(d / f"{default_id}.desktop")
            break
    icon = entry.get("icon", "web-browser")
    name = entry.get("name", "el navegador")
    text = ("[Desktop Entry]\nType=Application\nName=Navegador\n"
            f"Comment=Abre {name}\nExec=umbra-navegador %U\nIcon={icon}\nTerminal=false\n"
            "X-UMBRA-Dock=true\nStartupNotify=true\n")
    config_home = config_home or Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    path = config_home / "xfce4" / "panel" / f"launcher-{DOCK_BROWSER_SLOT}" / NAV_LAUNCHER
    try:
        if path.read_text(encoding="utf-8") == text:
            return False
    except OSError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return True


def set_default_browser(key: str) -> bool:
    pattern = BROWSERS[key][2]
    found = sorted(glob.glob(f"/usr/share/applications/{pattern}"))
    if not found:
        return False
    desktop = Path(found[0]).name
    r = _run(["xdg-settings", "set", "default-web-browser", desktop])
    _run(["xdg-mime", "default", desktop, "x-scheme-handler/http", "x-scheme-handler/https", "text/html"])
    sync_browser_launcher(default_id=desktop)
    return bool(r and r.returncode == 0)
