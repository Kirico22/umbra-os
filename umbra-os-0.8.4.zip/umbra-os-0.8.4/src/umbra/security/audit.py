"""Registro de auditoría: una línea JSON por acción, solo se añade, nunca se reescribe."""

from __future__ import annotations

import getpass
import json
import os
import time
from pathlib import Path
from typing import Any

SENSITIVE_WORDS = ("password", "passwd", "contraseña", "token", "secret", "secreto", "api_key", "apikey")
SENSITIVE_EXACT = {"clave", "pin", "otp"}


def is_sensitive(name: str) -> bool:
    name = str(name).lower()
    return name in SENSITIVE_EXACT or any(w in name for w in SENSITIVE_WORDS)


def redact(data: Any) -> Any:
    """Oculta valores cuyo nombre sugiera un secreto."""
    if isinstance(data, dict):
        return {k: "***" if is_sensitive(k) else redact(v) for k, v in data.items()}
    if isinstance(data, list):
        return [redact(v) for v in data]
    return data


class AuditLog:
    MAX_BYTES = 5 * 1024 * 1024  # al pasar de 5 MB se rota
    KEEP = 3  # copias antiguas: audit.log.1, .2 y .3

    def __init__(self, path: Path, max_bytes: int | None = None) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if max_bytes is not None:
            self.MAX_BYTES = max_bytes

    def _rotate(self) -> None:
        try:
            if self.path.stat().st_size < self.MAX_BYTES:
                return
        except FileNotFoundError:
            return
        for i in range(self.KEEP, 0, -1):
            older = self.path.with_name(f"{self.path.name}.{i}")
            newer = self.path.with_name(f"{self.path.name}.{i - 1}") if i > 1 else self.path
            if newer.exists():
                newer.replace(older)

    def record(self, **entry: Any) -> None:
        self._rotate()
        entry = redact(entry)
        entry.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        try:
            entry.setdefault("user", getpass.getuser())
        except Exception:  # pragma: no cover - entornos sin usuario
            entry.setdefault("user", str(os.getuid()))
        line = json.dumps(entry, ensure_ascii=False, default=str)
        # O_APPEND: escrituras atómicas al final; permisos 600 al crear
        fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")

    def tail(self, n: int = 20) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        lines = self.path.read_text(encoding="utf-8").splitlines()[-n:]
        return [json.loads(line) for line in lines if line.strip()]
