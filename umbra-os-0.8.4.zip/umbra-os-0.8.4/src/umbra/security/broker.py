"""Intermediario de ejecución seguro entre NYX y Linux.

NYX nunca ejecuta comandos. Solo puede *pedir* acciones registradas por nombre.
El broker:
  1. busca la acción en el registro (si no existe, se rechaza),
  2. valida los argumentos,
  3. comprueba que la política concede al módulo todos los permisos necesarios,
  3b. ejecuta la comprobación previa de la acción, si la tiene,
  4. pide confirmación al usuario si el riesgo es MEDIUM o HIGH,
  5. ejecuta capturando errores,
  6. deja todo registrado en la auditoría (también los rechazos).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from .audit import AuditLog
from .policy import Action, Module, Policy, Risk

# Recibe (acción, argumentos) y devuelve True solo si el usuario confirma.
ConfirmFn = Callable[[Action, dict[str, Any]], bool]


def deny_all(_action: Action, _args: dict[str, Any]) -> bool:
    return False


@dataclass
class ToolCall:
    action_id: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionResult:
    ok: bool
    action_id: str
    output: Any = None
    error: str | None = None
    status: str = "ok"  # ok | rejected | denied | cancelled | error


class Broker:
    def __init__(self, policy: Policy, audit: AuditLog, confirm: ConfirmFn = deny_all) -> None:
        self.policy = policy
        self.audit = audit
        self.confirm = confirm
        self._actions: dict[str, tuple[Module, Action]] = {}
        self._modules: dict[str, Module] = {}

    # --- registro -------------------------------------------------------
    def register(self, module: Module) -> None:
        if module.id in self._modules:
            raise ValueError(f"módulo duplicado: {module.id}")
        self._modules[module.id] = module
        for action in module.actions:
            if action.id in self._actions:
                raise ValueError(f"acción duplicada: {action.id}")
            self._actions[action.id] = (module, action)

    def modules(self) -> list[Module]:
        return list(self._modules.values())

    def available_actions(self) -> list[Action]:
        """Acciones que la política permite usar (las demás ni se ofrecen al modelo)."""
        out = []
        for module, action in self._actions.values():
            if action.permissions <= self.policy.granted(module):
                out.append(action)
        return out

    # --- ejecución ------------------------------------------------------
    def execute(self, call: ToolCall) -> ExecutionResult:
        entry = self._actions.get(call.action_id)
        if entry is None:
            return self._finish(call, "rejected", error="acción desconocida")
        module, action = entry

        try:
            args = action.validate_args(call.args)
        except ValueError as exc:
            return self._finish(call, "rejected", error=str(exc))

        missing = action.permissions - self.policy.granted(module)
        if missing:
            names = ", ".join(sorted(p.value for p in missing))
            return self._finish(call, "denied", error=f"permisos no concedidos: {names}")

        if action.precheck is not None:
            try:
                action.precheck(**args)
            except PermissionError as exc:
                return self._finish(call, "denied", error=str(exc))
            except Exception as exc:
                return self._finish(call, "rejected", error=str(exc))

        if action.risk >= Risk.MEDIUM:
            try:
                accepted = bool(self.confirm(action, args))
            except Exception:
                accepted = False
            if not accepted:
                return self._finish(call, "cancelled", error="el usuario no lo ha confirmado")

        try:
            output = action.handler(**args)
        except PermissionError as exc:  # p. ej. ruta fuera de las carpetas permitidas
            return self._finish(call, "denied", error=str(exc))
        except Exception as exc:  # el error se informa, nunca tumba a NYX
            return self._finish(call, "error", error=f"{type(exc).__name__}: {exc}")
        return self._finish(call, "ok", output=output)

    def _finish(self, call: ToolCall, status: str, output: Any = None, error: str | None = None) -> ExecutionResult:
        self.audit.record(action=call.action_id, args=call.args, status=status, error=error)
        return ExecutionResult(
            ok=status == "ok", action_id=call.action_id, output=output, error=error, status=status
        )
