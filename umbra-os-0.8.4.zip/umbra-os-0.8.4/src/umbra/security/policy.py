"""Modelo de permisos de UMBRA.

Reglas clave:
- Cada acción declara los permisos que necesita y su nivel de riesgo.
- Cada módulo declara los permisos que solicita; la política decide cuáles se le conceden.
- La política se carga desde ficheros del sistema. El modelo de IA no tiene ninguna
  vía para modificarla: no existe ninguna acción que conceda permisos.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from pathlib import Path
from typing import Any, Callable


class Permission(str, Enum):
    SYSTEM_READ = "system.read"
    FILES_READ = "files.read"
    FILES_WRITE = "files.write"
    PROCESS_READ = "process.read"
    PROCESS_CONTROL = "process.control"
    SERVICE_READ = "service.read"
    SERVICE_CONTROL = "service.control"
    PACKAGE_READ = "package.read"
    PACKAGE_INSTALL = "package.install"
    APPS_LAUNCH = "apps.launch"
    NETWORK_READ = "network.read"
    NETWORK_CONTROL = "network.control"
    MEMORY_READ = "memory.read"
    MEMORY_WRITE = "memory.write"


# Permisos concedidos por defecto: solo lectura y la memoria propia de NYX.
DEFAULT_GRANTS: frozenset[Permission] = frozenset(
    {
        Permission.SYSTEM_READ,
        Permission.FILES_READ,
        Permission.PROCESS_READ,
        Permission.SERVICE_READ,
        Permission.NETWORK_READ,
        Permission.PACKAGE_READ,
        Permission.APPS_LAUNCH,
        Permission.MEMORY_READ,
        Permission.MEMORY_WRITE,
    }
)


class Risk(IntEnum):
    """Nivel de riesgo de una acción."""

    LOW = 0  # solo lectura o cambios en la memoria propia de NYX
    MEDIUM = 1  # cambia el sistema pero se puede deshacer -> pide confirmación
    HIGH = 2  # administrativa o irreversible -> pide confirmación explícita


@dataclass(frozen=True)
class Param:
    name: str
    type: type
    required: bool = True
    description: str = ""


@dataclass
class Action:
    id: str  # "modulo.funcion"
    description: str
    handler: Callable[..., Any]
    permissions: frozenset[Permission]
    risk: Risk = Risk.LOW
    params: tuple[Param, ...] = ()
    # Comprobación previa opcional: se ejecuta ANTES de pedir confirmación, para no
    # preguntar al usuario por algo que de todas formas se va a rechazar.
    precheck: Callable[..., None] | None = None

    def validate_args(self, args: dict[str, Any]) -> dict[str, Any]:
        """Comprueba argumentos: sin claves desconocidas, tipos correctos, obligatorios presentes."""
        if not isinstance(args, dict):
            raise ValueError("los argumentos deben ser un objeto")
        known = {p.name: p for p in self.params}
        unknown = set(args) - set(known)
        if unknown:
            raise ValueError(f"argumentos no permitidos: {', '.join(sorted(unknown))}")
        clean: dict[str, Any] = {}
        for p in self.params:
            if p.name not in args:
                if p.required:
                    raise ValueError(f"falta el argumento obligatorio '{p.name}'")
                continue
            value = args[p.name]
            # bool es subclase de int: no aceptarlo donde se espera un número
            if p.type is int and isinstance(value, bool):
                raise ValueError(f"'{p.name}' debe ser {p.type.__name__}")
            if not isinstance(value, p.type):
                raise ValueError(f"'{p.name}' debe ser {p.type.__name__}")
            clean[p.name] = value
        return clean


@dataclass
class Module:
    id: str
    name: str
    description: str
    requested: frozenset[Permission]
    actions: list[Action] = field(default_factory=list)
    trusted: bool = True  # los módulos externos empiezan como no confiables

    def __post_init__(self) -> None:
        for action in self.actions:
            if not action.id.startswith(self.id + "."):
                raise ValueError(f"la acción {action.id} no pertenece al módulo {self.id}")
            missing = action.permissions - self.requested
            if missing:
                raise ValueError(
                    f"la acción {action.id} usa permisos no solicitados por el módulo: "
                    + ", ".join(sorted(p.value for p in missing))
                )


@dataclass
class Policy:
    """Permisos concedidos a cada módulo. Solo se lee de ficheros, nunca la cambia NYX."""

    default_grants: frozenset[Permission] = DEFAULT_GRANTS
    module_grants: dict[str, frozenset[Permission]] = field(default_factory=dict)

    def granted(self, module: Module) -> frozenset[Permission]:
        if not module.trusted:
            return frozenset()
        extra = self.module_grants.get(module.id, frozenset())
        return (self.default_grants | extra) & module.requested

    @classmethod
    def from_file(cls, path: Path) -> "Policy":
        """Formato:
        [grants]
        services = ["service.control"]
        """
        with Path(path).open("rb") as fh:
            raw = tomllib.load(fh)
        grants = {
            module_id: frozenset(Permission(p) for p in perms)
            for module_id, perms in raw.get("grants", {}).items()
        }
        return cls(module_grants=grants)
