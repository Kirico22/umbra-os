"""Carga de configuración (TOML) con valores por defecto seguros."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

SYSTEM_CONFIG = Path("/etc/umbra/umbra.toml")


def safe_mode() -> bool:
    """Sesión «UMBRA (modo seguro)»: sin animaciones, sin cerebro y sin extras; la seguridad sigue activa."""
    return os.environ.get("UMBRA_SEGURO") == "1"


def user_config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "umbra"


def user_data_dir() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "umbra"


@dataclass
class NyxConfig:
    provider: str = "auto"  # auto | cerebro | llama_cpp | ollama | none
    model_path: str = "~/.local/share/umbra/models/nyx.gguf"
    model: str = "llama3.2:3b"
    ollama_url: str = "http://127.0.0.1:11434"
    timeout_seconds: int = 120
    context_messages: int = 12


@dataclass
class Config:
    nyx: NyxConfig = field(default_factory=NyxConfig)
    memory_path: Path = field(default_factory=lambda: user_data_dir() / "memory.db")
    audit_log: Path = field(default_factory=lambda: user_data_dir() / "audit.log")
    allowed_roots: list[Path] = field(default_factory=lambda: [Path.home()])


def _merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for key, value in extra.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def load_config(path: Path | None = None) -> Config:
    """Lee la configuración del sistema, la del usuario y, si se indica, un fichero concreto."""
    raw: dict = {}
    candidates = [SYSTEM_CONFIG, user_config_dir() / "umbra.toml"]
    if path is not None:
        candidates.append(Path(path))
    for candidate in candidates:
        if candidate.is_file():
            with candidate.open("rb") as fh:
                raw = _merge(raw, tomllib.load(fh))

    cfg = Config()
    nyx = raw.get("nyx", {})
    for key in ("provider", "model_path", "model", "ollama_url", "timeout_seconds", "context_messages"):
        if key in nyx:
            setattr(cfg.nyx, key, nyx[key])

    mem = raw.get("memory", {})
    if mem.get("path"):
        cfg.memory_path = Path(mem["path"]).expanduser()

    sec = raw.get("security", {})
    if sec.get("audit_log"):
        cfg.audit_log = Path(sec["audit_log"]).expanduser()
    if sec.get("allowed_roots"):
        cfg.allowed_roots = [Path(p).expanduser() for p in sec["allowed_roots"]]
    return cfg
