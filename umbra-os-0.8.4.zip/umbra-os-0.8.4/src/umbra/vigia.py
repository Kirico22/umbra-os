"""Vigía de descargas: NYX revisa cada archivo que llega a Descargas y avisa si es peligroso.

    umbra-vigia                 vigila la carpeta de descargas (arranca con la sesión)
    umbra-vigia --una-vez       analiza lo que haya ahora y termina

Cómo funciona:
- Ignora las descargas a medio terminar (.crdownload, .part, .opdownload...) y espera a que el
  tamaño del archivo deje de cambiar antes de analizarlo.
- Los archivos que ya estaban al arrancar no se vuelven a analizar (solo los nuevos).
- Si algo no es seguro le quita el permiso de ejecución, lo apunta en el registro de auditoría
  y abre el aviso de NYX, donde el usuario decide: cuarentena o mantenerlo.
- NYX no borra ni mueve nada por su cuenta: la cuarentena siempre la decide el usuario.
- Solo hay un vigía por usuario (fichero de bloqueo) y se apaga solo si se desactiva en Ajustes.
"""

from __future__ import annotations

import argparse
import fcntl
import json
import os
import shutil
import subprocess
import sys
import time
import tomllib
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path

from . import scanner
from .config import load_config, user_config_dir

TEMP_SUFFIXES = (".crdownload", ".part", ".partial", ".download", ".opdownload", ".tmp", ".!ut", ".aria2")


# --------------------------------------------------------------------------- ajustes

@dataclass
class Settings:
    vigia: bool = True  # vigilar Descargas
    antivirus_completo: bool = False  # usar clamscan aunque clamd esté parado (lento, ~1 GB de RAM)
    avisar_seguros: bool = True  # notificación discreta también cuando todo está bien
    voz: bool = True  # NYX lee el aviso en voz alta si es peligroso
    avisos_sistema: bool = True  # NYX proactiva: disco lleno, programas colgados, actualizaciones


def settings_path() -> Path:
    return user_config_dir() / "seguridad.toml"


def load_settings(path: Path | None = None) -> Settings:
    path = path or settings_path()
    s = Settings()
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return s
    for key, default in asdict(s).items():
        value = raw.get(key, default)
        if isinstance(value, bool):
            setattr(s, key, value)
    return s


def save_settings(s: Settings, path: Path | None = None) -> Path:
    path = path or settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# Seguridad de UMBRA OS (se cambia desde Ajustes → Seguridad)"]
    lines += [f"{k} = {'true' if v else 'false'}" for k, v in asdict(s).items()]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


# --------------------------------------------------------------------------- vigilancia

def is_candidate(p: Path) -> bool:
    name = p.name
    return not name.startswith(".") and not name.lower().endswith(TEMP_SUFFIXES)


class Watcher:
    """Vigilancia por sondeo: robusta, sin dependencias y casi sin consumo (un stat por archivo)."""

    def __init__(self, folder: Path, on_report: Callable[[scanner.Report], None], *,
                 settle: float = 2.0, scan_existing: bool = False,
                 scan_fn: Callable[[Path], scanner.Report] | None = None,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.folder = Path(folder)
        self.on_report = on_report
        self.settle = settle
        self.clock = clock
        self.scan_fn = scan_fn or (lambda p: scanner.scan(p))
        self.seen: dict[Path, tuple[int, int]] = {}
        self.pending: dict[Path, tuple[tuple[int, int], float]] = {}
        if not scan_existing:
            self.seen = self._snapshot()

    def _snapshot(self) -> dict[Path, tuple[int, int]]:
        out: dict[Path, tuple[int, int]] = {}
        try:
            entries = list(os.scandir(self.folder))
        except OSError:
            return out
        for e in entries:
            try:
                if not e.is_file(follow_symlinks=False):
                    continue
                st = e.stat(follow_symlinks=False)
            except OSError:
                continue
            p = Path(e.path)
            if is_candidate(p):
                out[p] = (st.st_size, st.st_mtime_ns)
        return out

    def poll(self) -> list[scanner.Report]:
        now = self.clock()
        current = self._snapshot()
        reports: list[scanner.Report] = []
        for p, key in current.items():
            if self.seen.get(p) == key:
                continue
            prev = self.pending.get(p)
            if prev is None or prev[0] != key:
                self.pending[p] = (key, now)  # nuevo o todavía creciendo: esperamos
                continue
            if now - prev[1] < self.settle:
                continue
            del self.pending[p]
            self.seen[p] = key
            try:
                rep = self.scan_fn(p)
            except (OSError, ValueError):
                continue  # desapareció o dejó de ser un archivo normal
            reports.append(rep)
            self.on_report(rep)
        for gone in set(self.seen) - set(current):
            del self.seen[gone]
        for gone in set(self.pending) - set(current):
            del self.pending[gone]
        return reports


# --------------------------------------------------------------------------- reacción

def report_dir() -> Path:
    base = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache")
    d = base / "umbra" / "avisos"
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    return d


def save_report(rep: scanner.Report) -> Path:
    path = report_dir() / f"{time.strftime('%Y%m%d-%H%M%S')}-{os.getpid()}-{abs(hash(rep.path)) % 10**6}.json"
    path.write_text(json.dumps(rep.to_dict(), ensure_ascii=False), encoding="utf-8")
    os.chmod(path, 0o600)
    return path


def notify(title: str, body: str, urgency: str = "normal", icon: str = "security-high") -> None:
    if shutil.which("notify-send") is None:
        return
    try:
        subprocess.Popen(["notify-send", "-a", "NYX", "-u", urgency, "-i", icon, "--", title, body],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def react(rep: scanner.Report, settings: Settings, audit=None, launch_alert: bool = True) -> str:
    """Lo que hace el vigía con cada informe. Devuelve lo que ha hecho (para registro y pruebas)."""
    did = "avisado"
    if rep.verdict != scanner.SEGURO and scanner.strip_exec(rep.path):
        did = "avisado, sin permiso de ejecución"
    if audit is not None:
        audit.record(action="vigia.analisis", args={"archivo": rep.path, "sha256": rep.sha256},
                     status=rep.verdict, error=None)
    if rep.verdict == scanner.SEGURO:
        if settings.avisar_seguros:
            notify("NYX ha revisado una descarga", f"{rep.name}: no he encontrado nada sospechoso.",
                   urgency="low", icon="security-high")
        return "seguro"
    if launch_alert and shutil.which("umbra-aviso"):
        try:
            subprocess.Popen(["umbra-aviso", str(save_report(rep))],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            return did
        except OSError:
            pass
    peligro = rep.verdict == scanner.PELIGROSO
    notify("⚠ Descarga peligrosa" if peligro else "Descarga: precaución", rep.summary(),
           urgency="critical" if peligro else "normal", icon="security-low" if peligro else "security-medium")
    return did


def _single_instance() -> object | None:
    lock = report_dir().parent / "vigia.lock"
    fh = open(lock, "w")  # noqa: SIM115 - debe seguir abierto mientras viva el proceso
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return None
    return fh


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="umbra-vigia", description="NYX vigila tus descargas")
    parser.add_argument("--carpeta", type=Path, help="carpeta a vigilar (por defecto, Descargas)")
    parser.add_argument("--una-vez", action="store_true", help="analizar lo que haya ahora y salir")
    parser.add_argument("--intervalo", type=float, default=1.5)
    args = parser.parse_args(argv)

    settings = load_settings()
    folder = (args.carpeta or scanner.downloads_dir()).expanduser()
    folder.mkdir(parents=True, exist_ok=True)
    from .security import AuditLog

    audit = AuditLog(load_config().audit_log)
    antivirus: bool | str = True if settings.antivirus_completo else "rapido"
    scan_fn = lambda p: scanner.scan(p, antivirus=antivirus)  # noqa: E731

    if args.una_vez:
        w = Watcher(folder, lambda r: None, scan_existing=True, settle=0, scan_fn=scan_fn)
        w.poll()  # el primer sondeo anota los archivos; el segundo, con tamaño estable, los analiza
        reports = w.poll()
        for r in reports:
            print(f"{scanner.LABEL[r.verdict]:<11} {r.name}  {'; '.join(f.message for f in r.findings)}")
        return 1 if any(r.verdict == scanner.PELIGROSO for r in reports) else 0

    lock = _single_instance()
    if lock is None:
        print("El vigía ya está en marcha.", file=sys.stderr)
        return 0
    if not settings.vigia:
        return 0
    watcher = Watcher(folder, lambda r: react(r, load_settings(), audit), scan_fn=scan_fn)
    cfg_path = settings_path()
    cfg_mtime = cfg_path.stat().st_mtime if cfg_path.exists() else 0
    while True:
        time.sleep(args.intervalo)
        watcher.poll()
        # Si se desactiva en Ajustes, el vigía se apaga solo
        mtime = cfg_path.stat().st_mtime if cfg_path.exists() else 0
        if mtime != cfg_mtime:
            cfg_mtime = mtime
            if not load_settings().vigia:
                return 0


if __name__ == "__main__":
    raise SystemExit(main())
