"""Módulo files: explorar, buscar y organizar archivos dentro de las carpetas permitidas.

Organizar es la única acción que modifica algo:
- solo mueve archivos del primer nivel de la carpeta (no entra en subcarpetas),
- nunca sobrescribe (si el destino existe, ese archivo se salta),
- pide confirmación (riesgo MEDIO) y guarda un registro para poder deshacerlo.
"""

from __future__ import annotations

import fnmatch
import json
import os
import time
from pathlib import Path

from ..security import Action, Module, Param, Permission, Risk

MAX_ENTRIES = 200
MAX_SCAN = 100_000

CATEGORIES: dict[str, tuple[str, ...]] = {
    "Imágenes": (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg", ".heic", ".tiff"),
    "Documentos": (".pdf", ".doc", ".docx", ".odt", ".txt", ".md", ".rtf", ".xls", ".xlsx",
                   ".ods", ".csv", ".ppt", ".pptx", ".odp", ".epub"),
    "Música": (".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac", ".opus"),
    "Vídeos": (".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv"),
    "Comprimidos": (".zip", ".rar", ".7z", ".tar", ".gz", ".xz", ".bz2", ".tgz"),
    "Programas": (".deb", ".appimage", ".sh", ".run", ".exe", ".msi", ".iso"),
    "Código": (".py", ".js", ".ts", ".html", ".css", ".json", ".c", ".cpp", ".h", ".java",
               ".rs", ".go", ".php", ".sql", ".toml", ".yaml", ".yml"),
}


class PathNotAllowed(PermissionError):
    pass


def safe_path(raw: str, allowed_roots: list[Path]) -> Path:
    """Resuelve la ruta (incluidos enlaces simbólicos y '..') y exige que caiga dentro de una raíz."""
    path = Path(raw).expanduser().resolve()
    for root in allowed_roots:
        root = Path(root).expanduser().resolve()
        if path == root or root in path.parents:
            return path
    raise PathNotAllowed(f"ruta fuera de las carpetas permitidas: {path}")


def category_for(name: str) -> str | None:
    ext = Path(name).suffix.lower()
    for cat, exts in CATEGORIES.items():
        if ext in exts:
            return cat
    return None


def _dir_size(path: Path, limit: int = 200_000) -> int:
    """Tamaño de una carpeta sin seguir enlaces simbólicos. Se corta tras `limit` archivos."""
    total = 0
    seen = 0
    for dirpath, _dirnames, filenames in os.walk(path, followlinks=False, onerror=lambda e: None):
        for name in filenames:
            try:
                total += os.lstat(os.path.join(dirpath, name)).st_size
            except OSError:
                pass
            seen += 1
            if seen >= limit:
                return total
    return total


def build(allowed_roots: list[Path], undo_dir: Path | None = None) -> Module:
    roots = [Path(r) for r in allowed_roots]
    undo_dir = Path(undo_dir) if undo_dir else Path.home() / ".local" / "share" / "umbra" / "undo"

    def list_dir(path: str = "~") -> dict:
        target = safe_path(path, roots)
        if not target.is_dir():
            raise NotADirectoryError(str(target))
        entries = []
        for i, entry in enumerate(sorted(target.iterdir(), key=lambda p: p.name.lower())):
            if i >= MAX_ENTRIES:
                break
            try:
                st = entry.lstat()
            except OSError:
                continue
            entries.append(
                {"nombre": entry.name, "tipo": "carpeta" if entry.is_dir() else "archivo", "bytes": st.st_size}
            )
        return {"ruta": str(target), "entradas": entries}

    def usage(path: str = "~", top: int = 10) -> dict:
        target = safe_path(path, roots)
        if not target.is_dir():
            raise NotADirectoryError(str(target))
        top = max(1, min(top, 50))
        sizes = []
        for entry in target.iterdir():
            try:
                if entry.is_symlink():
                    continue
                size = _dir_size(entry) if entry.is_dir() else entry.stat().st_size
            except OSError:
                continue
            sizes.append((size, entry.name))
        sizes.sort(reverse=True)
        return {
            "ruta": str(target),
            "mayores": [{"nombre": n, "mb": round(s / 1024**2, 1)} for s, n in sizes[:top]],
        }

    def find(name: str, path: str = "~", limit: int = 30) -> dict:
        """Busca por nombre (sin distinguir mayúsculas; admite comodines * y ?)."""
        target = safe_path(path, roots)
        pattern = name.lower() if any(c in name for c in "*?[") else f"*{name.lower()}*"
        limit = max(1, min(limit, 200))
        found, scanned = [], 0
        for dirpath, dirnames, filenames in os.walk(target, followlinks=False, onerror=lambda e: None):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]  # sin carpetas ocultas
            for entry in dirnames + filenames:
                scanned += 1
                if fnmatch.fnmatch(entry.lower(), pattern):
                    found.append(os.path.join(dirpath, entry))
                    if len(found) >= limit:
                        return {"buscado": name, "en": str(target), "resultados": found, "completo": False}
            if scanned >= MAX_SCAN:
                return {"buscado": name, "en": str(target), "resultados": found, "completo": False}
        return {"buscado": name, "en": str(target), "resultados": found, "completo": True}

    def _plan(target: Path) -> list[tuple[Path, Path]]:
        moves = []
        for entry in sorted(target.iterdir()):
            if entry.is_symlink() or not entry.is_file() or entry.name.startswith("."):
                continue
            cat = category_for(entry.name)
            if cat is None:
                continue
            dest = target / cat / entry.name
            if not dest.exists():
                moves.append((entry, dest))
        return moves

    def organize_preview(path: str = "~/Descargas") -> dict:
        target = safe_path(path, roots)
        if not target.is_dir():
            raise NotADirectoryError(str(target))
        resumen: dict[str, int] = {}
        for _src, dest in _plan(target):
            resumen[dest.parent.name] = resumen.get(dest.parent.name, 0) + 1
        return {"ruta": str(target), "por_carpeta": resumen, "total": sum(resumen.values())}

    def organize(path: str = "~/Descargas") -> dict:
        target = safe_path(path, roots)
        if not target.is_dir():
            raise NotADirectoryError(str(target))
        done = []
        for src, dest in _plan(target):
            dest.parent.mkdir(exist_ok=True)
            if dest.exists():  # comprobación final por si cambió entre medias
                continue
            src.rename(dest)
            done.append({"de": str(src), "a": str(dest)})
        journal = None
        if done:
            undo_dir.mkdir(parents=True, exist_ok=True)
            journal = undo_dir / f"organize-{time.strftime('%Y%m%d-%H%M%S')}-{os.getpid()}.json"
            journal.write_text(json.dumps(done, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"ruta": str(target), "movidos": len(done), "deshacer": str(journal) if journal else None}

    def undo_organize() -> dict:
        """Deshace la última organización (devuelve cada archivo a su sitio si está libre)."""
        journals = sorted(undo_dir.glob("organize-*.json")) if undo_dir.exists() else []
        if not journals:
            return {"restaurados": 0, "mensaje": "No hay nada que deshacer."}
        last = journals[-1]
        moves = json.loads(last.read_text(encoding="utf-8"))
        restored = 0
        for m in reversed(moves):
            src, dest = Path(m["a"]), Path(m["de"])
            safe_path(str(src), roots)
            safe_path(str(dest), roots)
            if src.exists() and not dest.exists():
                src.rename(dest)
                restored += 1
                try:
                    src.parent.rmdir()  # solo si quedó vacía
                except OSError:
                    pass
        last.rename(last.with_suffix(".deshecho"))
        return {"restaurados": restored, "mensaje": f"Restaurados {restored} archivos."}

    read = frozenset({Permission.FILES_READ})
    write = frozenset({Permission.FILES_READ, Permission.FILES_WRITE})
    return Module(
        id="files",
        name="Archivos",
        description="Explorar, buscar y organizar archivos.",
        requested=write,
        actions=[
            Action("files.list", "Lista el contenido de una carpeta.", list_dir, read, Risk.LOW,
                   (Param("path", str, required=False),)),
            Action("files.usage", "Muestra lo que más espacio ocupa en una carpeta.", usage, read, Risk.LOW,
                   (Param("path", str, required=False), Param("top", int, required=False))),
            Action("files.find", "Busca archivos o carpetas por nombre.", find, read, Risk.LOW,
                   (Param("name", str), Param("path", str, required=False), Param("limit", int, required=False))),
            Action("files.organize_preview", "Muestra cómo quedaría una carpeta organizada por tipos, sin tocar nada.",
                   organize_preview, read, Risk.LOW, (Param("path", str, required=False),)),
            Action("files.organize", "Organiza los archivos de una carpeta en subcarpetas por tipo (se puede deshacer).",
                   organize, write, Risk.MEDIUM, (Param("path", str, required=False),),
                   precheck=lambda path="~/Descargas": safe_path(path, roots) and None),
            Action("files.undo_organize", "Deshace la última organización de archivos.",
                   undo_organize, write, Risk.MEDIUM),
        ],
    )
