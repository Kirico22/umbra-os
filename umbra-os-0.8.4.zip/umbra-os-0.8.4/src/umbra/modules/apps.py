"""Módulo apps: listar y abrir aplicaciones instaladas.

Solo abre aplicaciones que existen como lanzador .desktop instalado; el modelo da
un nombre, pero lo que se ejecuta es siempre el identificador del lanzador encontrado.
"""

from __future__ import annotations

import configparser
import os
import shutil
import subprocess
import unicodedata
from pathlib import Path

from ..security import Action, Module, Param, Permission, Risk


def _dirs() -> list[Path]:
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    data_dirs = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")
    return [data_home / "applications", *(Path(d) / "applications" for d in data_dirs)]


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in text if not unicodedata.combining(c)).strip()


# Categorías del cajón de aplicaciones (por las Categories del .desktop)
GROUPS = [
    ("internet", "Internet", ("Network", "WebBrowser", "Email", "Chat", "InstantMessaging")),
    ("multimedia", "Multimedia", ("AudioVideo", "Audio", "Video", "Graphics", "Photography")),
    ("oficina", "Oficina", ("Office", "WordProcessor", "Spreadsheet", "Presentation")),
    ("juegos", "Juegos", ("Game",)),
    ("desarrollo", "Desarrollo", ("Development", "IDE")),
    ("sistema", "Sistema", ("System", "Settings", "Utility", "Security", "Accessibility", "Monitor")),
]
_CACHE: dict = {}


def group_of(categories: str) -> str:
    cats = set(filter(None, categories.split(";")))
    for key, _label, names in GROUPS:
        if cats & set(names):
            return key
    return "otras"


def _visible(e, desktop: str) -> bool:
    if e.get("Type") != "Application" or e.get("NoDisplay", "").lower() == "true" \
            or e.get("Hidden", "").lower() == "true":
        return False
    if e.get("X-UMBRA-Dock", "").lower() == "true":
        return False  # botones del dock (Aplicaciones, Archivos, Navegador, Apagar): ya están en el dock
    only = [x for x in e.get("OnlyShowIn", "").split(";") if x]
    if only and desktop not in only:
        return False  # p. ej. ajustes solo de GNOME o KDE: en XFCE no funcionan
    if desktop in e.get("NotShowIn", "").split(";"):
        return False
    try_exec = e.get("TryExec", "").strip()
    if try_exec and shutil.which(try_exec) is None and not Path(try_exec).is_file():
        return False  # el programa ya no está instalado
    return True


def installed(dirs: list[Path] | None = None) -> dict[str, dict]:
    """Aplicaciones instaladas. Se guarda en memoria y solo se relee si cambia alguna carpeta."""
    dirs = list(dirs or _dirs())
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "XFCE").split(":")[0] or "XFCE"
    stamp = []
    for d in dirs:
        try:
            stamp.append((str(d), d.stat().st_mtime_ns))
        except OSError:
            stamp.append((str(d), 0))
    key = (tuple(stamp), desktop)
    if _CACHE.get("key") == key:
        return dict(_CACHE["apps"])
    apps: dict[str, dict] = {}
    for d in dirs:
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.desktop")):
            if f.stem in apps:
                continue  # el primero (usuario) tiene prioridad
            cp = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                cp.read(f, encoding="utf-8")
                e = cp["Desktop Entry"]
            except (configparser.Error, KeyError, UnicodeDecodeError):
                continue
            if not _visible(e, desktop):
                apps.setdefault(f.stem, None)  # oculta: tapa también a las de carpetas del sistema
                continue
            name = e.get("Name[es]") or e.get("Name") or f.stem
            apps[f.stem] = {"id": f.stem, "nombre": name, "descripcion": e.get("Comment[es]") or e.get("Comment", ""),
                            "icono": e.get("Icon", "") or "application-x-executable",
                            "grupo": group_of(e.get("Categories", ""))}
    apps = {k: v for k, v in apps.items() if v is not None}
    _CACHE.update(key=key, apps=apps)
    return dict(apps)


def find_app(query: str, apps: dict[str, dict]) -> dict | None:
    q = _norm(query)
    if not q:
        return None
    exact = [a for a in apps.values() if _norm(a["nombre"]) == q or _norm(a["id"]) == q]
    if exact:
        return exact[0]
    partial = [a for a in apps.values() if q in _norm(a["nombre"]) or q in _norm(a["id"])]
    return min(partial, key=lambda a: len(a["nombre"])) if partial else None


def _game_mode(on: bool) -> dict:
    from .. import gamemode

    return gamemode.enable() if on else gamemode.disable()


def build(dirs: list[Path] | None = None, launcher=None) -> Module:
    def list_apps() -> list[dict]:
        return sorted(installed(dirs).values(), key=lambda a: _norm(a["nombre"]))

    def open_app(name: str) -> dict:
        app = find_app(name, installed(dirs))
        if app is None:
            raise LookupError(f"no encuentro ninguna aplicación llamada '{name}'")
        if launcher is not None:
            launcher(app["id"])
        else:
            if shutil.which("gtk-launch") is None:
                raise RuntimeError("falta gtk-launch para abrir aplicaciones")
            subprocess.Popen(  # se separa de NYX: cerrar NYX no cierra la app
                ["gtk-launch", app["id"]], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        return {"abierta": app["nombre"], "id": app["id"]}

    return Module(
        id="apps",
        name="Aplicaciones",
        description="Listar y abrir aplicaciones instaladas.",
        requested=frozenset({Permission.SYSTEM_READ, Permission.APPS_LAUNCH}),
        actions=[
            Action("apps.list", "Lista las aplicaciones instaladas.", list_apps,
                   frozenset({Permission.SYSTEM_READ})),
            Action("apps.open", "Abre una aplicación instalada por su nombre.", open_app,
                   frozenset({Permission.APPS_LAUNCH}), Risk.LOW, (Param("name", str),)),
            Action("apps.game_mode", "Activa o desactiva el modo juego (sin notificaciones, pantalla siempre "
                   "encendida, fondo en pausa y GameMode). Se deshace del todo al desactivarlo.", _game_mode,
                   frozenset({Permission.APPS_LAUNCH}), Risk.LOW, (Param("on", bool),)),
        ],
    )
