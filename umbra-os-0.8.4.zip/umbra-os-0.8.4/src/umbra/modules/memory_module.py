"""Módulo memory: permite a NYX guardar, consultar y olvidar datos en su memoria."""

from __future__ import annotations

from ..nyx.memory import Memory
from ..security import Action, Module, Param, Permission, Risk


def build(memory: Memory) -> Module:
    def remember(key: str, value: str) -> str:
        memory.remember(key, value)
        return f"Guardado: {key}"

    def recall(query: str = "") -> list[dict]:
        return memory.recall(query)

    def forget(key: str) -> str:
        return "Olvidado" if memory.forget(key) else "No había nada con esa clave"

    r = frozenset({Permission.MEMORY_READ})
    w = frozenset({Permission.MEMORY_WRITE})
    return Module(
        id="memory",
        name="Memoria",
        description="Memoria persistente de NYX.",
        requested=r | w,
        actions=[
            Action("memory.remember", "Guarda un dato o preferencia del usuario.", remember, w, Risk.LOW,
                   (Param("key", str), Param("value", str))),
            Action("memory.recall", "Busca en la memoria.", recall, r, Risk.LOW,
                   (Param("query", str, required=False),)),
            Action("memory.forget", "Borra un dato de la memoria.", forget, w, Risk.LOW,
                   (Param("key", str),)),
        ],
    )
