"""Módulo processes: procesos que más memoria usan, leyendo /proc (solo lectura)."""

from __future__ import annotations

import os
import signal
from pathlib import Path

from ..security import Action, Module, Param, Permission, Risk


def _read_proc(pid_dir: Path) -> dict | None:
    try:
        status = (pid_dir / "status").read_text()
    except OSError:
        return None
    name, rss_kb = "?", 0
    for line in status.splitlines():
        if line.startswith("Name:"):
            name = line.split(":", 1)[1].strip()
        elif line.startswith("VmRSS:"):
            rss_kb = int(line.split()[1])
    return {"pid": int(pid_dir.name), "nombre": name, "ram_mb": round(rss_kb / 1024, 1)}


def top(n: int = 10) -> list[dict]:
    n = max(1, min(n, 50))
    procs = []
    for pid_dir in Path("/proc").iterdir() if Path("/proc").exists() else []:
        if pid_dir.name.isdigit():
            info = _read_proc(pid_dir)
            if info:
                procs.append(info)
    procs.sort(key=lambda p: p["ram_mb"], reverse=True)
    return procs[:n]


def check_stop(pid: int) -> None:
    """Solo procesos PROPIOS: nunca de otros usuarios, de root, el PID 1 ni NYX."""
    if pid <= 1 or pid == os.getpid():
        raise PermissionError("ese proceso no se puede cerrar")
    try:
        owner = (Path("/proc") / str(pid)).stat().st_uid
    except FileNotFoundError:
        raise LookupError(f"no existe el proceso {pid}") from None
    if owner != os.getuid() or owner == 0:
        raise PermissionError("solo puedo cerrar procesos de tu usuario")


def stop(pid: int) -> dict:
    """Pide a un proceso propio que se cierre (SIGTERM)."""
    check_stop(pid)  # se repite justo antes de actuar, por si algo cambió
    info = _read_proc(Path("/proc") / str(pid)) or {"nombre": "?"}
    os.kill(pid, signal.SIGTERM)
    return {"cerrado": info["nombre"], "pid": pid}


def build() -> Module:
    read = frozenset({Permission.PROCESS_READ})
    control = frozenset({Permission.PROCESS_CONTROL})
    return Module(
        id="processes",
        name="Procesos",
        description="Ver y cerrar procesos.",
        requested=read | control,
        actions=[
            Action(
                id="processes.top",
                description="Lista los procesos que más RAM usan.",
                handler=top,
                permissions=read,
                risk=Risk.LOW,
                params=(Param("n", int, required=False, description="cuántos mostrar (máx. 50)"),),
            ),
            Action(
                id="processes.stop",
                description="Cierra un proceso de tu usuario por su número (pid).",
                handler=stop,
                permissions=control,
                risk=Risk.MEDIUM,
                params=(Param("pid", int),),
                precheck=check_stop,
            ),
        ],
    )
