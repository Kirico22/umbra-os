"""Módulo network: estado de la red (solo lectura). Comandos fijos, sin shell."""

from __future__ import annotations

import json
import shutil
import subprocess

from ..security import Action, Module, Permission


def _ip_json(*args: str) -> list:
    if shutil.which("ip") is None:
        return []
    proc = subprocess.run(["ip", "-j", *args], capture_output=True, text=True, timeout=10, check=False)
    try:
        return json.loads(proc.stdout or "[]")
    except json.JSONDecodeError:
        return []


def status() -> dict:
    interfaces = []
    for iface in _ip_json("addr", "show"):
        if iface.get("ifname") == "lo":
            continue
        ips = [a["local"] for a in iface.get("addr_info", []) if a.get("family") == "inet"]
        interfaces.append({"nombre": iface.get("ifname"), "estado": iface.get("operstate"), "ipv4": ips})
    routes = _ip_json("route", "show", "default")
    gateway = routes[0].get("gateway") if routes else None
    dns = []
    try:
        with open("/etc/resolv.conf", encoding="utf-8") as fh:
            dns = [line.split()[1] for line in fh if line.startswith("nameserver")]
    except OSError:
        pass
    return {
        "interfaces": interfaces,
        "puerta_enlace": gateway,
        "dns": dns,
        "conectado": bool(gateway) and any(i["ipv4"] for i in interfaces),
    }


def build() -> Module:
    read = frozenset({Permission.NETWORK_READ})
    return Module(
        id="network",
        name="Red",
        description="Estado de la red.",
        requested=read,
        actions=[Action("network.status", "Interfaces, direcciones IP, puerta de enlace y DNS.", status, read)],
    )
