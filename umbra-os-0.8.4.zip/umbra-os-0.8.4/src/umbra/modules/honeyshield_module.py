"""Módulo honeyshield: NYX vigila los señuelos, explica las amenazas y bloquea IPs si tú lo confirmas.

- Ver el estado, los eventos y las amenazas: solo lectura.
- Encender o apagar los señuelos abre o cierra puertos en el cortafuegos: riesgo MEDIO.
- Bloquear o desbloquear una IP cambia el cortafuegos: riesgo MEDIO, y además pide la contraseña.
"""

from __future__ import annotations

import shutil
import subprocess

from .. import honeyshield as hs
from ..security import Action, Module, Param, Permission, Risk


def build() -> Module:
    def enable(red_local: bool = True) -> dict:
        s = hs.load_settings()
        s.direccion = "0.0.0.0" if red_local else "127.0.0.1"
        out = {"señuelos": {n: p for n, (p, _) in hs.DECOYS.items()}, "escucha_en": s.direccion}
        if red_local:
            out["cortafuegos"] = hs.firewall("abrir")
        s.activo = True
        hs.save_settings(s)
        if shutil.which("umbra-honeyshield"):
            subprocess.Popen(["umbra-honeyshield"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        out["activo"] = True
        return out

    def disable() -> dict:
        s = hs.load_settings()
        was_open = s.direccion == "0.0.0.0"
        s.activo = False
        hs.save_settings(s)  # el demonio lo ve y se para solo
        out = {"activo": False}
        if was_open:
            try:
                out["cortafuegos"] = hs.firewall("cerrar")
            except (RuntimeError, PermissionError) as e:
                out["aviso"] = f"señuelos parados, pero los puertos siguen abiertos: {e}"
        return out

    def check_ip(ip: str) -> None:
        hs.valid_block_ip(ip)

    return Module(
        id="honeyshield",
        name="HoneyShield",
        description="Señuelos (honeypots) que detectan escaneos y ataques en la red, y bloqueo de IPs.",
        requested=frozenset({Permission.NETWORK_READ, Permission.NETWORK_CONTROL}),
        actions=[
            Action("honeyshield.status", "Estado de HoneyShield: si está activo, cuántos ataques ha visto "
                   "y las IPs más peligrosas.", hs.status, frozenset({Permission.NETWORK_READ}), Risk.LOW),
            Action("honeyshield.events", "Últimas conexiones a los señuelos.", hs.recent,
                   frozenset({Permission.NETWORK_READ}), Risk.LOW, (Param("limit", int, required=False),)),
            Action("honeyshield.threats", "IPs ordenadas por nivel de amenaza.",
                   lambda limit=10: hs.tracker_from_events(hs.load_events()).ranking(limit),
                   frozenset({Permission.NETWORK_READ}), Risk.LOW, (Param("limit", int, required=False),)),
            Action("honeyshield.enable", "Enciende los señuelos. En la red local abre sus puertos "
                   "(2121, 2222, 2323, 2525, 3307, 8081) en el cortafuegos.", enable,
                   frozenset({Permission.NETWORK_CONTROL}), Risk.MEDIUM, (Param("red_local", bool, required=False),)),
            Action("honeyshield.disable", "Apaga los señuelos y vuelve a cerrar sus puertos.", disable,
                   frozenset({Permission.NETWORK_CONTROL}), Risk.MEDIUM),
            Action("honeyshield.block", "Bloquea una IP en el cortafuegos (pide la contraseña).",
                   lambda ip: hs.firewall("bloquear", hs.valid_block_ip(ip)),
                   frozenset({Permission.NETWORK_CONTROL}), Risk.MEDIUM, (Param("ip", str),), precheck=check_ip),
            Action("honeyshield.unblock", "Quita el bloqueo de una IP.",
                   lambda ip: hs.firewall("desbloquear", hs.valid_block_ip(ip)),
                   frozenset({Permission.NETWORK_CONTROL}), Risk.MEDIUM, (Param("ip", str),), precheck=check_ip),
        ],
    )
