"""NYX Modules: capacidades del sistema expuestas como acciones con permisos."""

from __future__ import annotations

from pathlib import Path

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # solo para los tipos: así «import umbra.modules.apps» no carga todo NYX
    from ..nyx.memory import Memory
    from ..security import Module


def builtin_modules(allowed_roots: list[Path], memory: Memory, undo_dir: Path | None = None) -> list[Module]:
    from . import (apps, files, honeyshield_module, memory_module, network, packages, processes,
                   routines_module, security, services, system)

    return [
        system.build(),
        files.build(allowed_roots, undo_dir),
        processes.build(),
        services.build(),
        network.build(),
        apps.build(),
        packages.build(),
        memory_module.build(memory),
        security.build(allowed_roots),
        routines_module.build(),
        honeyshield_module.build(),
    ]
