"""Módulo packages: buscar e instalar programas desde los repositorios de Debian.

- Buscar es solo lectura.
- Instalar es riesgo ALTO: NYX pide escribir CONFIRMAR y, además, el sistema pide la
  contraseña de administrador mediante polkit (pkexec). NYX nunca ve ni guarda esa contraseña.
- El nombre del paquete se valida con una expresión estricta y se pasa como argumento
  fijo, nunca a través de un shell.
"""

from __future__ import annotations

import re
import shutil
import subprocess

from ..security import Action, Module, Param, Permission, Risk

PACKAGE_RE = re.compile(r"^[a-z0-9][a-z0-9+.\-]{0,62}$")


def valid_package(name: str) -> str:
    name = name.strip().lower()
    if not PACKAGE_RE.match(name):
        raise ValueError(f"nombre de paquete no válido: {name!r}")
    return name


def search(query: str, limit: int = 15) -> list[dict]:
    query = valid_package(query)
    if shutil.which("apt-cache") is None:
        raise RuntimeError("este sistema no usa apt")
    proc = subprocess.run(["apt-cache", "search", "--names-only", query],
                          capture_output=True, text=True, timeout=30, check=False)
    out = []
    for line in proc.stdout.splitlines():
        name, _, desc = line.partition(" - ")
        out.append({"paquete": name.strip(), "descripcion": desc.strip()})
    out.sort(key=lambda p: (p["paquete"] != query, len(p["paquete"])))
    return out[: max(1, min(limit, 50))]


def install(name: str) -> dict:
    name = valid_package(name)
    if shutil.which("pkexec") is None:
        raise RuntimeError("falta pkexec (polkit) para pedir autorización de administrador")
    proc = subprocess.run(
        ["pkexec", "/usr/bin/apt-get", "install", "-y", "--no-install-recommends", name],
        capture_output=True, text=True, timeout=1800, check=False,
    )
    if proc.returncode == 126:
        raise PermissionError("la autorización de administrador se canceló o se denegó")
    if proc.returncode != 0:
        raise RuntimeError(f"apt-get terminó con error {proc.returncode}: {proc.stderr.strip()[-300:]}")
    return {"instalado": name}


def check_browser(name: str) -> None:
    from ..desktop import BROWSERS

    if name not in BROWSERS:
        raise ValueError(f"navegador no disponible: {name!r} (opciones: {', '.join(BROWSERS)})")


def install_browser(name: str) -> dict:
    from ..desktop import install_browser as _install

    ok, msg = _install(name)
    if not ok:
        raise RuntimeError(msg)
    return {"instalado": msg}


def install_pack(name: str) -> dict:
    from ..packs import install_pack as _install

    return _install(name)


def check_pack(name: str) -> None:
    from ..packs import check_pack as _check

    _check(name)


def list_packs() -> list[dict]:
    from ..packs import list_packs as _list

    return _list()


def build() -> Module:
    return Module(
        id="packages",
        name="Programas",
        description="Buscar e instalar programas.",
        requested=frozenset({Permission.PACKAGE_READ, Permission.PACKAGE_INSTALL}),
        actions=[
            Action("packages.search", "Busca programas en los repositorios.", search,
                   frozenset({Permission.PACKAGE_READ}), Risk.LOW,
                   (Param("query", str), Param("limit", int, required=False))),
            Action("packages.install", "Instala un programa (pide autorización de administrador).", install,
                   frozenset({Permission.PACKAGE_INSTALL}), Risk.HIGH, (Param("name", str),),
                   precheck=lambda name: valid_package(name) and None),
            Action("packages.browser", "Instala Opera GX o Google Chrome desde su repositorio oficial "
                   "y lo pone como navegador predeterminado.", install_browser,
                   frozenset({Permission.PACKAGE_INSTALL}), Risk.HIGH, (Param("name", str),),
                   precheck=check_browser),
            Action("packages.packs", "Lista los packs de aplicaciones (gaming, creativo, programación, multimedia).",
                   list_packs, frozenset({Permission.PACKAGE_READ}), Risk.LOW),
            Action("packages.pack", "Instala un pack de aplicaciones: lo de Debian con contraseña de "
                   "administrador y lo de Flathub solo para tu usuario.", install_pack,
                   frozenset({Permission.PACKAGE_INSTALL}), Risk.HIGH, (Param("name", str),),
                   precheck=check_pack),
        ],
    )
