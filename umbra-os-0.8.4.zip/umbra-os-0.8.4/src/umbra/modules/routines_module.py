"""Módulo routines: crear, ver y borrar rutinas de NYX. Crear o borrar pide confirmación."""

from __future__ import annotations

from pathlib import Path

from .. import routines
from ..security import Action, Module, Param, Permission, Risk


def build(store: Path | None = None) -> Module:
    def add(orden: str, cuando: str) -> dict:
        return routines.add(orden, cuando, p=store)

    def check_add(orden: str, cuando: str) -> None:
        routines.check_order(orden)
        routines.parse_schedule(cuando)

    return Module(
        id="routines",
        name="Rutinas",
        description="Órdenes que NYX repite sola (las de riesgo alto nunca se hacen solas).",
        requested=frozenset({Permission.MEMORY_READ, Permission.MEMORY_WRITE}),
        actions=[
            Action("routines.add", "Crea una rutina: una orden que NYX repetirá sola en ese horario.", add,
                   frozenset({Permission.MEMORY_WRITE}), Risk.MEDIUM,
                   (Param("orden", str), Param("cuando", str)), precheck=check_add),
            Action("routines.list", "Lista las rutinas.", lambda: routines.listing(store),
                   frozenset({Permission.MEMORY_READ}), Risk.LOW),
            Action("routines.remove", "Borra una rutina por su número.", lambda id: routines.remove(id, store),
                   frozenset({Permission.MEMORY_WRITE}), Risk.MEDIUM, (Param("id", int),)),
        ],
    )
