"""Módulo services: servicios de systemd que han fallado (solo lectura).

El comando es fijo y se lanza sin shell; ningún dato del modelo entra en él.
"""

from __future__ import annotations

import shutil
import subprocess

from ..security import Action, Module, Permission, Risk

FAILED_CMD = ["systemctl", "--failed", "--no-legend", "--plain", "--no-pager"]


def failed() -> dict:
    if shutil.which("systemctl") is None:
        return {"disponible": False, "fallidos": []}
    proc = subprocess.run(FAILED_CMD, capture_output=True, text=True, timeout=15, check=False)
    units = []
    for line in proc.stdout.splitlines():
        parts = line.split(None, 4)
        if parts:
            units.append({"unidad": parts[0], "detalle": parts[4] if len(parts) > 4 else ""})
    return {"disponible": True, "fallidos": units}


def build() -> Module:
    read = frozenset({Permission.SERVICE_READ})
    return Module(
        id="services",
        name="Servicios",
        description="Comprobar servicios del sistema.",
        requested=read,
        actions=[
            Action(
                id="services.failed",
                description="Lista los servicios de systemd que han fallado.",
                handler=failed,
                permissions=read,
                risk=Risk.LOW,
            )
        ],
    )
