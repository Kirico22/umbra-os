"""Módulo system: información de hardware y rendimiento (solo lectura)."""

from __future__ import annotations

import os
import platform
import shutil
from pathlib import Path

from ..security import Action, Module, Permission, Risk


def _meminfo() -> dict[str, int]:
    """Lee /proc/meminfo en kB."""
    data: dict[str, int] = {}
    path = Path("/proc/meminfo")
    if not path.exists():
        return data
    for line in path.read_text().splitlines():
        key, _, rest = line.partition(":")
        parts = rest.split()
        if parts and parts[0].isdigit():
            data[key] = int(parts[0])
    return data


def _uptime_seconds() -> float | None:
    try:
        return float(Path("/proc/uptime").read_text().split()[0])
    except (OSError, ValueError, IndexError):
        return None


def info() -> dict:
    mem = _meminfo()
    total = mem.get("MemTotal", 0) * 1024
    available = mem.get("MemAvailable", 0) * 1024
    disk = shutil.disk_usage("/")
    try:
        load1, load5, load15 = os.getloadavg()
    except OSError:
        load1 = load5 = load15 = 0.0
    cpus = os.cpu_count() or 1
    return {
        "sistema": f"{platform.system()} {platform.release()}",
        "cpu_nucleos": cpus,
        "carga_1_5_15": [round(load1, 2), round(load5, 2), round(load15, 2)],
        "carga_por_nucleo_pct": round(load1 / cpus * 100, 1),
        "ram_total_gb": round(total / 1024**3, 2),
        "ram_disponible_gb": round(available / 1024**3, 2),
        "ram_uso_pct": round((1 - available / total) * 100, 1) if total else None,
        "swap_usada_gb": round((mem.get("SwapTotal", 0) - mem.get("SwapFree", 0)) / 1024**2, 2),
        "disco_raiz_total_gb": round(disk.total / 1024**3, 1),
        "disco_raiz_libre_gb": round(disk.free / 1024**3, 1),
        "disco_raiz_uso_pct": round((disk.total - disk.free) / disk.total * 100, 1),
        "encendido_horas": round((_uptime_seconds() or 0) / 3600, 1),
    }


def _memory() -> dict:
    from ..memoria import status

    return status()


def build() -> Module:
    return Module(
        id="system",
        name="Sistema",
        description="Estado del hardware: CPU, RAM, disco y carga.",
        requested=frozenset({Permission.SYSTEM_READ}),
        actions=[
            Action(
                id="system.info",
                description="Resumen de CPU, RAM, disco y carga del sistema.",
                handler=info,
                permissions=frozenset({Permission.SYSTEM_READ}),
                risk=Risk.LOW,
            ),
            Action(
                id="system.memory",
                description="Memoria virtual: RAM, memoria comprimida (zram) y swap en el disco.",
                handler=_memory,
                permissions=frozenset({Permission.SYSTEM_READ}),
                risk=Risk.LOW,
            ),
        ],
    )
