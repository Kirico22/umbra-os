"""🥚 `nyx --cosmos`: un átomo animado en la terminal (no aparece en la ayuda)."""

from __future__ import annotations

import math
import sys
import time

W, H = 64, 23
ORBITS = (-0.5, 0.55, 1.57)


def frame(t: float) -> list[str]:
    grid = [[" "] * W for _ in range(H)]
    cx, cy = W / 2, H / 2
    for k, ang in enumerate(ORBITS):
        for i in range(160):
            a = i / 160 * math.tau
            x, y = 26 * math.cos(a), 6.5 * math.sin(a)
            gx = int(round(cx + x * math.cos(ang) - y * math.sin(ang) * 2.0))
            gy = int(round(cy + (x * math.sin(ang) / 2.0 + y * math.cos(ang))))
            if 0 <= gx < W and 0 <= gy < H and grid[gy][gx] == " ":
                grid[gy][gx] = "·"
        a = t * (1.6 + 0.4 * k) + k * 2.1  # electrón
        x, y = 26 * math.cos(a), 6.5 * math.sin(a)
        gx = int(round(cx + x * math.cos(ang) - y * math.sin(ang) * 2.0))
        gy = int(round(cy + (x * math.sin(ang) / 2.0 + y * math.cos(ang))))
        if 0 <= gx < W and 0 <= gy < H:
            grid[gy][gx] = "●"
    for dx, dy, ch in ((-1, 0, "◉"), (1, 0, "○"), (0, -1, "○"), (0, 1, "◉"), (0, 0, "◉")):
        grid[int(cy) + dy][int(cx) + dx] = ch
    return ["".join(row) for row in grid]


def run(seconds: float = 5.0, fps: int = 20, out=sys.stdout) -> None:
    purple, reset = "\033[38;5;135m", "\033[0m"
    tty = out.isatty()
    start = time.monotonic()
    out.write("\033[?25l" if tty else "")
    try:
        while (now := time.monotonic() - start) < seconds:
            lines = frame(now)
            if tty:
                out.write("\033[H\033[2J")
            out.write("\n".join(purple + ln + reset if tty else ln for ln in lines) + "\n")
            out.write("        U M B R A   ·   todo está hecho de partículas\n")
            out.flush()
            if not tty:
                return
            time.sleep(1 / fps)
    finally:
        out.write("\033[?25h" if tty else "")
