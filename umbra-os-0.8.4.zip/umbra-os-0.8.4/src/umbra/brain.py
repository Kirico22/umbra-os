"""«Cerebro» de NYX: un modelo de lenguaje pequeño que funciona en el propio ordenador.

Sin cerebro, NYX entiende las órdenes habituales con su motor de intenciones. Con él, entiende
frases libres y puede conversar. Es opcional porque ocupa más de 1 GB y usa unos 2 GB de RAM.

- Se descarga desde Ajustes (o con ``nyx --cerebro``) a ~/.local/share/umbra/modelos.
- La descarga se comprueba con su huella SHA-256 oficial: si no coincide, se borra.
- Lo ejecuta llama-server (llama.cpp), solo en 127.0.0.1. El modelo nunca se conecta a internet.
- Igual que antes, el modelo NO ejecuta nada: solo propone acciones al broker de seguridad.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class BrainModel:
    id: str
    name: str
    file: str
    url: str
    sha256: str
    size: int
    license: str
    ram_gb: float


# Qwen2.5 1.5B Instruct (Apache 2.0): pequeño, rápido en CPU y con buen español.
# Huella y tamaño comprobados en la página oficial del modelo en Hugging Face.
MODELS: dict[str, BrainModel] = {m.id: m for m in (
    BrainModel(
        id="qwen2.5-1.5b",
        name="Qwen2.5 1.5B Instruct (Q4_K_M)",
        file="qwen2.5-1.5b-instruct-q4_k_m.gguf",
        url="https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
        sha256="6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e",
        size=1_117_320_736,
        license="Apache 2.0",
        ram_gb=2.0,
    ),
)}
DEFAULT = "qwen2.5-1.5b"
SERVER_CANDIDATES = ("/opt/umbra/llama/llama-server", "/usr/bin/llama-server", "/usr/local/bin/llama-server")


def models_dir() -> Path:
    base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share")
    return base / "umbra" / "modelos"


def model_path(model_id: str | None = None) -> Path:
    model_id = model_id or DEFAULT
    return models_dir() / MODELS[model_id].file


def installed(model_id: str | None = None) -> bool:
    model_id = model_id or DEFAULT
    p = model_path(model_id)
    return p.is_file() and p.stat().st_size == MODELS[model_id].size


def server_binary() -> str | None:
    for c in SERVER_CANDIDATES:
        if Path(c).is_file() and os.access(c, os.X_OK):
            return c
    return shutil.which("llama-server")


def status(model_id: str | None = None) -> dict:
    model_id = model_id or DEFAULT
    m = MODELS[model_id]
    free = shutil.disk_usage(models_dir().parent if models_dir().parent.exists() else Path.home()).free
    return {"modelo": m.name, "instalado": installed(model_id), "motor": server_binary() is not None,
            "tamano_gb": round(m.size / 1024**3, 2), "ram_gb": m.ram_gb, "licencia": m.license,
            "espacio_libre_gb": round(free / 1024**3, 1)}


def sha256_file(path: Path, chunk: int = 4 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while data := f.read(chunk):
            h.update(data)
    return h.hexdigest()


def download(model_id: str | None = None, progress: Callable[[int, int], None] | None = None,
             opener: Callable[..., object] = urllib.request.urlopen, cancel: Callable[[], bool] | None = None) -> Path:
    """Descarga (reanudable) y verifica el modelo. Devuelve la ruta final."""
    model_id = model_id or DEFAULT
    m = MODELS[model_id]
    dest = model_path(model_id)
    if installed(model_id):
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(dest.parent, 0o700)
    free = shutil.disk_usage(dest.parent).free
    part = dest.with_name(dest.name + ".part")
    have = part.stat().st_size if part.exists() else 0
    if free < (m.size - have) + 200 * 1024**2:
        raise RuntimeError(f"no hay espacio: hacen falta {m.size / 1024**3:.1f} GB libres")
    req = urllib.request.Request(m.url, headers={"Range": f"bytes={have}-"} if have else {})
    with opener(req, timeout=60) as resp:
        if have and getattr(resp, "status", 200) != 206:
            have = 0  # el servidor no permite reanudar: se empieza de cero
        with open(part, "ab" if have else "wb") as out:
            done = have
            while chunk := resp.read(1024 * 1024):
                if cancel and cancel():
                    raise RuntimeError("descarga cancelada (se puede reanudar)")
                out.write(chunk)
                done += len(chunk)
                if progress:
                    progress(done, m.size)
    if part.stat().st_size != m.size or sha256_file(part) != m.sha256:
        part.unlink(missing_ok=True)
        raise RuntimeError("el archivo descargado no coincide con la huella oficial; lo he borrado")
    part.replace(dest)
    os.chmod(dest, 0o600)
    return dest


def remove(model_id: str | None = None) -> bool:
    model_id = model_id or DEFAULT
    removed = False
    for p in (model_path(model_id), model_path(model_id).with_name(MODELS[model_id].file + ".part")):
        if p.exists():
            p.unlink()
            removed = True
    return removed


def provider(model_id: str | None = None):
    """Proveedor listo para NYX, o None si falta el modelo o el motor."""
    model_id = model_id or DEFAULT
    from .nyx.providers import LlamaServerProvider

    binary = server_binary()
    if not (installed(model_id) and binary):
        return None
    return LlamaServerProvider(model_path(model_id), binary, threads=max(1, (os.cpu_count() or 2) - 1))
