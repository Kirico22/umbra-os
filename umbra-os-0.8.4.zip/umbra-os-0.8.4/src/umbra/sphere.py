"""Esfera de partículas de NYX (matemática pura, sin dependencias gráficas).

La usan la ventana de NYX (dibujo con cairo) y el generador de la animación de arranque.

Estados:
  - "reposo":   gira despacio y respira.
  - "pensando": gira más rápido y las partículas ondulan en espiral.
  - "hablando": la esfera se expande y las partículas vibran al ritmo de la voz (energía 0..1).

Efectos especiales (easter eggs): trigger("supernova" | "barrel_roll" | "arcoiris" | "matrix" | "halloween").
"""

from __future__ import annotations

import colorsys
import math
import random
from dataclasses import dataclass


@dataclass
class Projected:
    x: float
    y: float
    depth: float  # -1 (detrás) .. 1 (delante)
    size: float
    alpha: float
    index: int = 0


def fibonacci_sphere(n: int) -> list[tuple[float, float, float]]:
    """n puntos repartidos de forma uniforme sobre una esfera unidad."""
    golden = math.pi * (3 - math.sqrt(5))
    pts = []
    for i in range(n):
        y = 1 - (i / (n - 1)) * 2
        r = math.sqrt(max(0.0, 1 - y * y))
        theta = golden * i
        pts.append((math.cos(theta) * r, y, math.sin(theta) * r))
    return pts


class ParticleSphere:
    def __init__(self, n: int = 420, seed: int = 7) -> None:
        rnd = random.Random(seed)
        self.base = fibonacci_sphere(n)
        self.phase = [rnd.uniform(0, math.tau) for _ in range(n)]
        self.freq = [rnd.uniform(0.7, 1.6) for _ in range(n)]
        self.size = [rnd.uniform(0.7, 1.4) for _ in range(n)]
        self.scatter = [rnd.uniform(0.6, 1.4) for _ in range(n)]
        self.effects: dict[str, float] = {}  # efecto -> instante en que empezó
        self.t = 0.0
        self.angle_y = 0.0
        self.tilt = 0.35  # inclinación para que se vea en 3D
        self.state = "reposo"
        self.energy = 0.0  # suavizada
        self._target_energy = 0.0
        self._think = 0.0  # 0..1, transición suave hacia "pensando"

    EFFECT_DURATION = {"supernova": 2.4, "barrel_roll": 1.2, "arcoiris": 8.0, "matrix": 8.0, "halloween": 30.0}

    def trigger(self, effect: str) -> None:
        if effect in self.EFFECT_DURATION:
            self.effects[effect] = self.t

    def _progress(self, effect: str) -> float | None:
        """0..1 mientras el efecto está activo; None si no lo está."""
        start = self.effects.get(effect)
        if start is None:
            return None
        p = (self.t - start) / self.EFFECT_DURATION[effect]
        if p >= 1:
            del self.effects[effect]
            return None
        return max(0.0, p)

    def tint(self, i: int) -> tuple[float, float, float] | None:
        """Color especial de la partícula i si hay un efecto de color activo."""
        p = self._progress("arcoiris")
        if p is not None:
            return colorsys.hsv_to_rgb((i / len(self.base) + self.t * 0.35) % 1, 0.65, 1.0)
        p = self._progress("matrix")
        if p is not None:
            flick = 0.55 + 0.45 * math.sin(self.t * 9 + self.phase[i] * 3)
            return (0.15 * flick, 1.0 * flick, 0.35 * flick)
        p = self._progress("halloween")
        if p is not None:
            return (1.0, 0.55 + 0.15 * math.sin(self.phase[i]), 0.1)
        return None

    def set_energy(self, value: float) -> None:
        self._target_energy = max(0.0, min(1.0, value))

    def update(self, dt: float) -> None:
        dt = max(0.0, min(dt, 0.1))
        self.t += dt
        # La energía sube rápido (sílabas) y baja más despacio (suave a la vista)
        k = 22.0 if self._target_energy > self.energy else 7.0
        self.energy += (self._target_energy - self.energy) * min(1.0, k * dt)
        goal = 1.0 if self.state == "pensando" else 0.0
        self._think += (goal - self._think) * min(1.0, 3.0 * dt)
        speed = 0.35 + 1.4 * self._think + 0.5 * self.energy
        self.angle_y = (self.angle_y + speed * dt) % math.tau
        for name, start in list(self.effects.items()):
            if self.t - start >= self.EFFECT_DURATION[name]:
                del self.effects[name]

    def project(self, cx: float, cy: float, radius: float, sort: bool = True) -> list[Projected]:
        """Puntos en pantalla, ordenados de atrás hacia delante (o en su orden original)."""
        breathe = 1 + 0.035 * math.sin(self.t * 1.6)
        r_all = radius * breathe * (1 + 0.16 * self.energy)
        cos_y, sin_y = math.cos(self.angle_y), math.sin(self.angle_y)
        tilt = self.tilt
        roll = self._progress("barrel_roll")
        if roll is not None:
            tilt += math.tau * (roll * roll * (3 - 2 * roll))  # una vuelta completa, suave
        cos_x, sin_x = math.cos(tilt), math.sin(tilt)
        nova = self._progress("supernova")
        # Supernova: las partículas salen disparadas y vuelven a juntarse
        blast = math.sin(math.pi * nova) ** 0.7 * 2.8 if nova is not None else 0.0
        out = []
        for i, (x, y, z) in enumerate(self.base):
            ph, fr = self.phase[i], self.freq[i]
            # Desplazamiento radial: respiración suave + vibración con la voz
            wobble = 0.025 * math.sin(self.t * 2 * fr + ph)
            wobble += self.energy * 0.32 * (0.5 + 0.5 * math.sin(self.t * 14 * fr + ph))
            # Al pensar, ondas en espiral según la latitud
            wobble += self._think * 0.09 * math.sin(self.t * 5 + y * 6 + ph * 0.3)
            s = 1 + wobble + blast * self.scatter[i]
            px, py, pz = x * s, y * s, z * s
            # Giro sobre Y y luego inclinación sobre X
            px, pz = px * cos_y + pz * sin_y, -px * sin_y + pz * cos_y
            py, pz = py * cos_x - pz * sin_x, py * sin_x + pz * cos_x
            persp = 1 / (1.9 - pz * 0.45)
            out.append(
                Projected(
                    x=cx + px * r_all * persp * 1.3,
                    y=cy + py * r_all * persp * 1.3,
                    depth=pz,
                    size=self.size[i] * (0.9 + 0.9 * (pz + 1) / 2) * (1 + 0.5 * self.energy),
                    alpha=(0.22 + 0.78 * ((max(-1.0, min(1.0, pz)) + 1) / 2)) * (1 - 0.45 * min(1.0, blast / 2.8)),
                    index=i,
                )
            )
        if sort:
            out.sort(key=lambda p: p.depth)
        return out
