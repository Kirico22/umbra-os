"""Estado del arranque: NYX lo comprueba y lo explica, pero NUNCA toca la BIOS/UEFI.

Solo lee archivos del núcleo (/sys y /proc): no cambia ajustes del firmware, no instala claves
y no modifica el cargador de arranque. Activar o desactivar Secure Boot lo hace siempre la
persona, en la configuración de su placa base.

Cadena de arranque verificado de UMBRA (la de Debian 13):
    firmware UEFI  →  shim (firmado por Microsoft)  →  GRUB (firmado por Debian)  →  núcleo Linux (firmado por Debian)
Si alguna pieza no tiene una firma válida, el firmware o shim se niegan a arrancarla.
"""

from __future__ import annotations

import platform
from pathlib import Path

EFI_GLOBAL = "8be4df61-93ca-11d2-aa0d-00e098032b8c"


def _efivar(root: Path, name: str) -> int | None:
    """Las variables EFI llevan 4 bytes de atributos y luego el valor."""
    try:
        data = (root / "sys/firmware/efi/efivars" / f"{name}-{EFI_GLOBAL}").read_bytes()
    except OSError:
        return None
    return data[4] if len(data) >= 5 else None


def _lockdown(root: Path) -> str | None:
    try:
        text = (root / "sys/kernel/security/lockdown").read_text()
    except OSError:
        return None
    start, end = text.find("["), text.find("]")
    return text[start + 1 : end] if 0 <= start < end else None


def boot_status(root: Path = Path("/")) -> dict:
    uefi = (root / "sys/firmware/efi").is_dir()
    secure = _efivar(root, "SecureBoot") if uefi else None
    setup = _efivar(root, "SetupMode") if uefi else None
    lockdown = _lockdown(root)
    st = {
        "firmware": "UEFI" if uefi else "BIOS antigua (legacy)",
        "arranque_seguro": "activado" if secure == 1 else "desactivado" if secure == 0 else "no disponible",
        "nucleo": f"Linux {platform.release()}" if root == Path("/") else "Linux",
        "bloqueo_nucleo": lockdown or "desconocido",
        "nivel": "bien",
        "consejo": "",
    }
    if not uefi:
        st["nivel"] = "aviso"
        st["consejo"] = ("Tu equipo arranca en modo BIOS antiguo, donde el arranque seguro no existe. Si tu placa "
                         "lo permite, cambia a modo UEFI en su configuración (al encender, suele ser F2 o Supr). "
                         "Ese cambio lo haces tú: NYX nunca toca la BIOS.")
    elif secure != 1:
        st["nivel"] = "aviso"
        st["consejo"] = ("Secure Boot está desactivado: el equipo arrancaría un cargador modificado sin avisar. "
                         "Puedes activarlo en la configuración de tu placa base; UMBRA arranca igual con él "
                         "activado. Ese cambio lo haces tú: NYX nunca toca la BIOS.")
        if setup == 1:
            st["consejo"] += " (Tu placa está en «modo configuración»: primero hay que restaurar sus claves de fábrica.)"
    else:
        st["consejo"] = ("Arranque verificado: firmware UEFI → shim (firmado por Microsoft) → GRUB → núcleo Linux "
                         "(firmados por Debian). Si alguien cambiara una pieza, el equipo no la arrancaría.")
    return st
