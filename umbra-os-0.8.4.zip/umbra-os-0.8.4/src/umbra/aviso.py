"""Aviso de NYX cuando una descarga no es segura.

    umbra-aviso ~/.cache/umbra/avisos/<informe>.json   (lo abre el vigía)
    umbra-aviso ~/Descargas/archivo                    (analiza y muestra el resultado)

Ventana de cristal con la esfera de NYX en rojo (peligroso) o ámbar (precaución), los motivos
explicados en español y dos botones. La cuarentena pasa por el broker de seguridad como cualquier
otra acción de NYX: necesita el permiso de la política y queda en el registro de auditoría. El clic
del usuario en el botón es la confirmación.
"""

from __future__ import annotations

import json
import sys
import threading
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import scanner, theme  # noqa: E402
from .sphere import ParticleSphere  # noqa: E402
from .widgets import SpeakingSphere, draw_sphere, float_window, wmctrl  # noqa: E402

TITLE = "NYX-aviso"
WIDTH = 560
COLORS = {scanner.PELIGROSO: (0.98, 0.32, 0.38), scanner.PRECAUCION: (1.0, 0.72, 0.25),
          scanner.SEGURO: (0.35, 0.92, 0.62)}
HEAD = {scanner.PELIGROSO: "Descarga peligrosa", scanner.PRECAUCION: "Ten precaución",
        scanner.SEGURO: "Todo en orden"}

EXTRA_CSS = """
.aviso-head { font-size: 22px; font-weight: 600; color: #ffffff; }
.aviso-file { font-family: "DejaVu Sans Mono", monospace; font-size: 13px; color: alpha(#ffffff, 0.85); }
.verdict { border-radius: 99px; padding: 3px 12px; font-size: 11px; font-weight: 700; letter-spacing: 2px; }
.verdict.peligroso { background: alpha(#ff4d5e, 0.25); color: #ffb3ba; border: 1px solid alpha(#ff4d5e, 0.7); }
.verdict.precaucion { background: alpha(#ffb340, 0.22); color: #ffd99a; border: 1px solid alpha(#ffb340, 0.7); }
.verdict.seguro { background: alpha(#4be39b, 0.20); color: #b5f5d4; border: 1px solid alpha(#4be39b, 0.7); }
.reason { font-size: 13px; color: #f3eefc; }
.reason-icon { font-size: 14px; min-width: 22px; }
.reason-icon.peligroso { color: #ff7a86; }
.reason-icon.precaucion { color: #ffc766; }
.reasons { background: alpha(#000000, 0.22); border-radius: 16px; padding: 12px 14px;
           border: 1px solid alpha(#ffffff, 0.08); }
button.aviso-btn { padding: 9px 18px; font-weight: 600; }
button.danger-btn { background-image: linear-gradient(180deg, alpha(#ff4d5e, 0.85), alpha(#c42a3a, 0.85));
                    color: #ffffff; border: 1px solid alpha(#ffb3ba, 0.5); border-radius: 99px; }
button.danger-btn:hover { background-image: linear-gradient(180deg, #ff6372, #d6394a); }
.done { color: #b5f5d4; font-size: 13px; }
.fail { color: #ffb3ba; font-size: 13px; }
"""

ICON = {scanner.PELIGROSO: "✖", scanner.PRECAUCION: "⚠", scanner.SEGURO: "✔"}


def load_report(arg: str) -> dict:
    p = Path(arg).expanduser()
    if p.suffix == ".json" and p.resolve().parent == scanner_report_dir():
        return json.loads(p.read_text(encoding="utf-8"))
    return scanner.scan(p).to_dict()


def scanner_report_dir() -> Path:
    from .vigia import report_dir

    return report_dir().resolve()


def quarantine_via_broker(path: str) -> tuple[bool, str]:
    """La cuarentena pasa por el broker: permisos de la política + auditoría."""
    from .cli import build_nyx
    from .config import load_config
    from .nyx.format import format_result
    from .security import ToolCall

    nyx = build_nyx(load_config(), None)
    nyx.broker.confirm = lambda action, args: action.id == "security.quarantine"  # el clic del usuario
    res = nyx.broker.execute(ToolCall("security.quarantine", {"path": path}))
    return res.ok, format_result(res)


class AlertWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application, report: dict) -> None:
        super().__init__(application=app, title=TITLE, decorated=False, resizable=False)
        self.add_css_class("glass")
        self.set_default_size(WIDTH, -1)
        self.report = report
        verdict = report["verdict"]
        self.color = COLORS[verdict]
        look = theme.load()

        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        panel.add_css_class("glass-panel")
        for side in ("top", "bottom", "start", "end"):
            getattr(panel, f"set_margin_{side}")(18)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        for side in ("top", "bottom", "start", "end"):
            getattr(inner, f"set_margin_{side}")(22)

        # Cabecera: esfera de NYX teñida del color del veredicto
        head = Gtk.Box(spacing=16)
        self.sphere = ParticleSphere(n=170, seed=7)
        self.speaker = SpeakingSphere(self.sphere)
        self.speaker.enabled = look.voz and self.speaker.voice.available
        self.orb = Gtk.DrawingArea(content_width=86, content_height=86)
        self.orb.set_draw_func(lambda _a, cr, w, h: draw_sphere(cr, self.sphere, w / 2, h / 2, w * 0.28, self.color))
        self._last = None
        self.orb.add_tick_callback(self._tick)
        titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, valign=Gtk.Align.CENTER)
        top = Gtk.Box(spacing=10)
        h = Gtk.Label(label=HEAD[verdict], xalign=0)
        h.add_css_class("aviso-head")
        pill = Gtk.Label(label=report["etiqueta"].upper(), valign=Gtk.Align.CENTER)
        pill.add_css_class("verdict")
        pill.add_css_class(verdict)
        top.append(h)
        top.append(pill)
        name = Gtk.Label(label=report["name"], xalign=0, ellipsize=3, max_width_chars=44)
        name.add_css_class("aviso-file")
        sub = Gtk.Label(label="NYX ha analizado esta descarga sin abrirla.", xalign=0)
        sub.add_css_class("glass-dim")
        titles.append(top)
        titles.append(name)
        titles.append(sub)
        head.append(self.orb)
        head.append(titles)

        # Motivos
        reasons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        reasons.add_css_class("reasons")
        findings = sorted(report["findings"], key=lambda f: f["level"] != scanner.PELIGROSO)
        for f in findings[:7] or [{"level": scanner.SEGURO, "message": "no he encontrado nada sospechoso"}]:
            row = Gtk.Box(spacing=8)
            ic = Gtk.Label(label=ICON[f["level"]], valign=Gtk.Align.START)
            ic.add_css_class("reason-icon")
            ic.add_css_class(f["level"])
            msg = f["message"]
            lab = Gtk.Label(label=msg[0].upper() + msg[1:] + ".", xalign=0, wrap=True, hexpand=True)
            lab.set_max_width_chars(58)
            lab.add_css_class("reason")
            row.append(ic)
            row.append(lab)
            reasons.append(row)
        if len(findings) > 7:
            more = Gtk.Label(label=f"…y {len(findings) - 7} motivos más.", xalign=0)
            more.add_css_class("glass-dim")
            reasons.append(more)

        kind = scanner.KIND_TEXT.get(report["kind"], report["kind"])
        size = report["size"]
        size_txt = (f"{size} bytes" if size < 1024 else f"{size / 1024:,.0f} KB" if size < 1024**2
                    else f"{size / 1024**2:,.1f} MB").replace(",", ".")
        meta = Gtk.Label(xalign=0, wrap=True, label=(
            f"Tipo real: {kind} · {size_txt} · antivirus: {report['antivirus']}\n"
            f"SHA-256 {report['sha256'][:32]}…"))
        meta.add_css_class("glass-dim")

        advice = Gtk.Label(xalign=0, wrap=True)
        advice.set_max_width_chars(64)
        advice.add_css_class("reason")
        if verdict == scanner.PELIGROSO:
            advice.set_label("Te recomiendo no abrirlo y ponerlo en cuarentena. Le he quitado el permiso de "
                             "ejecución mientras decides.")
        elif verdict == scanner.PRECAUCION:
            advice.set_label("Ábrelo solo si sabes de dónde viene y confías en quien te lo dio.")
        else:
            advice.set_label("Puedes abrirlo con tranquilidad.")

        self.status = Gtk.Label(xalign=0, wrap=True)
        buttons = Gtk.Box(spacing=10, halign=Gtk.Align.END)
        keep = Gtk.Button(label="Mantener el archivo" if verdict == scanner.PELIGROSO else "Entendido")
        keep.add_css_class("glass-pill")
        keep.add_css_class("aviso-btn")
        keep.connect("clicked", lambda _b: self.close())
        buttons.append(keep)
        if verdict != scanner.SEGURO:
            self.qbtn = Gtk.Button(label="Poner en cuarentena")
            self.qbtn.add_css_class("aviso-btn")
            self.qbtn.add_css_class("danger-btn" if verdict == scanner.PELIGROSO else "glass-pill")
            self.qbtn.connect("clicked", self._quarantine)
            buttons.append(self.qbtn)

        for w in (head, reasons, meta, advice, self.status, buttons):
            inner.append(w)
        panel.append(inner)
        self.set_child(panel)

        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", lambda _c, kv, _k, _s: kv == Gdk.KEY_Escape and (self.close() or True))
        self.add_controller(keys)

        if verdict == scanner.PELIGROSO:
            self.sphere.trigger("supernova")  # estallido de alerta al aparecer
        GLib.timeout_add(500, self._speak)

    def _speak(self) -> bool:
        from .vigia import load_settings

        if self.report["verdict"] == scanner.PELIGROSO and load_settings().voz:
            self.speaker.say(self.report["resumen"] + " Te recomiendo ponerlo en cuarentena.")
        return False

    def _tick(self, _w, clock) -> bool:
        now = clock.get_frame_time() / 1e6
        dt = 1 / 60 if self._last is None else now - self._last
        self._last = now
        self.speaker.tick()
        self.sphere.update(dt)
        self.orb.queue_draw()
        return True

    def _quarantine(self, btn: Gtk.Button) -> None:
        btn.set_sensitive(False)
        btn.set_label("Apartando…")

        def work() -> None:
            try:
                ok, msg = quarantine_via_broker(self.report["path"])
            except Exception as exc:  # noqa: BLE001 - el aviso nunca debe caerse
                ok, msg = False, f"No he podido: {exc}"
            GLib.idle_add(self._done, ok, msg)

        threading.Thread(target=work, daemon=True).start()

    def _done(self, ok: bool, msg: str) -> bool:
        self.status.set_label(("✔ " if ok else "✖ ") + msg)
        self.status.add_css_class("done" if ok else "fail")
        if ok:
            self.qbtn.set_label("En cuarentena")
            self.color = COLORS[scanner.SEGURO]
            GLib.timeout_add(3500, lambda: self.close() or False)
        else:
            self.qbtn.set_label("Poner en cuarentena")
            self.qbtn.set_sensitive(True)
        return False


class AlertApp(Gtk.Application):
    def __init__(self, report: dict) -> None:
        super().__init__(application_id=None)
        self.report = report

    def do_activate(self) -> None:
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data((theme.glass_css() + EXTRA_CSS).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        win = AlertWindow(self, self.report)
        win.present()
        GLib.timeout_add(80, self._place)

    def _place(self) -> bool:
        monitors = Gdk.Display.get_default().get_monitors()
        if monitors.get_n_items():
            geo = monitors.get_item(0).get_geometry()
            wmctrl("-r", TITLE, "-e", f"0,{geo.x + (geo.width - WIDTH - 36) // 2},{geo.y + geo.height // 6},-1,-1")
            float_window(TITLE)
        return False


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print("uso: umbra-aviso <archivo o informe.json>", file=sys.stderr)
        return 2
    try:
        report = load_report(argv[0])
    except (OSError, ValueError) as exc:
        print(f"umbra-aviso: {exc}", file=sys.stderr)
        return 1
    GLib.set_prgname("umbra-aviso")  # clase «Umbra-aviso»: picom le pone el cristal
    return AlertApp(report).run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
