"""Ventana de NYX para el escritorio de UMBRA OS (GTK 4).

- NYX es una esfera de partículas viva: gira en reposo, se arremolina al pensar
  y vibra al ritmo de su voz cuando habla.
- Voz local (Piper o espeak-ng), se puede silenciar con el botón del altavoz.
- Mensajes que aparecen con animación (deslizamiento + fundido).
- Indicador animado mientras NYX piensa.
- Accesos rápidos a las tareas más comunes.
- Tarjetas de confirmación animadas para acciones delicadas
  (las de riesgo ALTO exigen escribir CONFIRMAR).
- NYX trabaja en un hilo aparte: la ventana nunca se congela.
"""

from __future__ import annotations

import sys
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import __version__  # noqa: E402
from .cli import build_nyx, make_provider  # noqa: E402
from .config import load_config  # noqa: E402
from .gui_bridge import ConfirmBridge  # noqa: E402
from .nyx import easter  # noqa: E402
from .nyx.voice import Voice  # noqa: E402
from .security import Risk  # noqa: E402
from .sphere import ParticleSphere  # noqa: E402
from .widgets import draw_sphere  # noqa: E402
from . import theme  # noqa: E402

CSS = b"""
window.nyx { background: alpha(#0b0812, 0.86); color: #e8e2f4; }
.header { padding: 4px 18px 8px 18px; }
.title { font-size: 20px; font-weight: 300; letter-spacing: 10px; color: #f1eaff; }
.subtitle { font-size: 11px; color: #9c86c9; letter-spacing: 1px; }
.state { font-size: 11px; color: #b07cff; letter-spacing: 2px; }
button.voice {
  background: transparent; border: 1px solid #2d2242; border-radius: 99px; color: #cdb8f5;
  min-width: 34px; min-height: 34px; padding: 0; transition: all 180ms ease-out;
}
button.voice:hover { border-color: #8c5cff; }
button.voice.off { color: #5d4d7a; }
.chat { padding: 6px 16px 10px 16px; }
.bubble {
  padding: 10px 14px; border-radius: 16px; margin: 4px 0;
  font-size: 13.5px;
}
.bubble.user { background: linear-gradient(135deg, #7b3fe4, #a15cff); color: #ffffff; border-bottom-right-radius: 4px; }
.bubble.nyx  { background: #17111f; border: 1px solid #2a1f3d; color: #e8e2f4; border-bottom-left-radius: 4px; font-family: "DejaVu Sans Mono", monospace; font-size: 12.5px; }
.bubble.error { border-color: #7a2a44; color: #ffb3c4; }
.dots label { color: #b07cff; font-size: 22px; animation: blink 1.2s ease-in-out infinite; }
.dots label.d2 { animation-delay: 0.2s; }
.dots label.d3 { animation-delay: 0.4s; }
@keyframes blink { 0% { opacity: 0.15; } 50% { opacity: 1; } 100% { opacity: 0.15; } }
.chips { padding: 4px 14px 6px 14px; }
.chip {
  background: #150f1f; border: 1px solid #2d2242; color: #cdb8f5;
  border-radius: 99px; padding: 4px 12px; font-size: 12px;
  transition: all 180ms ease-out;
}
.chip:hover { background: #241837; border-color: #8c5cff; color: #ffffff; }
.composer { padding: 10px 14px 16px 14px; }
entry.prompt {
  background: #120d1a; border: 1px solid #2d2242; border-radius: 14px;
  padding: 10px 14px; color: #f1eaff; caret-color: #b07cff; min-height: 22px;
  transition: border-color 200ms ease-out, box-shadow 200ms ease-out;
}
entry.prompt:focus-within { border-color: #8c5cff; box-shadow: 0 0 0 3px alpha(#8c5cff, 0.25); }
button.send {
  background: linear-gradient(135deg, #7b3fe4, #a15cff); color: white; border-radius: 14px;
  padding: 0 16px; border: none; transition: all 160ms ease-out;
}
button.send:hover { box-shadow: 0 0 14px alpha(#a76eff, 0.6); }
.confirm {
  background: #1a1126; border: 1px solid #8c5cff; border-radius: 14px; padding: 14px; margin: 6px 0;
}
.confirm.high { border-color: #ff5c8a; }
.confirm .ctitle { font-weight: bold; color: #f1eaff; }
.confirm .cdesc { color: #b9a6dc; font-size: 12px; }
button.allow { background: #8c5cff; color: white; border-radius: 10px; border: none; }
button.deny  { background: transparent; color: #cdb8f5; border: 1px solid #3a2c55; border-radius: 10px; }
"""

QUICK = [
    ("⚡ Rendimiento", "Analiza el rendimiento del sistema"),
    ("💾 Espacio", "Busca qué está ocupando espacio"),
    ("🛠 Servicios", "Comprueba si hay algún servicio fallando"),
    ("🌐 Red", "¿Estoy conectado a internet?"),
    ("🗂 Organizar Descargas", "Organiza los archivos de ~/Descargas"),
    ("↩ Deshacer", "Deshaz"),
]


class NyxWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title="NYX")
        self.add_css_class("nyx")
        self.set_default_size(560, 860)
        self.busy = False

        self.look = theme.load()
        cfg = load_config()
        provider, label = make_provider(cfg)
        self.nyx = build_nyx(cfg, provider)
        self.nyx.broker.confirm = ConfirmBridge(self._ask_confirmation)
        self.nyx.on_step = lambda text: GLib.idle_add(self._step, text)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.set_child(root)

        # --- Cabecera: la esfera de partículas ES NYX ---
        self.sphere = ParticleSphere(n=560)
        self.voice = Voice()
        self.voice_on = self.voice.available and self.look.voz
        if self.voice_on:
            GLib.timeout_add_seconds(4, lambda: self.voice.warm_up() or False)
        self._speech: tuple[float, list[float]] | None = None  # (inicio, envolvente)
        self._last_frame = None

        stage = Gtk.Overlay()
        self.canvas = Gtk.DrawingArea(content_height=230, hexpand=True)
        self.canvas.set_draw_func(self._draw_sphere)
        self.canvas.add_tick_callback(self._tick)
        stage.set_child(self.canvas)
        self.voice_btn = Gtk.Button(label="🔊" if self.voice_on else "🔇", halign=Gtk.Align.END, valign=Gtk.Align.START)
        self.voice_btn.add_css_class("voice")
        self.voice_btn.set_margin_top(12)
        self.voice_btn.set_margin_end(14)
        self.voice_btn.set_tooltip_text(f"Voz de NYX ({self.voice.engine})")
        self.voice_btn.connect("clicked", self._toggle_voice)
        if not self.voice_on:
            self.voice_btn.add_css_class("off")
        stage.add_overlay(self.voice_btn)
        root.append(stage)

        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        header.add_css_class("header")
        t = Gtk.Label(label="N Y X")
        t.add_css_class("title")
        self.state_label = Gtk.Label(label="EN REPOSO")
        self.state_label.add_css_class("state")
        s = Gtk.Label(label=f"UMBRA OS {__version__} · {label}")
        s.add_css_class("subtitle")
        header.append(t)
        header.append(self.state_label)
        header.append(s)
        root.append(header)

        self.scroller = Gtk.ScrolledWindow(vexpand=True)
        self.scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.chat = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.chat.add_css_class("chat")
        self.scroller.set_child(self.chat)
        root.append(self.scroller)

        chips = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=6, row_spacing=6, column_spacing=6)
        chips.add_css_class("chips")
        for text, order in QUICK:
            b = Gtk.Button(label=text)
            b.add_css_class("chip")
            b.connect("clicked", lambda _b, o=order: self.send(o))
            chips.append(b)
        root.append(chips)

        composer = Gtk.Box(spacing=8)
        composer.add_css_class("composer")
        self.entry = Gtk.Entry(hexpand=True, placeholder_text="Pídele algo a NYX…")
        self.entry.add_css_class("prompt")
        self.entry.connect("activate", lambda e: self.send(e.get_text()))
        send = Gtk.Button(label="➤")
        send.add_css_class("send")
        send.connect("clicked", lambda _b: self.send(self.entry.get_text()))
        composer.append(self.entry)
        composer.append(send)
        root.append(composer)

        greeting = easter.greeting()
        seasonal = easter.seasonal_effect()
        if seasonal:
            self.sphere.trigger(seasonal)
        self.konami = easter.KonamiTracker()
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", self._secret_keys)
        self.add_controller(keys)
        self.add_bubble(greeting, "nyx")
        GLib.timeout_add(700, lambda: (self._say(greeting), False)[1])

    # --- esfera de partículas -------------------------------------------------
    def _tick(self, _widget, clock) -> bool:
        now = clock.get_frame_time() / 1e6
        dt = 1 / 60 if self._last_frame is None else now - self._last_frame
        self._last_frame = now
        if self._speech is not None:
            start, env = self._speech
            i = int((time.monotonic() - start) * 60)
            self.sphere.set_energy(env[i] if 0 <= i < len(env) else 0.0)
        if not hasattr(self, "_every"):
            from . import perf

            self._every, self._frame = perf.sphere_every(getattr(self.look, "rendimiento", "auto")), 0
        self._frame += 1
        every = self._every[0] if (self._speech is not None or self.sphere.effects) else self._every[1]
        if self._frame % every:
            return True
        self.sphere.update(dt * every)
        self.canvas.queue_draw()
        return True

    def _draw_sphere(self, _area, cr, width, height) -> None:
        draw_sphere(cr, self.sphere, width / 2, height / 2 + 6, min(width, height) * 0.42, self.look.rgb(0))

    def _set_state(self, state: str) -> None:
        self.sphere.state = state
        self.state_label.set_label({"reposo": "EN REPOSO", "pensando": "PENSANDO…", "hablando": "HABLANDO"}[state])

    def _toggle_voice(self, _btn) -> None:
        if not self.voice.available:
            self.voice_btn.set_tooltip_text("No hay ningún motor de voz instalado")
            return
        self.voice_on = not self.voice_on
        self.voice_btn.set_label("🔊" if self.voice_on else "🔇")
        if self.voice_on:
            self.voice_btn.remove_css_class("off")
        else:
            self.voice_btn.add_css_class("off")
            self.voice.stop()

    def _say(self, text: str) -> None:
        """Sintetiza en segundo plano y anima la esfera mientras suena."""
        if not (self.voice_on and self.voice.available):
            self._set_state("reposo")
            return

        started = self.voice.speak(
            text,
            on_chunk=lambda utt: GLib.idle_add(self._start_speech, utt.envelope),
            on_done=lambda: GLib.idle_add(self._end_speech),
        )
        if not started:
            self._set_state("reposo")

    def _start_speech(self, env) -> bool:
        self._set_state("hablando")
        self._speech = (time.monotonic(), env)
        return False

    def _end_speech(self) -> bool:
        self._speech = None
        self.sphere.set_energy(0)
        self._set_state("reposo")
        return False

    # --- mensajes animados ---------------------------------------------------
    def _reveal(self, child: Gtk.Widget, transition=Gtk.RevealerTransitionType.SLIDE_UP) -> Gtk.Revealer:
        rev = Gtk.Revealer(transition_type=transition, transition_duration=260)
        rev.set_child(child)
        self.chat.append(rev)
        GLib.idle_add(lambda: (rev.set_reveal_child(True), False)[1])
        GLib.timeout_add(300, self._scroll_bottom)
        return rev

    def _scroll_bottom(self) -> bool:
        adj = self.scroller.get_vadjustment()
        adj.set_value(adj.get_upper())
        return False

    def add_bubble(self, text: str, who: str, error: bool = False) -> Gtk.Revealer:
        label = Gtk.Label(label=text, wrap=True, selectable=True, xalign=0)
        label.set_max_width_chars(52)
        label.add_css_class("bubble")
        label.add_css_class(who)
        if error:
            label.add_css_class("error")
        label.set_halign(Gtk.Align.END if who == "user" else Gtk.Align.START)
        return self._reveal(label)

    def _thinking(self) -> Gtk.Revealer:
        box = Gtk.Box(spacing=2, halign=Gtk.Align.START)
        box.add_css_class("dots")
        for i in (1, 2, 3):
            d = Gtk.Label(label="•")
            d.add_css_class(f"d{i}")
            box.append(d)
        return self._reveal(box, Gtk.RevealerTransitionType.CROSSFADE)

    def _remove_animated(self, rev: Gtk.Revealer) -> None:
        rev.set_reveal_child(False)
        GLib.timeout_add(280, lambda: (self.chat.remove(rev), False)[1])

    # --- envío ----------------------------------------------------------------
    def send(self, text: str) -> None:
        text = (text or "").strip()
        if not text or self.busy:
            return
        self.busy = True
        self.entry.set_text("")
        self.add_bubble(text, "user")
        self.voice.stop()
        self._speech = None
        self._set_state("pensando")
        thinking = self._thinking()

        def work() -> None:
            started = time.monotonic()
            try:
                reply, failed = self.nyx.handle(text), False
            except Exception as exc:  # la ventana nunca se cae
                reply, failed = f"Ha ocurrido un error: {exc}", True
            # Que el remolino de "pensando" se llegue a ver aunque la respuesta sea instantánea
            time.sleep(max(0.0, 0.7 - (time.monotonic() - started)))
            GLib.idle_add(self._done, thinking, reply, failed)

        threading.Thread(target=work, daemon=True).start()

    def _secret_keys(self, _c, keyval, _code, _state) -> bool:
        if self.konami.feed(Gdk.keyval_name(keyval) or ""):
            self.sphere.trigger("supernova")
            self.sphere.trigger("arcoiris")
            look = theme.load()
            look.secreto = True
            theme.save(look)
            self.add_bubble("↑↑↓↓←→←→BA 🎮 Código aceptado. Has desbloqueado el color secreto «nebulosa» "
                            "en Ajustes de UMBRA.", "nyx")
        return False

    def _step(self, text: str) -> bool:
        self.add_bubble(text, "nyx")
        return False

    def _done(self, thinking: Gtk.Revealer, reply: str, failed: bool) -> bool:
        self._remove_animated(thinking)
        lowered = reply.lower()
        error = failed or lowered.startswith(("no tengo permiso", "ha fallado", "no puedo", "cancelado"))
        self.add_bubble(reply, "nyx", error=error)
        if self.nyx.last_effect:
            self.sphere.trigger(self.nyx.last_effect)
        self._say(reply)
        self.busy = False
        self.entry.grab_focus()
        return False

    # --- confirmación ----------------------------------------------------------
    def _ask_confirmation(self, action, args, reply) -> None:
        GLib.idle_add(self._show_confirmation, action, args, reply)

    def _show_confirmation(self, action, args, reply) -> bool:
        high = action.risk >= Risk.HIGH
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.add_css_class("confirm")
        if high:
            card.add_css_class("high")
        title = Gtk.Label(label=("⚠ Acción de administrador" if high else "¿Permites esta acción?"), xalign=0)
        title.add_css_class("ctitle")
        detail = ", ".join(f"{k}: {v}" for k, v in args.items())
        desc = Gtk.Label(label=f"{action.description}\n{action.id}  {detail}", xalign=0, wrap=True)
        desc.add_css_class("cdesc")
        card.append(title)
        card.append(desc)
        word = None
        if high:
            word = Gtk.Entry(placeholder_text="Escribe CONFIRMAR")
            word.add_css_class("prompt")
            card.append(word)
        buttons = Gtk.Box(spacing=8, halign=Gtk.Align.END)
        deny = Gtk.Button(label="Cancelar")
        deny.add_css_class("deny")
        allow = Gtk.Button(label="Permitir")
        allow.add_css_class("allow")
        buttons.append(deny)
        buttons.append(allow)
        card.append(buttons)
        rev = self._reveal(card, Gtk.RevealerTransitionType.SLIDE_DOWN)

        def answer(ok: bool) -> None:
            if ok and word is not None and word.get_text().strip() != "CONFIRMAR":
                word.add_css_class("error")
                return
            reply(ok)
            self._remove_animated(rev)

        self._pending_answer = answer  # permite responder desde atajos de teclado o pruebas
        allow.connect("clicked", lambda _b: answer(True))
        deny.connect("clicked", lambda _b: answer(False))
        return False


class NyxApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.Nyx")

    def do_activate(self) -> None:
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data(theme.glass_css().encode() + CSS)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        win = self.props.active_window or NyxWindow(self)
        win.present()
        win.entry.grab_focus()


def main() -> int:
    GLib.set_prgname("umbra-nyx")  # clase de ventana «Umbra-nyx»: picom le pone el cristal
    return NyxApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
