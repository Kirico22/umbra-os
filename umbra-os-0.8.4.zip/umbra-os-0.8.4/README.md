# UMBRA OS

Distribución Linux propia con **NYX** como inteligencia central del sistema.

NYX entiende órdenes en lenguaje natural, decide qué hacer y actúa sobre el sistema
**solo a través de módulos con permisos**, con confirmación humana para lo delicado y
todo registrado en una auditoría. Funciona **100 % en local**: sin internet y sin APIs externas.

```
$ nyx "NYX, analiza el rendimiento del sistema"
CPU: 4 núcleos, carga 12.0% ...
RAM: 2.10 GB libres de 4.00 GB (47.5% en uso).
Disco /: 30.0 GB libres de 49.0 GB (38.8% usado).
Todo dentro de lo normal.
```

## Estado

Versión **0.7.0** — NYX más lista y el sistema completo:
- **Háblale a NYX**: botón de micrófono en el orbe y «Oye NYX» opcional (voz a texto en tu equipo con Vosk).
- **Cerebro local opcional**: un modelo de IA pequeño (Qwen2.5 1.5B, 1 GB) que se descarga desde Ajustes,
  se verifica con su huella y funciona sin internet. Con él, NYX entiende frases libres.
- **NYX proactiva y rutinas**: avisa si el disco se llena o un programa se cuelga, y repite órdenes
  («cada viernes a las 18:00 organiza las descargas»). Las de riesgo alto nunca se hacen solas.
- **Bienvenida** en el primer inicio (color, navegador, NYX, packs, protección), **pantalla de acceso**
  con la esfera, **notificaciones de cristal**, **panel rápido** (volumen, energía, «no molestar»).
- **Apps de base**: LibreOffice, VLC, KeePassXC, Thunderbird, Timeshift, Déjà Dup, tienda con Flathub…
  y **packs** que NYX instala: gaming, creativo, programación y multimedia.
- **Modo juego**, sesión **modo seguro** y **cifrado del disco** en el instalador.

Versión 0.6.0 — seguridad:
- **NYX vigila tus descargas**: analiza cada archivo que descargas sin abrirlo y te avisa si es
  peligroso (programas disfrazados, `factura.pdf.exe`, scripts que descargan y ejecutan código, macros,
  PDF con JavaScript, bombas zip, paquetes .deb con scripts dañinos, ClamAV…). Cuarentena con un clic.
- **Sistema endurecido de serie**: cortafuegos activo, AppArmor, parches de seguridad automáticos,
  antivirus ClamAV y núcleo endurecido. Detalles en [SECURITY.md](SECURITY.md).
- Apartado **Seguridad** en Ajustes de UMBRA.

Versión 0.5.0:
- **Fondo de átomo de partículas**: protones, neutrones y electrones son bolitas de partículas.
  El átomo está **vivo** (los electrones orbitan) y esconde una sorpresa…
- **Puntero del ratón personalizable**: punteros propios de UMBRA (oscuro y claro, con espera animada
  de partículas), Breeze, DMZ y Adwaita; tamaño de 24 a 64 px.
- **Easter eggs** repartidos por el sistema. Lista completa (con spoilers) en [docs/SECRETOS.md](docs/SECRETOS.md).

Versión 0.4.0:
- **Orbe de NYX en el escritorio**: la esfera en pequeño, siempre visible. Mantén el clic para
  moverla (recuerda dónde la dejas); un clic abre una burbuja de cristal para escribirle.
- **Liquid Glass**: ventanas, buscador, panel y menús de cristal translúcido con desenfoque.
- **Buscador** (Súper + Espacio): aplicaciones, ajustes, archivos y preguntas a NYX.
- **Ajustes de UMBRA**: color de acento (5), nivel de cristal, fondo, tamaño de iconos, orbe, voz
  y navegador (**Opera GX** o **Google Chrome** con un clic; Chromium incluido).

- **NYX es una esfera de partículas** que gira en reposo, se arremolina al pensar y vibra al ritmo
  de su propia **voz** (voz neuronal local Piper, española; respaldo espeak-ng).
- 10 módulos y 31 acciones, ventana gráfica animada y modo terminal.
- ISO sobre **Debian 13**: XFCE negro y morado, animaciones de ventanas y un **arranque de partículas**
  (las partículas forman la esfera, escriben «UMBRA» y vuelven a la esfera con el nombre).
  Se construye en GitHub Actions ([iso/README.md](iso/README.md)).

Ver [ROADMAP.md](ROADMAP.md).

## Qué sabe hacer NYX

| Pide… | NYX… |
|---|---|
| «Analiza el rendimiento del sistema» | CPU, RAM, disco, carga y procesos que más consumen |
| «Busca qué está ocupando espacio» | lo que más pesa en una carpeta |
| «Busca el archivo factura» | busca por nombre (admite `*.pdf`) |
| «Organiza los archivos de ~/Descargas» | enseña el plan, pide permiso y ordena por tipos |
| «Deshaz» | devuelve los archivos a su sitio |
| «Abre Firefox» | abre aplicaciones instaladas |
| «Comprueba si hay algún servicio fallando» | servicios de systemd con fallos |
| «¿Estoy conectado a internet?» | interfaces, IP, puerta de enlace y DNS |
| «Cierra el proceso 4321» | cierra procesos de tu usuario (con permiso) |
| «Busca el programa blender» / «Instala vlc» | busca e instala (CONFIRMAR + contraseña de administrador) |
| «Instala Opera GX» / «Instala Chrome» | lo instala desde su repositorio oficial y lo pone como predeterminado |
| «Recuerda que…» / «¿Qué recuerdas?» / «Olvida…» | memoria persistente |
| «¿Es seguro factura.pdf.exe?» / «Analiza las descargas» | analiza sin abrir y explica si es seguro, merece precaución o es peligroso |
| «Pon en cuarentena X» / «¿Qué hay en la cuarentena?» / «Restaura X de la cuarentena» | aparta archivos peligrosos (con tu confirmación) |
| «¿Estoy protegido?» | cortafuegos, AppArmor, antivirus, parches y vigía |
| «Instala el pack de gaming» / «¿Qué packs hay?» | instala grupos de apps (Debian + Flathub) |
| «Cada viernes a las 18:00 organiza las descargas» / «¿Qué rutinas tengo?» | rutinas que NYX repite sola |
| «Activa el modo juego» / «Desactiva el modo juego» | sin notificaciones, pantalla encendida, GameMode |

## Cómo piensa NYX

1. **Motor de intenciones en Python** (`nyx/rules.py`): entiende las órdenes habituales al
   instante y sin modelo de IA.
2. **Modelo de lenguaje local** para todo lo demás:
   - un archivo `.gguf` cargado dentro de Python con `llama-cpp-python` (sin servidor), o
   - un servidor Ollama local, si está instalado.
3. Si no hay modelo, NYX lo dice y sigue funcionando con el motor de intenciones.

## Uso rápido

```bash
pip install -e .
nyx-gui                               # ventana de NYX (GTK 4)
nyx-orbe                              # orbe flotante en el escritorio
umbra-buscar                          # buscador (Súper + Espacio en UMBRA OS)
umbra-ajustes                         # personalización
nyx                                   # conversación en terminal
nyx "busca qué está ocupando espacio"  # una orden
nyx --acciones                        # qué puede hacer y con qué permisos
nyx --auditoria                       # últimas acciones registradas
nyx --sin-modelo "..."                # forzar solo el motor de intenciones
```

## Documentación

- [ARCHITECTURE.md](ARCHITECTURE.md): componentes y flujo.
- [SECURITY.md](SECURITY.md): modelo de permisos y garantías.
- [INSTALLATION.md](INSTALLATION.md): instalación y modelo local.
- [ROADMAP.md](ROADMAP.md) y [CHANGELOG.md](CHANGELOG.md).

Autor: Héctor Rodríguez Pérez.
