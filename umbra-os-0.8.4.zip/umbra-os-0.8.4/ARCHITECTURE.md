# Arquitectura de UMBRA OS

```
 Usuario ──► Interfaz: ventana GTK 4 (gui.py) o terminal (cli.py)
                │
                ▼
          NYX AI Engine (src/umbra/nyx/engine.py)
          ├─ 1. Motor de intenciones en Python (rules.py)
          ├─ 2. Modelo local: llama-cpp-python (.gguf) u Ollama (providers.py)
          └─ NYX Memory: SQLite (memory.py)
                │  solo PIDE acciones por nombre: {"herramienta": id, "argumentos": {...}}
                ▼
          NYX Security · Broker (src/umbra/security/broker.py)
          ├─ ¿existe la acción?            → si no: rechazada
          ├─ ¿argumentos válidos?          → si no: rechazada
          ├─ ¿política concede permisos?   → si no: denegada
          ├─ ¿riesgo MEDIO/ALTO?           → confirmación humana
          ├─ ejecución aislada de errores
          └─ auditoría JSON (todo, también los rechazos)
                │
                ▼
          NYX Modules (src/umbra/modules/)
          system · files · processes · services · network · apps · packages · memory
                │
                ▼
             Linux
```

## Componentes

| Componente | Dónde | Estado |
|---|---|---|
| UMBRA CORE | `config.py`, `cli.py` | Configuración y arranque. Servicio systemd: pendiente |
| NYX AI Engine | `nyx/engine.py`, `nyx/rules.py`, `nyx/providers.py` | Funcional |
| NYX Memory | `nyx/memory.py` | Funcional (hechos + conversaciones) |
| NYX Modules | `modules/` | 8 módulos, 18 acciones |
| NYX Security | `security/` | Broker, políticas, auditoría |
| UMBRA Interface | `gui.py`, `iso/` | Ventana de NYX animada; XFCE con tema, Plymouth y picom |
| UMBRA System Manager | — | Pendiente (fase 6) |

## Interfaz gráfica

La cabecera de la ventana es NYX: una esfera de partículas (`sphere.py`, matemática pura)
dibujada con cairo a la frecuencia de la pantalla. Cuando NYX habla, `voice.py` genera el audio
en local y calcula su envolvente de volumen (60 valores por segundo); la esfera se expande y vibra
siguiendo esa envolvente mientras suena. El mismo modelo de esfera genera la animación de arranque.

`gui.py` (GTK 4) ejecuta NYX en un hilo aparte para no congelar la ventana.
Las confirmaciones viajan del hilo de trabajo a la ventana con `gui_bridge.ConfirmBridge`:
si el usuario no contesta en 2 minutos, cuenta como «no». Con `on_step`, NYX muestra cada
paso en cuanto termina (por ejemplo, el plan de organización antes de pedir permiso).

## Decisiones

- **Sin dependencias externas** en el núcleo (solo biblioteca estándar de Python 3.11+),
  para empaquetarlo fácilmente como `.deb`.
- **El modelo nunca ejecuta nada.** Solo propone acciones registradas; el broker decide.
- **Las órdenes habituales no dependen del modelo**: son rápidas y predecibles en equipos modestos.
- **Proveedores intercambiables**: cualquier clase con `chat(messages) -> str` sirve.

## Crear un módulo

```python
Module(
    id="ejemplo",
    name="Ejemplo",
    description="Qué hace",
    requested=frozenset({Permission.SYSTEM_READ}),     # permisos que solicita
    actions=[Action(
        id="ejemplo.saludar",
        description="Texto que verá el modelo",
        handler=funcion_python,
        permissions=frozenset({Permission.SYSTEM_READ}),
        risk=Risk.LOW,                                   # LOW / MEDIUM / HIGH
        params=(Param("nombre", str),),
    )],
)
```
Un módulo no puede declarar acciones que usen permisos que no ha solicitado (error al cargarlo).
