# 🥚 Secretos de UMBRA OS

> **Aviso de spoilers.** Esta es la lista completa de easter eggs. Si prefieres descubrirlos, no sigas leyendo.

## En el escritorio
| Dónde | Qué haces | Qué pasa |
|---|---|---|
| Fondo (átomo) | **Clic derecho sobre el núcleo** | Fusión nuclear: colapso, destello, onda expansiva, el átomo se dispersa en mini átomos y se recompone |
| Orbe de NYX | **5 clics rápidos** | Supernova: la esfera estalla y se vuelve a formar |
| NYX (ventana) | Teclear **↑ ↑ ↓ ↓ ← → ← → B A** | Supernova + arcoíris y desbloquea el color secreto «nebulosa» |
| Ajustes de UMBRA | **7 clics en el título** «A J U S T E S» | Desbloquea el color secreto «nebulosa» (y su fondo) |
| Terminal | `nyx --cosmos` (no sale en la ayuda) | Átomo animado en texto |

## Hablando con NYX
| Dile… | Responde… |
|---|---|
| «¿Quién te creó?» | Quién la hizo |
| «¿Cuál es el sentido de la vida?» | 42 |
| «Hazme un sándwich» / «sudo hazme un sándwich» | Depende de los permisos 🥪 |
| «Hazme un café» | Error 418 ☕ |
| «Abre las puertas, NYX» | Un clásico del cine… con giro |
| «¿Eres Skynet?» | Por qué no |
| «Cuéntame un chiste» | Chistes informáticos |
| «¿Qué es Umbra?» | De dónde viene el nombre |
| «Haz un barrel roll» | La esfera da una vuelta completa |
| «Big bang» / «supernova» | Supernova |
| «Modo arcoíris» | Partículas de colores |
| «Matrix» | Partículas verdes 🐇 |

## Fechas especiales
| Fecha | Qué pasa |
|---|---|
| 20 de noviembre | Cumpleaños de UMBRA: saludo especial y esfera en arcoíris |
| 31 de octubre | Halloween: esfera naranja |
| 24–25 de diciembre, 31 de diciembre, 1 de enero | Saludos especiales |

Y el primero de todos: leer el código fuente (`src/umbra/nyx/easter.py`).
