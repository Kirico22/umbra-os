# Hoja de ruta

| Fase | Contenido | Estado |
|---|---|---|
| 1. Auditoría | Revisión de la VM y del proyecto existente | ✅ Hecha (20 nov 2026) |
| 2. Estabilización | Repositorio limpio, pruebas, CI, documentación | ✅ v0.1.0 |
| 3. NYX Core | Motor de conversación, contexto, proveedores locales, herramientas | ✅ Base hecha; falta planificación multi-paso avanzada |
| 4. Memoria | SQLite persistente: hechos, conversaciones | ✅ Base hecha; falta proyectos/tareas |
| 5. Permisos | Broker, políticas, confirmación, auditoría | ✅ Base hecha; falta polkit y usuario `umbra` |
| 6. Control del sistema | Archivos, procesos, servicios, paquetes, red, aplicaciones | ✅ Base hecha; falta control de servicios y red |
| 7. Interfaz UMBRA | Esfera con voz, orbe en el escritorio, Liquid Glass, buscador, ajustes, arranque de partículas | ✅ v0.4.0 |
| 8. Integración Linux | Paquetes `.deb`, servicio systemd, login personalizado | 🔶 Login y tema hechos; falta `.deb` y servicio |
| 9. ISO | Construcción automática en GitHub Actions, prueba en VirtualBox | 🔶 Configurada; pendiente la primera construcción en GitHub |
| 10. Optimización | Recursos, seguridad, rendimiento | ⏳ |

## Próximos pasos

1. Primera construcción de la ISO en GitHub y prueba en VirtualBox (arranque, animaciones, instalación).
2. Animación de arranque también en el sistema instalado (configurar `splash` en Calamares/GRUB).
3. Marca propia en Calamares y en el menú de arranque.
4. Servicio `umbra-core` con systemd y atajo de teclado global para abrir NYX.
5. Hablarle a NYX con el micrófono (reconocimiento de voz local) y que la esfera reaccione también al escuchar.
