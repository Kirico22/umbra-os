"""Motor de intenciones en Python puro.

Entiende las órdenes más habituales sin ningún modelo de IA, de forma rápida y
predecible. Si no reconoce la orden, devuelve None y NYX pasa al modelo (si lo hay).
El orden de las reglas importa: las más concretas van primero.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from ..security import ToolCall


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"^\s*nyx[\s,:]*", "", text)
    return re.sub(r"[¿?¡!.]+$", "", text).strip()


def _path_in(original: str) -> str | None:
    """Busca una ruta (/algo o ~/algo) en el texto original, respetando mayúsculas."""
    m = re.search(r"(~?/[^\s,;\"'?¿!¡]*|~)(?=[\s,;.\"'?!]|$)", original)
    return m.group(1).rstrip(".") if m else None


def _int_in(text: str) -> int | None:
    m = re.search(r"\b(\d{1,6})\b", text)
    return int(m.group(1)) if m else None


def _tail(original: str, words: str) -> str:
    """Lo que viene después de la última palabra clave, con mayúsculas originales."""
    m = re.search(rf"(?:{words})\s+(?:el |la |los |las |un |una |programa |aplicacion |aplicación |paquete |archivo |fichero )*(.+?)[\s.?!]*$",
                  original, re.IGNORECASE)
    return m.group(1).strip().strip("\"'") if m else ""


FILLER = {"el", "la", "los", "las", "un", "una", "este", "esta", "ese", "esa", "programa", "paquete",
          "aplicacion", "app", "llamado", "llamada", "de", "nombre"}


def _object_word(t: str, keyword: str) -> str:
    """Primera palabra útil tras la palabra clave: 'instala este programa: vlc' -> 'vlc'."""
    m = re.search(rf"(?:{keyword})\b(.*)$", t)
    words = re.findall(r"[a-z0-9][a-z0-9+.\-]*", m.group(1) if m else "")
    useful = [w for w in words if w not in FILLER]
    return useful[0] if useful else ""


def _file_arg(original: str, path: str | None) -> str:
    """Archivo del que se habla: una ruta, un nombre con extensión o la última palabra."""
    if path:
        return path
    names = re.findall(r"[\w\-()\[\]\u202a-\u202e+]+(?:\.[\w\u202a-\u202e]{1,10})+", original)
    if names:
        return names[-1]
    m = re.search(r"(?:archivo|fichero|programa|documento)\s+[\"']?([^\s\"'?]+)", original, re.IGNORECASE)
    return m.group(1) if m else ""


@dataclass
class Plan:
    intent: str
    calls: list[ToolCall]


def match(original: str) -> Plan | None:
    t = normalize(original)
    path = _path_in(original)

    # --- memoria ---
    m = re.match(r"^recuerda(?: que)? (.+?) (?:es|son|=) (.+)$", t)
    if m:
        # El valor se toma del texto original para conservar mayúsculas y acentos
        mo = re.search(r"\s(?:es|son|=)\s+(.+)$", original, re.IGNORECASE)
        value = mo.group(1).strip() if mo else m.group(2)
        return Plan("recordar", [ToolCall("memory.remember", {"key": m.group(1), "value": value})])
    m = re.match(r"^olvida(?: lo de| que)? (.+)$", t)
    if m:
        return Plan("olvidar", [ToolCall("memory.forget", {"key": m.group(1)})])
    if re.search(r"que (recuerdas|sabes de mi|tienes guardado)", t):
        m = re.search(r"sobre (.+)$", t)
        return Plan("consultar_memoria", [ToolCall("memory.recall", {"query": m.group(1) if m else ""})])

    # --- modo juego ---
    if re.search(r"\bmodo (juego|gaming|gamer)\b", t):
        off = re.search(r"\b(desactiva|quita|apaga|sal|salir|termina|para)\b", t)
        return Plan("modo_juego", [ToolCall("apps.game_mode", {"on": not off})])

    # --- rutinas («cada viernes a las 18:00 organiza las descargas») ---
    if re.search(r"\brutinas?\b", t):
        n = _int_in(t)
        if re.search(r"\b(borra|quita|elimina|cancela)\b", t) and n:
            return Plan("borrar_rutina", [ToolCall("routines.remove", {"id": n})])
        return Plan("ver_rutinas", [ToolCall("routines.list", {})])
    from ..routines import split_request

    parts = split_request(original)
    if parts:
        return Plan("crear_rutina", [ToolCall("routines.add", {"orden": parts[1], "cuando": parts[0]})])

    # --- arranque seguro / BIOS / UEFI (solo comprobar: NYX nunca toca el firmware) ---
    if re.search(r"\b(arranque seguro|secure ?boot|bios|uefi|firmware)\b", t) or re.search(
            r"\b(mi|el) arranque\b.*\b(seguro|protegido|verificado)", t):
        return Plan("arranque", [ToolCall("security.boot", {})])

    # --- seguridad (antes que "busca archivo" para que "busca virus" no busque un archivo) ---
    if re.search(r"(estado|nivel) de (la )?(seguridad|proteccion)|estoy protegido|esta (el sistema )?protegido|"
                 r"(como|que tal) (va|esta) (la seguridad|el antivirus|el cortafuegos)|^seguridad$", t):
        return Plan("estado_seguridad", [ToolCall("security.status", {})])
    if "cuarentena" in t:
        target = _file_arg(original, path) or _tail(original, r"restaura|recupera|saca|borra|elimina")
        if re.search(r"\b(restaura|recupera|saca|devuelve)\b", t) and target:
            return Plan("restaurar", [ToolCall("security.restore", {"id": target})])
        if re.search(r"\b(borra|elimina|vacia)\b", t) and target:
            return Plan("borrar_cuarentena", [ToolCall("security.delete", {"id": target})])
        if re.search(r"\b(pon|ponlo|ponla|mete|metelo|manda|envia|aisla|mueve)\b", t) and target:
            return Plan("cuarentena", [ToolCall("security.quarantine", {"path": target})])
        return Plan("ver_cuarentena", [ToolCall("security.quarantine_list", {})])
    if re.search(r"\b(analiza|escanea|revisa|comprueba|mira)\b.*\bdescargas\b|\bvirus\b.*\bdescargas\b", t) \
            and not _file_arg(original, path).count("."):
        return Plan("analizar_descargas", [ToolCall("security.scan_folder", {"path": path or ""})])
    if re.search(r"\bes (seguro|peligroso|un virus|fiable|de fiar)\b|\btiene (un )?virus\b|\bpuedo abrir\b|"
                 r"\b(analiza|escanea)\b", t) or (re.search(r"\b(revisa|comprueba)\b", t) and _file_arg(original, path)):
        target = _file_arg(original, path)
        if target:
            return Plan("analizar", [ToolCall("security.scan", {"path": target})])
        if re.fullmatch(r"(analiza|escanea)( (todo|ahora|esto))?", t) or \
                re.search(r"\b(virus|malware|amenazas?|archivos?|ficheros?|descargas?)\b", t):
            return Plan("analizar_descargas", [ToolCall("security.scan_folder", {})])

    # --- deshacer / organizar archivos ---
    if re.search(r"(deshaz|deshacer|revierte|vuelve a dejar).*(organiz|archivos|como estaba)", t) or t in ("deshaz", "deshacer"):
        return Plan("deshacer_organizar", [ToolCall("files.undo_organize", {})])
    if re.search(r"\b(organiza|ordena|clasifica)\b", t):
        p = path or "~/Descargas"
        return Plan("organizar", [ToolCall("files.organize_preview", {"path": p}),
                                  ToolCall("files.organize", {"path": p})])

    # --- programas (paquetes) ---
    if re.search(r"\bpacks?\b", t):
        from ..packs import ALIASES

        m = re.search(r"\bpacks?\s+(?:de\s+|para\s+)?(\w+)", t)
        word = m.group(1) if m else ""
        if re.match(r"^(instala|instalame|pon|ponme|quiero)\b", t) and word in ALIASES:
            return Plan("instalar_pack", [ToolCall("packages.pack", {"name": ALIASES[word]})])
        return Plan("ver_packs", [ToolCall("packages.packs", {})])
    if re.match(r"^(instala|instalame|pon|ponme)\b", t) and re.search(r"\b(opera|chrome)\b", t):
        return Plan("instalar_navegador", [ToolCall("packages.browser",
                                                    {"name": "opera-gx" if "opera" in t else "chrome"})])
    if re.match(r"^(instala|instalame)\b", t):
        return Plan("instalar", [ToolCall("packages.install", {"name": _object_word(t, r"instala(?:me)?")})])
    if re.search(r"busca (el |un )?(programa|paquete|aplicacion)", t):
        return Plan("buscar_programa", [ToolCall("packages.search", {"query": _object_word(t, r"programa|paquete|aplicacion")})])

    # --- aplicaciones ---
    if re.search(r"(que|cuales) (aplicaciones|programas|apps) (hay|tengo|estan)", t):
        return Plan("listar_apps", [ToolCall("apps.list", {})])
    if re.match(r"^(abre|abreme|lanza|ejecuta|inicia|arranca)\b", t) and not re.search(r"\bproceso\b", t):
        name = _tail(original, r"abre|ábreme|abreme|lanza|ejecuta|inicia|arranca")
        return Plan("abrir_app", [ToolCall("apps.open", {"name": name})])

    # --- procesos ---
    if re.search(r"(cierra|mata|termina|deten|para) (el )?proceso", t):
        pid = _int_in(t)
        if pid:
            return Plan("cerrar_proceso", [ToolCall("processes.stop", {"pid": pid})])

    # --- servicios ---
    if re.search(r"servicio", t) and re.search(r"fall|error|roto|caid|problema|estado|comprueba|revisa", t):
        return Plan("servicios_fallidos", [ToolCall("services.failed", {})])

    # --- espacio en disco ---
    if re.search(r"(ocupa|ocupando|espacio|pesa|llenando|lleno)", t):
        args = {"path": path or "~"}
        n = _int_in(t)
        if n and n <= 50:
            args["top"] = n
        return Plan("uso_disco", [ToolCall("files.usage", args), ToolCall("system.info", {})])

    # --- red ---
    if re.search(r"\b(red|internet|wifi|ip|conexion|conectado|conectada)\b", t):
        return Plan("red", [ToolCall("network.status", {})])

    # --- buscar archivos ---
    m = re.search(r"(busca|encuentra|donde esta|donde estan|localiza)\s+(?:el |la |los |las |mi |mis )?(?:archivo|archivos|fichero|ficheros|carpeta|documento)?s?\s*(?:llamad[oa]s?\s+)?(.+)$", t)
    if m:
        mo = re.search(r"(?:busca|encuentra|donde est[aá]n?|localiza)\s+(?:el |la |los |las |mi |mis )?(?:archivos?|ficheros?|carpetas?|documentos?)?\s*(?:llamad[oa]s?\s+)?(.+?)(?:\s+en\s+~?/\S*)?[\s.?!]*$",
                       original, re.IGNORECASE)
        name = (mo.group(1) if mo else m.group(2)).strip().strip("\"'")
        args = {"name": name}
        if path:
            args["path"] = path
        return Plan("buscar_archivo", [ToolCall("files.find", args)])

    # --- rendimiento ---
    if re.search(r"rendimiento|estado del sistema|como va el (sistema|equipo|ordenador)|cpu|ram|lento|recursos", t):
        return Plan("rendimiento", [ToolCall("system.info", {}), ToolCall("processes.top", {"n": 5})])

    if re.search(r"proceso", t):
        n = _int_in(t) or 10
        return Plan("procesos", [ToolCall("processes.top", {"n": min(n, 50)})])

    # --- archivos ---
    if re.search(r"(lista|muestra|ensena|que hay en|contenido de)", t) and re.search(r"archivo|carpeta|fichero|directorio|hay en|/|~", t):
        return Plan("listar", [ToolCall("files.list", {"path": path or "~"})])

    return None
