import sys
from pathlib import Path

from umbra import atomo_inicio, perf

INC = Path(__file__).resolve().parents[1] / "iso/config/includes.chroot"


def test_atom_launcher_exits_without_loading_gtk_in_light_mode(monkeypatch):
    monkeypatch.setattr(perf, "profile", lambda setting=None, info=None: "ligero")
    monkeypatch.setattr(sys, "argv", ["umbra-atomo"])
    sys.modules.pop("umbra.atomo", None)
    assert atomo_inicio.main() == 0
    assert "umbra.atomo" not in sys.modules  # ni GTK ni el motor del átomo


def test_light_compositor_has_no_fades_and_uses_damage():
    cfg = perf.light_picom_config()
    assert "fading = false" in cfg and "use-damage = true" in cfg and 'backend = "xrender"' in cfg


def test_nothing_updates_in_the_live_session():
    for unit in ("umbra-antivirus.service", "apt-daily.service.d/umbra.conf", "apt-daily-upgrade.service.d/umbra.conf"):
        assert "ConditionPathExists=!/run/live/medium" in (INC / "etc/systemd/system" / unit).read_text()
    for timer in ("apt-daily.timer.d/umbra.conf", "apt-daily-upgrade.timer.d/umbra.conf"):
        t = (INC / "etc/systemd/system" / timer).read_text()
        assert "Persistent=false" in t and "OnBootSec=15min" in t


def test_store_daemon_off_at_login_and_orb_staggered():
    assert "Hidden=true" in (INC / "etc/skel/.config/autostart/gnome-software-service.desktop").read_text()
    assert "sleep 6" in (INC / "etc/xdg/autostart/nyx-orbe.desktop").read_text()
