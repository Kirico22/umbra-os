"""Explorador Archivos de UMBRA: utilidades sin GTK."""

import pytest

pytest.importorskip("gi")
try:
    import gi

    gi.require_version("Gtk", "4.0")
    from umbra import archivos
except (ImportError, ValueError):  # pragma: no cover
    pytest.skip("sin GTK4", allow_module_level=True)


def test_kind_of():
    assert archivos.kind_of("factura.PDF")[0] == "PDF"
    assert archivos.kind_of("foto.jpeg")[0] == "IMG"
    assert archivos.kind_of("setup.exe")[0] == "PROG"
    assert archivos.kind_of("sinextension")[0] == "ARCH"


def test_human_size():
    assert archivos.human_size(512) == "512 bytes"
    assert archivos.human_size(2048) == "2,0 KB"


def test_list_folder_order(tmp_path):
    (tmp_path / "b.txt").write_text("x")
    (tmp_path / "A.txt").write_text("x")
    (tmp_path / "zcarpeta").mkdir()
    (tmp_path / ".oculto").write_text("x")
    names = [i["name"] for i in archivos.list_folder(tmp_path)]
    assert names == ["zcarpeta", "A.txt", "b.txt"]


def test_start_path(tmp_path):
    f = tmp_path / "x.txt"
    f.write_text("x")
    assert archivos._start_path(["a", str(tmp_path)]) == tmp_path
    assert archivos._start_path(["a", f.as_uri()]) == tmp_path
