import json

import pytest

from umbra.nyx import Memory, Nyx
from umbra.nyx import rules
from umbra.nyx.engine import extract_json
from umbra.nyx.providers import FakeProvider, ProviderError


# --- memoria ----------------------------------------------------------------
def test_memory_survives_restart(tmp_path):
    path = tmp_path / "m.db"
    m = Memory(path)
    m.remember("Color favorito", "morado")
    m.add_message("s", "user", "hola")
    m.close()
    m2 = Memory(path)
    assert m2.recall("color") == [{"key": "color favorito", "value": "morado", "category": "general"}]
    assert m2.recent_messages("s") == [{"role": "user", "content": "hola"}]
    assert m2.forget("color favorito") and m2.recall() == []


# --- motor de intenciones ---------------------------------------------------
@pytest.mark.parametrize(
    "text, intent",
    [
        ("NYX, analiza el rendimiento del sistema.", "rendimiento"),
        ("NYX, busca qué está ocupando espacio.", "uso_disco"),
        ("NYX, comprueba si hay algún servicio fallando.", "servicios_fallidos"),
        ("lista los archivos de ~/Descargas", "listar"),
        ("recuerda que mi editor es VS Code", "recordar"),
        ("¿qué recuerdas?", "consultar_memoria"),
        ("olvida mi editor", "olvidar"),
    ],
)
def test_rules_understand_common_orders(text, intent):
    plan = rules.match(text)
    assert plan is not None and plan.intent == intent


def test_rules_keep_original_case_and_path():
    plan = rules.match("recuerda que mi editor favorito es VS Code")
    assert plan.calls[0].args == {"key": "mi editor favorito", "value": "VS Code"}
    plan = rules.match("qué ocupa espacio en ~/Proyectos/UMBRA")
    assert plan.calls[0].args["path"] == "~/Proyectos/UMBRA"


def test_rules_return_none_for_unknown():
    assert rules.match("escríbeme un poema") is None


def test_extract_json():
    assert extract_json('blabla {"respuesta": "hola"} fin') == {"respuesta": "hola"}
    assert extract_json("sin json") is None


# --- motor NYX --------------------------------------------------------------
def test_nyx_without_model_uses_rules(broker, memory):
    nyx = Nyx(broker, memory, provider=None)
    assert "RAM" in nyx.handle("analiza el rendimiento")
    assert "cerebro local" in nyx.handle("escríbeme un poema")


def test_nyx_model_uses_tool_then_answers(broker, memory):
    provider = FakeProvider([
        json.dumps({"herramienta": "system.info", "argumentos": {}}),
        json.dumps({"respuesta": "Tu sistema va bien."}),
    ])
    nyx = Nyx(broker, memory, provider)
    assert nyx.handle("¿qué tal estoy de todo?") == "Tu sistema va bien."
    tool_msg = provider.seen[1][-1]["content"]
    assert tool_msg.startswith("RESULTADO DE HERRAMIENTA") and "cpu_nucleos" in tool_msg


def test_model_cannot_run_unregistered_actions(broker, memory):
    provider = FakeProvider([
        json.dumps({"herramienta": "shell.exec", "argumentos": {"cmd": "rm -rf /"}}),
        json.dumps({"respuesta": "No he podido."}),
    ])
    nyx = Nyx(broker, memory, provider)
    assert nyx.handle("borra todo") == "No he podido."
    assert '"estado": "rejected"' in provider.seen[1][-1]["content"]


def test_model_step_limit(broker, memory):
    loop = [json.dumps({"herramienta": "system.info", "argumentos": {}})] * 10
    nyx = Nyx(broker, memory, FakeProvider(loop), max_steps=3)
    assert "demasiados pasos" in nyx.handle("haz algo raro")


def test_provider_failure_is_reported(broker, memory):
    class Broken:
        name = "roto"

        def chat(self, messages):
            raise ProviderError("sin conexión")

    nyx = Nyx(broker, memory, Broken())
    assert "sin conexión" in nyx.handle("escríbeme una poesía sobre el mar")


def test_conversation_is_persisted(broker, memory):
    nyx = Nyx(broker, memory, None, session="t")
    nyx.handle("analiza el rendimiento")
    roles = [m["role"] for m in memory.recent_messages("t")]
    assert roles == ["user", "assistant"]


def test_memory_works_from_worker_thread(tmp_path):
    """La ventana gráfica usa NYX desde otro hilo."""
    import threading

    m = Memory(tmp_path / "m.db")
    errors = []

    def worker():
        try:
            m.remember("hilo", "ok")
            m.add_message("s", "user", "hola")
        except Exception as exc:  # pragma: no cover
            errors.append(exc)

    t = threading.Thread(target=worker)
    t.start()
    t.join()
    assert not errors and m.recall("hilo")[0]["value"] == "ok"


def test_confirm_bridge():
    from umbra.gui_bridge import ConfirmBridge

    yes = ConfirmBridge(lambda a, k, reply: reply(True))
    no = ConfirmBridge(lambda a, k, reply: reply(False))
    silent = ConfirmBridge(lambda a, k, reply: None, timeout=0.05)
    assert yes(None, {}) is True and no(None, {}) is False and silent(None, {}) is False


def test_on_step_shows_intermediate_results(broker, memory):
    steps = []
    nyx = Nyx(broker, memory, None, on_step=steps.append)
    final = nyx.handle("analiza el rendimiento")
    assert len(steps) == 1 and "RAM" in steps[0] and "Procesos" in final


def test_plan_stops_at_first_failure(broker, memory):
    nyx = Nyx(broker, memory, None)
    reply = nyx.handle("organiza los archivos de /etc")
    assert reply.count("No tengo permiso") == 1


def test_particle_sphere_reacts_to_voice():
    from umbra.sphere import ParticleSphere

    s = ParticleSphere(n=200)
    quiet = s.project(100, 100, 50)
    spread_quiet = max(p.x for p in quiet) - min(p.x for p in quiet)
    s.set_energy(1.0)
    for _ in range(30):
        s.update(1 / 60)
    loud = s.project(100, 100, 50)
    spread_loud = max(p.x for p in loud) - min(p.x for p in loud)
    assert len(loud) == 200 and spread_loud > spread_quiet * 1.1
    assert all(a.depth <= b.depth for a, b in zip(loud, loud[1:], strict=False))  # de atrás a delante


def test_greetings_and_help_without_model(broker, memory):
    nyx = Nyx(broker, memory, provider=None)
    assert "NYX" in nyx.handle("hola nyx qué tal") or "ayudo" in nyx.handle("hola nyx qué tal")
    help_text = nyx.handle("¿qué me recomiendas hacer?")
    assert "analiza mis descargas" in help_text
