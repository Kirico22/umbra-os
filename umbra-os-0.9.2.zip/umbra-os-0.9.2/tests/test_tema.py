import os
from pathlib import Path

INC = Path(__file__).resolve().parents[1] / "iso/config/includes.chroot"
THEME = INC / "usr/share/themes/UMBRA"


def test_umbra_gtk_theme_builds_on_arc_dark():
    css = (THEME / "gtk-3.0/gtk.css").read_text()
    assert css.startswith("/*") and '@import url("resource:///org/gnome/arc-theme/gtk-main-dark.css")' in css
    # sin su gresource el @import no encuentra nada: va enlazado al de Arc-Dark
    link = THEME / "gtk-3.0/gtk.gresource"
    assert link.is_symlink() and os.readlink(link) == "/usr/share/themes/Arc-Dark/gtk-3.0/gtk.gresource"
    for rule in (".thunar scrolledwindow.sidebar treeview.view", "headerbar", "button.suggested-action"):
        assert rule in css
    assert "GtkTheme=UMBRA" in (THEME / "index.theme").read_text()


def test_system_uses_umbra_theme_and_purple_folders():
    xs = (INC / "etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml").read_text()
    assert 'name="ThemeName" type="string" value="UMBRA"' in xs
    hook = (INC.parent / "hooks/normal/9000-umbra.hook.chroot").read_text()
    assert "-violet" in hook and "gtk-update-icon-cache" in hook
    thunar = (INC / "etc/xdg/xfce4/xfconf/xfce-perchannel-xml/thunar.xml").read_text()
    assert 'last-menubar-visible" type="bool" value="false"' in thunar


def test_installer_gets_umbra_theme():
    assert "GTK_THEME=UMBRA" in (INC / "usr/libexec/umbra/instalador").read_text()


def test_settings_window_has_sidebar_pages():
    src = (Path(__file__).resolve().parents[1] / "src/umbra/ajustes.py").read_text()
    for key in ("APARIENCIA", "RENDIMIENTO", "NYX", "SEGURIDAD", "NAVEGADOR", "ACERCA"):
        assert f'self._section("{key}")' in src
    assert "class _Pages" in src
