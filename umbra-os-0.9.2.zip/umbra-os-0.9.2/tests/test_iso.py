"""Comprobaciones de los ficheros de la ISO que no necesitan construirla."""

import re
import tomllib
from pathlib import Path

ISO = Path(__file__).resolve().parent.parent / "iso"
THEME = ISO / "config/includes.chroot/usr/share/plymouth/themes/umbra"


def test_plymouth_frame_counts_match_script():
    script = (THEME / "umbra.script").read_text()
    intro = int(re.search(r"INTRO = (\d+);", script).group(1))
    loop = int(re.search(r"LOOP = (\d+);", script).group(1))
    assert len(list(THEME.glob("intro-*.png"))) == intro
    assert len(list(THEME.glob("loop-*.png"))) == loop
    assert (THEME / "bullet.png").exists()


def test_policy_and_config_are_valid():
    etc = ISO / "config/includes.chroot/etc/umbra"
    policy = tomllib.loads((etc / "policy.toml").read_text())
    assert set(policy["grants"]) == {"files", "processes", "packages", "security", "honeyshield"}
    assert policy["grants"]["honeyshield"] == ["network.control"]  # nada más: ni servicios ni paquetes
    tomllib.loads((etc / "umbra.toml").read_text())


def test_version_matches_hook():
    version = tomllib.loads((ISO.parent / "pyproject.toml").read_text())["project"]["version"]
    hook = (ISO / "config/hooks/normal/9000-umbra.hook.chroot").read_text()
    assert f'UMBRA_VERSION="{version.rsplit(".", 1)[0]}"' in hook


def test_security_hardening_is_in_the_iso():
    from pathlib import Path

    iso = Path(__file__).resolve().parents[1] / "iso" / "config"
    pkgs = (iso / "package-lists/umbra.list.chroot").read_text()
    for pkg in ("ufw", "apparmor", "unattended-upgrades", "clamav", "clamav-freshclam", "libnotify-bin"):
        assert f"\n{pkg}\n" in pkgs, pkg
    sysctl = (iso / "includes.chroot/etc/sysctl.d/99-umbra.conf").read_text()
    for key in ("kernel.kptr_restrict = 2", "kernel.yama.ptrace_scope = 1", "net.ipv4.tcp_syncookies = 1",
                "fs.protected_symlinks = 1", "net.ipv4.conf.all.accept_redirects = 0"):
        assert key in sysctl
    # No se tocan los espacios de nombres de usuario: el sandbox de Chrome/Chromium los necesita
    assert "unprivileged_userns_clone" not in sysctl
    auto = (iso / "includes.chroot/etc/apt/apt.conf.d/20auto-upgrades").read_text()
    assert 'Unattended-Upgrade "1"' in auto
    hook = (iso / "hooks/normal/9000-umbra.hook.chroot").read_text()
    assert "ENABLED=yes" in hook and "umbra-vigia" in hook
    assert (iso / "includes.chroot/etc/xdg/autostart/umbra-vigia.desktop").is_file()


def test_build_script_is_valid_and_used_by_workflows():
    import subprocess
    from pathlib import Path

    import yaml

    root = Path(__file__).resolve().parents[1]
    script = root / "iso" / "construir.sh"
    assert subprocess.run(["bash", "-n", str(script)]).returncode == 0
    for wf in (root / ".github/workflows/iso.yml", root / "docs/umbra-desde-zip.yml"):
        steps = yaml.safe_load(wf.read_text())["jobs"]["iso"]["steps"]
        assert any(s.get("run") == "bash iso/construir.sh" for s in steps)


def test_installer_branding():
    import yaml

    b = ISO / "config/includes.chroot/etc/calamares/branding/umbra"
    desc = yaml.safe_load((b / "branding.desc").read_text())
    assert desc["componentName"] == "umbra" == b.name
    assert desc["strings"]["bootloaderEntryName"] == "Debian"  # carpeta EFI del shim firmado: Secure Boot
    for key in ("productLogo", "productIcon", "productWelcome"):
        assert (b / desc["images"][key]).is_file()
    qml = (b / desc["slideshow"]).read_text()
    for name in __import__("re").findall(r'source: "([^"]+)"', qml):
        assert (b / name).is_file()
    assert (b / "stylesheet.qss").is_file()
    hook = (ISO / "config/hooks/normal/9000-umbra.hook.chroot").read_text()
    assert "branding: umbra" in hook
