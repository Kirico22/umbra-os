"""Imágenes de la marca UMBRA para el instalador (Calamares): logo, portada y diapositivas.

uso: PYTHONPATH=src python3 iso/tools/make_calamares.py iso/config/includes.chroot/etc/calamares/branding/umbra
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from umbra.sphere import ParticleSphere

PURPLE = (167, 110, 255)
LIGHT = (230, 214, 255)
INK = (243, 238, 252)
DIM = (184, 170, 210)
FONT_DIR = Path("/usr/share/fonts/opentype/inter")


def font(weight: str, size: int) -> ImageFont.FreeTypeFont:
    for name in (f"Inter-{weight}.otf", "Inter-Regular.otf"):
        p = FONT_DIR / name
        if p.exists():
            return ImageFont.truetype(str(p), size)
    return ImageFont.truetype("DejaVuSans.ttf", size)


def background(w: int, h: int) -> Image.Image:
    """Fondo morado muy oscuro con un halo, como el escritorio."""
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    base = np.array([14, 8, 26], np.float32)
    glow = np.exp(-(((xx - w * 0.72) / (w * 0.45)) ** 2 + ((yy - h * 0.5) / (h * 0.8)) ** 2))
    img = base + glow[..., None] * np.array([60, 28, 110], np.float32)
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB").convert("RGBA")


def sphere(img: Image.Image, cx: float, cy: float, r: float, n: int = 520, angle: float = 0.6) -> None:
    halo = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(halo).ellipse([cx - r * 1.3, cy - r * 1.3, cx + r * 1.3, cy + r * 1.3], fill=(*PURPLE, 70))
    img.alpha_composite(halo.filter(ImageFilter.GaussianBlur(r * 0.35)))
    d = ImageDraw.Draw(img)
    sph = ParticleSphere(n=n, seed=7)
    sph.angle_y = angle
    for pt in sph.project(cx, cy, r):
        k = (pt.depth + 1) / 2
        col = tuple(int(PURPLE[c] + (LIGHT[c] - PURPLE[c]) * k) for c in range(3))
        rad = (0.7 + 1.3 * pt.size * (0.5 + 0.5 * k)) * r / 190
        d.ellipse([pt.x - rad, pt.y - rad, pt.x + rad, pt.y + rad], fill=(*col, int(255 * pt.alpha)))


def logo(size: int = 256) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    sphere(img, size / 2, size / 2, size * 0.36, n=360)
    return img


def welcome(w: int = 760, h: int = 300) -> Image.Image:
    img = background(w, h)
    sphere(img, w * 0.76, h / 2, h * 0.36)
    d = ImageDraw.Draw(img)
    d.text((48, h / 2 - 70), "UMBRA OS", font=font("Bold", 64), fill=INK)
    d.text((50, h / 2 + 10), "Tu sistema, tu IA, en tu equipo.", font=font("Regular", 24), fill=DIM)
    d.text((50, h / 2 + 48), "Basado en Debian 13 · con NYX", font=font("Medium", 18), fill=PURPLE)
    return img


SLIDES = [
    ("Bienvenido a UMBRA OS", ["Mientras se instala, te contamos", "lo que vas a encontrar."]),
    ("NYX, tu asistente local", ["Le hablas en español y maneja el equipo.", "Sin nube: todo se queda en tu ordenador."]),
    ("Segura por diseño", ["NYX pide permiso antes de hacer algo", "importante y todo queda registrado."]),
    ("Tus descargas, vigiladas", ["Cada archivo se analiza sin abrirlo.", "Lo peligroso va a cuarentena."]),
    ("A tu gusto", ["Colores, cristal, navegador y packs", "de aplicaciones en la Bienvenida."]),
]


def slide(title: str, lines: list[str], i: int, w: int = 800, h: int = 400) -> Image.Image:
    img = background(w, h)
    sphere(img, w * 0.78, h / 2, h * 0.30, angle=0.4 + i * 0.7)
    d = ImageDraw.Draw(img)
    d.text((48, 120), title, font=font("Bold", 40), fill=INK)
    for k, line in enumerate(lines):
        d.text((50, 190 + k * 36), line, font=font("Regular", 24), fill=DIM)
    for k in range(len(SLIDES)):  # puntos de progreso
        x = 52 + k * 22
        d.ellipse([x, h - 48, x + 10, h - 38], fill=(*(PURPLE if k == i else (80, 64, 110)), 255))
    return img


def main(out: str) -> None:
    o = Path(out)
    o.mkdir(parents=True, exist_ok=True)
    logo().save(o / "logo.png")
    welcome().convert("RGB").save(o / "bienvenida.png")
    for i, (t, ls) in enumerate(SLIDES, 1):
        slide(t, ls, i - 1).convert("RGB").save(o / f"diapositiva{i}.png")


if __name__ == "__main__":
    main(sys.argv[1])
