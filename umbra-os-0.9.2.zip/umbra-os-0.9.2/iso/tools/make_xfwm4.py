"""Bordes y barra de título de las ventanas (xfwm4) con el morado oscuro de UMBRA.

Parte del tema xfwm4 de Arc-Dark (GPL-3.0, https://github.com/jnsh/arc-theme): copia sus imágenes y
cambia los grises azulados por los morados de UMBRA, conservando la luz y la sombra de cada píxel.
Los botones de cerrar en rojo se respetan.

uso: python3 iso/tools/make_xfwm4.py /usr/share/themes/Arc-Dark/xfwm4 iso/config/includes.chroot/usr/share/themes/UMBRA/xfwm4
"""

from __future__ import annotations

import colorsys
import re
import shutil
import sys
from pathlib import Path

from PIL import Image

HEADER = (0x1b, 0x11, 0x31)  # mismo color que las barras del tema GTK (umbra_header)
ARC_HEADER = (0x2f, 0x34, 0x3f)


def recolor(img: Image.Image) -> Image.Image:
    img = img.convert("RGBA")
    px = img.load()
    h0, s0, v0 = colorsys.rgb_to_hsv(*(c / 255 for c in HEADER))
    _, _, va = colorsys.rgb_to_hsv(*(c / 255 for c in ARC_HEADER))
    for y in range(img.height):
        for x in range(img.width):
            r, g, b, a = px[x, y]
            h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            if s < 0.30 and v < 0.85:  # grises de Arc (fondos, bordes, iconos apagados)
                nv = min(1.0, v * v0 / va)
                nr, ng, nb = colorsys.hsv_to_rgb(h0, min(1.0, s0 * (0.4 + v)), nv)
                px[x, y] = (int(nr * 255), int(ng * 255), int(nb * 255), a)
            elif 0.50 < h < 0.70 and s > 0.30:  # azul de Arc (resaltados) -> morado de NYX
                nr, ng, nb = colorsys.hsv_to_rgb(0.72, s, v)
                px[x, y] = (int(nr * 255), int(ng * 255), int(nb * 255), a)
    return img


def main(src: str, dst: str) -> None:
    s, d = Path(src), Path(dst)
    d.mkdir(parents=True, exist_ok=True)
    for f in sorted(s.iterdir()):
        if f.suffix == ".png":
            recolor(Image.open(f)).save(d / f.name)
        elif f.name == "themerc":
            text = f.read_text()
            text = re.sub(r"active_text_color=#\w+", "active_text_color=#e6dcf7", text)
            text = re.sub(r"inactive_text_color=#\w+", "inactive_text_color=#9d8fbd", text)
            text = re.sub(r"(in)?active_text_shadow_color=#\w+", lambda m: f"{m.group(1) or ''}active_text_shadow_color=#140c26", text)
            (d / "themerc").write_text("# Tema de ventanas de UMBRA OS, derivado de Arc-Dark (GPL-3.0)\n" + text)
        elif f.suffix == ".xpm":
            shutil.copy(f, d / f.name)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
