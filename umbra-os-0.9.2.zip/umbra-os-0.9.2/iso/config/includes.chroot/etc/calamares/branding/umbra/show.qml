/* Diapositivas de UMBRA OS mientras se instala (Calamares, slideshowAPI 2). */
import QtQuick 2.0
import calamares.slideshow 1.0

Presentation
{
    id: presentation

    Timer {
        id: avance
        interval: 7000
        running: presentation.activatedInCalamares
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Slide { Image { anchors.centerIn: parent; source: "diapositiva1.png"; width: parent.width; height: parent.height; fillMode: Image.PreserveAspectFit } }
    Slide { Image { anchors.centerIn: parent; source: "diapositiva2.png"; width: parent.width; height: parent.height; fillMode: Image.PreserveAspectFit } }
    Slide { Image { anchors.centerIn: parent; source: "diapositiva3.png"; width: parent.width; height: parent.height; fillMode: Image.PreserveAspectFit } }
    Slide { Image { anchors.centerIn: parent; source: "diapositiva4.png"; width: parent.width; height: parent.height; fillMode: Image.PreserveAspectFit } }
    Slide { Image { anchors.centerIn: parent; source: "diapositiva5.png"; width: parent.width; height: parent.height; fillMode: Image.PreserveAspectFit } }

    function onActivate() { presentation.currentSlide = 0; }
    function onLeave() { }
}
