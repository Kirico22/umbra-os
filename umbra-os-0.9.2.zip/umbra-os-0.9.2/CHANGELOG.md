# Cambios

## 0.9.2 — 2026-11-25

Revisión de rendimiento del código (medido antes y después).

- **Archivos**: la cuadrícula solo crea los iconos que se ven (GridView). Abrir una carpeta con
  3000 archivos pasa de 1,4 s a 0,24 s; volver a una carpeta pequeña, de 165 a 46 ms. Los cambios
  en la carpeta se agrupan en un solo refresco y lo analizado por NYX solo se relee si cambia.
- **Fondo animado**: los halos de las partículas se pintan una vez y se reutilizan, las órbitas se
  calculan una vez y se trazan en ~25 pasadas en vez de ~420, y el fondo se convierte una sola vez.
  Gasta un 25 % menos de procesador. Cuando una ventana lo tapa, deja de despertarse.
- **Vigía de descargas**: si la carpeta no cambia, solo mira su fecha (2 µs) en vez de leerla
  entera cada segundo y medio (6 ms con 800 archivos). Cada minuto la repasa entera por seguridad.
- **NYX guardián**: solo carga NYX si hay una rutina que ejecutar.
- Buscador: los nombres de las aplicaciones se normalizan una vez y no en cada tecla.
- HoneyShield comprueba sus ajustes cada 4 s en vez de cada 2.
- Pruebas nuevas del vigía en reposo y de la caché del fondo animado; todas las pruebas de las
  ventanas (GTK) se ejecutan ahora también.

## 0.9.1 — 2026-11-25

Todo con el mismo diseño, como en la maqueta.

- **Archivos de UMBRA**: explorador propio igual que el diseño. Barra lateral con tus carpetas,
  Descargas «vigiladas», Papelera, Cuarentena y espacio del disco; migas de ruta, búsqueda e iconos
  grandes o pequeños; etiquetas de color por tipo de archivo y, debajo de cada uno, lo que dijo NYX
  (Seguro, Precaución, Peligroso). En Descargas, aviso de NYX con el resumen y botón «Analizar ahora».
  Abrir algo peligroso pide confirmación. Menú del botón derecho: abrir, analizar con NYX, renombrar,
  copiar la ruta y mover a la papelera. Thunar sigue disponible para copiar, pegar y crear carpetas.
- **Sin ventanas blancas**: barras de título de las ventanas (xfwm4) con el tema UMBRA,
  tema GTK 4 oscuro y morado (menús, desplegables, diálogos) y modo oscuro por defecto.
- NYX recuerda lo que ha analizado (`~/.cache/umbra/analizados.json`) para enseñarlo en Archivos.
- **Ajustes**: efecto cristal (Alto, Medio, Opaco) y Rendimiento con botones en vez de desplegables;
  nombre debajo de cada fondo de escritorio.

## 0.9.0 — 2026-11-25

Aspecto propio de UMBRA en todas las aplicaciones.

- **Tema GTK «UMBRA»** (basado en Arc-Dark): Archivos, diálogos de abrir y guardar, LibreOffice,
  el panel y el resto de aplicaciones GTK 3 con el morado oscuro de NYX, botones redondeados,
  selección morada, menús y descripciones a juego.
- **Carpetas moradas** en el tema de iconos Papirus.
- **Archivos (Thunar)** más limpio: sin barra de menús (queda el botón de menú), iconos más grandes.
- **Ajustes rediseñados**: barra lateral por secciones (Apariencia, Rendimiento, Ratón, NYX,
  Seguridad, Navegador, Acerca de) y cada opción en su tarjeta.
- Arreglado: con el cristal «apagado» (y en modo ligero) las ventanas de UMBRA salían blancas.
- El instalador usa también el tema UMBRA.

## 0.8.8 — 2026-11-25

Arreglos encontrados en la grabación de pantalla.

- **Pantalla negra al cambiar el «Efecto cristal» en Ajustes**: escribía la configuración completa
  del compositor (OpenGL + desenfoque) aunque el equipo estuviera en modo ligero; en una máquina
  virtual picom no arrancaba. Ahora respeta el modo de rendimiento.
- **Ventanas transparentes sin desenfoque**: en modo ligero las ventanas de UMBRA son opacas (antes
  se veía el escritorio a través de Ajustes). El control de cristal se desactiva y lo explica.
- **El orbe de NYX ocupaba 487 MB**: el modelo de voz vivía dentro de la ventana. Ahora va en un
  proceso aparte (224 MB) que se cierra solo tras 10 minutos sin hablar; la ventana se queda en
  ~40 MB más GTK.
- NYX entiende «hola nyx, ¿qué tal?», «¿qué puedes hacer?» y «¿qué me recomiendas?»; el mensaje
  cuando no entiende algo es más útil.
- El escritorio ya no repite iconos que están en el dock (Navegador, NYX, Ajustes, Buscar) y ya no
  tapan el logotipo del fondo.

## 0.8.7 — 2026-11-25

Voz de NYX sin cortes.

- **Una sola corriente de audio por respuesta** (pacat o aplay leyendo audio crudo): antes cada
  frase abría su propio reproductor y en una máquina virtual se oían huecos y chasquidos entre frases.
- **Espera adaptativa**: con la primera frase NYX mide lo rápido que calcula la voz el equipo. Si es
  rápido, habla al momento; si es lento, prepara lo justo antes de empezar para no cortarse a mitad.
  Medido con un equipo simulado 1,4 veces más lento que el tiempo real: de 10 s de cortes en una
  respuesta de 17 s a ninguno.
- El cálculo de la voz ya no va con prioridad muy baja (nice 2 en vez de 10): en equipos justos se
  quedaba sin procesador.
- Nuevo paquete: pulseaudio-utils (pacat).

## 0.8.6 — 2026-11-25

- **Instalador con la marca de UMBRA**: logo de la esfera de NYX, portada, barra lateral morada,
  estilo oscuro en todas las pantallas y 5 diapositivas mientras se instala.
- Al abrirse como administrador (pkexec) el instalador perdía el tema oscuro del usuario y salía
  blanco; ahora lo recibe directamente.
- La entrada de arranque sigue llamándose «Debian» a propósito: es la carpeta EFI que espera el
  cargador firmado para Secure Boot.

## 0.8.5 — 2026-11-25

Más fluidez, sobre todo al iniciar sesión y en máquinas virtuales.

- **Nada se actualiza en la sesión en vivo**: ni apt ni las firmas del antivirus (~300 MB que
  iban a la RAM).
- **Las actualizaciones atrasadas ya no se lanzan justo al arrancar**: esperan 15 minutos y van
  con prioridad baja. Los parches de seguridad siguen siendo diarios.
- **La tienda (GNOME Software) ya no se queda en segundo plano** al iniciar sesión (~200 MB y
  descargas de catálogos). Sigue funcionando al abrirla.
- **Modo ligero**: el compositor ya no hace fundidos (en una VM cada uno redibujaba la ventana
  ~10 veces), solo redibuja lo que cambia y se aparta con vídeo o juegos a pantalla completa.
- La esfera de NYX en reposo va a 10 fps en modo ligero.
- El fondo animado decide si arrancar antes de cargar GTK: en modo ligero no gasta nada.
- El orbe arranca 6 s después de entrar y la voz de NYX se precarga a los 40 s, para no
  competir con el inicio de sesión.

## 0.8.4 — 2026-11-25

- **La Bienvenida va en silencio**: ya no carga la voz de NYX (~100 MB de RAM y unos segundos de
  CPU) en el primer arranque. NYX habla después, desde el orbe.
- La esfera de la Bienvenida se dibuja a 20 fps en vez de 60.

## 0.8.3 — 2026-11-25

- **Arreglado: pantalla negra al instalar packs en la sesión en vivo.** Sin instalar, todo lo que se
  instala va a la RAM; el pack Gaming (~4,5 GB) o el Creativo (~3 GB) la llenaban y el escritorio
  se colgaba. Ahora los packs solo se instalan con UMBRA ya instalado; la Bienvenida lo explica.
- Antes de instalar un pack se comprueba que hay espacio en el disco (tamaño del pack + 2 GB).
- En la sesión en vivo la pantalla ya no se apaga sola mientras pruebas o instalas.

## 0.8.2 — 2026-11-25

Memoria virtual, como la «RAM virtual» de los móviles.

- **Hasta 8 GB de swap en el disco**, creados solos al arrancar el sistema instalado si sobra
  espacio: siempre quedan libres al menos 15 GB (o el 10 % del disco).
- Dos niveles: primero zram (RAM comprimida, rápida, prioridad 100) y después el disco
  (prioridad 10), solo cuando zram ya está lleno.
- Si el instalador ya creó un swap, UMBRA solo añade lo que falte hasta 8 GB; si el disco se
  llena, lo reduce o lo quita en el siguiente arranque.
- Nunca en la sesión en vivo y nunca toca particiones: es un archivo (/swapfile-umbra, solo root).
- Interruptor en **Ajustes → Rendimiento** (pide la contraseña) y NYX lo explica:
  «¿cuánta memoria virtual tengo?».
- Ajustes del núcleo para zram: vm.swappiness 100 y vm.page-cluster 0.

## 0.8.1 — 2026-11-25

Dock nuevo, cajón de aplicaciones y más rendimiento.

- **Dock pequeño y centrado abajo**, de cristal y con esquinas redondeadas: Aplicaciones (botón
  propio con la esfera de NYX en la órbita de UMBRA), Archivos, Navegador, ventanas abiertas,
  Wi-Fi, volumen y Apagar.
- **El botón Navegador lleva el icono del navegador que elijas** (Opera GX, Chrome o Chromium) y
  cambia al momento, sin reiniciar el panel.
- **Cajón de aplicaciones**: al pulsar el botón de NYX salen todas las aplicaciones en cuadrícula,
  por categorías. Al escribir, busca apps, archivos y ajustes, o le preguntas a NYX.

Errores corregidos:
- El buscador mostraba iconos equivocados (usaba el nombre del lanzador en vez de su icono).
- Salían aplicaciones que no funcionan en UMBRA (solo de GNOME o KDE) o ya desinstaladas.
- Una prueba dejaba una carpeta `__pycache__` dentro de los archivos de la ISO.
- Avisos del analizador de código (import sin usar, argumento mutable).

Rendimiento (medido):
- En máquinas virtuales o sin aceleración gráfica, las ventanas GTK 4 se dibujan con cairo:
  127 MB en vez de 172 MB por ventana y algo menos de CPU.
- El buscador ya no recorre tu carpeta personal en cada tecla: índice de 1 minuto (0,5 ms por tecla).
- La lista de aplicaciones se guarda en memoria y solo se relee si se instala o quita algo.
- El buscador ya no carga la voz de NYX (~100 MB) salvo que le preguntes algo.
- Abrir NYX o el buscador ya no carga todos los módulos de NYX de golpe.

## 0.8.0 — 2026-11-25

HoneyShield se une a UMBRA y NYX.

- **Señuelos (honeypots)**: SSH 2222, FTP 2121, Telnet 2323, HTTP 8081, MySQL 3307 y SMTP 2525.
  Cualquier conexión a ellos es sospechosa: escaneos, fuerza bruta o un equipo infectado en tu red.
- **Puntuación de amenaza** por IP (baja, media, alta) según lo que hace: escanear varios puertos,
  probar usuarios o enviar órdenes de ataque (descargas de malware, shells, inyección SQL…).
- **NYX lo explica**: «¿quién me está atacando?», «estado de HoneyShield», «bloquea la IP X».
- **Bloqueo de IPs** en el cortafuegos con confirmación y contraseña (ayudante de polkit con
  órdenes fijas y validación de la IP).
- Interruptor en **Ajustes → Seguridad**.

Seguridad: apagado por defecto; sin root; los señuelos solo saludan, leen como mucho 4 KB y
cierran; nunca ejecutan nada; las contraseñas probadas no se guardan; nada sale del equipo.

## 0.7.2 — 2026-11-22

Voz de NYX más limpia y rápida.

- **Sin distorsión**: Piper genera la voz al 80 % del volumen. A tope llegaba al límite y, al pasar
  a 48 kHz, los picos se recortaban (chasquidos).
- **Sin cortes**: el reproductor usa un búfer de 250 ms; con el procesador ocupado (máquina virtual)
  el sonido ya no se queda sin datos a mitad de frase.
- **Responde antes**: habla frase a frase; empieza con la primera mientras prepara las demás
  (de 1,3 s a 0,26 s en una respuesta de 14 s, medido).
- **La ventana no se congela al abrirse**: el modelo de voz se carga en segundo plano.
- La síntesis va en un hilo de prioridad baja: la interfaz y el audio tienen preferencia.
- La esfera se dibuja a 30 fps mientras habla en los modos equilibrado y ligero (antes 60).
- Nuevo diagnóstico: `nyx --voz-prueba`.

## 0.7.1 — 2026-11-22

### Corregido
- **El instalador no se abría**: el lanzador de Debian ejecuta `sudo` sin ventana y podía quedarse esperando
  una contraseña invisible. Nuevo lanzador `umbra-instalar` (icono «Instalar UMBRA», solo en la sesión en
  vivo): avisa al momento, pausa el fondo animado, pide la contraseña con polkit y, si falla, lo dice y deja
  el registro en `/var/log/umbra-instalador.log`.

### Rendimiento
- **Modo de rendimiento** (`perf.py`, Ajustes → Rendimiento): automático, máximo, equilibrado o ligero.
  En máquinas virtuales, sin aceleración gráfica o con menos de 4 GB de RAM elige «ligero» solo: picom sin
  desenfoque ni animaciones (xrender) y fondo fijo.
- El átomo se **pausa cuando una ventana lo tapa** (45 % → 1 % de CPU medido) y va a 20 fps en «equilibrado».
- El orbe en reposo dibuja a 20 fps en vez de 60 (15 % → 6 % de CPU medido).
- El vigía y el guardián arrancan 40 y 90 s después de entrar; el antivirus actualiza sus firmas 20 minutos
  después de arrancar y con la prioridad más baja (antes lo hacía al encender).
- Memoria comprimida en RAM (zram, zstd, hasta el 50 %).

## 0.7.0 — 2026-11-20

### Añadido
- **Oído de NYX** (`nyx/listen.py`): voz a texto local con Vosk (modelo español pequeño), botón de micrófono
  en la burbuja del orbe y «Oye NYX» opcional (apagado por defecto; no se guarda ningún audio).
- **Cerebro local** (`brain.py`): Qwen2.5 1.5B Instruct Q4_K_M (Apache 2.0) descargable desde Ajustes, la
  bienvenida o `nyx --cerebro descargar`; descarga reanudable verificada con SHA-256; lo ejecuta llama-server
  solo en 127.0.0.1 (`LlamaServerProvider`).
- **Guardián** (`nyx-guardian`): avisos de disco casi lleno, programas que se comen la CPU y actualizaciones.
- **Rutinas** (`routines.py`, módulo `routines`): «cada viernes a las 18:00 …», «todos los días a las 9 …»,
  «cada hora …». Riesgo bajo: solas; medio: preguntan con una notificación; alto: nunca.
- **Packs** (`packs.py`): gaming, creativo, programación y multimedia; Debian vía polkit con listas fijas
  (`/usr/libexec/umbra/instalar-pack`) y Flathub solo para el usuario.
- **Bienvenida** (`umbra-bienvenida`) en el primer inicio.
- **Modo juego** (`gamemode.py`) y sesión **«UMBRA (modo seguro)»**.
- ISO: LibreOffice, VLC, KeePassXC, Thunderbird, Atril, Ristretto, Xarchiver, 7zip, Discos, Baobab,
  Timeshift, Déjà Dup, Flatpak + GNOME Software + Flathub, Gufw; panel rápido (volumen, energía,
  notificaciones); pantalla de acceso con la esfera (`make_login.py`) y tema de cristal; notificaciones
  de cristal; Calamares con cifrado LUKS disponible y sin opción de borrado preseleccionada.

### Corregido
- `umbra-vigia --una-vez` no analizaba nada (el primer sondeo solo anotaba los archivos).
- Resumen de carpetas: mostraba el primer motivo en vez del más grave; EICAR contado dos veces en zips.

## 0.6.0 — 2026-11-20

### Añadido
- **Analizador de archivos de NYX** (`scanner.py`, Python puro y sin conexión): tipo real por los
  primeros bytes, extensiones dobles, caracteres invisibles en el nombre, órdenes peligrosas en scripts
  y lanzadores, macros de Office, PDF con JavaScript o `/Launch`, comprimidos por dentro (bombas zip,
  rutas con `..`, cifrados), scripts de instalación de `.deb`, EICAR, lista local de huellas y ClamAV.
- **Vigía de descargas** (`umbra-vigia`): analiza cada descarga al terminar, quita el permiso de ejecución
  a lo sospechoso, lo audita y abre el **aviso de NYX** (`umbra-aviso`), con voz si es peligroso.
- **Cuarentena** (permisos 000), restaurar (riesgo ALTO, sin sobrescribir) y borrar.
- Módulo `security` con 7 acciones y órdenes naturales: «¿es seguro X?», «analiza las descargas»,
  «pon en cuarentena X», «¿estoy protegido?»…
- **ISO endurecida**: ufw activo, AppArmor con perfiles extra, `unattended-upgrades`, `needrestart`,
  ClamAV con `freshclam`, `sysctl` endurecido, carpetas personales `0700`, notificaciones (`xfce4-notifyd`).
- Ajustes → **Seguridad**: estado de la protección, vigía, avisos, voz, ClamAV en cada descarga,
  «Analizar ahora» y cuarentena.

### Corregido (comprobación de errores)
- El registro de auditoría crecía sin límite: ahora rota a los 5 MB.
- Las rutas al final de una pregunta se quedaban con la «?» pegada («¿cuánto ocupa ~/Descargas?»).
- Limpieza de imports sin usar y `zip(strict=…)` (ruff).
- Prueba contra caracteres de inversión de texto ocultos en el código («Trojan Source»).

## 0.5.0 — 2026-11-20

### Añadido
- **Fondo de átomo**: núcleo de 7 protones y 7 neutrones y 3 electrones, todos bolitas de partículas;
  6 versiones de color.
- **Átomo vivo** (`umbra-atomo`): ventana bajo todas las demás, alineada con el fondo, que anima el átomo.
  Clic derecho en el núcleo: fusión nuclear que se dispersa en mini átomos y se recompone (probado con clic real).
- **Puntero del ratón**: temas UMBRA y UMBRA-Claro (generados con xcursorgen, espera animada de partículas),
  Breeze y DMZ en la ISO; apartado en Ajustes con tema, tamaño y vista previa.
- **Easter eggs**: frases secretas, código Konami, supernova del orbe, barrel roll, arcoíris, Matrix,
  fechas especiales, `nyx --cosmos` y el color secreto «nebulosa». Ver `docs/SECRETOS.md`.
- Ajustes: interruptor de fondo animado; el fondo elegido se recuerda.

### Cambiado
- Cristal algo más opaco para leerse bien también sin desenfoque.

## 0.4.0 — 2026-11-20

### Añadido
- **Orbe de NYX** (`nyx-orbe`): esfera flotante siempre encima; arrastrar con el clic mantenido
  (posición guardada), clic para abrir una burbuja de cristal con conversación, voz y confirmaciones;
  clic derecho con accesos a NYX, Buscar, Ajustes y ocultar. Probado con un gestor de ventanas real.
- **Liquid Glass** (`theme.py`): estilo de cristal compartido por todas las apps de UMBRA, 5 colores
  de acento y 3 niveles de cristal; picom desenfoca (dual_kawase) ventanas de UMBRA, panel y menús.
- **Buscador** (`umbra-buscar`, Súper + Espacio): apps, ajustes, archivos y «Preguntar a NYX».
- **Ajustes de UMBRA** (`umbra-ajustes`): acento, cristal, fondo, tamaño de iconos, orbe, voz y navegador.
- **Navegadores**: Chromium incluido; Opera GX y Google Chrome desde sus repositorios oficiales con un
  clic (instalador fijo vía polkit) o pidiéndoselo a NYX.
- Escritorio: panel inferior de cristal tipo dock, iconos Papirus con carpetas violeta, iconos propios
  (NYX, Buscar, Ajustes), lanzadores en el escritorio, 5 fondos (uno por color), bienvenida al primer inicio.

### Cambiado
- Firefox sustituido por Chromium. La configuración de picom se genera desde `desktop.picom_config()`.

## 0.3.0 — 2026-11-20

### Añadido
- **NYX como esfera de partículas** (`sphere.py`): 560 partículas en 3D que giran, respiran,
  se arremolinan al pensar y vibran con la voz. Un estado visible: en reposo, pensando, hablando.
- **Voz de NYX** (`nyx/voice.py`): Piper con voz española femenina, local y sin internet;
  respaldo espeak-ng. Lee solo la parte útil de cada respuesta. Botón para silenciarla.
- **Nuevo arranque**: las partículas se reúnen en la esfera, escriben «UMBRA» y vuelven a la esfera
  con el nombre. Al apagar, la esfera con «Apagando UMBRA OS…». Probado con Plymouth real.
- La ISO incluye Piper y la voz (descargadas al construir) y el audio (PipeWire).

### Cambiado
- Fotogramas de Plymouth con paleta de 64 colores (9,4 MB → 2,1 MB) y carga uno a uno.

## 0.2.0 — 2026-11-20

### Añadido
- ISO de UMBRA OS sobre **Debian 13** con live-build, construida en GitHub Actions.
- Escritorio XFCE con tema oscuro, fondo y pantalla de inicio de sesión de UMBRA.
- Animación de arranque y apagado (tema Plymouth `umbra`), probada con Plymouth real.
- Animaciones de ventanas con picom 12 (abrir, cerrar, minimizar, mover) y esquinas redondeadas.
- Ventana gráfica de NYX (GTK 4): mensajes animados, indicador de «pensando», accesos rápidos
  y tarjetas de confirmación (las de riesgo alto exigen escribir CONFIRMAR).
- Herramientas nuevas: buscar archivos, organizar archivos por tipo con deshacer, estado de red,
  listar/abrir aplicaciones, cerrar procesos propios, buscar e instalar programas (polkit).
- `on_step`: NYX muestra cada paso en cuanto termina.

### Corregido
- La memoria SQLite no se podía usar desde el hilo de la ventana gráfica.

## 0.1.0 — 2026-11-20

Primera versión del repositorio reorganizado.

### Añadido
- NYX AI Engine: motor de intenciones en Python puro y conversación con herramientas (JSON).
- Proveedores de modelo locales: `llama-cpp-python` (.gguf en proceso) y Ollama; detección automática.
- NYX Memory en SQLite: datos recordados y conversaciones, persistentes.
- NYX Security: broker con lista de acciones, validación de argumentos, permisos por módulo,
  confirmación por riesgo y auditoría con ocultación de secretos.
- Módulos de solo lectura: `system`, `files`, `processes`, `services`, `memory`.
- CLI `nyx`, configuración TOML, 30 pruebas y CI en GitHub Actions.

### Corregido respecto al prototipo `nyx/nyx.py`
- Pedía la respuesta de Ollama en *streaming* pero la leía como un único JSON (fallaba siempre).
- Un fallo de conexión con Ollama cerraba el programa.
