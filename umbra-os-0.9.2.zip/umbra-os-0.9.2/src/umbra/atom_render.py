"""Dibuja el átomo vivo con cairo (lo usan la ventana del escritorio y el generador de vídeo)."""

from __future__ import annotations

import math

import cairo

from .atom import Frame, orbit_point

NEUTRON = (196 / 255, 188 / 255, 222 / 255)
ORBIT_SEGMENTS = 140
ORBIT_ALPHAS = 40  # niveles de brillo de las órbitas (a simple vista es continuo)


class AtomRenderer:
    def __init__(self, proton: tuple[float, float, float], center: tuple[float, float], scale: float) -> None:
        self.proton = proton
        self.electron = tuple(c + (1 - c) * 0.55 for c in proton)
        self.center = center
        self.scale = scale
        self._glows: dict[tuple, cairo.ImageSurface] = {}
        self._orbit_cache: dict[tuple[int, float], list[tuple[float, float, float]]] = {}

    def draw(self, cr: cairo.Context, frame: Frame) -> None:
        cx, cy = self.center
        s = self.scale
        self._orbits(cr, frame, front=False)
        drawn_front = False
        for b in frame.balls:  # de atrás hacia delante
            if not drawn_front and b.depth > 1.0:  # todo el núcleo ya está pintado
                self._orbits(cr, frame, front=True)
                drawn_front = True
            self._ball(cr, cx + b.x * s, cy + b.y * s, b.radius * s, b.kind, b.sphere, b.alpha)
        if not drawn_front:
            self._orbits(cr, frame, front=True)
        for e in frame.effects:
            self._effect(cr, cx + e.x * s, cy + e.y * s, e.radius * s, e.kind, e.alpha)

    def _color(self, kind: str) -> tuple[float, float, float]:
        if "neutron" in kind:
            return NEUTRON
        if kind == "electron":
            return self.electron
        return self.proton

    def _ball(self, cr, x, y, radius, kind, sphere, alpha) -> None:
        if alpha <= 0.01 or radius <= 0.5:
            return
        r0, g0, b0 = self._color(kind)
        # Halo: una imagen ya pintada por color y tamaño (pintar el degradado cada vez era
        # lo más caro del fondo animado: ~5 ms de cada fotograma)
        spr, half = self._glow_sprite((r0, g0, b0), radius * 1.8)
        cr.set_source_surface(spr, x - half, y - half)
        cr.paint_with_alpha(0.22 * alpha)
        # cuerpo oscuro que separa cada bolita de las que tiene detrás
        cr.set_source_rgba(r0 * 0.16, g0 * 0.16, b0 * 0.16, 0.6 * alpha)
        cr.arc(x, y, radius * 0.98, 0, math.tau)
        cr.fill()
        dot = max(0.6, radius / 18)
        for p in sphere.project(x, y, radius / 1.3):
            k = max(0.0, min(1.0, (p.depth + 1) / 2))
            cr.set_source_rgba(r0 + (1 - r0) * 0.45 * k, g0 + (1 - g0) * 0.45 * k, b0 + (1 - b0) * 0.45 * k,
                               p.alpha * alpha)
            cr.arc(p.x, p.y, dot * (0.5 + 0.5 * p.size), 0, math.tau)
            cr.fill()

    def _glow_sprite(self, color: tuple[float, float, float], r: float) -> tuple[cairo.ImageSurface, float]:
        """Halo radial de radio r (redondeado a medio píxel), guardado para los siguientes fotogramas."""
        key = (color, round(r * 2) / 2)
        spr = self._glows.get(key)
        if spr is None:
            if len(self._glows) > 400:
                self._glows.clear()
            rr = key[1]
            size = int(math.ceil(rr * 2)) + 2
            spr = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size)
            c = cairo.Context(spr)
            g = cairo.RadialGradient(size / 2, size / 2, 0, size / 2, size / 2, rr)
            g.add_color_stop_rgba(0, *color, 1)
            g.add_color_stop_rgba(1, *color, 0)
            c.set_source(g)
            c.arc(size / 2, size / 2, rr, 0, math.tau)
            c.fill()
            self._glows[key] = spr
        return spr, spr.get_width() / 2

    def _orbit_points(self, i: int, scale: float) -> list[tuple[float, float, float]]:
        """Puntos de una órbita ya en pantalla; solo se recalculan si cambia su tamaño."""
        key = (i, round(scale, 3))
        pts = self._orbit_cache.get(key)
        if pts is None:
            if len(self._orbit_cache) > 64:
                self._orbit_cache.clear()
            cx, cy = self.center
            s = self.scale
            pts = []
            for k in range(ORBIT_SEGMENTS + 1):
                x, y, z = orbit_point(i, k / ORBIT_SEGMENTS * math.tau, key[1])
                pts.append((cx + x * s, cy + y * s, z))
            self._orbit_cache[key] = pts
        return pts

    def _orbits(self, cr, frame: Frame, front: bool) -> None:
        if frame.orbit_scale < 0.02:
            return
        er, eg, eb = self.electron
        phases = [None, None, None]
        for i, ang in frame.electrons:
            phases[i] = ang
        cr.set_line_width(max(1.0, 1.4 * self.scale))
        # Segmentos con brillo parecido en un solo trazo: ~25 trazos por fotograma en vez de ~420
        buckets: dict[int, list] = {}
        for i, phase in enumerate(phases):
            pts = self._orbit_points(i, frame.orbit_scale)
            for k in range(ORBIT_SEGMENTS):
                x0, y0, z = pts[k]
                if (z >= 0) != front:
                    continue
                a0 = k / ORBIT_SEGMENTS * math.tau
                lag = (phase - a0) % math.tau if phase is not None else math.tau
                trail = max(0.0, 1 - lag / 2.2)  # estela brillante detrás del electrón
                alpha = (0.10 + 0.22 * (z + 1) / 2 + 0.55 * trail) * frame.orbit_alpha
                level = round(min(1.0, alpha) * ORBIT_ALPHAS)
                if level:
                    buckets.setdefault(level, []).append((x0, y0, pts[k + 1][0], pts[k + 1][1]))
        for level, segs in buckets.items():
            cr.set_source_rgba(er, eg, eb, level / ORBIT_ALPHAS)
            for x0, y0, x1, y1 in segs:
                cr.move_to(x0, y0)
                cr.line_to(x1, y1)
            cr.stroke()

    def _effect(self, cr, x, y, radius, kind, alpha) -> None:
        if alpha <= 0.01:
            return
        if kind == "glow":  # destello de la fusión
            g = cairo.RadialGradient(x, y, 0, x, y, radius)
            g.add_color_stop_rgba(0, 1, 1, 1, 0.95 * alpha)
            g.add_color_stop_rgba(0.3, *self.electron, 0.6 * alpha)
            g.add_color_stop_rgba(1, *self.proton, 0)
            cr.set_source(g)
            cr.arc(x, y, radius, 0, math.tau)
            cr.fill()
        elif kind == "ring":  # onda expansiva
            cr.set_line_width(max(2.0, 10 * alpha * self.scale))
            cr.set_source_rgba(*self.electron, min(1.0, 1.2 * alpha))
            cr.arc(x, y, radius, 0, math.tau)
            cr.stroke()
            cr.set_line_width(max(1.0, 34 * alpha * self.scale))
            cr.set_source_rgba(*self.proton, 0.30 * alpha)
            cr.arc(x, y, radius * 0.96, 0, math.tau)
            cr.stroke()
        elif kind == "mini-orbit":  # órbita de cada mini átomo
            cr.save()
            cr.translate(x, y)
            cr.scale(1, 0.32)
            cr.set_line_width(max(1.2, 1.8 * self.scale))
            cr.set_source_rgba(*self.electron, alpha)
            cr.arc(0, 0, radius, 0, math.tau)
            cr.restore()
            cr.stroke()
