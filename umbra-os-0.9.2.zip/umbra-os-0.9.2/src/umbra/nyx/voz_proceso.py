"""Proceso aparte que genera la voz de NYX con Piper.

El modelo de voz ocupa unos 250 MB de RAM. Si se cargara dentro del orbe, esa memoria se quedaría
ocupada para siempre. Aquí vive en un proceso propio que se cierra solo tras 10 minutos sin
hablar, y el sistema recupera la memoria entera.

Protocolo (una línea por mensaje): el proceso dice «listo» al cargar el modelo; después recibe
{"texto": ..., "wav": ruta} y contesta «ok» o «error».
"""

from __future__ import annotations

import json
import os
import select
import sys
import wave

IDLE_SECONDS = 600


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        os.nice(2)  # algo por debajo de la interfaz, sin quedarse sin procesador
    except OSError:
        pass
    try:
        from piper import PiperVoice, SynthesisConfig

        from .voice import PIPER_LENGTH_SCALE, PIPER_SPEAKER, PIPER_VOLUME

        voice = PiperVoice.load(argv[0])
        cfg = SynthesisConfig(speaker_id=voice.config.speaker_id_map.get(PIPER_SPEAKER),
                              length_scale=PIPER_LENGTH_SCALE, volume=PIPER_VOLUME)
    except Exception:
        print("error", flush=True)
        return 1
    print("listo", flush=True)
    while True:
        ready, _, _ = select.select([sys.stdin], [], [], IDLE_SECONDS)
        if not ready:
            return 0  # 10 minutos sin hablar: se libera la memoria
        line = sys.stdin.readline()
        if not line:
            return 0
        try:
            job = json.loads(line)
            with wave.open(str(job["wav"]), "wb") as w:
                voice.synthesize_wav(str(job["texto"]), w, syn_config=cfg)
            print("ok", flush=True)
        except Exception:
            print("error", flush=True)


if __name__ == "__main__":
    sys.exit(main())
