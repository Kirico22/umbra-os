"""NYX AI Engine: entiende, planifica, pide acciones al broker y explica resultados.

Orden de decisión:
  1. Motor de intenciones en Python (rules.py): rápido, sin modelo.
  2. Si no lo reconoce y hay modelo local, conversación con herramientas (JSON).
  3. Si el modelo falla o no existe, NYX lo dice con claridad.
"""

from __future__ import annotations

import json
from typing import Any

from ..security import Broker, ToolCall
from . import easter, rules
from .format import format_result
from .memory import Memory
from .providers import Provider, ProviderError

SYSTEM_PROMPT = """Eres NYX, la inteligencia central de UMBRA OS.
Tu función es asistir al usuario dentro del sistema UMBRA OS.
Responde en español, de forma clara, directa y natural.
No inventes información. Si no sabes algo, dilo.
Funcionas de forma local, sin conexión a servicios externos.

Para actuar sobre el sistema SOLO puedes usar estas herramientas:
{tools}

Responde SIEMPRE con un único objeto JSON y nada más, de una de estas dos formas:
{{"herramienta": "<id>", "argumentos": {{...}}}}
{{"respuesta": "<texto para el usuario>"}}
Tras usar una herramienta recibirás su resultado y podrás usar otra o responder.
Nunca inventes resultados de herramientas. No puedes cambiar permisos ni saltarte confirmaciones.
"""

MAX_RESULT_CHARS = 4000


def _tool_catalog(broker: Broker) -> str:
    lines = []
    for a in broker.available_actions():
        params = ", ".join(
            f"{p.name}: {p.type.__name__}{'' if p.required else ' (opcional)'}" for p in a.params
        )
        lines.append(f"- {a.id}({params}): {a.description}")
    return "\n".join(lines)


def extract_json(text: str) -> dict[str, Any] | None:
    """Devuelve el primer objeto JSON válido que aparezca en el texto."""
    decoder = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch == "{":
            try:
                obj, _ = decoder.raw_decode(text[i:])
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict):
                return obj
    return None


class Nyx:
    def __init__(
        self,
        broker: Broker,
        memory: Memory,
        provider: Provider | None = None,
        session: str = "default",
        context_messages: int = 12,
        max_steps: int = 4,
        on_step=None,
    ) -> None:
        self.broker = broker
        self.memory = memory
        self.provider = provider
        self.session = session
        self.context_messages = context_messages
        self.max_steps = max_steps
        # Si se indica, recibe el texto de cada paso intermedio en cuanto termina
        # (la ventana lo muestra al momento, p. ej. el plan antes de pedir confirmación).
        self.on_step = on_step
        self.last_effect: str | None = None  # efecto visual pedido por un easter egg

    def handle(self, text: str) -> str:
        text = text.strip()
        if not text:
            return ""
        self.memory.add_message(self.session, "user", text)
        self.last_effect = None
        egg = easter.match(text)
        if egg is not None:
            self.last_effect = egg.effect
            self.memory.add_message(self.session, "assistant", egg.reply)
            return egg.reply
        reply = self._rules(text)
        if reply is None:
            reply = self._model(text) if self.provider else self._no_model()
        self.memory.add_message(self.session, "assistant", reply)
        return reply

    # --- 1. motor de intenciones ----------------------------------------
    def _rules(self, text: str) -> str | None:
        plan = rules.match(text)
        if plan is None:
            return None
        parts = []
        for i, call in enumerate(plan.calls):
            result = self.broker.execute(call)
            text = format_result(result)
            if not result.ok:  # si un paso falla, no se sigue con los demás
                parts.append(text)
                break
            if self.on_step and i < len(plan.calls) - 1:
                self.on_step(text)
            else:
                parts.append(text)
        return "\n\n".join(parts)

    def _no_model(self) -> str:
        return (
            "Eso no lo he entendido. Sin el cerebro local solo entiendo órdenes concretas, por ejemplo: "
            "«¿cómo va el equipo?», «analiza mis descargas» o «abre LibreOffice». "
            "Escribe «¿qué puedes hacer?» para ver más.\n"
            "Para preguntas libres, descarga el cerebro local en Ajustes → NYX (unos 1,1 GB, funciona sin internet)."
        )

    # --- 2. modelo con herramientas -------------------------------------
    def _model(self, text: str) -> str:
        system = SYSTEM_PROMPT.format(tools=_tool_catalog(self.broker))
        facts = self.memory.recall()
        if facts:
            system += "\nDatos que el usuario te pidió recordar:\n" + "\n".join(
                f"- {f['key']}: {f['value']}" for f in facts[:30]
            )
        history = self.memory.recent_messages(self.session, self.context_messages)
        messages = [{"role": "system", "content": system}, *history]

        for _ in range(self.max_steps):
            try:
                raw = self.provider.chat(messages)
            except ProviderError as exc:
                return f"No puedo usar el modelo de IA ahora mismo ({exc})."
            data = extract_json(raw)
            if data is None:
                return raw.strip()  # el modelo respondió en texto plano
            if "herramienta" in data:
                call = ToolCall(str(data["herramienta"]), data.get("argumentos") or {})
                if not isinstance(call.args, dict):
                    call.args = {}
                result = self.broker.execute(call)
                payload = {
                    "herramienta": call.action_id,
                    "estado": result.status,
                    "resultado": result.output if result.ok else result.error,
                }
                messages.append({"role": "assistant", "content": raw})
                messages.append(
                    {
                        "role": "user",
                        "content": "RESULTADO DE HERRAMIENTA:\n"
                        + json.dumps(payload, ensure_ascii=False, default=str)[:MAX_RESULT_CHARS],
                    }
                )
                continue
            if "respuesta" in data:
                return str(data["respuesta"]).strip()
            return raw.strip()
        return "He necesitado demasiados pasos y he parado por seguridad. Prueba a concretar más la orden."
