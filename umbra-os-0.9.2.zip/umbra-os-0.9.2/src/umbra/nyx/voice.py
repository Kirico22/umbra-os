"""Voz de NYX: síntesis local (sin internet ni APIs) y envolvente de volumen.

Motores, por orden de preferencia:
  1. Piper (voz neuronal, natural) con la voz española "sharvard", hablante femenina.
  2. espeak-ng (más robótica, pero siempre disponible en UMBRA OS).

`Voice.speak()` trocea la respuesta en frases: sintetiza la primera, empieza a hablar y prepara
las siguientes mientras suena (NYX responde antes). Cada trozo lleva su envolvente de volumen
(60 valores por segundo, de 0 a 1) para que la esfera se mueva al ritmo de la voz.

Para que no se distorsione ni se corte:
  - Piper se genera al 80 % del volumen máximo: a tope, la voz llega al límite (muestras
    recortadas) y al convertirla a 48 kHz el recorte se oye como ruido.
  - El reproductor usa un búfer de 250 ms: si el procesador va justo (máquina virtual), el
    sonido no se queda sin datos a mitad de frase.
  - La síntesis corre en un hilo con prioridad baja (nice 10) y el modelo se carga ahí, no al
    abrir la ventana: la interfaz y el audio tienen preferencia.
"""

from __future__ import annotations

import array
import importlib.util
import math
import os
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import wave
from dataclasses import dataclass
from pathlib import Path

VOICE_DIRS = [Path("/usr/share/umbra/voices"), Path.home() / ".local" / "share" / "umbra" / "voices"]
PIPER_VOICE = "es_ES-sharvard-medium"
PIPER_SPEAKER = "F"  # voz femenina: NYX es la diosa griega de la noche
PIPER_LENGTH_SCALE = 1.08  # un poco más pausada de lo normal: tono calmado
PIPER_VOLUME = 0.8  # margen para no recortar picos (ver arriba)
PLAYER_BUFFER_MS = 250
SYNTH_NICE = 2  # algo por debajo de la interfaz, pero sin quedarse sin CPU (si no, la voz se corta)
STREAM_BUFFER_MS = 400  # margen del reproductor continuo
SAFETY = 1.2  # colchón al decidir cuánta voz preparar antes de empezar a hablar
ENVELOPE_FPS = 60
MAX_SPOKEN_CHARS = 320


def speakable(text: str) -> str:
    """Prepara una respuesta para leerla en voz alta: primera parte útil, sin símbolos ni tablas."""
    lines = [ln.strip() for ln in text.strip().splitlines()]
    out: list[str] = []
    for ln in lines:
        if not ln:
            if out:
                break  # solo el primer bloque: no se leen listas largas
            continue
        out.append(ln)
    spoken = " ".join(out)
    spoken = re.sub(r"[→✓✗•·⚠│|`*_#>\[\]{}]", " ", spoken)
    spoken = re.sub(r"(/[\w.\-]+){2,}", " esa ruta ", spoken)  # no leer rutas enteras
    spoken = spoken.replace("%", " por ciento").replace("GB", " gigas").replace("MB", " megas")
    spoken = re.sub(r"\s+", " ", spoken).strip()
    if len(spoken) > MAX_SPOKEN_CHARS:
        cut = spoken[:MAX_SPOKEN_CHARS]
        spoken = cut[: cut.rfind(".") + 1] or cut[: cut.rfind(" ")] + "…"
    return spoken


def envelope(wav_path: Path, fps: int = ENVELOPE_FPS) -> list[float]:
    """Volumen (RMS) normalizado de 0 a 1, `fps` valores por segundo."""
    with wave.open(str(wav_path), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("se esperaba audio de 16 bits")
        rate, channels = w.getframerate(), w.getnchannels()
        raw = w.readframes(w.getnframes())
    step = max(1, rate // fps)
    try:
        import numpy as np

        a = np.frombuffer(raw, dtype="<i2")[::channels].astype(np.float64)
        n = -(-len(a) // step)
        pad = np.zeros(n * step)
        pad[: len(a)] = a
        sq = (pad ** 2).reshape(n, step).sum(axis=1)
        counts = np.full(n, step, dtype=np.float64)
        if n and len(a) % step:
            counts[-1] = len(a) % step
        values = [float(v) for v in np.sqrt(sq / counts)] if n else []
    except ImportError:  # sin numpy: más lento, mismo resultado
        samples = array.array("h", raw)[::channels]
        values = []
        for i in range(0, len(samples), step):
            chunk = samples[i : i + step]
            values.append(math.sqrt(sum(s * s for s in chunk) / len(chunk)))
    peak = max(values, default=0) or 1.0
    # Raíz para que las partes suaves también muevan la esfera
    return [min(1.0, (v / peak) ** 0.6) for v in values]


def sentences(text: str, min_chars: int = 30) -> list[str]:
    """Trocea en frases para empezar a hablar cuanto antes; une las muy cortas a la siguiente."""
    parts = [p.strip() for p in re.split(r"(?<=[.!?…;:])\s+", text.strip()) if p.strip()]
    out: list[str] = []
    for part in parts:
        if out and len(out[-1]) < min_chars:
            out[-1] = f"{out[-1]} {part}"
        else:
            out.append(part)
    return out


def player_command(player: str, wav: Path, buffer_ms: int = PLAYER_BUFFER_MS) -> list[str]:
    """Orden de reproducción con un búfer amplio para que el audio no se entrecorte."""
    if player == "pw-play":
        return [player, "--latency", f"{buffer_ms}ms", str(wav)]
    if player == "paplay":
        return [player, f"--latency-msec={buffer_ms}", str(wav)]
    if player == "aplay":
        return [player, "-q", f"--buffer-time={buffer_ms * 1000}", str(wav)]
    return [player, str(wav)]


def stream_command(player: str, rate: int, buffer_ms: int = STREAM_BUFFER_MS) -> list[str] | None:
    """Reproductor CONTINUO que lee audio crudo (16 bits, mono) por la entrada estándar.
    Una sola corriente para toda la respuesta: sin cortes ni chasquidos entre frases."""
    if player == "pacat":
        return [player, "--playback", "--format=s16le", f"--rate={rate}", "--channels=1",
                f"--latency-msec={buffer_ms}", "--client-name=NYX"]
    if player == "aplay":
        return [player, "-q", "-t", "raw", "-f", "S16_LE", "-r", str(rate), "-c", "1",
                f"--buffer-time={buffer_ms * 1000}", "-"]
    return None


def start_delay(first_synth: float, first_audio: float, first_chars: int, chars_left: int) -> float:
    """Cuánta voz hay que tener preparada antes de empezar a hablar para no cortarse.

    Con la primera frase se mide la velocidad del equipo: segundos de cálculo por segundo de voz
    (`rtf`) y segundos de voz por letra. Si el resto se puede calcular mientras suena lo ya
    preparado, se empieza enseguida; en un equipo lento se espera lo justo. Devuelve los segundos
    de voz que deben estar listos (0 = empezar ya)."""
    if first_audio <= 0 or first_chars <= 0 or chars_left <= 0:
        return 0.0
    rtf = first_synth / first_audio
    remaining_audio = chars_left * first_audio / first_chars
    return max(0.0, remaining_audio * rtf * SAFETY - first_audio)


def _lower_priority(nice: int = SYNTH_NICE) -> None:
    """Baja la prioridad del hilo actual (en Linux, la prioridad es por hilo y la heredan sus hijos)."""
    try:
        os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), nice)
    except (AttributeError, OSError):
        pass


class _PiperProcess:
    """Cliente del proceso de voz (voz_proceso.py): lo arranca cuando hace falta y lo rearranca
    si se cerró por estar inactivo."""

    def __init__(self, model: Path) -> None:
        self.model = model
        self.proc: subprocess.Popen | None = None
        self.lock = threading.Lock()

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self) -> bool:
        if self.alive():
            return True
        import sys

        # el proceso hijo encuentra «umbra» donde está este archivo (cwd="/" evita cargar código ajeno)
        package_root = str(Path(__file__).resolve().parents[2])
        env = dict(os.environ, PYTHONPATH=os.pathsep.join(filter(None, [package_root, os.environ.get("PYTHONPATH")])))
        try:
            self.proc = subprocess.Popen([sys.executable, "-m", "umbra.nyx.voz_proceso", str(self.model)],
                                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=env,
                                         stderr=subprocess.DEVNULL, text=True, bufsize=1, cwd="/")
            ready = self.proc.stdout.readline().strip() == "listo"
        except OSError:
            ready = False
        if not ready:
            self.stop()
        return ready

    def synth(self, text: str, out: Path) -> None:
        import json

        with self.lock:
            for _ in range(2):  # si el proceso se había cerrado por inactividad, se arranca otra vez
                if not self.start():
                    break
                try:
                    self.proc.stdin.write(json.dumps({"texto": text, "wav": str(out)}) + "\n")
                    self.proc.stdin.flush()
                    answer = self.proc.stdout.readline().strip()
                except (OSError, ValueError):
                    answer = ""
                if answer == "ok":
                    return
                if answer == "error":
                    raise RuntimeError("Piper no pudo generar la voz")
                self.stop()
            raise RuntimeError("el proceso de voz no responde")

    def stop(self) -> None:
        if self.proc is not None and self.proc.poll() is None:
            self.proc.kill()
        self.proc = None


@dataclass
class Utterance:
    wav: Path
    envelope: list[float]
    duration: float
    engine: str


class Voice:
    def __init__(self) -> None:
        self._model = next((d / f"{PIPER_VOICE}.onnx" for d in VOICE_DIRS if (d / f"{PIPER_VOICE}.onnx").is_file()), None)
        self._piper = None  # el modelo vive en otro proceso (voz_proceso.py), nunca en este
        self._proc = _PiperProcess(self._model) if self._model is not None else None
        self._load_lock = threading.Lock()
        self._espeak = shutil.which("espeak-ng") is not None
        # Elegir motor es instantáneo: el modelo (3-10 s) se carga después, en el hilo de voz
        if self._model is not None and importlib.util.find_spec("piper") is not None:
            self.engine = "piper"
        elif self._espeak:
            self.engine = "espeak-ng"
        else:
            self.engine = "ninguno"
        self.player = next((p for p in ("pw-play", "paplay", "aplay") if shutil.which(p)), None)
        self.streamer = next((p for p in ("pacat", "aplay") if shutil.which(p)), None)
        self._current: subprocess.Popen | None = None
        self._gen = 0
        self._jobs: queue.Queue | None = None

    @property
    def available(self) -> bool:
        return self.engine != "ninguno"

    # --- hilo de síntesis (prioridad baja) ------------------------------------------
    def _submit(self, job) -> None:
        if self._jobs is None:
            self._jobs = queue.Queue()

            def worker() -> None:
                _lower_priority()
                while True:
                    fn = self._jobs.get()
                    try:
                        fn()
                    except Exception:
                        pass

            threading.Thread(target=worker, name="nyx-voz", daemon=True).start()
        self._jobs.put(job)

    def warm_up(self) -> None:
        """Carga el modelo en segundo plano para que la primera respuesta no espere."""
        if self.engine == "piper":
            self._submit(self._load_piper)

    def _load_piper(self) -> bool:
        with self._load_lock:
            if self.engine != "piper" or self._proc is None:
                return False
            if self._proc.start():
                return True
            self.engine = "espeak-ng" if self._espeak else "ninguno"
            return False

    # --- síntesis -------------------------------------------------------------------
    def _synth_one(self, text: str) -> Utterance:
        fd, name = tempfile.mkstemp(prefix="nyx-voz-", suffix=".wav")
        os.close(fd)
        wav = Path(name)
        try:
            if self.engine == "piper" and self._load_piper():
                self._proc.synth(text, wav)
            elif self.engine == "espeak-ng":
                # Voz española, algo más grave y pausada para sonar menos robótica
                subprocess.run(["espeak-ng", "-v", "es+f3", "-s", "150", "-p", "38", "-w", str(wav), text],
                               check=True, timeout=60, capture_output=True)
            else:
                raise RuntimeError("no hay motor de voz")
            env = envelope(wav)
        except Exception:
            wav.unlink(missing_ok=True)
            raise
        return Utterance(wav, env, len(env) / ENVELOPE_FPS, self.engine)

    def synthesize(self, text: str) -> Utterance | None:
        """Todo el texto de una vez, en el hilo que llama (para pruebas y exportar audio)."""
        text = speakable(text)
        if not text or not self.available:
            return None
        return self._synth_one(text)

    # --- hablar ---------------------------------------------------------------------
    def speak(self, text: str, on_chunk=None, on_done=None) -> bool:
        """Habla en segundo plano, frase a frase. `on_chunk(utt)` se llama cuando empieza a sonar
        cada trozo y `on_done()` al terminar (no se llama si otra frase o `stop()` la interrumpen).
        Devuelve False si no hay nada que decir."""
        spoken = speakable(text)
        if not spoken or not self.available:
            return False
        self.stop()
        gen = self._gen
        chunks = sentences(spoken)
        ready: queue.Queue = queue.Queue()
        stats: dict = {}

        def synth() -> None:
            try:
                for i, chunk in enumerate(chunks):
                    if gen != self._gen:
                        break
                    t0 = time.monotonic()
                    utt = self._synth_one(chunk)
                    if i == 0:
                        stats.update(synth=time.monotonic() - t0, audio=utt.duration, chars=len(chunk),
                                     left=sum(len(c) for c in chunks[1:]))
                    ready.put(utt)
            except Exception:
                pass
            finally:
                ready.put(None)

        def play_all() -> None:
            first = ready.get()
            if first is None:
                if gen == self._gen and on_done:
                    on_done()
                return
            # Equipo lento: preparar más voz antes de empezar, para no cortarse a mitad
            need = start_delay(stats.get("synth", 0), stats.get("audio", 0), stats.get("chars", 0),
                               stats.get("left", 0))
            queued, done = [first], False
            buffered = first.duration
            while buffered < need and not done:
                nxt = ready.get()
                if nxt is None:
                    done = True
                else:
                    queued.append(nxt)
                    buffered += nxt.duration

            def items():
                yield from queued
                if not done:
                    while (u := ready.get()) is not None:
                        yield u

            if self.streamer:
                self._stream(items(), gen, on_chunk)
            else:
                for utt in items():
                    try:
                        if gen == self._gen:
                            if on_chunk:
                                on_chunk(utt)
                            self._play_blocking(utt)
                    finally:
                        utt.wav.unlink(missing_ok=True)
            if gen == self._gen and on_done:
                on_done()

        threading.Thread(target=play_all, name="nyx-voz-play", daemon=True).start()
        self._submit(synth)
        return True

    def _stream(self, utts, gen: int, on_chunk) -> bool:
        """Toda la respuesta por una sola corriente de audio. False si no se pudo abrir."""
        proc = None
        clock = 0.0
        blocking = False
        try:
            for utt in utts:
                try:
                    with wave.open(str(utt.wav)) as w:
                        rate, channels, pcm = w.getframerate(), w.getnchannels(), w.readframes(w.getnframes())
                    if channels > 1:
                        pcm = array.array("h", pcm)[::channels].tobytes()
                    if gen != self._gen:
                        break
                    if proc is None and not blocking:
                        try:
                            proc = subprocess.Popen(stream_command(self.streamer, rate), stdin=subprocess.PIPE,
                                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        except OSError:
                            blocking = True  # sin reproductor continuo: frase a frase, como antes
                        else:
                            self._current = proc
                            clock = time.monotonic() + STREAM_BUFFER_MS / 1000
                    if blocking:
                        if on_chunk:
                            on_chunk(utt)
                        self._play_blocking(utt)
                        continue
                    # la esfera cambia de trozo cuando ese trozo empieza a sonar, no cuando se escribe
                    start = max(clock, time.monotonic())
                    if on_chunk:
                        t = threading.Timer(max(0.0, start - time.monotonic()), lambda u=utt: (
                            gen == self._gen and on_chunk(u)))
                        t.daemon = True
                        t.start()
                    clock = start + utt.duration
                    proc.stdin.write(pcm)
                    proc.stdin.flush()
                finally:
                    utt.wav.unlink(missing_ok=True)
            if proc is not None:
                proc.stdin.close()
                proc.wait()
            return True
        except Exception:  # cortado a propósito (stop), sonido cerrado o un trozo ilegible
            return True
        finally:
            if proc is not None and proc.poll() is None and gen != self._gen:
                proc.terminate()

    def _play_blocking(self, utt: Utterance) -> None:
        start = time.monotonic()
        code = None
        if self.player:
            try:
                self._current = subprocess.Popen(player_command(self.player, utt.wav),
                                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                code = self._current.wait()
            except OSError:
                code = None
        if code not in (0, -15):
            # Sin sonido (o sin reproductor): la esfera se mueve igualmente lo que dura la frase
            time.sleep(max(0.0, utt.duration - (time.monotonic() - start)))

    def play(self, utt: Utterance, on_done=None) -> None:
        """Reproduce un audio ya sintetizado en segundo plano y lo borra al terminar."""
        self.stop()
        gen = self._gen

        def run() -> None:
            try:
                self._play_blocking(utt)
            finally:
                utt.wav.unlink(missing_ok=True)
                if on_done and gen == self._gen:
                    on_done()

        threading.Thread(target=run, daemon=True).start()

    def stop(self) -> None:
        self._gen += 1
        if self._current and self._current.poll() is None:
            self._current.terminate()
