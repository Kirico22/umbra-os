"""Archivos de UMBRA: explorador de archivos con el diseño de UMBRA y la seguridad de NYX a la vista.

- Barra lateral con tus carpetas, la Cuarentena y el espacio del disco.
- Bajo cada archivo, lo que dijo NYX al analizarlo (Seguro, Precaución, Peligroso o Sin analizar).
- En Descargas, un aviso de NYX con el resumen de lo analizado.
- Abrir un archivo que NYX marcó como peligroso pide confirmación.
- Menú del botón derecho: abrir, analizar con NYX, renombrar, mover a la papelera, copiar la ruta y
  abrir la carpeta en el gestor avanzado (Thunar) para copiar, pegar o crear carpetas.

uso: umbra-archivos [carpeta]
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path
from urllib.parse import unquote, urlparse

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, GObject, Gtk  # noqa: E402

from . import theme  # noqa: E402

# Colores de las «etiquetas» de tipo de archivo (como en el diseño)
KINDS = [
    ({"pdf"}, "PDF", "#e0566b"),
    ({"doc", "docx", "odt", "rtf"}, "DOC", "#4f7cff"),
    ({"xls", "xlsx", "ods", "csv"}, "HOJA", "#2fae73"),
    ({"ppt", "pptx", "odp"}, "PRES", "#ff7a45"),
    ({"png", "jpg", "jpeg", "gif", "webp", "svg", "bmp"}, "IMG", "#b46cff"),
    ({"mp3", "ogg", "flac", "wav", "m4a", "opus"}, "AUDIO", "#ff9f43"),
    ({"mp4", "mkv", "webm", "avi", "mov"}, "VÍDEO", "#ff5fa2"),
    ({"zip", "tar", "gz", "xz", "7z", "rar", "bz2", "zst"}, "ZIP", "#c99a2e"),
    ({"deb", "appimage", "run", "sh", "exe", "msi", "bin"}, "PROG", "#7d6f9a"),
    ({"txt", "md", "log", "json", "py", "html", "css", "js"}, "TXT", "#6f6390"),
]
VERDICT_TEXT = {"seguro": ("Seguro", "ok"), "precaucion": ("Precaución", "warn"), "peligroso": ("Peligroso", "bad")}

CSS = """
window.archivos { background: #130b22; color: #f3eefc; }
.arch-side { background: #0f081c; border-right: 1px solid alpha(#ffffff, 0.06); padding: 16px 12px; }
.arch-brand { font-weight: 600; font-size: 15px; }
.arch-orb { min-width: 26px; min-height: 26px; border-radius: 99px;
  background: radial-gradient(circle at 35% 35%, #e6d6ff 0%, #a76eff 45%, #3a1d6e 100%); box-shadow: 0 0 16px alpha(#a76eff, 0.55); }
.arch-head { font-size: 11px; font-weight: 600; letter-spacing: 2px; color: #9d8fbd; margin: 12px 8px 4px; }
.arch-side list, .arch-side row { background: transparent; }
.arch-side row { border-radius: 10px; padding: 8px 10px; color: #d9cff0; margin: 1px 0; }
.arch-side row:selected { background: alpha(#a76eff, 0.24); color: #ffffff; }
.arch-side row:hover { background: alpha(#a76eff, 0.12); }
.pill-ok { font-size: 11px; padding: 1px 7px; border-radius: 99px; background: alpha(#78dca0, 0.16); color: #8fe3b4; }
.arch-disk { font-size: 12px; color: #b8aad2; }
.arch-disk progressbar trough { min-height: 6px; border-radius: 3px; background: alpha(#ffffff, 0.08); }
.arch-disk progressbar progress { min-height: 6px; border-radius: 3px; background: linear-gradient(90deg, #7c4dff, #c9a7ff); }
.arch-bar { padding: 12px 16px; border-bottom: 1px solid alpha(#ffffff, 0.06); }
.arch-nav { min-width: 34px; min-height: 34px; border-radius: 10px; border: 1px solid alpha(#ffffff, 0.10);
  background: alpha(#ffffff, 0.05); color: #e6d6ff; padding: 0; }
.arch-nav:disabled { color: #6f6390; }
.arch-crumb-dim { color: #b8aad2; } .arch-crumb { font-weight: 600; }
.arch-search { border-radius: 12px; background: alpha(#000000, 0.28); border: 1px solid alpha(#ffffff, 0.10); min-height: 34px; color: #f3eefc; }
.arch-toggle { border-radius: 11px; background: alpha(#000000, 0.28); border: 1px solid alpha(#ffffff, 0.10); padding: 3px; }
.arch-toggle button { min-width: 32px; min-height: 28px; border-radius: 8px; border: none; background: transparent; color: #b8aad2; padding: 0; }
.arch-toggle button:checked { background: alpha(#a76eff, 0.35); color: #ffffff; }
.arch-nyx { margin: 14px 16px 0 16px; padding: 11px 14px; border-radius: 14px;
  background: linear-gradient(90deg, alpha(#a76eff, 0.16), alpha(#a76eff, 0.05)); border: 1px solid alpha(#a76eff, 0.30); }
.arch-nyx-dot { min-width: 22px; min-height: 22px; border-radius: 99px;
  background: radial-gradient(circle at 35% 35%, #e6d6ff 0%, #a76eff 50%, #3a1d6e 100%); }
.arch-link { color: #c9a7ff; background: none; border: none; box-shadow: none; padding: 2px 6px; }
gridview.arch-grid { background: transparent; padding: 14px; }
gridview.arch-grid > child { border-radius: 14px; padding: 12px 6px 8px 6px; margin: 4px; border: 1px solid transparent; background: none; }
gridview.arch-grid > child:hover { background: alpha(#a76eff, 0.10); }
gridview.arch-grid > child:selected { background: alpha(#a76eff, 0.20); border-color: alpha(#c9a7ff, 0.55); color: #f3eefc; }
.arch-name { font-size: 12.5px; color: #f3eefc; }
.arch-meta { font-size: 11px; color: #9d8fbd; }
.arch-meta.ok { color: #8fe3b4; } .arch-meta.warn { color: #ffcf70; } .arch-meta.bad { color: #ff7a8a; } .arch-meta.none { color: #b8aad2; }
.arch-badge { min-width: 44px; min-height: 54px; border-radius: 8px; font-size: 10px; font-weight: 700; color: #ffffff;
  box-shadow: inset 0 1px 0 alpha(#ffffff, 0.25); }
.arch-status { padding: 9px 16px; border-top: 1px solid alpha(#ffffff, 0.06); font-size: 12px; color: #b8aad2; }
.arch-live { min-width: 8px; min-height: 8px; border-radius: 99px; background: #8fe3b4; }
window.archivos tooltip, tooltip { background: #1a1030; color: #f3eefc; border: 1px solid alpha(#c9a7ff, 0.25); border-radius: 8px; }
window.archivos popover > contents { background: #1a1030; border: 1px solid alpha(#c9a7ff, 0.22); border-radius: 12px; }
popover.arch-menu > contents { padding: 6px; min-width: 230px; }
.arch-menu-item { background: none; border: none; box-shadow: none; color: #f3eefc; padding: 4px 12px; min-height: 30px; border-radius: 8px; font-weight: normal; }
.arch-menu-item:hover { background: alpha(#a76eff, 0.24); }
.arch-menu-item.danger { color: #ff8b98; }
popover.arch-menu separator { margin: 4px 6px; background: alpha(#ffffff, 0.08); }
.arch-btn { border-radius: 10px; padding: 6px 16px; border: 1px solid alpha(#ffffff, 0.12); background: alpha(#ffffff, 0.06); color: #f3eefc; box-shadow: none; }
.arch-btn:focus-visible { outline-color: alpha(#c9a7ff, 0.7); }
.arch-btn:hover { background: alpha(#a76eff, 0.18); }
.arch-btn.suggested-action { background: linear-gradient(180deg, #8f5cff, #6a3df0); border-color: transparent; }
.arch-btn.destructive-action { background: linear-gradient(180deg, #e0566b, #b83248); border-color: transparent; }
.arch-empty { color: #9d8fbd; font-size: 14px; }
"""


def badge_class(color: str) -> str:
    return "b-" + color.lstrip("#")


def badge_css() -> str:
    colors = {c for _e, _l, c in KINDS} | {"#5a4a80"}
    return "".join(f".{badge_class(c)} {{ background: linear-gradient(160deg, {c}, shade({c}, 0.55)); padding-bottom: 7px; }}\n"
                   for c in sorted(colors))


def human_size(n: int) -> str:
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n} {unit}" if unit == "bytes" else f"{n:.1f} {unit}".replace(".", ",")
        n /= 1024
    return f"{n:.1f} TB"


def kind_of(name: str) -> tuple[str, str]:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    for exts, label, color in KINDS:
        if ext in exts:
            return label, color
    return (ext.upper()[:4] or "ARCH"), "#5a4a80"


class Entry(GObject.Object):
    """Un archivo o carpeta en la lista (envoltorio para Gio.ListStore)."""

    def __init__(self, item: dict) -> None:
        super().__init__()
        self.item = item


def list_folder(path: Path, show_hidden: bool = False) -> list[dict]:
    """Contenido de una carpeta: carpetas primero, luego archivos, por nombre."""
    items = []
    try:
        entries = list(os.scandir(path))
    except OSError:
        return []
    for e in entries:
        if not show_hidden and e.name.startswith("."):
            continue
        try:
            is_dir = e.is_dir()
            size = 0 if is_dir else e.stat().st_size
        except OSError:
            continue
        items.append({"name": e.name, "path": Path(e.path), "dir": is_dir, "size": size})
    items.sort(key=lambda i: (not i["dir"], i["name"].casefold()))
    return items


def special_dirs() -> list[tuple[str, str, Path]]:
    """(nombre, icono, ruta) de las carpetas del usuario que existen."""
    home = Path.home()
    out = [("Carpeta personal", "user-home", home)]
    for key, name, icon in ((GLib.UserDirectory.DIRECTORY_DESKTOP, "Escritorio", "user-desktop"),
                            (GLib.UserDirectory.DIRECTORY_DOCUMENTS, "Documentos", "folder-documents"),
                            (GLib.UserDirectory.DIRECTORY_DOWNLOAD, "Descargas", "folder-download"),
                            (GLib.UserDirectory.DIRECTORY_PICTURES, "Imágenes", "folder-pictures"),
                            (GLib.UserDirectory.DIRECTORY_MUSIC, "Música", "folder-music"),
                            (GLib.UserDirectory.DIRECTORY_VIDEOS, "Vídeos", "folder-videos")):
        p = GLib.get_user_special_dir(key)
        if p and Path(p).is_dir() and Path(p) != home:
            out.append((name, icon, Path(p)))
    return out


class ArchivosWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application, start: Path) -> None:
        super().__init__(application=app, title="Archivos de UMBRA")
        self.add_css_class("archivos")
        self.set_default_size(1180, 720)
        self.history: list[Path] = []
        self.future: list[Path] = []
        self.cwd: Path | None = None
        self.mode = "folder"  # o "cuarentena"
        self.analyzed: dict = {}
        self._monitor = None

        root = Gtk.Box()
        self.set_child(root)
        root.append(self._sidebar())
        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
        root.append(main)
        main.append(self._topbar())
        self.nyx_bar = self._nyx_banner()
        main.append(self.nyx_bar)
        # GridView recicla los iconos: solo se crean los que se ven, aunque la carpeta tenga miles de archivos
        self.items: list[dict] = []
        self._dir_counts: dict[Path, int | None] = {}
        self._quar: list[dict] = []
        self.store = Gio.ListStore(item_type=Entry)
        self.filter = Gtk.CustomFilter.new(lambda e: self._match(e.item))
        self.filtered = Gtk.FilterListModel(model=self.store, filter=self.filter)
        self.sel = Gtk.SingleSelection(model=self.filtered, autoselect=False, can_unselect=True)
        self.sel.connect("notify::selected", lambda *_: self._update_status())
        self.flow = Gtk.GridView(model=self.sel, factory=self._factory(False), max_columns=8, min_columns=3,
                                 single_click_activate=False)
        self.flow.add_css_class("arch-grid")
        self.flow.connect("activate", lambda _g, pos: self._open(self.filtered.get_item(pos).item))
        right = Gtk.GestureClick(button=3)
        right.connect("pressed", self._on_right_click)
        self.flow.add_controller(right)
        self.empty = Gtk.Label(label="Esta carpeta está vacía", vexpand=True)
        self.empty.add_css_class("arch-empty")
        self.stack = Gtk.Stack(vexpand=True)
        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_child(self.flow)
        self.stack.add_named(scroll, "grid")
        self.stack.add_named(self.empty, "empty")
        main.append(self.stack)
        main.append(self._statusbar())
        self._actions()
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", self._on_key)
        self.add_controller(keys)
        self.navigate(start, record=False)

    # --- barra lateral --------------------------------------------------------------------
    def _sidebar(self) -> Gtk.Widget:
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, width_request=232)
        side.add_css_class("arch-side")
        brand = Gtk.Box(spacing=10)
        brand.set_margin_start(6)
        brand.set_margin_bottom(8)
        orb = Gtk.Box()
        orb.add_css_class("arch-orb")
        brand.append(orb)
        name = Gtk.Label(label="Archivos")
        name.add_css_class("arch-brand")
        brand.append(name)
        side.append(brand)
        head = Gtk.Label(label="LUGARES", xalign=0)
        head.add_css_class("arch-head")
        side.append(head)
        self.places = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.place_paths: list[Path | str] = []
        downloads = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
        for label, icon, path in special_dirs():
            self._place_row(self.places, label, icon, "vigiladas" if downloads and path == Path(downloads)
                            and self._vigia_on() else "")
            self.place_paths.append(path)
        self._place_row(self.places, "Papelera", "user-trash", "")
        self.place_paths.append("papelera")
        self.places.connect("row-activated", self._on_place)
        side.append(self.places)
        head2 = Gtk.Label(label="SEGURIDAD", xalign=0)
        head2.add_css_class("arch-head")
        side.append(head2)
        self.secure = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.quar_count = Gtk.Label(label="")
        self.quar_count.add_css_class("arch-meta")
        row = self._place_row(self.secure, "Cuarentena", "security-high", "")
        row.get_child().append(self.quar_count)
        self.secure.connect("row-activated", lambda *_: self.show_quarantine())
        side.append(self.secure)
        spacer = Gtk.Box(vexpand=True)
        side.append(spacer)
        disk = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        disk.add_css_class("arch-disk")
        disk.set_margin_start(8)
        disk.set_margin_end(8)
        try:
            du = shutil.disk_usage(Path.home())
            line = Gtk.Box()
            line.append(Gtk.Label(label="Disco", hexpand=True, xalign=0))
            line.append(Gtk.Label(label=f"{human_size(du.free)} libres de {human_size(du.total)}"))
            disk.append(line)
            bar = Gtk.ProgressBar(fraction=du.used / du.total if du.total else 0)
            disk.append(bar)
        except OSError:
            pass
        side.append(disk)
        return side

    def _place_row(self, box: Gtk.ListBox, label: str, icon: str, pill: str) -> Gtk.ListBoxRow:
        h = Gtk.Box(spacing=10)
        img = Gtk.Image.new_from_icon_name(icon)
        img.set_pixel_size(18)
        h.append(img)
        h.append(Gtk.Label(label=label, xalign=0, hexpand=True))
        if pill:
            p = Gtk.Label(label=pill)
            p.add_css_class("pill-ok")
            h.append(p)
        row = Gtk.ListBoxRow()
        row.set_child(h)
        box.append(row)
        return row

    @staticmethod
    def _vigia_on() -> bool:
        try:
            from .vigia import load_settings

            return load_settings().vigia
        except Exception:
            return False

    # --- barra superior -------------------------------------------------------------------
    def _topbar(self) -> Gtk.Widget:
        bar = Gtk.Box(spacing=12)
        bar.add_css_class("arch-bar")
        self.back = Gtk.Button(icon_name="go-previous-symbolic", tooltip_text="Atrás")
        self.fwd = Gtk.Button(icon_name="go-next-symbolic", tooltip_text="Adelante")
        for b in (self.back, self.fwd):
            b.add_css_class("arch-nav")
        self.back.connect("clicked", lambda *_: self.go_back())
        self.fwd.connect("clicked", lambda *_: self.go_forward())
        nav = Gtk.Box(spacing=6)
        nav.append(self.back)
        nav.append(self.fwd)
        bar.append(nav)
        self.crumbs = Gtk.Box(spacing=6, hexpand=True)
        bar.append(self.crumbs)
        self.search = Gtk.SearchEntry(placeholder_text="Buscar en esta carpeta…", width_request=300)
        self.search.add_css_class("arch-search")
        self.search.connect("search-changed", lambda *_: (self.filter.changed(Gtk.FilterChange.DIFFERENT),
                                                          self._update_status()))
        bar.append(self.search)
        toggle = Gtk.Box()
        toggle.add_css_class("arch-toggle")
        self.grid_btn = Gtk.ToggleButton(icon_name="view-grid-symbolic", active=True, tooltip_text="Iconos grandes")
        self.list_btn = Gtk.ToggleButton(icon_name="view-list-symbolic", tooltip_text="Iconos pequeños",
                                         group=self.grid_btn)
        self.grid_btn.connect("toggled", lambda b: self.flow.set_factory(self._factory(not b.get_active())))
        toggle.append(self.grid_btn)
        toggle.append(self.list_btn)
        bar.append(toggle)
        return bar

    def _set_crumbs(self, path: Path | None, title: str = "") -> None:
        while (c := self.crumbs.get_first_child()) is not None:
            self.crumbs.remove(c)
        if path is None:
            lbl = Gtk.Label(label=title)
            lbl.add_css_class("arch-crumb")
            self.crumbs.append(lbl)
            return
        home = Path.home()
        parts = [home.name] + list(path.relative_to(home).parts) if path.is_relative_to(home) else list(path.parts)
        for i, part in enumerate(parts):
            if i:
                sep = Gtk.Label(label="›")
                sep.add_css_class("arch-crumb-dim")
                self.crumbs.append(sep)
            lbl = Gtk.Label(label=part or "/")
            lbl.add_css_class("arch-crumb" if i == len(parts) - 1 else "arch-crumb-dim")
            self.crumbs.append(lbl)

    # --- aviso de NYX ---------------------------------------------------------------------
    def _nyx_banner(self) -> Gtk.Widget:
        box = Gtk.Box(spacing=12)
        box.add_css_class("arch-nyx")
        dot = Gtk.Box(valign=Gtk.Align.CENTER)
        dot.add_css_class("arch-nyx-dot")
        box.append(dot)
        self.nyx_text = Gtk.Label(xalign=0, hexpand=True, wrap=True, use_markup=True)
        box.append(self.nyx_text)
        scan = Gtk.Button(label="Analizar ahora")
        scan.add_css_class("arch-link")
        scan.connect("clicked", lambda *_: self.scan_folder())
        box.append(scan)
        return box

    def _update_banner(self) -> None:
        downloads = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
        if self.mode != "folder" or not downloads or self.cwd != Path(downloads):
            self.nyx_bar.set_visible(False)
            return
        files = [i for i in self.items if not i["dir"]]
        verdicts = [self._verdict(i) for i in files]
        seguros = verdicts.count("seguro")
        dudas = verdicts.count("precaucion") + verdicts.count("peligroso")
        sin = verdicts.count(None)
        q = len(self._quar)
        text = f"<b>NYX ha analizado {len(files) - sin} de {len(files)} descargas.</b> "
        parts = [f"{seguros} seguras"]
        if dudas:
            parts.append(f"{dudas} con avisos")
        if q:
            parts.append(f"{q} en cuarentena")
        if sin:
            parts.append(f"{sin} sin analizar")
        self.nyx_text.set_markup(text + GLib.markup_escape_text(", ".join(parts) + "."))
        self.nyx_bar.set_visible(True)

    # --- barra de estado ------------------------------------------------------------------
    def _statusbar(self) -> Gtk.Widget:
        bar = Gtk.Box(spacing=16)
        bar.add_css_class("arch-status")
        self.count_lbl = Gtk.Label()
        self.sel_lbl = Gtk.Label(hexpand=True, xalign=0)
        bar.append(self.count_lbl)
        bar.append(self.sel_lbl)
        if self._vigia_on():
            live = Gtk.Box(valign=Gtk.Align.CENTER)
            live.add_css_class("arch-live")
            bar.append(live)
            bar.append(Gtk.Label(label="Vigía de descargas activo"))
        return bar

    def _update_status(self) -> None:
        self.count_lbl.set_label(f"{self.filtered.get_n_items()} elementos")
        sel = self._selected()
        if sel:
            extra = "carpeta" if sel["dir"] else human_size(sel["size"])
            self.sel_lbl.set_label(f"«{sel['name']}» seleccionado · {extra}")
        else:
            self.sel_lbl.set_label("")

    # --- contenido ------------------------------------------------------------------------
    def navigate(self, path: Path, record: bool = True) -> None:
        path = Path(path)
        if not path.is_dir():
            return
        if record and self.cwd is not None and self.mode == "folder":
            self.history.append(self.cwd)
            self.future.clear()
        self.mode = "folder"
        self.cwd = path
        self.search.set_text("")
        self._watch(path)
        self._refresh()

    def _watch(self, path: Path) -> None:
        if self._monitor is not None:
            self._monitor.cancel()
        try:
            self._monitor = Gio.File.new_for_path(str(path)).monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
            self._monitor.set_rate_limit(800)
            self._monitor.connect("changed", lambda *_: self._queue_refresh())
        except GLib.Error:
            self._monitor = None

    def _queue_refresh(self) -> None:
        """Agrupa los cambios: una descarga genera decenas de avisos y basta con un refresco."""
        if getattr(self, "_refresh_id", 0):
            return
        self._refresh_id = GLib.timeout_add(400, self._refresh_once)

    def _refresh_once(self) -> bool:
        self._refresh_id = 0
        self._refresh()
        return False

    def _refresh(self) -> None:
        self._load_analyzed()
        self._quar = self._quarantine()
        self._dir_counts.clear()
        if self.mode == "cuarentena":
            self.items = [{"name": q.get("nombre", "?"), "path": None, "dir": False, "size": q.get("tam", 0),
                           "quarantine": q} for q in self._quar]
            self._set_crumbs(None, "Cuarentena")
        else:
            self.items = list_folder(self.cwd)
            self._set_crumbs(self.cwd)
            downloads = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
            if downloads and self.cwd == Path(downloads):
                for it in self.items:  # el veredicto se calcula una vez y lo usan el aviso y los iconos
                    it["verdict"] = self._verdict(it)
        self.store.splice(0, self.store.get_n_items(), [Entry(i) for i in self.items])
        self.sel.set_selected(Gtk.INVALID_LIST_POSITION)
        self.stack.set_visible_child_name("grid" if self.items else "empty")
        self.empty.set_label("La cuarentena está vacía" if self.mode == "cuarentena" else "Esta carpeta está vacía")
        self.back.set_sensitive(bool(self.history) or self.mode == "cuarentena")
        self.fwd.set_sensitive(bool(self.future))
        self.quar_count.set_label(str(len(self._quar)))
        self._sync_sidebar()
        self._update_banner()
        self._update_status()

    def _sync_sidebar(self) -> None:
        """Marca en la barra lateral el lugar en el que estás (o ninguno)."""
        if self.mode == "cuarentena":
            self.places.unselect_all()
            self.secure.select_row(self.secure.get_row_at_index(0))
            return
        self.secure.unselect_all()
        for i, target in enumerate(self.place_paths):
            if target == self.cwd:
                self.places.select_row(self.places.get_row_at_index(i))
                return
        self.places.unselect_all()

    def _load_analyzed(self) -> None:
        """Relee lo analizado por NYX solo si el archivo ha cambiado."""
        try:
            from .vigia import analyzed_path, load_analyzed

            mtime = analyzed_path().stat().st_mtime_ns
        except Exception:
            mtime = None
        if mtime != getattr(self, "_analyzed_mtime", -1):
            self._analyzed_mtime = mtime
            try:
                self.analyzed = load_analyzed() if mtime is not None else {}
            except Exception:
                self.analyzed = {}

    def _verdict(self, item: dict) -> str | None:
        if "verdict" in item:
            return item["verdict"]
        if item.get("quarantine"):
            return "peligroso"
        if item["dir"] or item["path"] is None:
            return None
        try:
            from .vigia import verdict_for

            return verdict_for(item["path"], self.analyzed)
        except Exception:
            return None

    def _factory(self, small: bool) -> Gtk.ListItemFactory:
        size = 36 if small else 56
        f = Gtk.SignalListItemFactory()

        def setup(_f, li: Gtk.ListItem) -> None:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, width_request=96 if small else 130)
            box.icon = Gtk.Image.new_from_icon_name("folder")
            box.icon.set_pixel_size(size)
            box.badge = Gtk.Label(yalign=0.82)
            box.badge.add_css_class("arch-badge")
            box.badge.set_size_request(int(size * 0.8), size)
            box.badge.set_halign(Gtk.Align.CENTER)
            box.badge_cls = ""
            box.name = Gtk.Label(ellipsize=3, max_width_chars=16, justify=Gtk.Justification.CENTER)
            box.name.add_css_class("arch-name")
            box.meta = Gtk.Label()
            box.meta.add_css_class("arch-meta")
            for w in (box.icon, box.badge, box.name, box.meta):
                box.append(w)
            li.set_child(box)

        def bind(_f, li: Gtk.ListItem) -> None:
            box, item = li.get_child(), li.get_item().item
            box.li = li
            box.icon.set_visible(item["dir"])
            box.badge.set_visible(not item["dir"])
            if not item["dir"]:
                label, color = kind_of(item["name"])
                box.badge.set_label(label)
                if box.badge_cls:
                    box.badge.remove_css_class(box.badge_cls)
                box.badge_cls = badge_class(color)
                box.badge.add_css_class(box.badge_cls)
            box.name.set_label(item["name"])
            box.set_tooltip_text(item["name"])
            box.meta.set_css_classes(["arch-meta"])
            if item["dir"]:
                n = self._dir_count(item["path"])
                box.meta.set_label("carpeta" if n is None else f"{n} elementos")
            elif item.get("quarantine"):
                box.meta.set_label("En cuarentena")
                box.meta.add_css_class("bad")
            else:
                v = self._verdict(item)
                text, cls = VERDICT_TEXT.get(v, (human_size(item["size"]), "none"))
                box.meta.set_label(text)
                box.meta.add_css_class(cls)

        f.connect("setup", setup)
        f.connect("bind", bind)
        return f

    def _dir_count(self, path: Path) -> int | None:
        """Elementos de una subcarpeta (solo de las que se ven, y una vez por refresco)."""
        if path not in self._dir_counts:
            try:
                with os.scandir(path) as it:
                    self._dir_counts[path] = sum(1 for e in it if not e.name.startswith("."))
            except OSError:
                self._dir_counts[path] = None
        return self._dir_counts[path]

    def _match(self, item: dict) -> bool:
        q = self.search.get_text().strip().casefold()
        return not q or q in item["name"].casefold()

    def _selected(self) -> dict | None:
        entry = self.sel.get_selected_item()
        return entry.item if entry is not None else None

    # --- navegación ------------------------------------------------------------------------
    def go_back(self) -> None:
        if self.mode == "cuarentena" and self.cwd is not None:
            self.mode = "folder"
            self._refresh()
            return
        if self.history:
            self.future.append(self.cwd)
            self.navigate(self.history.pop(), record=False)

    def go_forward(self) -> None:
        if self.future:
            self.history.append(self.cwd)
            self.navigate(self.future.pop(), record=False)

    def _on_place(self, _box, row: Gtk.ListBoxRow) -> None:
        self.secure.unselect_all()
        target = self.place_paths[row.get_index()]
        if target == "papelera":
            self._launch(["thunar", "trash:///"])
            return
        self.navigate(target)

    def show_quarantine(self) -> None:
        self.places.unselect_all()
        self.mode = "cuarentena"
        self._refresh()

    @staticmethod
    def _quarantine() -> list[dict]:
        try:
            from .scanner import quarantined

            return quarantined()
        except Exception:
            return []

    def _on_key(self, _ctrl, keyval, _code, state) -> bool:
        alt = state & Gdk.ModifierType.ALT_MASK
        if keyval == Gdk.KEY_BackSpace and not self.search.has_focus() or (alt and keyval == Gdk.KEY_Left):
            self.go_back()
            return True
        if alt and keyval == Gdk.KEY_Right:
            self.go_forward()
            return True
        if keyval == Gdk.KEY_F5:
            self._refresh()
            return True
        if keyval == Gdk.KEY_Delete and self._selected():
            self._trash(self._selected())
            return True
        return False

    # --- abrir -------------------------------------------------------------------------------
    def _open(self, item: dict) -> None:
        if item.get("quarantine"):
            self._info("Este archivo está en cuarentena y no se puede abrir.\n"
                       "Si estás seguro de que es de fiar, pídeselo a NYX: «restaura " + item["name"] + "».")
            return
        if item["dir"]:
            self.navigate(item["path"])
            return
        v = self._verdict(item)
        if v in ("peligroso", "precaucion"):
            self._confirm(f"NYX marcó «{item['name']}» como {VERDICT_TEXT[v][0].lower()}.",
                          "¿Quieres abrirlo de todos modos?", "Abrir igualmente", lambda: self._open_file(item))
            return
        self._open_file(item)

    def _open_file(self, item: dict) -> None:
        try:
            Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(str(item["path"])).get_uri(), None)
        except GLib.Error as e:
            self._info(f"No hay ninguna aplicación para abrir este archivo.\n{e.message}")

    @staticmethod
    def _launch(cmd: list[str]) -> None:
        if shutil.which(cmd[0]):
            try:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            except OSError:
                pass

    # --- menú del botón derecho ------------------------------------------------------------
    def _actions(self) -> None:
        for name, fn in (("abrir", lambda: self._selected() and self._open(self._selected())),
                         ("analizar", lambda: self._selected() and self.scan_items([self._selected()])),
                         ("renombrar", lambda: self._selected() and self._rename(self._selected())),
                         ("papelera", lambda: self._selected() and self._trash(self._selected())),
                         ("ruta", self._copy_path),
                         ("avanzado", lambda: self._launch(["thunar", str(self.cwd or Path.home())]))):
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", lambda _a, _p, f=fn: f())
            self.add_action(act)

    def _on_right_click(self, gesture, _n, x, y) -> None:
        child = None
        w = self.flow.pick(x, y, Gtk.PickFlags.DEFAULT)
        while w is not None and w is not self.flow:
            if getattr(w, "li", None) is not None and w.li.get_item() is not None:
                child = w.li.get_item()
                self.sel.set_selected(w.li.get_position())
                break
            w = w.get_parent()
        on_item = child is not None and not child.item.get("quarantine")
        entries: list[tuple[str, str] | None] = []
        if on_item:
            entries += [("Abrir", "abrir")]
            if not child.item["dir"]:
                entries.append(("Analizar con NYX", "analizar"))
            entries += [("Renombrar…", "renombrar"), ("Copiar la ruta", "ruta")]
        entries.append(("Copiar, pegar o crear carpetas…", "avanzado"))
        if on_item:
            entries += [None, ("Mover a la papelera", "papelera")]
        pop = Gtk.Popover(has_arrow=False)
        pop.add_css_class("arch-menu")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        for entry in entries:
            if entry is None:
                box.append(Gtk.Separator())
                continue
            label, action = entry
            btn = Gtk.Button(label=label)
            btn.get_child().set_xalign(0)
            btn.add_css_class("arch-menu-item")
            if action == "papelera":
                btn.add_css_class("danger")
            btn.connect("clicked", lambda _b, a=action: (pop.popdown(), self.activate_action(f"win.{a}", None)))
            box.append(btn)
        pop.set_child(box)
        pop.set_parent(self)
        pos = self.flow.translate_coordinates(self, x, y)
        wx, wy = (pos[-2], pos[-1]) if pos and pos[-1] is not None else (x, y)
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(wx), int(wy), 1, 1
        pop.set_pointing_to(rect)
        pop.set_position(Gtk.PositionType.BOTTOM)
        if getattr(self, "_menu", None) is not None:
            self._menu.unparent()
        self._menu = pop
        pop.popup()

    def _copy_path(self) -> None:
        item = self._selected()
        path = item["path"] if item and item.get("path") else self.cwd
        if path is not None:
            self.get_clipboard().set(str(path))

    def _trash(self, item: dict) -> None:
        if not item.get("path"):
            return
        try:
            Gio.File.new_for_path(str(item["path"])).trash(None)
        except GLib.Error as e:
            self._info(f"No se ha podido mover a la papelera: {e.message}")
        self._refresh()

    def _rename(self, item: dict) -> None:
        dlg = Gtk.Window(transient_for=self, modal=True, title="Renombrar", default_width=420)
        dlg.add_css_class("archivos")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for m in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{m}")(18)
        entry = Gtk.Entry(text=item["name"])
        entry.add_css_class("arch-search")
        box.append(entry)
        ok = Gtk.Button(label="Renombrar", halign=Gtk.Align.END)
        ok.add_css_class("suggested-action")

        def done(*_a) -> None:
            new = entry.get_text().strip()
            if new and "/" not in new and new not in (".", "..") and new != item["name"]:
                target = item["path"].with_name(new)
                if target.exists():
                    self._info(f"Ya existe «{new}» en esta carpeta.")
                    return
                try:
                    item["path"].rename(target)
                except OSError as e:
                    self._info(f"No se ha podido renombrar: {e.strerror}")
            dlg.close()
            self._refresh()

        ok.connect("clicked", done)
        entry.connect("activate", done)
        box.append(ok)
        dlg.set_child(box)
        dlg.present()

    # --- análisis con NYX --------------------------------------------------------------------
    def scan_folder(self) -> None:
        self.scan_items([i for i in self.items if not i["dir"] and i.get("path")])

    def scan_items(self, items: list[dict]) -> None:
        if not items:
            return
        self.nyx_text.set_markup("<b>NYX está analizando…</b> Sin abrir ningún archivo.")
        self.nyx_bar.set_visible(True)

        def work() -> None:
            from . import scanner, vigia

            dangerous = []
            for it in items[:200]:
                try:
                    rep = scanner.scan(it["path"], antivirus="rapido")
                    vigia.remember(rep)
                    if rep.verdict != scanner.SEGURO:
                        dangerous.append(rep)
                except Exception:
                    continue
            GLib.idle_add(self._scan_done, dangerous)

        threading.Thread(target=work, daemon=True).start()

    def _scan_done(self, dangerous: list) -> bool:
        self._refresh()
        if dangerous and shutil.which("umbra-aviso"):
            from .vigia import save_report

            for rep in dangerous[:3]:
                self._launch(["umbra-aviso", str(save_report(rep))])
        return False

    # --- diálogos con el estilo de UMBRA ------------------------------------------------------
    def _dialog(self, title: str, body: str, buttons: list[tuple[str, str, object]]) -> None:
        dlg = Gtk.Window(transient_for=self, modal=True, title="Archivos", default_width=440, resizable=False)
        dlg.add_css_class("archivos")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for m in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{m}")(20)
        t = Gtk.Label(label=title, xalign=0, wrap=True)
        t.add_css_class("arch-crumb")
        box.append(t)
        b = Gtk.Label(label=body, xalign=0, wrap=True)
        b.add_css_class("arch-meta")
        box.append(b)
        row = Gtk.Box(spacing=8, halign=Gtk.Align.END)
        row.set_margin_top(8)
        for label, css, fn in buttons:
            btn = Gtk.Button(label=label)
            btn.add_css_class("arch-btn")
            if css:
                btn.add_css_class(css)
            btn.connect("clicked", lambda _b, f=fn: (dlg.close(), f and f()))
            row.append(btn)
        box.append(row)
        dlg.set_child(box)
        dlg.present()

    def _info(self, text: str) -> None:
        first, _, rest = text.partition("\n")
        self._dialog(first, rest, [("Entendido", "suggested-action", None)])

    def _confirm(self, title: str, body: str, ok_label: str, fn) -> None:
        self._dialog(title, body, [("Cancelar", "", None), (ok_label, "destructive-action", fn)])


def _start_path(argv: list[str]) -> Path:
    for a in argv[1:]:
        if a.startswith("file://"):
            a = unquote(urlparse(a).path)
        p = Path(a).expanduser()
        if p.is_dir():
            return p
        if p.exists():
            return p.parent
    return Path.home()


class ArchivosApp(Gtk.Application):
    def __init__(self, start: Path) -> None:
        super().__init__(application_id="os.umbra.Archivos", flags=Gio.ApplicationFlags.NON_UNIQUE)
        self.start = start

    def do_activate(self) -> None:
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data((theme.glass_css() + CSS + badge_css()).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        ArchivosWindow(self, self.start).present()


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv if argv is None else argv
    GLib.set_prgname("umbra-archivos")
    return ArchivosApp(_start_path(argv)).run(argv[:1])


if __name__ == "__main__":
    sys.exit(main())
