"""UMBRA OS: núcleo de servicios y NYX."""

__version__ = "0.9.2"
