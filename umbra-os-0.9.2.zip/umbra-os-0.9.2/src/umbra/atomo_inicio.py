"""Arranque del fondo animado: decide ANTES de cargar GTK si hace falta.

En modo ligero (máquinas virtuales, poca RAM) o con el fondo animado apagado, sale al momento
sin importar GTK ni el motor del átomo: así no gasta ~100 MB ni un segundo de CPU al iniciar sesión.
"""

from __future__ import annotations

import sys


def main() -> int:
    if "--forzar" not in sys.argv:
        from . import perf, theme
        from .config import safe_mode

        if safe_mode():
            return 0
        look = theme.load()
        if not look.fondo_vivo or perf.profile(getattr(look, "rendimiento", "auto")) == "ligero":
            return 0
    from .atomo import main as atomo_main

    return atomo_main()


if __name__ == "__main__":
    raise SystemExit(main())
