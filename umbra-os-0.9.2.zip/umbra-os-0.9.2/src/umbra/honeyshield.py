"""HoneyShield: señuelos (honeypots) de UMBRA OS vigilados por NYX.

Abre servicios falsos (SSH, FTP, Telnet, HTTP, MySQL y SMTP) en puertos altos. Nadie con
buenas intenciones debería conectarse a ellos, así que cualquier conexión es una señal: un
escaneo de la red, un dispositivo infectado o alguien probando contraseñas.

Seguridad, lo primero:
  - Está APAGADO por defecto. Encenderlo abre puertos en el cortafuegos, y eso lo decides tú.
  - Corre como tu usuario, sin root, en puertos por encima de 1024.
  - Los señuelos solo saludan, leen como mucho 4 KB y cierran. Nunca ejecutan, guardan como
    archivo ni reenvían nada de lo que reciben.
  - Límite de conexiones simultáneas y tiempo máximo por conexión: no se pueden usar para
    tumbar el equipo.
  - Las contraseñas que prueban los atacantes NO se guardan: solo el usuario y cuántas veces.
  - Nada sale del equipo (no se consulta ninguna lista externa de IPs).
  - Bloquear una IP lo pide NYX al intermediario de seguridad y tú lo confirmas.

uso: umbra-honeyshield [--una-vez-segundos N] [--direccion 127.0.0.1]
"""

from __future__ import annotations

import argparse
import asyncio
import fcntl
import ipaddress
import json
import re
import shutil
import subprocess
import sys
import time
import tomllib
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from .config import user_config_dir

# servicio -> (puerto, saludo). Puertos altos: sin root y sin chocar con servicios reales.
DECOYS: dict[str, tuple[int, bytes]] = {
    "ssh": (2222, b"SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6\r\n"),
    "ftp": (2121, b"220 (vsFTPd 3.0.5)\r\n"),
    "telnet": (2323, b"\r\nUbuntu 22.04.4 LTS\r\nservidor login: "),
    "http": (8081, b""),  # responde después de leer la petición
    "mysql": (3307, b""),  # saludo binario, ver _mysql_greeting
    "smtp": (2525, b"220 mail.servidor.local ESMTP Postfix (Ubuntu)\r\n"),
}
MAX_READ = 4096
READ_TIMEOUT = 8.0
MAX_CONNECTIONS = 64
MAX_EVENTS_BYTES = 5 * 1024 * 1024
HELPER = "/usr/libexec/umbra/honeyshield-cortafuegos"

# Señales de ataque en lo que envían (se buscan, nunca se ejecutan)
ATTACK_PATTERNS: list[tuple[str, re.Pattern[bytes]]] = [
    ("descarga de malware", re.compile(rb"(wget|curl|tftp)\s+(-\S+\s+)*(https?|ftp)://", re.I)),
    ("intento de shell", re.compile(rb"/bin/(ba)?sh|cmd\.exe|powershell|nc\s+-e|busybox", re.I)),
    ("cambio de permisos", re.compile(rb"chmod\s+(\+x|7[0-7]{2})", re.I)),
    ("recorrido de carpetas", re.compile(rb"\.\./\.\./|%2e%2e%2f", re.I)),
    ("inyección SQL", re.compile(rb"union\s+(all\s+)?select|'\s*or\s+'?1'?\s*=\s*'?1|sleep\(\d+\)", re.I)),
    ("inyección de código", re.compile(rb"<script|\$\{jndi:|<\?php|eval\(", re.I)),
    ("búsqueda de paneles", re.compile(rb"GET\s+/(wp-login|phpmyadmin|\.env|\.git/|admin|cgi-bin)", re.I)),
]


# --------------------------------------------------------------------------- ajustes

@dataclass
class Settings:
    activo: bool = False  # apagado por defecto: encenderlo abre puertos
    direccion: str = "0.0.0.0"  # 0.0.0.0 = toda la red local; 127.0.0.1 = solo este equipo
    avisar: bool = True  # notificación cuando una IP pasa a amenaza alta


def settings_path() -> Path:
    return user_config_dir() / "honeyshield.toml"


def load_settings(path: Path | None = None) -> Settings:
    path = path or settings_path()
    s = Settings()
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return s
    if isinstance(raw.get("activo"), bool):
        s.activo = raw["activo"]
    if isinstance(raw.get("avisar"), bool):
        s.avisar = raw["avisar"]
    if raw.get("direccion") in ("0.0.0.0", "127.0.0.1"):
        s.direccion = raw["direccion"]
    return s


def save_settings(s: Settings, path: Path | None = None) -> Path:
    path = path or settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# HoneyShield de UMBRA OS (se cambia desde Ajustes → Seguridad o pidiéndoselo a NYX)",
             f"activo = {'true' if s.activo else 'false'}",
             f'direccion = "{s.direccion}"',
             f"avisar = {'true' if s.avisar else 'false'}"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def data_dir() -> Path:
    return Path.home() / ".local" / "share" / "umbra" / "honeyshield"


def events_path() -> Path:
    return data_dir() / "eventos.jsonl"


# --------------------------------------------------------------------------- análisis de lo recibido

def printable(data: bytes, limit: int = 160) -> str:
    """Vista segura de los bytes recibidos: sin caracteres de control ni secuencias de terminal."""
    text = data[:limit].decode("latin-1")
    text = "".join(c if 32 <= ord(c) < 127 else "·" for c in text)
    return text + ("…" if len(data) > limit else "")


def redact(service: str, data: bytes) -> bytes:
    """Tapa las contraseñas antes de guardar la muestra: no se guardan nunca."""
    data = re.sub(rb"(?im)^(PASS)\s+\S.*$", rb"\1 ****", data)
    data = re.sub(rb"(?i)(pass(?:word|wd)?|pwd|clave)=[^&\s]*", rb"\1=****", data)
    data = re.sub(rb"(?i)(Authorization:\s*\S+)\s+\S+", rb"\1 ****", data)
    if service == "smtp":  # AUTH LOGIN: después del usuario va la contraseña en base64
        data = re.sub(rb"(?is)(AUTH LOGIN[^\n]*\n(?:[^\n]*\n)?)[^\n]+", rb"\1****", data)
    if service == "telnet":  # 1.ª línea: usuario; 2.ª: contraseña
        lines = data.split(b"\n")
        if len(lines) > 1 and lines[1].strip():
            lines[1] = b"****\r" if lines[1].endswith(b"\r") else b"****"
        data = b"\n".join(lines)
    if service == "mysql" and len(data) > 36:
        user_end = data.find(b"\x00", 36)
        if user_end != -1:
            data = data[: user_end + 1] + b"****"
    return data


def credentials(service: str, data: bytes) -> list[str]:
    """Usuarios que han intentado entrar. Las contraseñas no se devuelven ni se guardan."""
    users: list[str] = []
    if service in ("ftp", "smtp"):
        users += [m.decode("latin-1") for m in re.findall(rb"^(?:USER|AUTH LOGIN)\s+(\S{1,64})", data, re.M | re.I)]
    elif service == "telnet":
        first = data.split(b"\n", 1)[0].strip()
        if first and re.fullmatch(rb"[\w.@-]{1,64}", first):
            users.append(first.decode("latin-1"))
    elif service == "http":
        m = re.search(rb"Authorization:\s*Basic\s+([A-Za-z0-9+/=]{4,200})", data, re.I)
        if m:
            import base64

            try:
                users.append(base64.b64decode(m.group(1)).split(b":", 1)[0].decode("latin-1")[:64])
            except (ValueError, UnicodeDecodeError):
                pass
        m = re.search(rb"(?:user(?:name)?|login|email)=([^&\s]{1,64})", data, re.I)
        if m:
            users.append(m.group(1).decode("latin-1"))
    elif service == "mysql" and len(data) > 36:
        name = data[36:].split(b"\x00", 1)[0]
        if name and re.fullmatch(rb"[\w.@-]{1,64}", name):
            users.append(name.decode("latin-1"))
    return [printable(u.encode("latin-1"), 64) for u in users]


def signals(data: bytes) -> list[str]:
    return [name for name, rx in ATTACK_PATTERNS if rx.search(data)]


# --------------------------------------------------------------------------- puntuación de amenaza

LEVELS = ((70, "alta"), (30, "media"), (0, "baja"))


def level_of(score: int) -> str:
    return next(name for limit, name in LEVELS if score >= limit)


@dataclass
class Threat:
    ip: str
    first: float
    last: float
    connections: int = 0
    services: set[str] = field(default_factory=set)
    users: Counter = field(default_factory=Counter)
    signals: Counter = field(default_factory=Counter)

    @property
    def score(self) -> int:
        s = min(self.connections, 5) * 6  # conectarse ya es raro
        s += max(0, len(self.services) - 1) * 20  # varios señuelos: escaneo de puertos
        s += min(sum(self.users.values()), 4) * 10  # probar usuarios: fuerza bruta
        s += min(len(self.signals), 3) * 30  # órdenes de ataque reconocibles
        return min(s, 100)

    @property
    def level(self) -> str:
        return level_of(self.score)

    def summary(self) -> dict:
        kind = "escaneo de puertos" if len(self.services) > 1 else "conexión a un señuelo"
        if self.users:
            kind = "intento de entrar probando usuarios"
        if self.signals:
            kind = "ataque: " + ", ".join(sorted(self.signals))
        return {"ip": self.ip, "puntuacion": self.score, "nivel": self.level, "que_hace": kind,
                "conexiones": self.connections, "señuelos": sorted(self.services),
                "usuarios_probados": [u for u, _ in self.users.most_common(5)],
                "primera_vez": _clock(self.first), "ultima_vez": _clock(self.last)}


def _clock(ts: float) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


class Tracker:
    """Junta los eventos por IP y calcula la amenaza de cada una."""

    def __init__(self) -> None:
        self.threats: dict[str, Threat] = {}

    def add(self, ev: dict) -> tuple[Threat, str | None]:
        """Devuelve la amenaza y su nivel anterior si ha subido de nivel (None si no)."""
        t = self.threats.get(ev["ip"])
        if t is None:
            t = self.threats[ev["ip"]] = Threat(ev["ip"], ev["ts"], ev["ts"])
        before = t.level
        t.last = max(t.last, ev["ts"])
        t.connections += 1
        t.services.add(ev["servicio"])
        t.users.update(ev.get("usuarios", []))
        t.signals.update(ev.get("señales", []))
        rank = {"baja": 0, "media": 1, "alta": 2}
        return t, (before if rank[t.level] > rank[before] else None)

    def ranking(self, limit: int = 20) -> list[dict]:
        ts = sorted(self.threats.values(), key=lambda t: (t.score, t.last), reverse=True)
        return [t.summary() for t in ts[:limit]]


def load_events(path: Path | None = None, limit: int = 5000) -> list[dict]:
    path = path or events_path()
    out: list[dict] = []
    for old in (path.with_suffix(".jsonl.1"), path):
        try:
            for line in old.read_text(encoding="utf-8").splitlines():
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        except OSError:
            continue
    return out[-limit:]


def tracker_from_events(events: list[dict]) -> Tracker:
    tr = Tracker()
    for ev in events:
        if isinstance(ev, dict) and {"ip", "ts", "servicio"} <= ev.keys():
            tr.add(ev)
    return tr


# --------------------------------------------------------------------------- servidor de señuelos

def _mysql_greeting() -> bytes:
    body = (b"\x0a" + b"5.7.42-0ubuntu0.18.04.1\x00" + (1234).to_bytes(4, "little") + b"abcdefgh\x00"
            + b"\xff\xf7\x08\x02\x00\xff\x81\x15" + b"\x00" * 10 + b"ijklmnopqrst\x00" + b"mysql_native_password\x00")
    return len(body).to_bytes(3, "little") + b"\x00" + body


HTTP_PAGE = (b"<!doctype html><title>Panel de administraci&oacute;n</title><h1>Acceso restringido</h1>"
             b"<form method=post><input name=username><input type=password name=password><button>Entrar</button></form>")


def http_reply(data: bytes) -> bytes:
    status = b"401 Unauthorized" if re.search(rb"^POST|Authorization:", data, re.I | re.M) else b"200 OK"
    head = (b"HTTP/1.1 " + status + b"\r\nServer: Apache/2.4.41 (Ubuntu)\r\nContent-Type: text/html\r\n"
            b"Content-Length: " + str(len(HTTP_PAGE)).encode() + b"\r\nConnection: close\r\n\r\n")
    return head + HTTP_PAGE


class Honeypot:
    def __init__(self, address: str = "0.0.0.0", on_event=None, ports: dict[str, int] | None = None,
                 events_file: Path | None = None) -> None:
        self.address = address
        self.on_event = on_event or (lambda ev: None)
        self.ports = ports or {name: port for name, (port, _) in DECOYS.items()}
        self.events_file = events_file or events_path()
        self.servers: list[asyncio.base_events.Server] = []
        self.bound: dict[str, int] = {}
        self.failed: dict[str, str] = {}
        self._slots = asyncio.Semaphore(MAX_CONNECTIONS)

    async def start(self) -> None:
        for name, port in self.ports.items():
            try:
                srv = await asyncio.start_server(lambda r, w, n=name: self._handle(n, r, w), self.address, port,
                                                 reuse_address=True)
            except OSError as e:
                self.failed[name] = e.strerror or str(e)
                continue
            self.servers.append(srv)
            self.bound[name] = srv.sockets[0].getsockname()[1]

    async def stop(self) -> None:
        for srv in self.servers:
            srv.close()
            await srv.wait_closed()
        self.servers.clear()

    async def _handle(self, service: str, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = writer.get_extra_info("peername") or ("?", 0)
        if self._slots.locked():  # demasiadas a la vez: se corta sin leer
            writer.close()
            return
        async with self._slots:
            data = b""
            try:
                if service == "mysql":
                    writer.write(_mysql_greeting())
                elif DECOYS[service][1]:
                    writer.write(DECOYS[service][1])
                await writer.drain()
                deadline = time.monotonic() + READ_TIMEOUT
                while len(data) < MAX_READ:
                    left = deadline - time.monotonic()
                    if left <= 0:
                        break
                    try:
                        chunk = await asyncio.wait_for(reader.read(MAX_READ - len(data)), left)
                    except asyncio.TimeoutError:
                        break
                    if not chunk:
                        break
                    data += chunk
                    if service == "http" and b"\r\n\r\n" in data:
                        writer.write(http_reply(data))
                        await writer.drain()
                        break
                    if service == "telnet" and b"\n" in data and data.count(b"\n") == 1:
                        writer.write(b"Password: ")
                        await writer.drain()
                    if service in ("ftp", "smtp") and re.search(rb"^(USER|AUTH)", data, re.M | re.I):
                        writer.write(b"331 Please specify the password.\r\n" if service == "ftp" else
                                     b"334 UGFzc3dvcmQ6\r\n")
                        await writer.drain()
                    if service == "ssh" and data.startswith(b"SSH-"):
                        break  # el resto del protocolo ya va cifrado: con la versión basta
            except (ConnectionError, OSError):
                pass
            finally:
                try:
                    writer.close()
                except Exception:
                    pass
            self.record(service, str(peer[0]), int(peer[1]) if len(peer) > 1 else 0, data)

    def record(self, service: str, ip: str, port: int, data: bytes) -> dict:
        ev = {"ts": round(time.time(), 3), "fecha": _clock(time.time()), "servicio": service,
              "puerto": self.ports.get(service), "ip": ip, "puerto_origen": port, "bytes": len(data),
              "muestra": printable(redact(service, data)), "usuarios": credentials(service, data), "señales": signals(data)}
        _append(self.events_file, ev)
        self.on_event(ev)
        return ev


def _append(path: Path, ev: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        if path.stat().st_size > MAX_EVENTS_BYTES:
            path.replace(path.with_suffix(".jsonl.1"))
    except OSError:
        pass
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(ev, ensure_ascii=False) + "\n")
    path.chmod(0o600)


# --------------------------------------------------------------------------- cortafuegos (vía polkit)

def valid_block_ip(ip: str) -> str:
    """Comprueba que una IP se puede bloquear. Devuelve la IP normalizada o lanza ValueError."""
    try:
        addr = ipaddress.ip_address(ip.strip())
    except ValueError:
        raise ValueError(f"«{ip}» no es una dirección IP válida") from None
    if addr.is_loopback or addr.is_unspecified or addr.is_multicast or addr.is_link_local:
        raise ValueError(f"{addr} no se puede bloquear (es una dirección especial)")
    return str(addr)


def firewall(*args: str, timeout: int = 120) -> dict:
    """Llama al ayudante del cortafuegos con pkexec: el sistema te pide la contraseña."""
    if not Path(HELPER).exists() or shutil.which("pkexec") is None:
        raise RuntimeError("el ayudante del cortafuegos solo está en UMBRA OS instalado")
    r = subprocess.run(["pkexec", HELPER, *args], capture_output=True, text=True, timeout=timeout)
    if r.returncode in (126, 127):
        raise PermissionError("no se ha concedido el permiso de administrador")
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip() or "el cortafuegos no ha aceptado el cambio")
    return {"hecho": " ".join(args), "detalle": r.stdout.strip()}


# --------------------------------------------------------------------------- estado (para NYX)

def is_running() -> bool:
    lock = data_dir() / "honeyshield.lock"
    if not lock.exists():
        return False
    try:
        with lock.open("a") as fh:
            fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(fh, fcntl.LOCK_UN)
            return False
    except OSError:
        return True


def status() -> dict:
    s = load_settings()
    events = load_events()
    tr = tracker_from_events(events)
    ranking = tr.ranking(5)
    return {
        "activo": s.activo,
        "en_marcha": is_running(),
        "escucha_en": "toda la red local" if s.direccion == "0.0.0.0" else "solo este equipo",
        "señuelos": {name: port for name, (port, _) in DECOYS.items()},
        "eventos": len(events),
        "ips": len(tr.threats),
        "amenazas_altas": sum(1 for t in tr.threats.values() if t.level == "alta"),
        "principales": ranking,
    }


def recent(limit: int = 20) -> list[dict]:
    keys = ("fecha", "servicio", "ip", "bytes", "usuarios", "señales", "muestra")
    return [{k: ev.get(k) for k in keys} for ev in load_events()[-max(1, min(limit, 200)):]][::-1]


# --------------------------------------------------------------------------- demonio

def _notify(t: Threat) -> None:
    from .vigia import notify

    s = t.summary()
    notify("HoneyShield: amenaza " + s["nivel"],
           f"{s['ip']} — {s['que_hace']} ({s['conexiones']} conexiones). "
           f"Si quieres bloquearla, dile a NYX: «bloquea la IP {s['ip']}».",
           urgency="critical" if t.level == "alta" else "normal", icon="security-low")


def _single_instance():
    data_dir().mkdir(parents=True, exist_ok=True)
    fh = (data_dir() / "honeyshield.lock").open("a")
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return None
    return fh


async def serve(settings: Settings, seconds: float | None = None, audit=None, quiet: bool = False) -> Honeypot:
    tracker = tracker_from_events(load_events())

    def on_event(ev: dict) -> None:
        threat, raised = tracker.add(ev)
        if audit is not None:
            audit.record(action="honeyshield.evento", args={"ip": ev["ip"], "servicio": ev["servicio"]},
                         status=threat.level, error=None)
        if not quiet:
            print(f"[{ev['fecha']}] {ev['servicio']:<6} {ev['ip']:<15} amenaza {threat.level} ({threat.score})"
                  f"  {', '.join(ev['señales'])}", flush=True)
        if raised and threat.level in ("media", "alta") and load_settings().avisar:
            _notify(threat)

    pot = Honeypot(settings.direccion, on_event)
    await pot.start()
    if not quiet:
        print("HoneyShield vigilando: " + ", ".join(f"{n} :{p}" for n, p in pot.bound.items()), flush=True)
        for n, err in pot.failed.items():
            print(f"  {n}: no se pudo abrir ({err})", file=sys.stderr)
    cfg = settings_path()
    mtime = cfg.stat().st_mtime if cfg.exists() else 0
    start = time.monotonic()
    while seconds is None or time.monotonic() - start < seconds:
        await asyncio.sleep(min(4.0, seconds or 4.0))
        now = cfg.stat().st_mtime if cfg.exists() else 0
        if now != mtime:  # si se apaga en Ajustes, se para solo
            mtime = now
            if not load_settings().activo:
                break
    await pot.stop()
    return pot


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="umbra-honeyshield", description="Señuelos de UMBRA OS vigilados por NYX")
    parser.add_argument("--direccion", choices=["0.0.0.0", "127.0.0.1"], help="dónde escuchar")
    parser.add_argument("--segundos", type=float, help="parar al cabo de N segundos (pruebas)")
    parser.add_argument("--estado", action="store_true", help="mostrar el estado y salir")
    args = parser.parse_args(argv)
    if args.estado:
        print(json.dumps(status(), ensure_ascii=False, indent=2))
        return 0
    settings = load_settings()
    if not settings.activo and args.segundos is None:
        return 0  # apagado: no abre nada
    if args.direccion:
        settings.direccion = args.direccion
    lock = _single_instance()
    if lock is None:
        print("HoneyShield ya está en marcha.", file=sys.stderr)
        return 0
    from .config import load_config
    from .security import AuditLog

    try:
        asyncio.run(serve(settings, args.segundos, AuditLog(load_config().audit_log)))
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
