import math
import shutil
import wave
import array

import pytest

from umbra.nyx import voice


def test_speakable_reads_first_block_without_symbols():
    text = "CPU: 2 núcleos, carga 5% → bien.\nRAM: 3 GB libres.\n\nProcesos que más RAM usan:\n  200 MB claude"
    spoken = voice.speakable(text)
    assert "Procesos" not in spoken and "→" not in spoken
    assert "por ciento" in spoken and "gigas" in spoken


def test_speakable_skips_long_paths_and_limits_length():
    assert "esa ruta" in voice.speakable("Encontrado: /home/umbra/Documentos/factura.pdf")
    assert len(voice.speakable("palabra " * 200)) <= voice.MAX_SPOKEN_CHARS + 1


def test_envelope_follows_volume(tmp_path):
    rate = 16000
    path = tmp_path / "t.wav"
    samples = array.array("h")
    for i in range(rate):  # 0,5 s de silencio + 0,5 s de tono
        samples.append(0 if i < rate // 2 else int(12000 * math.sin(i / 8)))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(samples.tobytes())
    env = voice.envelope(path)
    assert len(env) in (60, 61)  # el último trozo puede ser parcial
    assert max(env[:25]) < 0.05 and min(env[35:]) > 0.9


@pytest.mark.skipif(shutil.which("espeak-ng") is None, reason="espeak-ng no instalado")
def test_espeak_fallback_synthesizes(monkeypatch, tmp_path):
    monkeypatch.setattr(voice, "VOICE_DIRS", [tmp_path])  # sin modelo de Piper
    v = voice.Voice()
    assert v.engine == "espeak-ng"
    utt = v.synthesize("Hola, soy NYX.")
    assert utt and utt.duration > 0.3 and max(utt.envelope) == 1.0
    utt.wav.unlink()
