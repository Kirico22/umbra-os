"""Iconos propios de UMBRA (estilo cristal): NYX, Buscar y Ajustes.

uso: PYTHONPATH=src python3 iso/tools/make_icons.py <carpeta hicolor>
Genera PNG de 256, 128, 64 y 48 px en <hicolor>/<N>x<N>/apps/.
"""

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

from umbra.sphere import ParticleSphere

S = 256
PURPLE = (167, 110, 255)
LIGHT = (230, 214, 255)


def glass_base() -> Image.Image:
    """Fondo de icono: círculo de cristal oscuro con brillo superior y borde claro."""
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).ellipse([18, 26, S - 18, S - 10], fill=(0, 0, 0, 110))
    img = Image.alpha_composite(img, shadow.filter(ImageFilter.GaussianBlur(10)))
    body = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    bd = ImageDraw.Draw(body)
    bd.ellipse([20, 20, S - 20, S - 20], fill=(24, 12, 44, 235), outline=(255, 255, 255, 70), width=3)
    img = Image.alpha_composite(img, body)
    # Brillo superior (reflejo del cristal)
    shine = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(shine).ellipse([52, 30, S - 52, 120], fill=(255, 255, 255, 46))
    img = Image.alpha_composite(img, shine.filter(ImageFilter.GaussianBlur(6)))
    return img


def nyx_icon() -> Image.Image:
    img = glass_base()
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([60, 60, S - 60, S - 60], fill=(*PURPLE, 120))
    img = Image.alpha_composite(img, glow.filter(ImageFilter.GaussianBlur(22)))
    d = ImageDraw.Draw(img)
    sph = ParticleSphere(n=230, seed=5)
    sph.angle_y = 0.6
    for p in sph.project(S / 2, S / 2, 62):
        k = (p.depth + 1) / 2
        col = tuple(int(PURPLE[c] + (LIGHT[c] - PURPLE[c]) * k) for c in range(3))
        r = 1.2 + 1.6 * p.size * (0.6 + 0.4 * k)
        d.ellipse([p.x - r, p.y - r, p.x + r, p.y + r], fill=(*col, int(255 * p.alpha)))
    return img


def search_icon() -> Image.Image:
    img = glass_base()
    d = ImageDraw.Draw(img)
    d.ellipse([78, 70, 162, 154], outline=(*LIGHT, 255), width=14)
    d.line([150, 144, 186, 182], fill=(*LIGHT, 255), width=18)
    d.ellipse([178, 174, 194, 190], fill=(*LIGHT, 255))
    return img


def settings_icon() -> Image.Image:
    img = glass_base()
    d = ImageDraw.Draw(img)
    for y, knob in ((88, 150), (128, 100), (168, 135)):
        d.line([72, y, 184, y], fill=(255, 255, 255, 150), width=8)
        d.ellipse([knob - 15, y - 15, knob + 15, y + 15], fill=(*PURPLE, 255), outline=(*LIGHT, 255), width=4)
    return img


def main() -> None:
    out = Path(sys.argv[1])
    icons = {"umbra-nyx": nyx_icon(), "umbra-buscar": search_icon(), "umbra-ajustes": settings_icon()}
    for name, img in icons.items():
        for size in (256, 128, 64, 48):
            d = out / f"{size}x{size}" / "apps"
            d.mkdir(parents=True, exist_ok=True)
            img.resize((size, size), Image.LANCZOS).save(d / f"{name}.png", optimize=True)
    preview = Image.new("RGBA", (S * 3 + 40, S), (12, 8, 20, 255))
    for i, img in enumerate(icons.values()):
        preview.alpha_composite(img, (i * (S + 20), 0))
    preview.save(out / "preview.png")
    print("iconos:", ", ".join(icons))


if __name__ == "__main__":
    main()
