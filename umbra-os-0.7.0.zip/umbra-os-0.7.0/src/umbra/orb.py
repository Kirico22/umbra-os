"""Orbe de NYX para el escritorio de UMBRA OS.

- Una esfera de partículas pequeña flotando sobre el escritorio (siempre encima).
- Mantener pulsado y arrastrar: la mueves a donde quieras (recuerda la posición).
- Un clic: se abre una burbuja de cristal para escribirle a NYX; responde con texto y voz.
- Clic derecho: abrir la ventana completa de NYX, ajustes u ocultar el orbe.
"""

from __future__ import annotations

import math
import subprocess
import sys
import threading
import time
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import theme  # noqa: E402
from .cli import build_nyx, make_provider  # noqa: E402
from .config import load_config, user_config_dir  # noqa: E402
from .gui_bridge import ConfirmBridge  # noqa: E402
from .nyx import easter  # noqa: E402
from .security import Risk  # noqa: E402
from .sphere import ParticleSphere  # noqa: E402
from .widgets import SpeakingSphere, draw_sphere, float_window, load_json, window_geometry  # noqa: E402

ORB_TITLE = "NYX-orbe"
BUBBLE_TITLE = "NYX-burbuja"
DRAG_THRESHOLD = 6
BUBBLE_W = 360

EXTRA_CSS = """
.bubble-reply { font-size: 13px; color: #f3eefc; }
.bubble-state { font-size: 10px; letter-spacing: 2px; color: @accent_light; }
.orb-menu button { border-radius: 10px; }
button.mic { min-width: 38px; min-height: 38px; padding: 0; }
button.mic.listening { background-color: alpha(#ff4d5e, 0.55); border-color: alpha(#ffb3ba, 0.8); }
"""


def _pos_file() -> Path:
    return user_config_dir() / "orbe.json"


class Bubble(Gtk.Window):
    """Burbuja de cristal para hablar con NYX desde el escritorio."""

    def __init__(self, app: Gtk.Application, on_send, on_mic=None) -> None:
        super().__init__(application=app, title=BUBBLE_TITLE, decorated=False, resizable=False)
        self.add_css_class("glass")
        self.set_default_size(BUBBLE_W, -1)
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        panel.add_css_class("glass-panel")
        for side in ("top", "bottom", "start", "end"):
            getattr(panel, f"set_margin_{side}")(14)
        panel.set_size_request(BUBBLE_W - 28, -1)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for side in ("top", "bottom", "start", "end"):
            getattr(inner, f"set_margin_{side}")(14)
        self.state = Gtk.Label(label="NYX", xalign=0)
        self.state.add_css_class("bubble-state")
        self.reply = Gtk.Label(label=easter.greeting(), xalign=0, wrap=True, selectable=True)
        self.reply.set_max_width_chars(40)
        self.reply.add_css_class("bubble-reply")
        self.actions = Gtk.Box(spacing=8, halign=Gtk.Align.END)
        self.entry = Gtk.Entry(placeholder_text="Escríbele a NYX…", hexpand=True)
        self.entry.add_css_class("glass-entry")
        self.entry.connect("activate", lambda e: on_send(e.get_text()))
        inner.append(self.state)
        inner.append(self.reply)
        inner.append(self.actions)
        row = Gtk.Box(spacing=8)
        row.append(self.entry)
        self.mic = Gtk.Button(icon_name="audio-input-microphone-symbolic", tooltip_text="Háblale a NYX")
        self.mic.add_css_class("glass-pill")
        self.mic.add_css_class("mic")
        if on_mic:
            self.mic.connect("clicked", lambda _b: on_mic())
        row.append(self.mic)
        inner.append(row)
        panel.append(inner)
        self.set_child(panel)
        key = Gtk.EventControllerKey()
        key.connect("key-pressed", lambda _c, keyval, *_: keyval == Gdk.KEY_Escape and (self.set_visible(False) or True))
        self.add_controller(key)

    def clear_actions(self) -> None:
        child = self.actions.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.actions.remove(child)
            child = nxt


class Orb(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title=ORB_TITLE, decorated=False, resizable=False)
        self.add_css_class("glass")
        self.look = theme.load()
        self.size = theme.ORB_SIZES[self.look.orbe_tamano]
        self.set_default_size(self.size, self.size)

        self.sphere = ParticleSphere(n=260)
        self.speaker = SpeakingSphere(self.sphere, on_state=self._on_state)
        self.speaker.enabled = self.look.voz and self.speaker.voice.available
        self.busy = False
        self.burst = easter.ClickBurst(count=5, window=2.0)  # 5 clics rápidos: supernova
        seasonal = easter.seasonal_effect()
        if seasonal:
            self.sphere.trigger(seasonal)
        self._moving = False
        self._last = None

        self.canvas = Gtk.DrawingArea(content_width=self.size, content_height=self.size)
        self.canvas.set_draw_func(self._draw)
        self.canvas.add_tick_callback(self._tick)
        self.set_child(self.canvas)

        drag = Gtk.GestureDrag(button=1)
        drag.connect("drag-begin", self._drag_begin)
        drag.connect("drag-update", self._drag_update)
        drag.connect("drag-end", self._drag_end)
        self.canvas.add_controller(drag)
        right = Gtk.GestureClick(button=3)
        right.connect("pressed", self._menu)
        self.canvas.add_controller(right)

        cfg = load_config()
        provider, _label = make_provider(cfg)
        self.nyx = build_nyx(cfg, provider)
        self.nyx.broker.confirm = ConfirmBridge(self._ask_confirmation)
        self.bubble = Bubble(app, self.send, self.listen)
        self.listener = None
        self.wake = None
        self.listening = False
        if self.look.escucha:
            threading.Thread(target=self._start_wake, daemon=True).start()
        self.connect("map", lambda *_: GLib.timeout_add(250, self._place))

    # --- dibujo -------------------------------------------------------------------
    def _tick(self, _w, clock) -> bool:
        now = clock.get_frame_time() / 1e6
        dt = 1 / 60 if self._last is None else now - self._last
        self._last = now
        self.speaker.tick()
        self.sphere.update(dt)
        self.canvas.queue_draw()
        return True

    def _draw(self, _area, cr, width, height) -> None:
        draw_sphere(cr, self.sphere, width / 2, height / 2, width * 0.27, self.look.rgb(0))

    def _on_state(self, state: str) -> None:
        self.bubble.state.set_label({"reposo": "NYX", "pensando": "NYX · PENSANDO…", "hablando": "NYX · HABLANDO"}[state])

    # --- posición -----------------------------------------------------------------
    def _place(self) -> bool:
        saved = load_json(_pos_file(), None)
        display = Gdk.Display.get_default()
        monitors = display.get_monitors()
        geo = monitors.get_item(0).get_geometry() if monitors.get_n_items() else None
        if saved and isinstance(saved, dict) and "x" in saved and "y" in saved:
            x, y = int(saved["x"]), int(saved["y"])
        elif geo:
            x, y = geo.x + geo.width - self.size - 40, geo.y + geo.height - self.size - 90
        else:
            x = y = None
        float_window(ORB_TITLE, x, y)
        return False

    def _remember_position(self) -> bool:
        geo = window_geometry(ORB_TITLE)
        if geo:
            path = _pos_file()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(f'{{"x": {geo[0]}, "y": {geo[1]}}}\n', encoding="utf-8")
        return False

    # --- arrastrar o hacer clic ---------------------------------------------------------
    def _drag_begin(self, _g, x, y) -> None:
        self._moving = False
        self._press = (x, y)

    def _drag_update(self, gesture, dx, dy) -> None:
        if self._moving or math.hypot(dx, dy) < DRAG_THRESHOLD:
            return
        self._moving = True
        surface = self.get_surface()
        if isinstance(surface, Gdk.Toplevel):
            # El gestor de ventanas se encarga de mover el orbe mientras se mantiene el clic
            surface.begin_move(gesture.get_device(), 1, self._press[0], self._press[1],
                               gesture.get_current_event_time())
        self.bubble.set_visible(False)
        GLib.timeout_add(1500, self._remember_position)

    def _drag_end(self, _g, dx, dy) -> None:
        if not self._moving and math.hypot(dx, dy) < DRAG_THRESHOLD:
            if self.burst.click(time.monotonic()):
                self.bubble.set_visible(False)
                self.sphere.trigger("supernova")
            else:
                self.toggle_bubble()
        self._moving = False

    def toggle_bubble(self) -> None:
        if self.bubble.get_visible():
            self.bubble.set_visible(False)
            return
        self.bubble.present()
        GLib.timeout_add(120, self._place_bubble)
        self.bubble.entry.grab_focus()

    def _place_bubble(self) -> bool:
        orb = window_geometry(ORB_TITLE)
        if not orb:
            float_window(BUBBLE_TITLE)
            return False
        ox, oy, ow, oh = orb
        display = Gdk.Display.get_default()
        geo = display.get_monitors().get_item(0).get_geometry()
        bw = BUBBLE_W
        bh = max(self.bubble.get_height(), 180)
        x = min(max(geo.x + 8, ox + ow // 2 - bw // 2), geo.x + geo.width - bw - 8)
        y = oy - bh - 6 if oy - bh - 6 > geo.y else oy + oh + 6  # encima si cabe; si no, debajo
        float_window(BUBBLE_TITLE, x, y)
        return False

    # --- menú del clic derecho ----------------------------------------------------------
    def _menu(self, gesture, _n, x, y) -> None:
        pop = Gtk.Popover()
        pop.set_parent(self.canvas)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.add_css_class("orb-menu")
        for label, cmd in (("Abrir NYX", ["nyx-gui"]), ("Ajustes de UMBRA", ["umbra-ajustes"]),
                           ("Buscar…", ["umbra-buscar"])):
            b = Gtk.Button(label=label)
            b.connect("clicked", lambda _b, c=cmd: (pop.popdown(), subprocess.Popen(c, start_new_session=True)))
            box.append(b)
        hide = Gtk.Button(label="Ocultar el orbe")
        hide.connect("clicked", lambda _b: self.get_application().quit())
        box.append(hide)
        pop.set_child(box)
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(x), int(y), 1, 1
        pop.set_pointing_to(rect)
        pop.popup()

    # --- oído de NYX ---------------------------------------------------------------------
    def _get_listener(self):
        from .nyx import listen

        if self.listener is None:
            ok, why = listen.available()
            if not ok:
                raise RuntimeError(why)
            self.listener = listen.Listener()
        return self.listener

    def _start_wake(self) -> None:
        from .nyx import listen

        try:
            self.wake = listen.WakeWord(self._get_listener(), lambda: GLib.idle_add(self._woken))
            self.wake.start()
        except Exception:  # noqa: BLE001 - sin micrófono o sin modelo, el orbe sigue funcionando
            self.wake = None

    def _woken(self) -> bool:
        if not self.bubble.get_visible():
            self.toggle_bubble()
        self.listen()
        return False

    def listen(self) -> None:
        """Botón del micrófono o «Oye NYX»: escucha una orden y se la manda a NYX."""
        if self.busy or self.listening:
            if self.listener:
                self.listener.stop()
            return
        self.listening = True
        self.bubble.mic.add_css_class("listening")
        self.bubble.state.set_label("TE ESCUCHO…")
        self.speaker.voice.stop()
        if self.wake:
            self.wake.paused.set()

        def partial(text: str) -> None:
            GLib.idle_add(self.bubble.entry.set_text, text)
            self.sphere.set_energy(0.6)

        def work() -> None:
            try:
                text, err = self._get_listener().listen_once(on_partial=partial), None
            except Exception as exc:  # noqa: BLE001
                text, err = "", str(exc)
            GLib.idle_add(self._heard, text, err)

        threading.Thread(target=work, daemon=True).start()

    def _heard(self, text: str, err: str | None) -> bool:
        self.listening = False
        self.bubble.mic.remove_css_class("listening")
        self.bubble.state.set_label("NYX")
        self.sphere.set_energy(0.0)
        if self.wake:
            GLib.timeout_add(1500, lambda: self.wake.paused.clear() or False)
        if err:
            self.bubble.reply.set_label(f"No puedo escucharte: {err}.")
        elif text:
            self.send(text)
        else:
            self.bubble.reply.set_label("No te he oído. Vuelve a intentarlo.")
        return False

    # --- conversación -------------------------------------------------------------------
    def send(self, text: str) -> None:
        text = (text or "").strip()
        if not text or self.busy:
            return
        self.busy = True
        self.bubble.entry.set_text("")
        self.bubble.reply.set_label("…")
        self.speaker.thinking()

        def work() -> None:
            started = time.monotonic()
            try:
                reply = self.nyx.handle(text)
            except Exception as exc:
                reply = f"Ha ocurrido un error: {exc}"
            time.sleep(max(0.0, 0.6 - (time.monotonic() - started)))
            GLib.idle_add(self._done, reply)

        threading.Thread(target=work, daemon=True).start()

    def _done(self, reply: str) -> bool:
        self.bubble.reply.set_label(reply)
        if self.nyx.last_effect:
            self.sphere.trigger(self.nyx.last_effect)
        if self.wake:
            self.wake.paused.set()
            GLib.timeout_add(max(1500, len(reply) * 70), lambda: self.wake.paused.clear() or False)
        self.speaker.say(reply)
        self.busy = False
        GLib.timeout_add(80, self._place_bubble)
        return False

    def _ask_confirmation(self, action, args, reply) -> None:
        GLib.idle_add(self._show_confirmation, action, args, reply)

    def _show_confirmation(self, action, args, reply) -> bool:
        high = action.risk >= Risk.HIGH
        detail = ", ".join(f"{k}: {v}" for k, v in args.items())
        self.bubble.reply.set_label(("⚠ Acción de administrador\n" if high else "¿Me das permiso?\n")
                                    + f"{action.description}\n{detail}")
        self.bubble.clear_actions()
        word = None
        if high:
            word = Gtk.Entry(placeholder_text="CONFIRMAR", width_chars=11)
            word.add_css_class("glass-entry")
            self.bubble.actions.append(word)
        no = Gtk.Button(label="Cancelar")
        no.add_css_class("glass-pill")
        yes = Gtk.Button(label="Permitir")
        yes.add_css_class("glass-accent")
        self.bubble.actions.append(no)
        self.bubble.actions.append(yes)

        def answer(ok: bool) -> None:
            if ok and word is not None and word.get_text().strip() != "CONFIRMAR":
                return
            self.bubble.clear_actions()
            reply(ok)

        yes.connect("clicked", lambda _b: answer(True))
        no.connect("clicked", lambda _b: answer(False))
        self.bubble.present()
        return False


class OrbApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.NyxOrbe")

    def do_activate(self) -> None:
        if self.props.active_window:
            self.props.active_window.present()
            return
        look = theme.load()
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data((theme.glass_css(look) + EXTRA_CSS).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        Orb(self).present()


def main() -> int:
    GLib.set_prgname("umbra-orbe")  # clase de ventana «Umbra-orbe»: picom le pone el cristal
    from .config import safe_mode

    if safe_mode():
        return 0  # modo seguro: sin extras
    if not theme.load().orbe and "--forzar" not in sys.argv:
        return 0  # el usuario lo desactivó en Ajustes de UMBRA
    return OrbApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
