"""Apariencia de UMBRA: colores de acento, efecto cristal (Liquid Glass) y preferencias.

Todo lo que el usuario personaliza vive en ~/.config/umbra/apariencia.toml.
Este módulo no depende de GTK: genera el CSS que usan las ventanas de UMBRA.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import asdict, dataclass
from pathlib import Path

# Colores de acento: (principal, claro, oscuro)
ACCENTS: dict[str, tuple[str, str, str]] = {
    "morado": ("#a76eff", "#ddc8ff", "#6a35d6"),
    "azul": ("#5aa9ff", "#c9e2ff", "#2d6fd1"),
    "rosa": ("#ff6eb4", "#ffcce4", "#c93a83"),
    "verde": ("#3fd99a", "#c3f5df", "#1f9c69"),
    "ambar": ("#ffb347", "#ffe2b8", "#cc7d14"),
    "nebulosa": ("#56e6ff", "#d2f8ff", "#7a3cff"),  # 🥚 secreto: se desbloquea con el código Konami
}
SECRET_ACCENTS = {"nebulosa"}

# Opacidad del relleno de cristal y fuerza del desenfoque de fondo (picom)
GLASS_LEVELS: dict[str, tuple[float, int]] = {
    "alto": (0.10, 7),
    "medio": (0.22, 4),
    "apagado": (0.88, 0),
}

ORB_SIZES = {"pequeño": 96, "mediano": 128, "grande": 168}


def config_path() -> Path:
    base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "umbra" / "apariencia.toml"


@dataclass
class Appearance:
    acento: str = "morado"
    cristal: str = "alto"
    orbe: bool = True
    orbe_tamano: str = "pequeño"
    voz: bool = True
    iconos: int = 56
    fondo_vivo: bool = True  # átomo animado en el escritorio
    fondo: str = ""  # color del fondo elegido ("" = el mismo que el acento)
    puntero: str = "UMBRA"
    puntero_tamano: int = 32
    secreto: bool = False
    escucha: bool = False  # «Oye NYX»: micrófono escuchando de fondo (apagado por defecto)

    def normalized(self) -> "Appearance":
        a = Appearance(**asdict(self))
        if a.acento not in ACCENTS or (a.acento in SECRET_ACCENTS and not a.secreto):
            a.acento = "morado"
        a.puntero_tamano = max(16, min(int(a.puntero_tamano), 96))
        if a.fondo and (a.fondo not in ACCENTS or (a.fondo in SECRET_ACCENTS and not a.secreto)):
            a.fondo = ""
        if a.cristal not in GLASS_LEVELS:
            a.cristal = "alto"
        if a.orbe_tamano not in ORB_SIZES:
            a.orbe_tamano = "pequeño"
        a.iconos = max(32, min(int(a.iconos), 128))
        return a

    @property
    def colors(self) -> tuple[str, str, str]:
        return ACCENTS[self.acento]

    def rgb(self, which: int = 0) -> tuple[float, float, float]:
        h = self.colors[which].lstrip("#")
        return tuple(int(h[i : i + 2], 16) / 255 for i in (0, 2, 4))


def load() -> Appearance:
    path = config_path()
    data = {}
    if path.is_file():
        try:
            data = tomllib.loads(path.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, OSError):
            data = {}
    known = {k: v for k, v in data.items() if k in Appearance.__dataclass_fields__}
    try:
        return Appearance(**known).normalized()
    except (TypeError, ValueError):
        return Appearance()


def save(app: Appearance) -> Path:
    app = app.normalized()
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# Apariencia de UMBRA OS (se edita desde «Ajustes de UMBRA»)"]
    for key, value in asdict(app).items():
        if isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}")
        elif isinstance(value, int):
            lines.append(f"{key} = {value}")
        else:
            lines.append(f'{key} = "{value}"')
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def glass_css(app: Appearance | None = None) -> str:
    """CSS "Liquid Glass" para GTK 4: relleno translúcido, brillo en el borde superior,
    sombra profunda y un tinte del color de acento. El desenfoque lo pone picom detrás."""
    app = (app or load()).normalized()
    main, light, dark = app.colors
    fill, _blur = GLASS_LEVELS[app.cristal]
    tint = min(0.95, fill + 0.06)
    return f"""
@define-color accent {main};
@define-color accent_light {light};
@define-color accent_dark {dark};

window.glass, window.glass.background {{ background: transparent; box-shadow: none; }}
.glass-panel {{
  background-image: linear-gradient(160deg,
      alpha(#ffffff, {fill + 0.10:.2f}) 0%,
      alpha(#ffffff, {fill:.2f}) 38%,
      alpha(@accent_dark, {tint:.2f}) 100%);
  background-color: alpha(#0b0812, {min(0.95, 0.63 + fill):.2f});
  border: 1px solid alpha(#ffffff, 0.20);
  border-radius: 24px;
  box-shadow: inset 0 1px 0 alpha(#ffffff, 0.38),
              inset 0 -1px 0 alpha(#000000, 0.30),
              0 18px 48px alpha(#000000, 0.45);
  color: #f3eefc;
}}
.glass-pill {{
  background-image: linear-gradient(180deg, alpha(#ffffff, 0.16), alpha(#ffffff, 0.05));
  border: 1px solid alpha(#ffffff, 0.18);
  border-radius: 99px;
  box-shadow: inset 0 1px 0 alpha(#ffffff, 0.30);
  color: #f3eefc;
  transition: all 180ms ease-out;
}}
.glass-pill:hover {{ border-color: alpha(@accent_light, 0.7); background-color: alpha(@accent, 0.18); }}
entry.glass-entry {{
  background: alpha(#000000, 0.28); border: 1px solid alpha(#ffffff, 0.16);
  border-radius: 16px; padding: 10px 14px; color: #ffffff; caret-color: @accent_light;
  transition: border-color 200ms ease-out, box-shadow 200ms ease-out;
}}
entry.glass-entry:focus-within {{ border-color: alpha(@accent_light, 0.8); box-shadow: 0 0 0 3px alpha(@accent, 0.30); }}
.glass-row {{ border-radius: 14px; padding: 8px 10px; transition: background 150ms ease-out; }}
.glass-row:hover, row:selected .glass-row {{ background: alpha(@accent, 0.26); }}
.glass-dim {{ color: alpha(#f3eefc, 0.62); font-size: 11px; }}
.glass-title {{ font-weight: 300; letter-spacing: 6px; color: #ffffff; }}
button.glass-accent {{
  background-image: linear-gradient(135deg, @accent_dark, @accent);
  color: #ffffff; border: none; border-radius: 14px;
  box-shadow: inset 0 1px 0 alpha(#ffffff, 0.35);
}}
"""


def prefer_dark() -> None:
    """Pide a GTK su variante oscura (desplegables, interruptores, barras) en las apps de UMBRA."""
    try:
        from gi.repository import Gtk

        settings = Gtk.Settings.get_default()
        if settings is not None:
            settings.set_property("gtk-application-prefer-dark-theme", True)
    except Exception:
        pass


def picom_blur_strength(app: Appearance | None = None) -> int:
    return GLASS_LEVELS[(app or load()).normalized().cristal][1]
