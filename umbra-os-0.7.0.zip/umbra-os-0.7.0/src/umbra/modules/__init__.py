"""NYX Modules: capacidades del sistema expuestas como acciones con permisos."""

from __future__ import annotations

from pathlib import Path

from ..nyx.memory import Memory
from ..security import Module
from . import apps, files, memory_module, network, packages, processes, routines_module, security, services, system


def builtin_modules(allowed_roots: list[Path], memory: Memory, undo_dir: Path | None = None) -> list[Module]:
    return [
        system.build(),
        files.build(allowed_roots, undo_dir),
        processes.build(),
        services.build(),
        network.build(),
        apps.build(),
        packages.build(),
        memory_module.build(memory),
        security.build(allowed_roots),
        routines_module.build(),
    ]
