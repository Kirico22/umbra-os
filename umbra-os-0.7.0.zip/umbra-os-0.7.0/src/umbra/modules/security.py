"""Módulo security: NYX analiza archivos, gestiona la cuarentena y revisa la protección del sistema.

- Analizar es solo lectura: nunca abre ni ejecuta el archivo.
- Poner en cuarentena mueve el archivo y le quita todos los permisos (riesgo MEDIO, pide confirmación).
- Restaurar devuelve a su sitio algo que se consideró peligroso: riesgo ALTO (hay que escribir CONFIRMAR),
  y vuelve sin permiso de ejecución.
- Borrar de la cuarentena es definitivo: riesgo ALTO.
"""

from __future__ import annotations

from pathlib import Path

from .. import scanner
from ..security import Action, Module, Param, Permission, Risk
from .files import safe_path


def build(allowed_roots: list[Path], qdir: Path | None = None) -> Module:
    def resolve(path: str) -> Path:
        raw = path.strip().strip("\"'")
        if raw and "/" not in raw and not raw.startswith("~"):
            # Un nombre suelto se busca en Descargas
            raw = str(scanner.downloads_dir() / raw)
        p = safe_path(raw or str(scanner.downloads_dir()), allowed_roots)
        if not p.exists():
            raise FileNotFoundError(f"no encuentro {p}")
        return p

    def scan(path: str) -> dict:
        p = resolve(path)
        if p.is_dir():
            return scan_folder(str(p))
        return scanner.scan(p).to_dict()

    def scan_folder(path: str = "", limit: int = 30) -> dict:
        folder = resolve(path) if path else safe_path(str(scanner.downloads_dir()), allowed_roots)
        files = sorted((f for f in folder.iterdir() if f.is_file() and not f.is_symlink()),
                       key=lambda f: f.stat().st_mtime, reverse=True)[: max(1, min(limit, 200))]
        reports = [scanner.scan(f) for f in files]
        return {
            "carpeta": str(folder),
            "analizados": len(reports),
            "peligrosos": [r.to_dict() for r in reports if r.verdict == scanner.PELIGROSO],
            "precaucion": [r.to_dict() for r in reports if r.verdict == scanner.PRECAUCION],
            "seguros": [r.name for r in reports if r.verdict == scanner.SEGURO],
        }

    def check_exists(path: str) -> None:
        p = resolve(path)
        if not p.is_file():
            raise ValueError(f"no es un archivo: {p}")

    def quarantine(path: str) -> dict:
        p = resolve(path)
        return scanner.quarantine(p, qdir=qdir)

    def check_quarantined(id: str) -> None:  # noqa: A002 - nombre del parámetro público
        scanner._find(id, qdir or scanner.quarantine_dir())

    return Module(
        id="security",
        name="Seguridad",
        description="Analizar descargas, cuarentena y estado de la protección.",
        requested=frozenset({Permission.FILES_READ, Permission.FILES_WRITE, Permission.SYSTEM_READ}),
        actions=[
            Action("security.scan", "Analiza un archivo (sin abrirlo) y dice si es seguro, "
                   "merece precaución o es peligroso.", scan,
                   frozenset({Permission.FILES_READ}), Risk.LOW, (Param("path", str),)),
            Action("security.scan_folder", "Analiza los archivos más recientes de una carpeta "
                   "(por defecto, Descargas).", scan_folder, frozenset({Permission.FILES_READ}), Risk.LOW,
                   (Param("path", str, required=False), Param("limit", int, required=False))),
            Action("security.quarantine", "Pone un archivo en cuarentena: lo aparta y le quita todos "
                   "los permisos.", quarantine, frozenset({Permission.FILES_WRITE}), Risk.MEDIUM,
                   (Param("path", str),), precheck=check_exists),
            Action("security.quarantine_list", "Lista lo que hay en cuarentena.",
                   lambda: scanner.quarantined(qdir), frozenset({Permission.FILES_READ}), Risk.LOW),
            Action("security.restore", "Saca un archivo de la cuarentena y lo devuelve a su sitio "
                   "(sin permiso de ejecución).", lambda id: scanner.restore(id, qdir),
                   frozenset({Permission.FILES_WRITE}), Risk.HIGH, (Param("id", str),),
                   precheck=check_quarantined),
            Action("security.delete", "Borra definitivamente un archivo de la cuarentena.",
                   lambda id: scanner.delete_quarantined(id, qdir),
                   frozenset({Permission.FILES_WRITE}), Risk.HIGH, (Param("id", str),),
                   precheck=check_quarantined),
            Action("security.status", "Estado de la protección: cortafuegos, antivirus, AppArmor, "
                   "actualizaciones y vigía de descargas.", scanner.security_status,
                   frozenset({Permission.SYSTEM_READ}), Risk.LOW),
        ],
    )
