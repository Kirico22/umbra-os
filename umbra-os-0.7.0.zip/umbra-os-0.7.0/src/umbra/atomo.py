"""Átomo vivo del escritorio de UMBRA OS (umbra-atomo).

Una ventana sin bordes, siempre por debajo de las demás, colocada exactamente encima del
átomo del fondo de escritorio. Dibuja el mismo fondo (sin el átomo) y, encima, el átomo animado:
el núcleo gira y los electrones recorren sus órbitas.

🥚 Clic derecho sobre el núcleo: fusión nuclear. Los nucleones colapsan, destello, onda
expansiva, el átomo se dispersa en mini átomos y después se recompone.

Si no se puede colocar la ventana (sin gestor de ventanas compatible), se cierra y queda
el fondo fijo, que ya tiene el átomo dibujado.
"""

from __future__ import annotations

import sys
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk  # noqa: E402

from . import theme  # noqa: E402
from .atom import AtomScene  # noqa: E402
from .atom_render import AtomRenderer  # noqa: E402
from .widgets import float_window, wmctrl  # noqa: E402

TITLE = "UMBRA-atomo"
BASE_DIR = Path("/usr/share/umbra/fondos-base")
IMG_W, IMG_H = 1920, 1080
ATOM_X, ATOM_Y = 0.62, 0.45  # centro del átomo en el fondo (fracción de la imagen)
HALF_W, HALF_H = 540, 450  # tamaño de la ventana alrededor del átomo (en píxeles de 1080p)
FPS = 30


class AtomWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application, color: str) -> None:
        super().__init__(application=app, title=TITLE, decorated=False, resizable=False)
        self.scene = AtomScene()
        look = theme.load()
        proton = look.rgb(0) if color == look.acento else self._hex_rgb(theme.ACCENTS[color][0])
        self.base_path = BASE_DIR / f"umbra-{color}.png"
        self._last = None
        self._acc = 0.0
        self.bg: GdkPixbuf.Pixbuf | None = None

        geo = self._monitor()
        s = max(geo.width / IMG_W, geo.height / IMG_H)  # el fondo se ajusta «ampliado» (cubre)
        ox = geo.x + (geo.width - IMG_W * s) / 2
        oy = geo.y + (geo.height - IMG_H * s) / 2
        self.scale = s
        cx, cy = ox + ATOM_X * IMG_W * s, oy + ATOM_Y * IMG_H * s
        x0 = int(max(geo.x, cx - HALF_W * s))
        y0 = int(max(geo.y, cy - HALF_H * s))
        x1 = int(min(geo.x + geo.width, cx + HALF_W * s))
        y1 = int(min(geo.y + geo.height, cy + HALF_H * s))
        self.win_rect = (x0, y0, x1 - x0, y1 - y0)
        self.center = (cx - x0, cy - y0)  # centro del átomo dentro de la ventana
        self.renderer = AtomRenderer(proton, self.center, s)
        self._load_background(ox, oy, s)

        self.set_default_size(x1 - x0, y1 - y0)
        self.canvas = Gtk.DrawingArea(content_width=x1 - x0, content_height=y1 - y0)
        self.canvas.set_draw_func(self._draw)
        self.canvas.add_tick_callback(self._tick)
        self.set_child(self.canvas)
        right = Gtk.GestureClick(button=3)
        right.connect("pressed", self._right_click)
        self.canvas.add_controller(right)
        self.connect("map", lambda *_: GLib.timeout_add(200, self._place))

    @staticmethod
    def _hex_rgb(h: str) -> tuple[float, float, float]:
        h = h.lstrip("#")
        return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))

    def _monitor(self) -> Gdk.Rectangle:
        monitors = Gdk.Display.get_default().get_monitors()
        return monitors.get_item(0).get_geometry()

    def _load_background(self, ox: float, oy: float, s: float) -> None:
        if not self.base_path.is_file():
            return
        full = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(self.base_path), round(IMG_W * s), round(IMG_H * s), False)
        x0, y0, w, h = self.win_rect
        sx, sy = int(x0 - ox), int(y0 - oy)
        w = min(w, full.get_width() - sx)
        h = min(h, full.get_height() - sy)
        if w > 0 and h > 0 and sx >= 0 and sy >= 0:
            self.bg = full.new_subpixbuf(sx, sy, w, h).copy()

    def _place(self) -> bool:
        x, y, _w, _h = self.win_rect
        float_window(TITLE, x, y)  # fija la posición y la quita de la barra de tareas
        wmctrl("-r", TITLE, "-b", "remove,above")
        wmctrl("-r", TITLE, "-b", "add,below")  # siempre por debajo de las ventanas
        return False

    # --- animación -------------------------------------------------------------------------
    def _tick(self, _w, clock) -> bool:
        now = clock.get_frame_time() / 1e6
        dt = 1 / 60 if self._last is None else now - self._last
        self._last = now
        self._acc += dt
        if self._acc >= 1 / FPS:  # 30 fotogramas por segundo: suficiente y ligero
            self.scene.update(self._acc)
            self._acc = 0.0
            self.canvas.queue_draw()
        return True

    def _right_click(self, _g, _n, x, y) -> None:
        cx, cy = self.center
        if self.scene.hit_nucleus((x - cx) / self.scale, (y - cy) / self.scale):
            self.scene.trigger_fusion()

    # --- dibujo --------------------------------------------------------------------------------
    def _draw(self, _area, cr, width, height) -> None:
        if self.bg is not None:
            Gdk.cairo_set_source_pixbuf(cr, self.bg, 0, 0)
            cr.paint()
        else:
            cr.set_source_rgb(0.02, 0.012, 0.04)
            cr.paint()
        self.renderer.draw(cr, self.scene.frame())


class AtomApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.Atomo")

    def do_activate(self) -> None:
        if self.props.active_window:
            return
        look = theme.load()
        color = look.fondo if look.fondo in theme.ACCENTS else look.acento
        AtomWindow(self, color).present()


def main() -> int:
    GLib.set_prgname("umbra-atomo")
    from .config import safe_mode

    if safe_mode():
        return 0  # modo seguro: sin extras
    look = theme.load()
    if not look.fondo_vivo and "--forzar" not in sys.argv:
        return 0  # desactivado en Ajustes de UMBRA: queda el fondo fijo
    return AtomApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
