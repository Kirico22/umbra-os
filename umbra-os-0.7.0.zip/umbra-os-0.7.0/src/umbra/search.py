"""Lógica del buscador de UMBRA (sin GTK, para poder probarla).

Busca a la vez en: aplicaciones, ajustes del sistema y archivos del usuario.
La última opción siempre es «Preguntar a NYX».
"""

from __future__ import annotations

import os
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from .modules.apps import installed

SETTINGS_HINTS = ("settings", "ajustes", "configuracion", "preferencias", "xfce4-", "umbra-ajustes")
MAX_FILE_SCAN = 40_000


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in text if not unicodedata.combining(c)).strip()


@dataclass
class Result:
    kind: str  # app | ajuste | archivo | carpeta | nyx
    title: str
    subtitle: str
    target: str  # id del lanzador, ruta o texto para NYX
    score: float


def _score(query: str, text: str) -> float:
    q, t = norm(query), norm(text)
    if not q or q not in t:
        return 0.0
    if t == q:
        return 1.0
    if t.startswith(q):
        return 0.9
    if any(w.startswith(q) for w in t.split()):
        return 0.75
    return 0.5


def search_apps(query: str, dirs=None) -> list[Result]:
    out = []
    for app in installed(dirs).values():
        s = max(_score(query, app["nombre"]), _score(query, app["id"]) * 0.9,
                _score(query, app["descripcion"]) * 0.6)
        if s:
            is_setting = any(h in app["id"].lower() or h in norm(app["nombre"]) for h in SETTINGS_HINTS)
            out.append(Result("ajuste" if is_setting else "app", app["nombre"],
                              app["descripcion"] or ("Ajuste del sistema" if is_setting else "Aplicación"),
                              app["id"], s + (0.05 if not is_setting else 0)))
    return out


def search_files(query: str, root: Path | None = None, limit: int = 8) -> list[Result]:
    root = Path(root or Path.home())
    q = norm(query)
    if len(q) < 2:
        return []
    out, scanned = [], 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False, onerror=lambda e: None):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in ("node_modules", "__pycache__")]
        for name in dirnames + filenames:
            scanned += 1
            s = _score(q, name)
            if s:
                full = os.path.join(dirpath, name)
                kind = "carpeta" if name in dirnames else "archivo"
                out.append(Result(kind, name, full.replace(str(Path.home()), "~", 1), full, s * 0.8))
        if scanned > MAX_FILE_SCAN or len(out) > limit * 4:
            break
    out.sort(key=lambda r: -r.score)
    return out[:limit]


def search(query: str, root: Path | None = None, app_dirs=None) -> list[Result]:
    query = query.strip()
    if not query:
        return []
    results = search_apps(query, app_dirs) + search_files(query, root)
    results.sort(key=lambda r: -r.score)
    results = results[:12]
    results.append(Result("nyx", f"Preguntar a NYX: «{query}»", "NYX lo entiende y te responde", query, 0.0))
    return results
