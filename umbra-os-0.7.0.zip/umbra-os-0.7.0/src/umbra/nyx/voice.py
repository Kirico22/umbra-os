"""Voz de NYX: síntesis local (sin internet ni APIs) y envolvente de volumen.

Motores, por orden de preferencia:
  1. Piper (voz neuronal, natural) con la voz española "sharvard", hablante femenina.
  2. espeak-ng (más robótica, pero siempre disponible en UMBRA OS).

`speak()` devuelve la envolvente de volumen (60 valores por segundo, de 0 a 1) para que
la esfera de partículas se mueva al ritmo de la voz.
"""

from __future__ import annotations

import array
import math
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import wave
from dataclasses import dataclass
from pathlib import Path

VOICE_DIRS = [Path("/usr/share/umbra/voices"), Path.home() / ".local" / "share" / "umbra" / "voices"]
PIPER_VOICE = "es_ES-sharvard-medium"
PIPER_SPEAKER = "F"  # voz femenina: NYX es la diosa griega de la noche
PIPER_LENGTH_SCALE = 1.08  # un poco más pausada de lo normal: tono calmado
ENVELOPE_FPS = 60
MAX_SPOKEN_CHARS = 320


def speakable(text: str) -> str:
    """Prepara una respuesta para leerla en voz alta: primera parte útil, sin símbolos ni tablas."""
    lines = [ln.strip() for ln in text.strip().splitlines()]
    out: list[str] = []
    for ln in lines:
        if not ln:
            if out:
                break  # solo el primer bloque: no se leen listas largas
            continue
        out.append(ln)
    spoken = " ".join(out)
    spoken = re.sub(r"[→✓✗•·⚠│|`*_#>\[\]{}]", " ", spoken)
    spoken = re.sub(r"(/[\w.\-]+){2,}", " esa ruta ", spoken)  # no leer rutas enteras
    spoken = spoken.replace("%", " por ciento").replace("GB", " gigas").replace("MB", " megas")
    spoken = re.sub(r"\s+", " ", spoken).strip()
    if len(spoken) > MAX_SPOKEN_CHARS:
        cut = spoken[:MAX_SPOKEN_CHARS]
        spoken = cut[: cut.rfind(".") + 1] or cut[: cut.rfind(" ")] + "…"
    return spoken


def envelope(wav_path: Path, fps: int = ENVELOPE_FPS) -> list[float]:
    """Volumen (RMS) normalizado de 0 a 1, `fps` valores por segundo."""
    with wave.open(str(wav_path), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("se esperaba audio de 16 bits")
        rate, channels = w.getframerate(), w.getnchannels()
        samples = array.array("h", w.readframes(w.getnframes()))
    if channels > 1:
        samples = samples[::channels]
    step = max(1, rate // fps)
    values = []
    for i in range(0, len(samples), step):
        chunk = samples[i : i + step]
        if chunk:
            values.append(math.sqrt(sum(s * s for s in chunk) / len(chunk)))
    peak = max(values, default=0) or 1.0
    # Raíz para que las partes suaves también muevan la esfera
    return [min(1.0, (v / peak) ** 0.6) for v in values]


@dataclass
class Utterance:
    wav: Path
    envelope: list[float]
    duration: float
    engine: str


class Voice:
    def __init__(self) -> None:
        self.engine = "ninguno"
        self._piper = None
        self._piper_cfg = None
        model = next((d / f"{PIPER_VOICE}.onnx" for d in VOICE_DIRS if (d / f"{PIPER_VOICE}.onnx").is_file()), None)
        if model is not None:
            try:
                from piper import PiperVoice, SynthesisConfig

                self._piper = PiperVoice.load(model)
                speaker = self._piper.config.speaker_id_map.get(PIPER_SPEAKER)
                self._piper_cfg = SynthesisConfig(speaker_id=speaker, length_scale=PIPER_LENGTH_SCALE)
                self.engine = "piper"
            except Exception:
                self._piper = None
        if self._piper is None and shutil.which("espeak-ng"):
            self.engine = "espeak-ng"
        self.player = next((p for p in ("pw-play", "paplay", "aplay") if shutil.which(p)), None)
        self._current: subprocess.Popen | None = None

    @property
    def available(self) -> bool:
        return self.engine != "ninguno"

    def synthesize(self, text: str) -> Utterance | None:
        text = speakable(text)
        if not text or not self.available:
            return None
        fd, name = tempfile.mkstemp(prefix="nyx-voz-", suffix=".wav")
        os.close(fd)
        wav = Path(name)
        if self.engine == "piper":
            with wave.open(str(wav), "wb") as w:
                self._piper.synthesize_wav(text, w, syn_config=self._piper_cfg)
        else:
            # Voz española, algo más grave y pausada para sonar menos robótica
            subprocess.run(["espeak-ng", "-v", "es+f3", "-s", "150", "-p", "38", "-w", str(wav), text],
                           check=True, timeout=60, capture_output=True)
        env = envelope(wav)
        return Utterance(wav, env, len(env) / ENVELOPE_FPS, self.engine)

    def play(self, utt: Utterance, on_done=None) -> None:
        """Reproduce en segundo plano y borra el audio al terminar."""
        self.stop()

        def run() -> None:
            try:
                start = time.monotonic()
                ok = False
                if self.player:
                    self._current = subprocess.Popen([self.player, str(utt.wav)],
                                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    ok = self._current.wait() == 0
                if not ok and (self._current is None or self._current.returncode != -15):
                    # Sin sonido (o sin reproductor): la esfera se mueve igualmente lo que dura la frase
                    time.sleep(max(0.0, utt.duration - (time.monotonic() - start)))
            finally:
                utt.wav.unlink(missing_ok=True)
                if on_done:
                    on_done()

        threading.Thread(target=run, daemon=True).start()

    def stop(self) -> None:
        if self._current and self._current.poll() is None:
            self._current.terminate()
