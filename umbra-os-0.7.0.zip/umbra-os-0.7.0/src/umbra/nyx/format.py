"""Convierte resultados de acciones en respuestas en español (sin modelo)."""

from __future__ import annotations

from ..security import ExecutionResult


def _fmt_system(o: dict) -> str:
    lines = [
        f"CPU: {o['cpu_nucleos']} núcleos, carga {o['carga_por_nucleo_pct']}% "
        f"(media 1/5/15 min: {', '.join(str(x) for x in o['carga_1_5_15'])}).",
        f"RAM: {o['ram_disponible_gb']} GB libres de {o['ram_total_gb']} GB ({o['ram_uso_pct']}% en uso).",
        f"Disco /: {o['disco_raiz_libre_gb']} GB libres de {o['disco_raiz_total_gb']} GB ({o['disco_raiz_uso_pct']}% usado).",
    ]
    if o.get("swap_usada_gb", 0) > 0.5:
        lines.append(f"Swap en uso: {o['swap_usada_gb']} GB (señal de que falta RAM).")
    warnings = []
    if (o.get("ram_uso_pct") or 0) > 85:
        warnings.append("la RAM está casi llena")
    if o.get("carga_por_nucleo_pct", 0) > 90:
        warnings.append("la CPU va muy cargada")
    if o.get("disco_raiz_uso_pct", 0) > 90:
        warnings.append("queda poco disco")
    lines.append("Atención: " + ", ".join(warnings) + "." if warnings else "Todo dentro de lo normal.")
    return "\n".join(lines)


def _fmt_top(o: list) -> str:
    if not o:
        return "No he podido leer los procesos."
    rows = [f"  {p['ram_mb']:>8} MB  {p['nombre']} (pid {p['pid']})" for p in o]
    return "Procesos que más RAM usan:\n" + "\n".join(rows)


def _fmt_usage(o: dict) -> str:
    if not o["mayores"]:
        return f"{o['ruta']} está vacía."
    rows = [f"  {e['mb']:>10} MB  {e['nombre']}" for e in o["mayores"]]
    return f"Lo que más ocupa en {o['ruta']}:\n" + "\n".join(rows)


def _fmt_list(o: dict) -> str:
    if not o["entradas"]:
        return f"{o['ruta']} está vacía."
    rows = [f"  {'[d]' if e['tipo'] == 'carpeta' else '   '} {e['nombre']}" for e in o["entradas"]]
    return f"Contenido de {o['ruta']}:\n" + "\n".join(rows)


def _fmt_failed(o: dict) -> str:
    if not o["disponible"]:
        return "Este sistema no usa systemd; no puedo revisar servicios."
    if not o["fallidos"]:
        return "No hay ningún servicio fallando."
    rows = [f"  ✗ {u['unidad']} {u['detalle']}".rstrip() for u in o["fallidos"]]
    return f"Hay {len(rows)} servicio(s) con fallos:\n" + "\n".join(rows)


def _fmt_recall(o: list) -> str:
    if not o:
        return "No tengo nada guardado sobre eso."
    return "Esto es lo que recuerdo:\n" + "\n".join(f"  · {f['key']}: {f['value']}" for f in o)


def _fmt_find(o: dict) -> str:
    if not o["resultados"]:
        return f"No he encontrado nada llamado '{o['buscado']}' en {o['en']}."
    extra = "" if o["completo"] else " (hay más; concreta la búsqueda)"
    return f"Encontrado{extra}:\n" + "\n".join(f"  {r}" for r in o["resultados"])


def _fmt_preview(o: dict) -> str:
    if not o["total"]:
        return f"No hay nada que organizar en {o['ruta']}."
    rows = [f"  {n:>4} → {c}/" for c, n in sorted(o["por_carpeta"].items())]
    return f"Plan para {o['ruta']} ({o['total']} archivos):\n" + "\n".join(rows)


def _fmt_organize(o: dict) -> str:
    if not o["movidos"]:
        return "No se ha movido nada."
    return f"Listo: {o['movidos']} archivos organizados. Si quieres volver atrás, dime «deshaz»."


def _fmt_net(o: dict) -> str:
    rows = [f"  {i['nombre']}: {i['estado']} {' '.join(i['ipv4']) or 'sin IPv4'}" for i in o["interfaces"]]
    state = "Conectado" if o["conectado"] else "Sin conexión"
    return (f"{state}. Puerta de enlace: {o['puerta_enlace'] or '—'} · DNS: {', '.join(o['dns']) or '—'}\n"
            + "\n".join(rows))


def _fmt_apps(o: list) -> str:
    if not o:
        return "No encuentro aplicaciones instaladas."
    return f"Tienes {len(o)} aplicaciones:\n" + "\n".join(f"  · {a['nombre']}" for a in o[:60])


def _fmt_pkgs(o: list) -> str:
    if not o:
        return "No he encontrado programas con ese nombre."
    return "Programas disponibles:\n" + "\n".join(f"  {p['paquete']} — {p['descripcion']}" for p in o)


from ..scanner import KIND_TEXT  # noqa: E402

ICON = {"seguro": "✔", "precaucion": "⚠", "peligroso": "✖"}


def _fmt_scan(o: dict) -> str:
    if "carpeta" in o:
        return _fmt_scan_folder(o)
    lines = [f"{ICON[o['verdict']]} {o['name']}: {o['etiqueta'].upper()}",
             f"  Tipo real: {KIND_TEXT.get(o['kind'], o['kind'])} · {o['size']:,} bytes".replace(",", ".")]
    for f in sorted(o["findings"], key=lambda f: f["level"] != "peligroso"):
        lines.append(f"  {ICON[f['level']]} {f['message'][0].upper()}{f['message'][1:]}.")
    if o["verdict"] == "peligroso":
        lines.append("  No lo abras. Puedo ponerlo en cuarentena: «pon en cuarentena " + o["name"] + "».")
    elif o["verdict"] == "precaucion":
        lines.append("  Ábrelo solo si sabes de dónde viene.")
    else:
        lines.append("  No he encontrado nada sospechoso.")
    lines.append(f"  Antivirus: {o['antivirus']} · SHA-256 {o['sha256'][:16]}…")
    return "\n".join(lines)


def _worst(r: dict) -> str:
    """El motivo más grave de un informe."""
    order = {"peligroso": 0, "precaucion": 1, "seguro": 2}
    findings = sorted(r["findings"], key=lambda f: order[f["level"]])
    return findings[0]["message"] if findings else ""


def _fmt_scan_folder(o: dict) -> str:
    lines = [f"He analizado {o['analizados']} archivos de {o['carpeta']}."]
    if o["peligrosos"]:
        lines.append(f"✖ Peligrosos ({len(o['peligrosos'])}):")
        lines += [f"  {r['name']} — {_worst(r)}" for r in o["peligrosos"]]
    if o["precaucion"]:
        lines.append(f"⚠ Con precaución ({len(o['precaucion'])}):")
        lines += [f"  {r['name']} — {_worst(r)}" for r in o["precaucion"]]
    lines.append(f"✔ Seguros: {len(o['seguros'])}")
    if o["peligrosos"]:
        lines.append("Te recomiendo poner los peligrosos en cuarentena.")
    return "\n".join(lines)


def _fmt_quarantine_list(o: list) -> str:
    if not o:
        return "La cuarentena está vacía."
    return "En cuarentena:\n" + "\n".join(
        f"  {i['nombre']} ({i['veredicto']}, {i['fecha']}) — id {i['id']}" for i in o)


def _fmt_status(o: dict) -> str:
    rows = [("Cortafuegos", o["cortafuegos"]), ("AppArmor", o["apparmor"]), ("Antivirus", o["antivirus"]),
            ("Actualizaciones de seguridad automáticas", o["actualizaciones_automaticas"]),
            ("Vigía de descargas", o["vigia_descargas"]), ("Archivos en cuarentena", str(o["cuarentena"]))]
    return "Estado de la protección:\n" + "\n".join(f"  {k}: {v}" for k, v in rows)


FORMATTERS = {
    "files.find": _fmt_find,
    "files.organize_preview": _fmt_preview,
    "files.organize": _fmt_organize,
    "files.undo_organize": lambda o: o["mensaje"],
    "network.status": _fmt_net,
    "apps.list": _fmt_apps,
    "apps.open": lambda o: f"Abriendo {o['abierta']}.",
    "apps.game_mode": lambda o: o["mensaje"],
    "packages.search": _fmt_pkgs,
    "packages.install": lambda o: f"{o['instalado']} instalado correctamente.",
    "packages.browser": lambda o: o["instalado"],
    "packages.packs": lambda o: "Packs disponibles (di «instala el pack de …»):\n" + "\n".join(
        f"  {p['nombre']} — {p['contenido']}" for p in o),
    "packages.pack": lambda o: (f"Pack {o['pack']} instalado: {len(o['instalados'])} programas."
                                + (f" No se pudieron instalar: {', '.join(o['fallidos'])}." if o["fallidos"] else "")),
    "processes.stop": lambda o: f"He cerrado {o['cerrado']} (pid {o['pid']}).",
    "system.info": _fmt_system,
    "processes.top": _fmt_top,
    "files.usage": _fmt_usage,
    "files.list": _fmt_list,
    "services.failed": _fmt_failed,
    "memory.recall": _fmt_recall,
    "security.scan": _fmt_scan,
    "security.scan_folder": _fmt_scan_folder,
    "security.quarantine": lambda o: f"He puesto {o['nombre']} en cuarentena. Ya no se puede abrir ni ejecutar.",
    "security.quarantine_list": _fmt_quarantine_list,
    "security.restore": lambda o: f"He devuelto {o['nombre']} a {o['restaurado']} (sin permiso de ejecución).",
    "security.delete": lambda o: f"He borrado {o['eliminado']} definitivamente.",
    "security.status": _fmt_status,
    "routines.add": lambda o: f"Hecho: {o['cuando']} haré «{o['orden']}» (rutina {o['id']}).",
    "routines.list": lambda o: ("No tienes rutinas. Prueba: «cada viernes a las 18:00 organiza las descargas»."
                                if not o else "Tus rutinas:\n" + "\n".join(
                                    f"  {r['id']}. {r['cuando']}: {r['orden']}" for r in o)),
    "routines.remove": lambda o: f"He borrado la rutina {o['id']} («{o['orden']}»).",
}


def format_result(result: ExecutionResult) -> str:
    if not result.ok:
        reasons = {
            "rejected": "No puedo hacer eso",
            "denied": "No tengo permiso",
            "cancelled": "Cancelado",
            "error": "Ha fallado",
        }
        return f"{reasons.get(result.status, 'Error')}: {result.error}"
    fmt = FORMATTERS.get(result.action_id)
    return fmt(result.output) if fmt else str(result.output)
