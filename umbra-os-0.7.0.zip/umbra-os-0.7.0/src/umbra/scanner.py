"""Analizador de archivos de NYX (Python puro, sin conexión a internet).

Examina un archivo SIN ejecutarlo y devuelve un veredicto con motivos en español:

- ``seguro``      no se ha encontrado nada sospechoso,
- ``precaucion``  es un programa, tiene macros, scripts o no se puede ver por dentro,
- ``peligroso``   hay señales claras de engaño o de código dañino.

Qué mira:
- el tipo REAL del archivo por sus primeros bytes (no se fía de la extensión),
- extensiones dobles (``factura.pdf.exe``) y caracteres que invierten el texto del nombre,
- órdenes peligrosas dentro de scripts y lanzadores (.sh, .desktop, .py...),
- macros en documentos de Office y JavaScript/acciones automáticas en PDF,
- comprimidos: bombas zip, rutas que escapan de la carpeta, contenido cifrado y lo que hay dentro,
- paquetes .deb: los scripts que se ejecutan como administrador al instalarlos,
- la firma de prueba EICAR, una lista local de huellas SHA-256 maliciosas y, si está
  instalado, el antivirus ClamAV.

Nada de esto envía el archivo ni su huella a ningún servicio externo.
"""

from __future__ import annotations

import hashlib
import io
import json
import lzma
import os
import re
import shutil
import stat
import subprocess
import tarfile
import time
import uuid
import zipfile
from dataclasses import asdict, dataclass, field
from pathlib import Path

SEGURO, PRECAUCION, PELIGROSO = "seguro", "precaucion", "peligroso"
LEVEL = {SEGURO: 0, PRECAUCION: 1, PELIGROSO: 2}
LABEL = {SEGURO: "Seguro", PRECAUCION: "Precaución", PELIGROSO: "Peligroso"}

CONTENT_LIMIT = 4 * 1024 * 1024  # bytes que se leen para buscar patrones
INNER_LIMIT = 2 * 1024 * 1024  # tamaño máximo de un archivo interno de un comprimido que se analiza
INNER_MAX = 200  # nombres de archivos internos que se revisan
BOMB_RATIO = 100  # descomprimido / comprimido
BOMB_SIZE = 1024**3  # 1 GiB descomprimido

# Firma de prueba EICAR, partida en dos para que los antivirus no marquen este propio archivo.
EICAR = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + b"EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"

# Extensiones que el usuario espera que sean "inofensivas" (documentos, imágenes, música...).
HARMLESS_EXT = {
    ".pdf", ".txt", ".md", ".doc", ".docx", ".odt", ".rtf", ".xls", ".xlsx", ".ods", ".csv", ".ppt",
    ".pptx", ".odp", ".epub", ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg", ".heic",
    ".tiff", ".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac", ".opus", ".mp4", ".mkv", ".avi",
    ".mov", ".webm", ".wmv",
}
# Extensiones que ejecutan código al abrirse.
EXEC_EXT = {
    ".exe", ".scr", ".com", ".pif", ".bat", ".cmd", ".msi", ".vbs", ".vbe", ".js", ".jse", ".wsf",
    ".hta", ".lnk", ".ps1", ".jar", ".sh", ".run", ".bin", ".appimage", ".desktop", ".py", ".pl",
    ".deb", ".apk", ".elf", ".cpl", ".reg",
}
WINDOWS_ONLY = {".exe", ".scr", ".com", ".pif", ".bat", ".cmd", ".msi", ".vbs", ".vbe", ".jse",
                ".wsf", ".hta", ".lnk", ".ps1", ".cpl", ".reg"}
# Caracteres invisibles que dan la vuelta al texto: "fact<U+202E>fdp.exe" se ve como "factexe.pdf".
BIDI = {chr(c) for c in (0x200E, 0x200F, *range(0x202A, 0x202F), *range(0x2066, 0x206A))}

# (nivel, expresión, motivo). Se buscan en scripts, lanzadores y archivos de texto.
SCRIPT_PATTERNS: list[tuple[str, re.Pattern[bytes], str]] = [
    (PELIGROSO, re.compile(rb"(curl|wget)[^\n|;]{0,200}\|\s*(sudo\s+)?(ba|z|da)?sh\b"),
     "descarga algo de internet y lo ejecuta directamente (curl/wget | sh)"),
    (PELIGROSO, re.compile(rb"base64\s+(-d|--decode)[^\n]{0,80}\|\s*(ba|z)?sh\b"),
     "decodifica código oculto en base64 y lo ejecuta"),
    (PELIGROSO, re.compile(rb"/dev/(tcp|udp)/"), "abre una conexión de red oculta (/dev/tcp), típico de puertas traseras"),
    (PELIGROSO, re.compile(rb"\b(nc|ncat|netcat)\b[^\n]{0,60}\s-(e|c)\s"), "abre una shell remota con netcat"),
    (PELIGROSO, re.compile(rb"rm\s+-[a-z]*r[a-z]*f[a-z]*\s+(--no-preserve-root\s+)?(/|~|\$HOME)(\s|$|\*)"),
     "borra el sistema o la carpeta personal (rm -rf)"),
    (PELIGROSO, re.compile(rb"\bdd\b[^\n]{0,80}of=/dev/(sd|nvme|mmcblk|hd)"), "escribe directamente sobre un disco"),
    (PELIGROSO, re.compile(rb"\bmkfs(\.\w+)?\s+/dev/"), "formatea un disco"),
    (PELIGROSO, re.compile(rb":\(\)\s*\{\s*:\|:&\s*\}\s*;\s*:"), "bomba fork: bloquea el ordenador"),
    (PELIGROSO, re.compile(rb"(xmrig|minerd|cpuminer|stratum\+tcp://|cryptonight)", re.I),
     "contiene un minero de criptomonedas"),
    (PELIGROSO, re.compile(rb"/etc/(sudoers|shadow)\b"), "toca las contraseñas o los permisos de administrador"),
    (PELIGROSO, re.compile(rb"chmod\s+[0-7]*[4-7][0-7]{3}\s|chmod\s+[ug]\+s\b"),
     "da permisos especiales (setuid) a un programa"),
    (PELIGROSO, re.compile(rb"exec\s*\(\s*(base64\.b64decode|zlib\.decompress|bytes\.fromhex)"),
     "ejecuta código Python oculto"),
    (PELIGROSO, re.compile(rb"eval\s*\(\s*(atob|unescape|String\.fromCharCode)\s*\("),
     "ejecuta código JavaScript oculto"),
    (PRECAUCION, re.compile(rb"\bcrontab\b|/etc/cron\.|/var/spool/cron"), "se programa para ejecutarse solo (cron)"),
    (PRECAUCION, re.compile(rb"(>>?|tee\s+-a)\s*~?/?[^\s]*\.(bashrc|profile|zshrc|bash_profile)"),
     "modifica el arranque de la terminal (.bashrc/.profile)"),
    (PRECAUCION, re.compile(rb"\.config/autostart|systemctl\s+(--user\s+)?enable"), "se instala para arrancar con el sistema"),
    (PRECAUCION, re.compile(rb"\b(sudo|pkexec)\b"), "pide permisos de administrador"),
    (PRECAUCION, re.compile(rb"(curl|wget)\s"), "descarga archivos de internet"),
    (PRECAUCION, re.compile(rb"\bhistory\s+-c\b|unset\s+HISTFILE"), "borra el rastro de órdenes"),
]


@dataclass
class Finding:
    level: str
    message: str


@dataclass
class Report:
    path: str
    name: str
    size: int
    sha256: str
    kind: str
    verdict: str = SEGURO
    findings: list[Finding] = field(default_factory=list)
    antivirus: str = "no disponible"

    def add(self, level: str, message: str) -> None:
        if any(f.message == message for f in self.findings):
            return
        self.findings.append(Finding(level, message))
        if LEVEL[level] > LEVEL[self.verdict]:
            self.verdict = level

    @property
    def label(self) -> str:
        return LABEL[self.verdict]

    def summary(self) -> str:
        """Frase corta para notificaciones y para la voz de NYX."""
        if self.verdict == SEGURO:
            return f"{self.name} parece seguro."
        top = sorted(self.findings, key=lambda f: -LEVEL[f.level])[0].message
        if self.verdict == PELIGROSO:
            return f"Cuidado: {self.name} es peligroso. {top[0].upper()}{top[1:]}."
        return f"Precaución con {self.name}: {top}."

    def to_dict(self) -> dict:
        d = asdict(self)
        d["etiqueta"] = self.label
        d["resumen"] = self.summary()
        return d


# --------------------------------------------------------------------------- tipo real

def detect_kind(head: bytes, name: str = "") -> str:
    if head.startswith(b"\x7fELF"):
        return "appimage" if head[8:11] in (b"AI\x01", b"AI\x02") else "elf"
    if head.startswith(b"MZ"):
        return "pe"
    if head.startswith(b"!<arch>\n"):
        return "deb" if b"debian-binary" in head[:200] else "ar"
    if head.startswith(b"%PDF"):
        return "pdf"
    if head.startswith(b"PK\x03\x04") or head.startswith(b"PK\x05\x06"):
        return "zip"
    if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        return "ole"
    if head.startswith(b"Rar!\x1a\x07"):
        return "rar"
    if head.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"
    if head.startswith(b"\x1f\x8b"):
        return "gzip"
    if head.startswith(b"\xfd7zXZ\x00"):
        return "xz"
    if head.startswith(b"BZh"):
        return "bzip2"
    if len(head) > 262 and head[257:262] == b"ustar":
        return "tar"
    if head.startswith(b"#!"):
        return "script"
    if head.startswith((b"\x89PNG", b"\xff\xd8\xff", b"GIF8", b"BM")) or head[8:12] == b"WEBP":
        return "imagen"
    if head[4:8] == b"ftyp" or head.startswith((b"\x1aE\xdf\xa3", b"RIFF", b"OggS", b"fLaC", b"ID3")):
        return "multimedia"
    if b"[Desktop Entry]" in head[:4096]:
        return "lanzador"
    if b"\x00" not in head[:4096]:
        return "texto"
    return "binario"


KIND_TEXT = {
    "elf": "programa de Linux", "appimage": "programa AppImage", "pe": "programa de Windows",
    "deb": "paquete de instalación .deb", "ar": "archivo ar", "pdf": "documento PDF",
    "zip": "archivo comprimido ZIP", "ole": "documento de Office antiguo", "rar": "comprimido RAR",
    "7z": "comprimido 7z", "gzip": "comprimido gzip", "xz": "comprimido xz", "bzip2": "comprimido bzip2",
    "tar": "archivo tar", "script": "script ejecutable", "imagen": "imagen", "multimedia": "audio o vídeo",
    "lanzador": "lanzador de escritorio", "texto": "texto", "binario": "datos binarios",
    "office": "documento de Office", "jar": "programa Java", "apk": "aplicación de Android",
}
EXECUTABLE_KINDS = {"elf", "appimage", "pe", "script", "lanzador", "jar", "apk", "deb"}
ARCHIVE_KINDS = {"zip", "rar", "7z", "gzip", "xz", "bzip2", "tar"}


# --------------------------------------------------------------------------- firmas

def _blocklists() -> list[Path]:
    home = Path(os.environ.get("HOME", "~")).expanduser()
    return [Path("/etc/umbra/firmas.txt"), Path("/usr/share/umbra/firmas.txt"),
            home / ".local/share/umbra/firmas.txt"]


def load_blocklist(paths: list[Path] | None = None) -> dict[str, str]:
    """Archivos de texto con líneas ``sha256  nombre opcional``; '#' son comentarios."""
    out: dict[str, str] = {}
    for p in paths if paths is not None else _blocklists():
        try:
            lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            digest, _, label = line.partition(" ")
            if re.fullmatch(r"[0-9a-fA-F]{64}", digest):
                out[digest.lower()] = label.strip() or "malware conocido"
    return out


def clamav(path: Path, timeout: int = 120, slow: bool = True) -> tuple[str, str | None]:
    """Devuelve (estado, nombre de la amenaza).

    Usa el demonio clamd si está activo (rápido). ``clamscan`` carga la base de firmas entera
    (cerca de 1 GB de RAM) en cada llamada, así que solo se usa si ``slow`` es True."""
    for exe in ("clamdscan", "clamscan") if slow else ("clamdscan",):
        binary = shutil.which(exe)
        if not binary:
            continue
        args = [binary, "--no-summary", "--infected"]
        if exe == "clamdscan":
            args.append("--fdpass")
        try:
            proc = subprocess.run([*args, "--", str(path)], capture_output=True, text=True,
                                  timeout=timeout, check=False)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if proc.returncode == 1:
            m = re.search(r":\s*(.+?)\s+FOUND", proc.stdout)
            return "amenaza", m.group(1) if m else "amenaza"
        if proc.returncode == 0:
            return "limpio", None
        # código 2 = error (p. ej. sin base de firmas o demonio parado): probamos el siguiente
    return "no disponible", None


# --------------------------------------------------------------------------- análisis

def _check_name(rep: Report, name: str) -> None:
    if any(c in BIDI for c in name):
        rep.add(PELIGROSO, "el nombre usa caracteres invisibles que esconden la extensión real")
    parts = [p.lower() for p in Path(name).suffixes]
    if len(parts) >= 2 and parts[-1] in EXEC_EXT and parts[-2] in HARMLESS_EXT:
        rep.add(PELIGROSO, f"tiene doble extensión ({parts[-2]}{parts[-1]}): se hace pasar por "
                           f"{parts[-2][1:].upper()} pero es un programa")
    if re.search(r"\s{6,}\.\w+$", name):
        rep.add(PELIGROSO, "esconde la extensión real tras muchos espacios")


def _scan_text(rep: Report, data: bytes, where: str = "") -> None:
    if EICAR in data:
        rep.add(PELIGROSO, f"contiene la firma de prueba antivirus EICAR{where}")
    for level, rx, msg in SCRIPT_PATTERNS:
        if rx.search(data):
            rep.add(level, msg + where)
    # «descarga algo y lo ejecuta» ya incluye «descarga archivos»: no repetirlo
    if any("curl/wget | sh" in f.message for f in rep.findings):
        rep.findings = [f for f in rep.findings if not f.message.startswith("descarga archivos de internet")]


def _scan_desktop(rep: Report, data: bytes) -> None:
    rep.add(PRECAUCION, "es un lanzador: al abrirlo ejecuta un programa")
    m = re.search(rb"^Exec\s*=\s*(.+)$", data, re.M)
    if m:
        cmd = m.group(1)
        if re.search(rb"\b(sh|bash|zsh|dash)\s+-c\b|python3?\s+-c\b|perl\s+-e\b", cmd):
            rep.add(PELIGROSO, "el lanzador ejecuta órdenes ocultas en una línea (sh -c)")
        if re.search(rb"https?://", cmd):
            rep.add(PRECAUCION, "el lanzador descarga algo de internet")


def _scan_pdf(rep: Report, data: bytes) -> None:
    if re.search(rb"/Launch\b", data):
        rep.add(PELIGROSO, "el PDF intenta abrir otros programas (/Launch)")
    js = re.search(rb"/(JavaScript|JS)\b", data)
    auto = re.search(rb"/(OpenAction|AA)\b", data)
    if js and auto:
        rep.add(PELIGROSO, "el PDF ejecuta JavaScript automáticamente al abrirse")
    elif js:
        rep.add(PRECAUCION, "el PDF lleva JavaScript")
    if re.search(rb"/EmbeddedFile\b", data):
        rep.add(PRECAUCION, "el PDF lleva archivos adjuntos escondidos")
    if re.search(rb"/(URI|SubmitForm)\b", data) and js:
        rep.add(PRECAUCION, "el PDF puede enviar datos a internet")


def _scan_ole(rep: Report, data: bytes) -> None:
    if re.search(rb"(_VBA_PROJECT|VBA\x00|Macros|\x00A\x00t\x00t\x00r\x00i\x00b\x00u\x00t)", data):
        rep.add(PRECAUCION, "el documento tiene macros (código que se ejecuta al abrirlo)")
        if re.search(rb"(AutoOpen|Auto_Open|Document_Open|Workbook_Open)", data):
            rep.add(PELIGROSO, "las macros se ejecutan solas al abrir el documento")
        if re.search(rb"(Shell|WScript\.Shell|URLDownloadToFile|powershell)", data, re.I):
            rep.add(PELIGROSO, "las macros ejecutan programas o descargan archivos")


def _inner_name_checks(rep: Report, names: list[str]) -> None:
    exec_inside = []
    for n in names[:INNER_MAX]:
        clean = n.replace("\\", "/")
        if clean.startswith("/") or re.match(r"^[A-Za-z]:", clean) or ".." in clean.split("/"):
            rep.add(PELIGROSO, "el comprimido intenta escribir fuera de su carpeta (ruta con .. o absoluta)")
        base = clean.rsplit("/", 1)[-1]
        if not base:
            continue
        sub = Report("", base, 0, "", "")
        _check_name(sub, base)
        for f in sub.findings:
            rep.add(f.level, f"dentro hay un archivo sospechoso ({base}): {f.message}")
        if Path(base).suffix.lower() in EXEC_EXT:
            exec_inside.append(base)
    if exec_inside:
        listado = ", ".join(exec_inside[:3]) + ("…" if len(exec_inside) > 3 else "")
        rep.add(PRECAUCION, f"contiene programas o scripts: {listado}")


def _scan_zip(rep: Report, path: Path, depth: int) -> None:
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError):
        rep.add(PRECAUCION, "el comprimido está dañado y no se puede revisar por dentro")
        return
    with zf:
        infos = zf.infolist()
        names = [i.filename for i in infos]
        lower = {n.lower() for n in names}
        # Tipos que en realidad son ZIP
        if "[content_types].xml" in lower or "mimetype" in lower:
            rep.kind = "office"
            if any(n.endswith("vbaproject.bin") for n in lower):
                rep.add(PRECAUCION, "el documento tiene macros (código que se ejecuta al abrirlo)")
            if any("oleobject" in n or n.endswith(".bin") and "embeddings" in n for n in lower):
                rep.add(PRECAUCION, "el documento lleva objetos incrustados")
            rels = [i for i in infos if i.filename.lower().endswith(".rels") and i.file_size < INNER_LIMIT]
            for i in rels[:40]:
                try:
                    xml = zf.read(i)
                except Exception:  # noqa: BLE001 - un miembro dañado no debe parar el análisis
                    continue
                if re.search(rb'TargetMode="External"', xml) and re.search(rb"attachedTemplate|oleObject", xml):
                    rep.add(PELIGROSO, "el documento descarga una plantilla o un objeto de internet al abrirse")
            return
        if "meta-inf/manifest.mf" in lower and any(n.endswith(".class") for n in lower):
            rep.kind = "jar"
            rep.add(PRECAUCION, "es un programa Java: ejecútalo solo si confías en quien lo hizo")
            return
        if "androidmanifest.xml" in lower and "classes.dex" in lower:
            rep.kind = "apk"
            rep.add(PRECAUCION, "es una aplicación de Android; en este ordenador no hace nada")
            return

        if any(i.flag_bits & 0x1 for i in infos):
            rep.add(PRECAUCION, "el comprimido tiene contraseña: no se puede revisar lo que hay dentro")
        total = sum(i.file_size for i in infos)
        packed = max(1, sum(i.compress_size for i in infos))
        if total > BOMB_SIZE and total / packed > BOMB_RATIO:
            rep.add(PELIGROSO, f"es una bomba zip: ocupa {packed // 1024} KB pero se descomprime a "
                               f"{total / 1024**3:.1f} GB y puede llenar el disco")
        if any(n.lower().endswith((".zip", ".7z", ".rar")) for n in names) and total / packed > BOMB_RATIO:
            rep.add(PRECAUCION, "lleva comprimidos dentro de comprimidos con mucha compresión")
        _inner_name_checks(rep, names)
        if depth > 0:
            return
        for i in infos[:INNER_MAX]:
            if i.is_dir() or i.flag_bits & 0x1 or i.file_size > INNER_LIMIT:
                continue
            try:
                data = zf.read(i)
            except Exception:  # noqa: BLE001
                continue
            _scan_inner(rep, i.filename, data)


def _scan_tar(rep: Report, path: Path, depth: int) -> None:
    try:
        tf = tarfile.open(path)  # detecta gzip, bzip2 y xz solo
    except (tarfile.TarError, OSError, EOFError, lzma.LZMAError):
        return
    with tf:
        try:
            members = []
            for m in tf:
                members.append(m)
                if len(members) >= INNER_MAX:
                    break
        except (tarfile.TarError, OSError, EOFError, lzma.LZMAError):
            rep.add(PRECAUCION, "el comprimido está dañado y no se puede revisar entero")
        rep.kind = "tar"
        _inner_name_checks(rep, [m.name for m in members])
        for m in members:
            if m.issym() or m.islnk():
                target = m.linkname
                if target.startswith("/") or "../" in target:
                    rep.add(PRECAUCION, f"contiene un enlace que apunta fuera de la carpeta ({m.name})")
            if m.mode & (stat.S_ISUID | stat.S_ISGID) and m.isfile():
                rep.add(PELIGROSO, f"contiene un programa con permisos especiales setuid ({m.name})")
            if depth == 0 and m.isfile() and m.size <= INNER_LIMIT:
                try:
                    f = tf.extractfile(m)
                    data = f.read() if f else b""
                except (tarfile.TarError, OSError, EOFError, lzma.LZMAError):
                    continue
                _scan_inner(rep, m.name, data)


def _scan_inner(rep: Report, name: str, data: bytes) -> None:
    """Analiza un archivo de dentro de un comprimido (un solo nivel)."""
    base = name.rsplit("/", 1)[-1]
    where = f" (en {base})"
    if EICAR in data:
        rep.add(PELIGROSO, f"contiene la firma de prueba antivirus EICAR{where}")
    kind = detect_kind(data[:4096], base)
    if kind in ("script", "lanzador", "texto"):
        for level, rx, msg in SCRIPT_PATTERNS:
            # Dentro de un comprimido solo cuentan las señales claras, no "usa sudo"
            if level == PELIGROSO and rx.search(data):
                rep.add(level, msg + where)
    if kind == "lanzador":
        sub = Report("", base, 0, "", "lanzador")
        _scan_desktop(sub, data)
        for f in sub.findings:
            if f.level == PELIGROSO:
                rep.add(f.level, f.message + where)
    if kind in ("pe", "elf") and Path(base).suffix.lower() in HARMLESS_EXT:
        rep.add(PELIGROSO, f"dentro hay un programa disfrazado de {Path(base).suffix[1:].upper()}{where}")
    if kind == "pdf":
        sub = Report("", base, 0, "", "pdf")
        _scan_pdf(sub, data)
        for f in sub.findings:
            rep.add(f.level, f.message + where)


def _ar_members(data: bytes) -> dict[str, bytes]:
    out: dict[str, bytes] = {}
    pos = 8
    while pos + 60 <= len(data) and len(out) < 16:
        hdr = data[pos:pos + 60]
        name = hdr[:16].decode("ascii", "replace").strip().rstrip("/")
        try:
            size = int(hdr[48:58].decode().strip())
        except ValueError:
            break
        pos += 60
        out[name] = data[pos:pos + size]
        pos += size + (size % 2)
    return out


def _scan_deb(rep: Report, path: Path) -> None:
    rep.add(PRECAUCION, "es un instalador .deb: se instala con permisos de administrador. "
                        "Si puedes, instala el programa desde los repositorios (NYX: «instala …»)")
    try:
        with open(path, "rb") as f:
            data = f.read(64 * 1024 * 1024)
    except OSError:
        return
    members = _ar_members(data)
    control = next((v for k, v in members.items() if k.startswith("control.tar")), None)
    if control is None:
        rep.add(PRECAUCION, "el paquete .deb no tiene el formato normal")
        return
    try:
        tf = tarfile.open(fileobj=io.BytesIO(control))
    except (tarfile.TarError, lzma.LZMAError, EOFError, OSError):
        return
    with tf:
        for m in tf.getmembers():
            base = m.name.rsplit("/", 1)[-1]
            if base not in ("preinst", "postinst", "prerm", "postrm", "config") or not m.isfile():
                continue
            f = tf.extractfile(m)
            script = f.read(INNER_LIMIT) if f else b""
            for level, rx, msg in SCRIPT_PATTERNS:
                if level == PELIGROSO and rx.search(script):
                    rep.add(PELIGROSO, f"el script de instalación ({base}) {msg}")
            if re.search(rb"(curl|wget)\s", script):
                rep.add(PRECAUCION, f"el script de instalación ({base}) descarga cosas de internet")


def scan(path: str | Path, *, antivirus: bool | str = True, blocklist: dict[str, str] | None = None,
         _depth: int = 0) -> Report:
    p = Path(path).expanduser()
    st = p.lstat()
    if stat.S_ISLNK(st.st_mode):
        p = p.resolve()
        st = p.stat()
    if not stat.S_ISREG(st.st_mode):
        raise ValueError(f"no es un archivo normal: {p}")

    h = hashlib.sha256()
    head = b""
    content = bytearray()
    with open(p, "rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
            if len(head) < 4096:
                head = (head + chunk)[:4096]
            if len(content) < CONTENT_LIMIT:
                content += chunk[: CONTENT_LIMIT - len(content)]
    data = bytes(content)
    kind = detect_kind(head, p.name)
    rep = Report(str(p), p.name, st.st_size, h.hexdigest(), kind)
    ext = p.suffix.lower()

    blocked = (blocklist if blocklist is not None else load_blocklist()).get(rep.sha256)
    if blocked:
        rep.add(PELIGROSO, f"su huella coincide con un archivo malicioso conocido ({blocked})")

    _check_name(rep, p.name)

    # Programa disfrazado: extensión de documento, contenido de programa
    if kind in ("elf", "pe", "appimage", "script", "lanzador") and ext in HARMLESS_EXT:
        rep.add(PELIGROSO, f"dice ser {ext[1:].upper()} pero en realidad es un {KIND_TEXT[kind]}")

    if kind in ("elf", "appimage"):
        rep.add(PRECAUCION, "es un programa: ejecútalo solo si confías en quien te lo dio")
        if st.st_mode & stat.S_ISUID:
            rep.add(PELIGROSO, "tiene permisos especiales setuid")
        if re.search(rb"(xmrig|stratum\+tcp://|cryptonight)", data, re.I):
            rep.add(PELIGROSO, "contiene un minero de criptomonedas")
    elif kind == "pe" or ext in WINDOWS_ONLY:
        rep.add(PRECAUCION, "es un programa de Windows: en UMBRA no se ejecuta, y no conviene abrirlo con Wine "
                            "si no sabes de dónde viene")
    if kind in ("script", "texto", "lanzador") or ext in {".sh", ".py", ".pl", ".js", ".desktop", ".run"}:
        if kind == "script" or ext in {".sh", ".py", ".pl", ".run"}:
            rep.add(PRECAUCION, "es un script: puede hacer cualquier cosa que haga tu usuario")
        _scan_text(rep, data)
    elif EICAR in data and kind not in ARCHIVE_KINDS:  # en comprimidos se mira archivo por archivo
        rep.add(PELIGROSO, "contiene la firma de prueba antivirus EICAR")
    if kind == "lanzador" or ext == ".desktop":
        _scan_desktop(rep, data)
    if kind == "pdf":
        _scan_pdf(rep, data)
    if kind == "ole":
        _scan_ole(rep, data)
    if kind == "zip":
        _scan_zip(rep, p, _depth)
    elif kind in ("tar", "gzip", "xz", "bzip2"):
        _scan_tar(rep, p, _depth)
    elif kind in ("rar", "7z"):
        rep.add(PRECAUCION, f"es un comprimido {kind.upper()}: NYX no puede ver lo que hay dentro sin "
                            "descomprimirlo; revísalo después de extraerlo")
    if kind == "deb":
        _scan_deb(rep, p)

    if antivirus:
        # antivirus="rapido": solo con el demonio (lo usa el vigía para no gastar RAM)
        estado, amenaza = clamav(p, slow=antivirus != "rapido")
        rep.antivirus = estado
        if amenaza:
            rep.add(PELIGROSO, f"el antivirus ClamAV lo detecta como «{amenaza}»")
    return rep


# --------------------------------------------------------------------------- cuarentena

def quarantine_dir() -> Path:
    home = Path(os.environ.get("HOME", "~")).expanduser()
    base = Path(os.environ.get("XDG_DATA_HOME") or home / ".local/share")
    d = base / "umbra" / "cuarentena"
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    return d


def quarantine(path: str | Path, report: Report | None = None, qdir: Path | None = None) -> dict:
    """Mueve el archivo a la cuarentena y le quita TODOS los permisos (no se puede abrir ni ejecutar)."""
    p = Path(path).expanduser()
    if not p.is_file() or p.is_symlink():
        raise ValueError(f"no es un archivo normal: {p}")
    q = qdir or quarantine_dir()
    rep = report or scan(p, antivirus=False)
    qid = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
    dest = q / f"{qid}.bin"
    shutil.move(str(p), dest)
    os.chmod(dest, 0)
    meta = {"id": qid, "original": str(p.resolve() if p.exists() else p), "nombre": p.name,
            "fecha": time.strftime("%Y-%m-%d %H:%M"), "sha256": rep.sha256, "veredicto": rep.verdict,
            "motivos": [f.message for f in rep.findings]}
    meta_path = q / f"{qid}.json"
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    os.chmod(meta_path, 0o600)
    return meta


def quarantined(qdir: Path | None = None) -> list[dict]:
    q = qdir or quarantine_dir()
    out = []
    for meta in sorted(q.glob("*.json"), reverse=True):
        try:
            out.append(json.loads(meta.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    return out


def _find(qid: str, qdir: Path) -> dict:
    for item in quarantined(qdir):
        if item["id"] == qid or item["nombre"] == qid:
            return item
    raise ValueError(f"no hay nada en cuarentena con ese nombre: {qid!r}")


def restore(qid: str, qdir: Path | None = None) -> dict:
    """Devuelve el archivo a su sitio, SIN permiso de ejecución. Nunca sobrescribe."""
    q = qdir or quarantine_dir()
    item = _find(qid, q)
    src = q / f"{item['id']}.bin"
    dest = Path(item["original"])
    dest.parent.mkdir(parents=True, exist_ok=True)
    n = 1
    while dest.exists():
        dest = dest.with_name(f"{Path(item['nombre']).stem} (restaurado {n}){''.join(Path(item['nombre']).suffixes)}")
        n += 1
    os.chmod(src, 0o600)
    shutil.move(str(src), dest)
    (q / f"{item['id']}.json").unlink(missing_ok=True)
    return {"restaurado": str(dest), "nombre": item["nombre"]}


def delete_quarantined(qid: str, qdir: Path | None = None) -> dict:
    q = qdir or quarantine_dir()
    item = _find(qid, q)
    src = q / f"{item['id']}.bin"
    if src.exists():
        os.chmod(src, 0o600)
        src.unlink()
    (q / f"{item['id']}.json").unlink(missing_ok=True)
    return {"eliminado": item["nombre"]}


def strip_exec(path: str | Path) -> bool:
    """Quita el permiso de ejecución (lo usa el vigía con archivos sospechosos)."""
    p = Path(path)
    try:
        mode = p.stat().st_mode
        if mode & 0o111:
            os.chmod(p, mode & ~0o111)
            return True
    except OSError:
        pass
    return False


# --------------------------------------------------------------------------- estado del sistema

def _read(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def downloads_dir() -> Path:
    home = Path(os.environ.get("HOME", "~")).expanduser()
    user_dirs = _read(str(home / ".config/user-dirs.dirs"))
    m = re.search(r'XDG_DOWNLOAD_DIR="([^"]+)"', user_dirs)
    if m:
        return Path(m.group(1).replace("$HOME", str(home)))
    for name in ("Descargas", "Downloads"):
        if (home / name).is_dir():
            return home / name
    return home / "Descargas"


def _vigia_running() -> bool:
    for proc in Path("/proc").glob("[0-9]*"):
        cmd = _read(str(proc / "cmdline"))
        if "umbra-vigia" in cmd or "umbra.vigia" in cmd:
            return True
    return False


def security_status() -> dict:
    ufw = _read("/etc/ufw/ufw.conf")
    clam_db = [p for p in Path("/var/lib/clamav").glob("*.c[vl]d")] if Path("/var/lib/clamav").is_dir() else []
    clam_age = None
    if clam_db:
        clam_age = int((time.time() - max(p.stat().st_mtime for p in clam_db)) // 86400)
    auto = _read("/etc/apt/apt.conf.d/20auto-upgrades")
    sysctl = {
        "kernel.kptr_restrict": _read("/proc/sys/kernel/kptr_restrict"),
        "kernel.dmesg_restrict": _read("/proc/sys/kernel/dmesg_restrict"),
        "kernel.yama.ptrace_scope": _read("/proc/sys/kernel/yama/ptrace_scope"),
        "net.ipv4.tcp_syncookies": _read("/proc/sys/net/ipv4/tcp_syncookies"),
    }
    try:
        n_quar = len(quarantined())
    except OSError:
        n_quar = 0
    return {
        "cortafuegos": "activo" if re.search(r"^ENABLED=yes", ufw, re.M) else
                       ("instalado, apagado" if ufw else "no instalado"),
        "apparmor": "activo" if _read("/sys/module/apparmor/parameters/enabled") == "Y" else "inactivo",
        "antivirus": ("ClamAV, firmas de hace %d días" % clam_age) if clam_age is not None else
                     ("ClamAV sin firmas todavía" if shutil.which("clamscan") else "no instalado"),
        "actualizaciones_automaticas": "sí" if 'Unattended-Upgrade "1"' in auto else "no",
        "vigia_descargas": "vigilando" if _vigia_running() else "parado",
        "cuarentena": n_quar,
        "nucleo": {k: v for k, v in sysctl.items() if v},
    }
