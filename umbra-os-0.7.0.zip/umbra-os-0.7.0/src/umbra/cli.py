"""Interfaz de terminal de NYX.

    nyx                      conversación interactiva
    nyx "analiza el rendimiento del sistema"   una sola orden
    nyx --acciones           acciones disponibles y sus permisos
    nyx --auditoria          últimas acciones registradas
"""

from __future__ import annotations

import argparse
import sys
import urllib.request
from pathlib import Path

from . import __version__
from .config import Config, load_config
from .modules import builtin_modules
from .nyx import Memory, Nyx
from .nyx.providers import LlamaCppProvider, OllamaProvider, Provider, ProviderError
from .security import Action, AuditLog, Broker, Policy, Risk

POLICY_FILE = Path("/etc/umbra/policy.toml")

PURPLE = "\033[38;5;135m"
DIM = "\033[2m"
RESET = "\033[0m"


def _c(text: str, color: str) -> str:
    return f"{color}{text}{RESET}" if sys.stdout.isatty() else text


def ask_confirmation(action: Action, args: dict) -> bool:
    """Confirmación humana en el terminal. Nunca la puede responder el modelo."""
    level = "ALTO" if action.risk >= Risk.HIGH else "MEDIO"
    print(_c(f"\n⚠ NYX quiere ejecutar: {action.id} {args}", PURPLE))
    print(f"  {action.description}  [riesgo {level}]")
    if not sys.stdin.isatty():
        print("  Sin terminal interactivo: se cancela.")
        return False
    if action.risk >= Risk.HIGH:
        return input("  Escribe 'CONFIRMAR' para continuar: ").strip() == "CONFIRMAR"
    return input("  ¿Continuar? [s/N]: ").strip().lower() in ("s", "si", "sí", "y")


def _ollama_up(url: str) -> bool:
    try:
        with urllib.request.urlopen(url.rstrip("/") + "/api/tags", timeout=2):
            return True
    except Exception:
        return False


def make_provider(cfg: Config) -> tuple[Provider | None, str]:
    choice = cfg.nyx.provider
    from .config import safe_mode

    if safe_mode():
        return None, "modo seguro: solo motor de intenciones"
    if choice in ("cerebro", "auto"):
        from . import brain

        p = brain.provider()
        if p is not None:
            return p, f"cerebro local ({brain.MODELS[brain.DEFAULT].name})"
    model_path = Path(cfg.nyx.model_path).expanduser()
    if choice in ("llama_cpp", "auto") and model_path.is_file():
        try:
            return LlamaCppProvider(model_path), f"modelo local {model_path.name}"
        except ProviderError as exc:
            if choice == "llama_cpp":
                return None, f"sin modelo ({exc})"
    if choice in ("ollama", "auto") and _ollama_up(cfg.nyx.ollama_url):
        return OllamaProvider(cfg.nyx.model, cfg.nyx.ollama_url, cfg.nyx.timeout_seconds), f"Ollama ({cfg.nyx.model})"
    return None, "solo motor de intenciones (sin modelo)"


def build_nyx(cfg: Config, provider: Provider | None) -> Nyx:
    memory = Memory(cfg.memory_path)
    policy = Policy.from_file(POLICY_FILE) if POLICY_FILE.is_file() else Policy()
    broker = Broker(policy, AuditLog(cfg.audit_log), confirm=ask_confirmation)
    for module in builtin_modules(cfg.allowed_roots, memory, cfg.memory_path.parent / "undo"):
        broker.register(module)
    return Nyx(broker, memory, provider, context_messages=cfg.nyx.context_messages)


def _brain_command(cmd: str) -> int:
    from . import brain

    st = brain.status()
    if cmd == "estado":
        print(f"Cerebro: {st['modelo']} ({st['licencia']}), {st['tamano_gb']} GB, usa ~{st['ram_gb']} GB de RAM")
        print(f"  Descargado: {'sí' if st['instalado'] else 'no'} · Motor llama-server: {'sí' if st['motor'] else 'no'}")
        return 0
    if cmd == "borrar":
        print("Cerebro borrado." if brain.remove() else "No había cerebro descargado.")
        return 0
    print(f"Descargando {st['modelo']} ({st['tamano_gb']} GB)…")

    def progress(done: int, total: int) -> None:
        print(f"\r  {done * 100 // total:3d}%  {done / 1024**2:,.0f} de {total / 1024**2:,.0f} MB", end="", flush=True)

    try:
        path = brain.download(progress=progress)
    except (OSError, RuntimeError) as exc:
        print(f"\nNo se pudo: {exc}")
        return 1
    print(f"\nListo y verificado (SHA-256): {path}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="nyx", description="NYX, la IA central de UMBRA OS")
    parser.add_argument("orden", nargs="*", help="orden en lenguaje natural")
    parser.add_argument("--config", type=Path, help="fichero de configuración adicional")
    parser.add_argument("--sin-modelo", action="store_true", help="usar solo el motor de intenciones")
    parser.add_argument("--acciones", action="store_true", help="listar acciones y permisos")
    parser.add_argument("--auditoria", type=int, nargs="?", const=20, metavar="N", help="últimas N acciones")
    parser.add_argument("--version", action="version", version=f"UMBRA OS {__version__}")
    parser.add_argument("--cerebro", choices=["estado", "descargar", "borrar"], help="cerebro local de NYX")
    parser.add_argument("--cosmos", action="store_true", help=argparse.SUPPRESS)  # 🥚
    args = parser.parse_args(argv)

    if args.cosmos:
        from .cosmos import run

        run()
        return 0

    if args.cerebro:
        return _brain_command(args.cerebro)

    cfg = load_config(args.config)
    if args.sin_modelo:
        cfg.nyx.provider = "none"

    if args.auditoria:
        for e in AuditLog(cfg.audit_log).tail(args.auditoria):
            print(f"{e['ts']}  {e['status']:<9} {e['action']}  {e.get('args', {})}  {e.get('error') or ''}")
        return 0

    provider, label = make_provider(cfg) if cfg.nyx.provider != "none" else (None, "solo motor de intenciones (sin modelo)")
    nyx = build_nyx(cfg, provider)

    if args.acciones:
        for module in nyx.broker.modules():
            granted = nyx.broker.policy.granted(module)
            print(_c(f"{module.id} — {module.name}", PURPLE), f"({module.description})")
            for a in module.actions:
                ok = "✓" if a.permissions <= granted else "✗ sin permiso"
                perms = ", ".join(sorted(p.value for p in a.permissions))
                print(f"   {ok} {a.id}  [{perms}] riesgo={a.risk.name}")
        return 0

    if args.orden:
        print(nyx.handle(" ".join(args.orden)))
        return 0

    print(_c("NYX", PURPLE), f"· UMBRA OS {__version__} · {label}")
    print(_c("Escribe 'salir' para terminar.", DIM))
    while True:
        try:
            text = input(_c("\nTú › ", PURPLE))
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if text.strip().lower() in ("salir", "exit", "quit"):
            break
        print(_c("NYX › ", PURPLE) + nyx.handle(text))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
