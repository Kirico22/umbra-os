"""Buscador de UMBRA OS (Super + Espacio): aplicaciones, ajustes, archivos y NYX.

Ventana de cristal centrada. Flechas para moverse, Intro para abrir, Esc para cerrar.
Si eliges «Preguntar a NYX», la respuesta aparece aquí mismo, con la esfera hablando.
"""

from __future__ import annotations

import subprocess
import sys
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import theme  # noqa: E402
from .search import Result, search  # noqa: E402
from .sphere import ParticleSphere  # noqa: E402
from .widgets import SpeakingSphere, draw_sphere, wmctrl  # noqa: E402

ICONS = {"app": "application-x-executable", "ajuste": "preferences-system", "archivo": "text-x-generic",
         "carpeta": "folder", "nyx": "dialog-question"}

EXTRA_CSS = """
.search-entry { font-size: 20px; padding: 14px 16px; }
.result-title { font-size: 14px; color: #ffffff; }
.kind { font-size: 10px; letter-spacing: 1px; color: @accent_light; }
list.results { background: transparent; }
list.results row { background: transparent; padding: 0; }
.answer { font-family: "DejaVu Sans Mono", monospace; font-size: 12px; color: #f3eefc; }
"""


class SearchWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title="Buscar en UMBRA", decorated=False, resizable=False)
        self.add_css_class("glass")
        self.set_default_size(680, 520)
        self.look = theme.load()
        self.results: list[Result] = []
        self._query_id = 0
        self._nyx = None

        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        panel.add_css_class("glass-panel")
        for side in ("top", "bottom", "start", "end"):
            getattr(panel, f"set_margin_{side}")(18)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for side in ("top", "bottom", "start", "end"):
            getattr(inner, f"set_margin_{side}")(16)

        top = Gtk.Box(spacing=12)
        self.sphere = ParticleSphere(n=150)
        self.speaker = SpeakingSphere(self.sphere)
        self.speaker.enabled = self.look.voz and self.speaker.voice.available
        orb = Gtk.DrawingArea(content_width=52, content_height=52)
        orb.set_draw_func(lambda _a, cr, w, h: draw_sphere(cr, self.sphere, w / 2, h / 2, w * 0.3,
                                                           self.look.rgb(0), halo=False))
        self._last = None
        orb.add_tick_callback(self._tick)
        self.orb = orb
        self.entry = Gtk.Entry(placeholder_text="Busca aplicaciones, archivos, ajustes… o pregúntale a NYX",
                               hexpand=True)
        self.entry.add_css_class("glass-entry")
        self.entry.add_css_class("search-entry")
        self.entry.connect("changed", self._changed)
        self.entry.connect("activate", lambda _e: self._open_selected())
        top.append(orb)
        top.append(self.entry)

        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.listbox.add_css_class("results")
        self.listbox.connect("row-activated", lambda _l, row: self._open(self.results[row.get_index()]))
        scroller = Gtk.ScrolledWindow(vexpand=True)
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_child(self.listbox)

        self.answer = Gtk.Label(xalign=0, wrap=True, selectable=True)
        self.answer.add_css_class("answer")
        self.answer_rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=220)
        self.answer_rev.set_child(self.answer)

        hint = Gtk.Label(label="↑ ↓ para elegir · Intro para abrir · Esc para cerrar", xalign=0)
        hint.add_css_class("glass-dim")
        inner.append(top)
        inner.append(self.answer_rev)
        inner.append(scroller)
        inner.append(hint)
        panel.append(inner)
        self.set_child(panel)

        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._key)
        self.add_controller(keys)
        # Al perder el foco (clic fuera), el buscador se cierra
        self.connect("notify::is-active", lambda w, _p: (not w.is_active() and not self._nyx_busy()
                                                          and GLib.timeout_add(150, self._close_if_inactive)))

    def _nyx_busy(self) -> bool:
        return self.sphere.state != "reposo"

    def _close_if_inactive(self) -> bool:
        if not self.is_active():
            self.close()
        return False

    def _tick(self, _w, clock) -> bool:
        now = clock.get_frame_time() / 1e6
        dt = 1 / 60 if self._last is None else now - self._last
        self._last = now
        self.speaker.tick()
        self.sphere.update(dt)
        self.orb.queue_draw()
        return True

    # --- búsqueda (en segundo plano para no bloquear al escribir) -----------------------
    def _changed(self, entry) -> None:
        self._query_id += 1
        qid, text = self._query_id, entry.get_text()
        self.answer_rev.set_reveal_child(False)

        def work() -> None:
            time.sleep(0.12)  # espera a que dejes de teclear
            if qid != self._query_id:
                return
            res = search(text)
            GLib.idle_add(self._show, qid, res)

        threading.Thread(target=work, daemon=True).start()

    def _show(self, qid: int, results: list[Result]) -> bool:
        if qid != self._query_id:
            return False
        self.results = results
        self.listbox.remove_all()
        for r in results:
            row = Gtk.Box(spacing=12)
            row.add_css_class("glass-row")
            icon = Gtk.Image.new_from_icon_name(r.target if r.kind in ("app", "ajuste") else ICONS[r.kind])
            icon.set_pixel_size(30)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t = Gtk.Label(label=r.title, xalign=0, ellipsize=3)
            t.add_css_class("result-title")
            s = Gtk.Label(label=r.subtitle, xalign=0, ellipsize=3)
            s.add_css_class("glass-dim")
            texts.append(t)
            texts.append(s)
            kind = Gtk.Label(label=r.kind.upper(), hexpand=True, xalign=1)
            kind.add_css_class("kind")
            row.append(icon)
            row.append(texts)
            row.append(kind)
            self.listbox.append(row)
        first = self.listbox.get_row_at_index(0)
        if first:
            self.listbox.select_row(first)
        return False

    def _key(self, _c, keyval, _code, _state) -> bool:
        if keyval == Gdk.KEY_Escape:
            self.close()
            return True
        if keyval in (Gdk.KEY_Down, Gdk.KEY_Up) and self.results:
            row = self.listbox.get_selected_row()
            i = row.get_index() if row else -1
            i = min(len(self.results) - 1, i + 1) if keyval == Gdk.KEY_Down else max(0, i - 1)
            self.listbox.select_row(self.listbox.get_row_at_index(i))
            return True
        return False

    def _open_selected(self) -> None:
        row = self.listbox.get_selected_row()
        if row is not None and self.results:
            self._open(self.results[row.get_index()])

    def _open(self, r: Result) -> None:
        if r.kind == "nyx":
            self._ask_nyx(r.target)
            return
        cmd = ["gtk-launch", r.target] if r.kind in ("app", "ajuste") else ["xdg-open", r.target]
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError:
            pass
        self.close()

    def _ask_nyx(self, text: str) -> None:
        if self._nyx is None:
            from .cli import build_nyx, make_provider
            from .config import load_config

            cfg = load_config()
            provider, _ = make_provider(cfg)
            self._nyx = build_nyx(cfg, provider)
        self.speaker.thinking()
        self.answer.set_label("…")
        self.answer_rev.set_reveal_child(True)

        def work() -> None:
            try:
                reply = self._nyx.handle(text)
            except Exception as exc:
                reply = f"Ha ocurrido un error: {exc}"
            GLib.idle_add(self._answer, reply)

        threading.Thread(target=work, daemon=True).start()

    def _answer(self, reply: str) -> bool:
        self.answer.set_label(reply)
        if self._nyx.last_effect:
            self.sphere.trigger(self._nyx.last_effect)
        self.speaker.say(reply)
        return False


class SearchApp(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="os.umbra.Buscar")

    def do_activate(self) -> None:
        win = self.props.active_window
        if win:  # segunda pulsación de Super+Espacio: se cierra
            win.close()
            return
        theme.prefer_dark()
        provider = Gtk.CssProvider()
        provider.load_from_data((theme.glass_css() + EXTRA_CSS).encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        win = SearchWindow(self)
        win.present()
        win.entry.grab_focus()
        GLib.timeout_add(60, self._center, win)

    def _center(self, win) -> bool:
        """Centrado en horizontal y a un tercio de altura, como un buscador tipo Spotlight."""
        monitors = Gdk.Display.get_default().get_monitors()
        if monitors.get_n_items():
            geo = monitors.get_item(0).get_geometry()
            x = geo.x + (geo.width - 680) // 2
            y = geo.y + max(20, geo.height // 5)
            wmctrl("-r", "Buscar en UMBRA", "-e", f"0,{x},{y},-1,-1")
        return False


def main() -> int:
    GLib.set_prgname("umbra-buscar")  # clase de ventana «Umbra-buscar»: picom le pone el cristal
    return SearchApp().run(sys.argv[:1])


if __name__ == "__main__":
    raise SystemExit(main())
