"""UMBRA OS: núcleo de servicios y NYX."""

__version__ = "0.7.1"
