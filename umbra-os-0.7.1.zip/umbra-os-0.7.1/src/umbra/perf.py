"""Modo de rendimiento de UMBRA: el escritorio se adapta al equipo.

- «máximo»:      cristal con desenfoque, animaciones de ventana y átomo vivo a 30 fps.
- «equilibrado»: cristal suave, animaciones y átomo a 20 fps que se pausa si una ventana lo tapa.
- «ligero»:      sin desenfoque ni animaciones (solo fundidos) y fondo fijo. Para máquinas virtuales,
                 gráficas sin aceleración o equipos con poca memoria.
- «auto» (por defecto): UMBRA elige al iniciar sesión según el equipo.

    umbra-sesion     prepara el compositor según el modo y arranca picom (al iniciar sesión)
"""

from __future__ import annotations

import os
import re
import shutil
import sys
from pathlib import Path

PROFILES = ("auto", "maximo", "equilibrado", "ligero")
LABELS = {"auto": "Automático", "maximo": "Máximo", "equilibrado": "Equilibrado", "ligero": "Ligero"}
VIRT_RE = re.compile(r"virtualbox|vmware|qemu|kvm|bochs|hyper-v|parallels|xen|virtual machine", re.I)
VIRT_GPU = {"vboxvideo", "vmwgfx", "qxl", "bochs", "bochs-drm", "virtio_gpu", "virtio-pci", "cirrus", "hyperv_drm"}
ATOM_FPS = {"maximo": 30, "equilibrado": 20}


def _read(p: Path) -> str:
    try:
        return p.read_text(errors="replace").strip()
    except OSError:
        return ""


def detect(root: Path = Path("/")) -> dict:
    dmi = " ".join(_read(root / "sys/class/dmi/id" / f) for f in ("product_name", "sys_vendor", "board_vendor"))
    gpu_drivers = set()
    for card in (root / "sys/class/drm").glob("card[0-9]*"):
        drv = card / "device" / "driver"
        if drv.exists():
            gpu_drivers.add(drv.resolve().name)
    mem = re.search(r"MemTotal:\s+(\d+)", _read(root / "proc/meminfo"))
    ram_gb = int(mem.group(1)) / 1024 / 1024 if mem else 0.0
    return {
        "maquina_virtual": bool(VIRT_RE.search(dmi)) or bool(gpu_drivers & VIRT_GPU),
        "graficas": sorted(gpu_drivers),
        "sin_aceleracion": not gpu_drivers or bool(gpu_drivers & VIRT_GPU),
        "ram_gb": round(ram_gb, 1),
        "nucleos": os.cpu_count() or 1,
    }


def choose(info: dict) -> str:
    if info["maquina_virtual"] or info["sin_aceleracion"] or info["ram_gb"] and info["ram_gb"] < 4:
        return "ligero"
    if info["ram_gb"] and info["ram_gb"] < 8 or info["nucleos"] <= 2:
        return "equilibrado"
    return "maximo"


def profile(setting: str | None = None, info: dict | None = None) -> str:
    """Modo efectivo: el elegido en Ajustes o, en «auto», el detectado."""
    if setting is None:
        from . import theme

        setting = getattr(theme.load(), "rendimiento", "auto")
    if setting in ("maximo", "equilibrado", "ligero"):
        return setting
    return choose(info or detect())


def light_picom_config() -> str:
    """picom para el modo ligero: sin GPU, sin desenfoque, sin animaciones; solo fundidos rápidos."""
    return """# Compositor de UMBRA OS - modo ligero (máquinas virtuales y equipos modestos).
# Generado por UMBRA. Se cambia en Ajustes de UMBRA → Rendimiento.
backend = "xrender";
vsync = false;
shadow = false;
corner-radius = 0;
fading = true;
fade-in-step = 0.12;
fade-out-step = 0.14;
fade-delta = 10;
"""


def write_picom(mode: str, glass_level: str = "alto") -> Path:
    from .desktop import picom_config, user_picom_path

    path = user_picom_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    if mode == "ligero":
        text = light_picom_config()
    else:
        text = picom_config("medio" if mode == "equilibrado" and glass_level == "alto" else glass_level)
    path.write_text(text, encoding="utf-8")
    return path


def session_main(argv: list[str] | None = None) -> int:
    """Al iniciar sesión: escribe la configuración del compositor según el modo y arranca picom."""
    from . import theme
    from .config import safe_mode

    if safe_mode():
        return 0
    look = theme.load()
    mode = profile(getattr(look, "rendimiento", "auto"))
    path = write_picom(mode, look.cristal)
    print(f"UMBRA: modo de rendimiento {mode}")
    if "--sin-picom" in (argv or sys.argv[1:]) or shutil.which("picom") is None:
        return 0
    os.execvp("picom", ["picom", "--config", str(path)])
    return 0
